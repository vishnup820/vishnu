import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BsDatepickerModule, BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { AuthGuardService } from '../shared/services/auth-guard/auth-guard.service';
import { RoleGuardService } from '../shared/services/role-guard/role-guard.service';
import { SharedModule } from '../shared/shared.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ClickOutsideModule } from 'ng4-click-outside';
import { ProjectToolsComponent } from './components/project-tools/project-tools.component';
import { ProjectListingComponent } from './components/project-listing/project-listing.component';
import { AddProjectComponent } from './components/add-project/add-project.component';
import { ProjectSettingsComponent } from './components/project-settings/project-settings.component';
import { ProjectRolesComponent } from './components/masters/project-roles/project-roles.component';
import { ResourceTypeComponent } from './components/masters/resource-type/resource-type.component';
import { ProjectTypeComponent } from './components/masters/project-type/project-type.component';
import { ProjectDurationComponent } from './components/masters/project-duration/project-duration.component';
import { ResourceAllocationComponent } from './components/resource-allocation/resource-allocation.component';
import { ProjectComponent } from './components/project/project.component';
import { ProjectCalendarComponent } from './components/project-calendar/project-calendar.component';
import { ProjectDetailComponent } from './components/project-detail/project-detail.component';
@NgModule({
  declarations: [ProjectToolsComponent, ProjectListingComponent, AddProjectComponent, ProjectSettingsComponent, ProjectRolesComponent, ResourceTypeComponent, ProjectTypeComponent, ProjectDurationComponent, ResourceAllocationComponent, ProjectComponent, ProjectCalendarComponent, ProjectDetailComponent],
  imports: [
    CommonModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    ClickOutsideModule,
    BsDatepickerModule.forRoot(),
    RouterModule.forChild([
      {
        path: 'tools-list',
        canActivate: [RoleGuardService],
        component: ProjectToolsComponent,
      },
      {
        path: 'project-list',
        canActivate: [RoleGuardService],
        component: ProjectListingComponent,
      },
      {
        path: 'add-project',
        canActivate: [RoleGuardService],
        component: AddProjectComponent,
      },
      {
        path: 'add-project/:pr_id',
        canActivate: [RoleGuardService],
        component: AddProjectComponent,
      },
      {
        path: 'project-settings',
        // canActivate : [RoleGuardService],
        component: ProjectSettingsComponent,
      },
      {
        path: 'masters/project-roles',
        // canActivate : [RoleGuardService],
        component: ProjectRolesComponent,
      },
      {
        path: 'masters/resource-type',
        // canActivate : [RoleGuardService],
        component: ResourceTypeComponent,
      },
      {
        path: 'masters/project-type',
        // canActivate : [RoleGuardService],
        component: ProjectTypeComponent,
      },
      {
        path: 'masters/project-duration',
        // canActivate : [RoleGuardService],
        component: ProjectDurationComponent,
      },
      {
        path: 'resource-allocation',
        // canActivate : [RoleGuardService],
        component: ResourceAllocationComponent,
      },
      {
        path: 'resource-allocation/:pr_id',
        // canActivate : [RoleGuardService],
        component: ResourceAllocationComponent,
      },
      {
        path: 'project-calendar',
        // canActivate : [RoleGuardService],
        component: ProjectCalendarComponent,
      },
      {
        path: 'project-detail/:proj_id',
        // canActivate : [RoleGuardService],
        component: ProjectDetailComponent,
      }
    ])
  ]
})
export class ProjectModule { }
