import { Component, OnInit, ElementRef, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { ProjectToolService } from '../../service/project-tool/project-tool.service';
@Component({
  selector: 'app-project-tools',
  templateUrl: './project-tools.component.html',
  styleUrls: ['../../../../assets/content/css/user-accounts.css']
})
export class ProjectToolsComponent implements OnInit {
  @ViewChild('foc') inputEl: ElementRef;
  addTool: boolean=false;
  confirmBoxCancel: boolean=false;
  searchTextBox: boolean = false;
  toolDetailError: boolean= false;
  filterActive: boolean= false;
  showAdvanceFilter: boolean= false;
  confirmBoxDelete: boolean= false;
  editToolLoader: boolean= false;
  editbutton: boolean= false;
  filterSort: any = {};
  queryObject: any = {};
  toolData: any = [];
  categoryData: any = [];
  editToolData: any = [];
  selcatName: any;
  new_category: any;
  recordsPerPage: number = 10;
  searchD: any;
  deleteToolid: any;
  selectcatType: any;
  roleChecked: any;
  categoryStatus: any;
  totalRecords: number;
  editToolId: any;
  currentPage: number=1;
  config: any = {};
  searchKeyword: any = "";
  toolDetails: FormGroup;
  name: FormControl;
  url: FormControl;
  description: FormControl;
  constructor(private projectToolService:ProjectToolService,
    private loader:LoaderActionsService,
    private notificationService:NotificationService) { }

  ngOnInit() {
    this.config = "Are You Sure You Want To Delete?"
    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    this.currentPage = 1;
    this.queryObject.page_limit = this.recordsPerPage;
    this.queryObject.page = this.currentPage;
    this.createFormControls();
    this.createForm();
    this.toolList();
    this. toolCategorylist();
  }
  createFormControls() {
    let alpha = "^[a-zA-Z ]*$";
    let beta = "^[a-zA-Z ]+[.]*[a-zA-Z]*$";
    let contactNumber = "^[0-9+() -]*$";
    let number = "^[0-9]*$";
    let useName = "^[a-zA-Z0-9._@]+$";
    let emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$";
    let urlpattern = /(http|https|ftp):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
    this.name = new FormControl('', [Validators.required, this.noWhitespaceValidator, Validators.pattern(beta)]);
    this.url = new FormControl('', [Validators.pattern(urlpattern)]);
    this.description = new FormControl('');
  }

  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }
  toolCategorylist(){
    this.loader.display(true);
    this.projectToolService.getcategorytData(res => {
      if (res.status == "OK") {
        this.loader.display(false);
        this.categoryData = res.data;
      }
      else{
        this.loader.display(false);
        this.categoryData=[];
      }
    });
  }
  inputfocus() {
    setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
  }
  createForm() {
    this.toolDetails = new FormGroup({
      name: this.name,
      url: this.url,
      description: this.description
    });
  }
  addtoolData(){
    if (!this.toolDetails.valid || !this.categoryStatus.selected[0]) {
      this.toolDetailError = true;
    }
    else{
      this.loader.display(true);
      this.addTool=false;
      this.roleChecked = [];
      let parms : any;
      parms = {
        "tool_name":this.toolDetails.value.name,
        "tool_category_id":this.categoryStatus.selected[0].id,
        "tool_url":(this.toolDetails.value.url)? this.toolDetails.value.url: null,
        "tool_description":(this.toolDetails.value.description)? this.toolDetails.value.description: null
      }
      this.projectToolService.addTool(parms,this.editToolId,res =>{
        let self = this;
        if(res.status=="OK"){
          this.toolDetails.reset();
          this.loader.display(false);
          this.addTool=false;
          this.editbutton=false;
          this. toolCategorylist();
          this.toolList();
          setTimeout(function () {
            self.notificationService.alertBoxValue("success", res.message);
          });
        }
        else{
          //this.toolDetails.reset();
          this.loader.display(false);
          if(this.categoryStatus.selected[0]){
            for(let i=0;i<this.categoryData.length;i++){
              if(this.categoryData[i].id == this.categoryStatus.selected[0].id){
                this.roleChecked=[i];
                break;
              }
            }
          }
          this.addTool=true;
          self.notificationService.alertBoxValue("error", res.message);
        }
      });
    }
  }
  editTool(tool_id){
    if(tool_id){
      this.editbutton=true;
    }
    else
    {this.editbutton=false;}
    this.addTool=true;
    this.toolDetailError = false;
    this.editToolLoader=true;
    this.projectToolService.editToolData(tool_id,res=>{
      if(res.status== "OK"){
        this.editToolLoader=false;
        this.editToolData = res.data;
        this.toolDetails.patchValue({
          name: this.editToolData.tool_name,
          url: this.editToolData.tool_url,
          description: this.editToolData.tool_description
        });
        for(let i=0;i<this.categoryData.length;i++){
          if(this.categoryData[i].id == this.editToolData.tool_category_id){
            this.roleChecked=[i];
            break;
          }
        }
      }
      else{
        this.editToolLoader=false;
        this.editToolData = [];
      }
    });
  }
  toolList(){
    this.loader.display(true);
    this.projectToolService.gettooltData(this.queryObject,res => {
      if (res.status == "OK") {
        this.loader.display(false);
        this.currentPage = this.queryObject.page;
        this.toolData = res.data;
        this.totalRecords = res.count;
      }
      else{
        this.loader.display(false);
        this.toolData=[];
      }
    });
  }
  deleteTool(){
    this.confirmBoxDelete=false;
    this.loader.display(true);
    this.projectToolService.deleteTool(this.deleteToolid, res => {
      this.loader.display(false);
      if (res.status == "OK") {
        this.queryObject.page = 1;
        this.toolList();
        this. toolCategorylist();
        this.notificationService.alertBoxValue("success", res.message);
      }
      else {
        this.notificationService.alertBoxValue("success", res.message);
      }
    });
  }
  searchList(keyword){
    if (this.searchKeyword || this.searchD.trim() != '') {
      this.searchKeyword = keyword;
      // this.queryObject.page = 1;
      this.queryObject['page'] = 1;
      this.queryObject.keyword = this.searchKeyword ? this.searchKeyword : '';
      this.toolList();

    }
  }
  canceltoolAdd(){
    this.toolDetails.reset();
    this.roleChecked=[];
    this.addTool=false;
    this.confirmBoxCancel=false;
    this.editbutton=false;
    this.toolDetailError = false;
  }
  selectedCatName(event){
    if (event && event.selected && event.selected.length) {
      this.queryObject.catId = event.selected[0].id;
    }
    else {
      this.queryObject.catId = null;
    }
  }
  filterApply(){
    if (this.selcatName && this.selcatName.selected && this.selcatName.selected.length) {
      this.filterActive = true;
      this.showAdvanceFilter = false;
      this.queryObject.page = 1;
      // this.addTimeSheet = [];
      this.toolList();
      
    }
  }
  filterCancel(){
    if (this.selcatName && this.selcatName.selected && this.selcatName.selected.length) {
      this.queryObject['page'] = 1;
      this.filterActive = false;
      this.queryObject.catId = null;
      this.selectcatType = [];
      this.toolList();
    }
  }
  sortCategory(label) {
    let currentSortStatus = this.filterSort[label] ? this.filterSort[label].rev : true;
    this.filterSort = {};
    this.filterSort[label] = { rev: !currentSortStatus }
    this.filterSort["label"] = label;
    this.queryObject.sort = `${this.filterSort[label].rev ? '-' : ''}${label}`
    this.toolList();

  }
  showAddNew(event){
    if(event.status){
      this.new_category={"new_category" : event.value } 
      this.projectToolService.aadCategory(this.new_category,res => {
        if (res.status == "OK") {
          this.categoryData.push({id:res.catId,name:event.value})
          this.roleChecked = [this.categoryData.length - 1];
					this.notificationService.alertBoxValue("success", res.message);
				}
				else {
          this.roleChecked = [this.categoryData.length - 1];
					this.notificationService.alertBoxValue("error", res.message);
				}
      });
    }
  }
  getCustomerList(event) {
    this.currentPage = event;
    this.queryObject['page'] = this.currentPage;
    this.toolList();
  }
  getpage(event) {
    if (event > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      this.queryObject['page'] = this.currentPage
      this.queryObject['page_limit'] = this.recordsPerPage
      this.toolList();

    }
  }
}
