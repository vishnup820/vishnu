import { Component, OnInit, ElementRef, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Location } from '@angular/common'
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { ProjectAddService } from '../../service/project-add/project-add.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { ResourceAllocationService } from '../../service/resource-allocation/resource-allocation.service';
import { CookieService } from 'ngx-cookie-service';
import { filter } from 'rxjs/operators';

// declare var require: any;
// var moment = require('moment');
@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['../../../../assets/content/css/recruitment.css']
})
export class AddProjectComponent implements OnInit {
  projectStatus: any = [{ "value": "New", "name": 1 }, { "value": "In Progress", "name": 2 }, { "value": "Completed", "name": 3 }, { "value": "On Hold", "name": 4 }, { "value": "Withdrawn", "name": 5 }];
  projectDuration: any = [{ "value": "Short Term", "name": 1 }, { "value": "Long Term", "name": 2 }]
  projectType: any = [{ "value": "Confirmed", "name": 1 }, { "value": "Lead", "name": 2 }]
  childrenListPerson: any = [];
  childrenListTool: any = [];
  cusData: any = [];
  toolCat: any = [];
  tooldata: any = [];
  contactData: any = [];
  keepcontactData: any = [];
  tempObjperson: any = [];
  tempObjtool: any = [];
  childcusData: any;
  projDuration: any;
  toolNameList: any = [];
  tempObjToolData: any = [];
  editprojData: any = [];
  listDesignation: any = [];
  index1: any;
  index2: any;
  minToDate: any;
  maxDate: any;
  minDate: any;
  minActDate: any;
  checkedStatus: any;
  checkedContactPerson: any;
  // toolCatSelect: any;
  toolSelected: any;
  statusSelected: any;
  projectTypeSelected: any;
  projectManagerSelect: any;
  sowDate: any;
  toolcat: any;
  roleChecked: any;
  cusNameSelected: any;
  tenEndData: any;
  tenStartData: any;
  contactNo: any;
  emailId: any;
  projType: any;
  actStartDate: any;
  actEndDate: any;
  managerSelect: any;
  requestedOn: any;
  contactSelect: any;
  designationSelect: any;
  projectManger: any = [];
  projectMaster: any = [];
  checkedCustomerName: any;
  projectDurationSelected: any;
  currentURL: any;
  previousURL: any;
  confirmBox1: boolean = false;
  confirmBoxcancel: boolean = false;
  viewPersonal: boolean = false;
  viewCustomer: boolean = false;
  viewContact: boolean = false;
  viewTool: boolean = false;
  dojError: boolean = false;
  getCusLoader: boolean = false;
  loadTime: number = 0;
  confirmBox2: boolean = false;
  duplicateContact: boolean = false;
  toolCategory: boolean = false;
  projectDetailError: boolean = false;
  projectContactError: boolean = false;
  pageStatus: boolean = false;
  duplicateTool: boolean = false;
  getContactLoader: boolean = false;
  contactNumbervalid: boolean = false;
  contactEmailvalid: boolean = false;
  toolNameStatus: boolean = false;
  projectDetails: FormGroup;
  projectTitle: FormControl;
  projectOwner: FormControl;
  projectdec: FormControl;
  purchaseNo: FormControl;
  sowNo: FormControl;
  cusDisplayName: FormControl;
  cusContactNumber: FormControl;
  cuscontactEmail: FormControl;
  cusdes: FormControl;
  peopleList: any = [];
  OwnerSelected: any;
  checkedOwner: any;
  fullName: any;
  userId: any;
  last_name: any;
  first_name: any;
  pageStatuss: any;
  lazyLoad: boolean = false;

  @ViewChild('panel') public panel: ElementRef;

  constructor(private timeZone: TimezoneDetailsService,
    private projectAddService: ProjectAddService,
    private loaderActionsService: LoaderActionsService,
    private notificationService: NotificationService,
    private locations: Router,
    private routeActive: ActivatedRoute,
    private location: Location,
    private resourceAllocationService: ResourceAllocationService,
    private cookies: CookieService) {

  }
  public moveToSpecificView(): void {
    setTimeout(() => {
      this.panel.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'start' });
    });
  }
  ngOnInit() {
    this.routeActive.snapshot.params['pr_id'] ? this.pageStatus = false : this.pageStatus = true;
    //this.pageStatuss = parseInt(this.routeActive.snapshot.paramMap.get('details'))
    //this.routeActive.snapshot.params['1'] ? this.pageStatuss = false : this.pageStatuss = true;
    this.loaderActionsService.display(true);
    //console.log(this.pageStatuss);
    this.getCustomer();
    this.getMasters();
    this.getToolCat();
    this.getTool();
    this.createFormControls();
    this.createForm();
    this.listPeople();

    this.getProjectManager();
    this.getDesignationData()
    setTimeout(() => { this.editProjectData(); }, 3000);

    this.childrenListPerson = [{ person_id: undefined, name: undefined, checkedContactPerson: undefined, checkeddesignation: undefined, disableField: true, designation: undefined, designation_id: undefined, contactNo: undefined, emailId: undefined, nameError: false }];
    this.childrenListTool = [{ id: undefined, toolCatSelect: undefined, toolCategorySelect: undefined, toolCategory: undefined, toolCategoryId: undefined, toolName: undefined, toolCategoryError: false, toolNameError: false }];
    if (this.pageStatus) {
      for (let i = 0; i < this.projectStatus.length; i++) {
        if (this.projectStatus[i].value == 'New') {
          this.checkedStatus = [i]
          break
        }
      }
    }
    else
      this.lazyLoad = true



  }

  getMasters() {
    this.projectAddService.getMaster(res => {
      if (res.status == "OK") {
        this.projectMaster = res.data;
      }
      else {
        this.projectMaster = [];
      }
    });
  }
  getProjectManager() {
    // this.loaderActionsService.display(true);
    this.projectAddService.projectManager(res => {
      if (res.status == "OK") {
        this.projectManger = res.data;
        for (let i = 0; i < this.projectManger.length; i++) {
          this.projectManger[i]['fullName'] = this.projectManger[i].name + '' + '(' + this.projectManger[i].code + ')'
        }
        // this.loaderActionsService.display(false);
      }
      else {
        this.projectManger = [];
        // this.loaderActionsService.display(false);
      }
    });
  }
  getCustomer() {
    this.getContactLoader = true;
    this.projectAddService.getcustomertData(res => {
      if (res.status == "OK") {
        this.cusData = res.data;
        this.getContactLoader = false;
      }
      else {
        this.cusData = [];
        this.getContactLoader = false;
      }
    });
  }
  getContact() {
    this.projectAddService.getcontactData(this.cusNameSelected.selected[0].id, res => {
      if (res.status == "OK") {
        this.contactData = res.data;

        if (!this.pageStatus) {
          for (let i = 0; i < this.contactData.length; i++) {
            for (let j = 0; j < this.childrenListPerson.length; j++) {
              if (this.contactData[i].id == this.childrenListPerson[j].person_id) {
                this.childrenListPerson[j].checkedContactPerson = [i]
              }
            }
          }
        }

      }
      else {
        this.contactData = [];

      }
    });
  }

  listPeople() {
    this.resourceAllocationService.peopleAllocation(res => {
      if (res.status == "OK") {
        this.peopleList = res.data;
        this.userId = JSON.parse(this.cookies.get('user-data'));
        this.checkedOwner = [this.matchingIndex(this.peopleList, this.userId.user_id, "id")];
        //console.log(this.checkedOwner);
        //console.log(this.userId);
        for (let i = 0; i < this.peopleList.length; i++) {
          this.peopleList[i]['fullName'] = this.peopleList[i].name + '' + '(' + this.peopleList[i].code + ')'
        }

      }
      else {
        this.peopleList = [];
      }

    });
  }



  getToolCat() {
    //this.loaderActionsService.display(true);
    this.projectAddService.getToolCat(res => {
      if (res.status == "OK") {
        this.toolCat = res.data;
        //this.loaderActionsService.display(false);
      }
      else {
        this.toolCat = [];
        //this.loaderActionsService.display(false);
      }
    });
  }
  getTool() {
    this.loaderActionsService.display(true);
    this.projectAddService.getTool(res => {
      if (res.status == "OK") {

        this.tooldata = res.data;
        let self = this
        setTimeout(() => {
          self.loaderActionsService.display(false);
        }, 3000)
        setTimeout(() => {
          for (let i = 0; i < this.toolCat.length; i++) {
            this.toolCat[i]['sub_category'] = []
            for (let j = 0; j < this.tooldata.length; j++) {
              if (this.toolCat[i].id == this.tooldata[j].tool_category_id) {
                this.toolCat[i].sub_category.push({ "toolnames": this.tooldata[j]['tool_name'], "toolId": this.tooldata[j]['id'] })
              }
            }
          }
        }, 3000)
        if (!this.pageStatus) {
          setTimeout(() => {
            for (let i = 0; i < this.toolCat.length; i++) {
              for (let j = 0; j < this.childrenListTool.length; j++) {
                if (this.toolCat[i].id == this.childrenListTool[j].toolCategoryId) {
                  this.childrenListTool[j].toolCatSelect = [i];
                }
              }
            }
          }, 3000)
          setTimeout(() => {
            for (let i = 0; i < this.toolCat.length; i++) {
              for (let j = 0; j < this.toolCat[i].sub_category.length; j++) {
                for (let k = 0; k < this.childrenListTool.length; k++) {
                  if (this.toolCat[i].sub_category[j].toolId == this.childrenListTool[k].id) {
                    this.childrenListTool[k].toolCategorySelect = [j];
                  }
                }
              }
            }
          }, 3000)
        }

      }
      else {
        this.tooldata = [];
        this.loaderActionsService.display(false);
      }
    });
  }

  editProjectData() {
    if (!this.pageStatus) {
      if (localStorage.getItem('editProjectSection')) {
        let value = localStorage.getItem('editProjectSection')
        if (value === 'projectInfo') {
          this.viewPersonal = false;
          this.viewCustomer = true;
          this.viewContact = true;
          this.viewTool = true;
          setTimeout(() => {
            document.getElementById("projInfo").focus();
            document.getElementById("projInfo").scrollIntoView(true);
          }, 500);
        }
        if (value === 'customerInfo') {
          this.viewPersonal = true;
          this.viewCustomer = false;
          this.viewContact = false;
          this.viewTool = true;
          setTimeout(() => {
            document.getElementById("cusInfo").focus();
            document.getElementById("cusInfo").scrollIntoView(true);
          }, 500);
        }
        if (value === 'contactPersonInfo') {
          this.viewPersonal = true;
          this.viewCustomer = true;
          this.viewContact = false;
          this.viewTool = true;
          setTimeout(() => {
            document.getElementById("contactInfo").focus();
            document.getElementById("contactInfo").scrollIntoView(true);
          }, 500);
        }
        if (value === 'projectTool') {
          this.viewPersonal = true;
          this.viewCustomer = true;
          this.viewContact = true;
          this.viewTool = false;
          setTimeout(() => {
            document.getElementById("toolInfo").focus();
            document.getElementById("toolInfo").scrollIntoView(true);
          }, 500);
        }
      }

      this.loaderActionsService.display(true);
      this.projectAddService.editProjectData(this.routeActive.snapshot.params['pr_id'], res => {
        if (res.status == "OK") {
          this.editprojData = res.data;
          this.projectDetails.patchValue({
            projectTitle: this.editprojData.prjt_name,
            //projectOwner: this.editprojData.prjt_owner,
            projectdec: this.editprojData.prjt_desc,
            purchaseNo: this.editprojData.prjt_pon,
            sowNo: this.editprojData.prjt_sow_no,
            cusDisplayName: this.editprojData.cust_disply_name,
            cusContactNumber: this.editprojData.cust_contact,
            cuscontactEmail: this.editprojData.cust_email,
            cusdes: this.editprojData.cust_description,
          });
          this.sowDate = (this.editprojData.prjt_sow_date != "0000-00-00") ? this.timeZone.toLocal(this.editprojData.prjt_sow_date) : '';
          this.tenStartData = (this.editprojData.prjt_tent_start != "0000-00-00") ? this.timeZone.toLocal(this.editprojData.prjt_tent_start) : '',
            this.tenEndData = (this.editprojData.prjt_tent_end != "0000-00-00") ? this.timeZone.toLocal(this.editprojData.prjt_tent_end) : '';
          this.actStartDate = (this.editprojData.prjt_actual_start != "0000-00-00") ? this.timeZone.toLocal(this.editprojData.prjt_actual_start) : '';
          this.requestedOn = (this.editprojData.prjt_po_date != "0000-00-00") ? this.timeZone.toLocal(this.editprojData.prjt_po_date) : '';
          this.actEndDate = (this.editprojData.prjt_actual_end != "0000-00-00") ? this.timeZone.toLocal(this.editprojData.prjt_actual_end) : '';
          setTimeout(() => {
            /* for (let i = 0; i < this.cusData.length; i++) {
              if (this.cusData[i].id == this.editprojData.prjt_customer) {
                this.checkedCustomerName = [i];
              } */
            this.checkedCustomerName = [this.matchingIndex(this.cusData, this.editprojData.prjt_customer, "id")];
          }, 3000);

          if (this.editprojData.contact_person_details.length && !this.pageStatus) {
            this.childrenListPerson = [];
            for (let i = 0; i < this.editprojData.contact_person_details.length; i++) {
              this.childrenListPerson.push({
                person_id: this.editprojData.contact_person_details[i].cnt_id, name: this.editprojData.contact_person_details[i].name,
                checkedContactPerson: undefined, disableField: true, designation: this.editprojData.contact_person_details[i].designation_name, designation_id: this.editprojData.contact_person_details[i].designation,
                contactNo: this.editprojData.contact_person_details[i].contactNo, emailId: this.editprojData.contact_person_details[i].email, nameError: false
              });
            }
          }
          if (this.editprojData.project_tools.length && !this.pageStatus) {
            this.childrenListTool = [];
            for (let i = 0; i < this.editprojData.project_tools.length; i++) {
              this.childrenListTool.push({
                id: this.editprojData.project_tools[i].id, toolCatSelect: undefined, toolCategorySelect: undefined, toolCategory: this.editprojData.project_tools[i].catagory_name, toolCategoryId: this.editprojData.project_tools[i].catagory, toolName: this.editprojData.project_tools[i].name, toolCategoryError: false
              });
            }
          }

          /*  for (let i = 0; i < this.projectStatus.length; i++) {
             if (this.projectStatus[i].name == this.editprojData.prjt_status) {
               this.checkedStatus = [i]
             }
           }  */
          this.checkedStatus = [this.matchingIndex(this.projectStatus, this.editprojData.prjt_status, "name")];


          /* for (let i = 0; i < this.projectMaster.prjt_types.length; i++) {
            if (this.projectMaster.prjt_types[i].id == this.editprojData.prjt_type) {
              this.projType = [i]
            }
          } */
          this.projType = [this.matchingIndex(this.projectMaster.prjt_types, this.editprojData.prjt_type, "id")];

          /*   for (let i = 0; i < this.projectMaster.prjt_durations.length; i++) {
              if (this.projectMaster.prjt_durations[i].id == this.editprojData.prjt_duration) {
                this.projDuration = [i]
              }
            } */
          this.projDuration = [this.matchingIndex(this.projectMaster.prjt_durations, this.editprojData.prjt_duration, "id")];

          this.checkedOwner = [this.matchingIndex(this.peopleList, this.editprojData.prjt_owner, "id")];
          setTimeout(() => {
            /*  for (let i = 0; i < this.projectManger.length; i++) {
               if (this.projectManger[i].id == this.editprojData.prjt_manager) {
                 this.managerSelect = [i]
               }
             } */
            this.managerSelect = [this.matchingIndex(this.projectManger, this.editprojData.prjt_manager, "id")];
          }, 2000);
          let self = this;
          setTimeout(() => {
            self.loaderActionsService.display(false);
          }, 3000);
        }
      });
    }
  }
  formatForApi3(inputDate) {
    var date = this.timeZone.toLocal(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return "0" + date.getDate() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
          }
          else {
            return date.getDate() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return "0" + date.getDate() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
          }
          else {
            return date.getDate() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
          }
        }
      }
      else
        return undefined;
  }
  createFormControls() {
    let alpha = "^[a-zA-Z ]*$";
    let beta = "^[a-zA-Z ]+[.]*[a-zA-Z]*$";
    let contactNumber = "^[0-9+() -]*$";
    let number = "^[0-9]*$";
    let useName = "^[a-zA-Z0-9._@]+$";
    let emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$";
    this.projectTitle = new FormControl('', [Validators.required, this.noWhitespaceValidator]);
    //this.projectOwner = new FormControl('', [Validators.required]);
    this.projectdec = new FormControl('');
    this.purchaseNo = new FormControl('', [Validators.pattern(useName)]);
    this.sowNo = new FormControl('', [Validators.pattern(useName)]);
    this.cusDisplayName = new FormControl('');
    this.cusContactNumber = new FormControl('', [Validators.pattern(contactNumber)]);
    this.cuscontactEmail = new FormControl('', [Validators.pattern(emailPattern)]);
    this.cusdes = new FormControl('');

  }
  createForm() {
    this.projectDetails = new FormGroup({
      projectTitle: this.projectTitle,
      //projectOwner: this.projectOwner,
      projectdec: this.projectdec,
      purchaseNo: this.purchaseNo,
      sowNo: this.sowNo,
      cusDisplayName: this.cusDisplayName,
      cusContactNumber: this.cusContactNumber,
      cuscontactEmail: this.cuscontactEmail,
      cusdes: this.cusdes

    });
  }
  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }
  submitProject() {
    if (!this.projectDetails.valid || !this.statusSelected.selected[0] || !this.OwnerSelected.selected[0] || !this.projectTypeSelected.selected[0] || !this.projectDurationSelected.selected[0] || !this.cusNameSelected.selected[0] || !this.contactSelect.selected[0] || this.contactNumbervalid || this.contactEmailvalid || this.toolNameStatus) {
      //|| !this.tenStartData || !this.tenEndData
      this.projectDetailError = true;
      this.projectContactError = true;
      setTimeout(() => {
        const error = document.querySelector('.error');
        if (error) {
          // this.loaderActionsService.display(false);
          this.scrollTop(error);
        }
        return;
      })
    }
    else {
      this.loaderActionsService.display(true);
      for (let i = 0; i < this.childrenListTool.length; i++) {

        this.tempObjtool.push({
          "id": this.childrenListTool[i].id,
          "category": this.childrenListTool[i].toolCategoryId,
          "name": this.childrenListTool[i].toolName
        });
      }
      for (let j = 0; j < this.childrenListPerson.length; j++) {
        this.tempObjperson.push({
          "name": this.childrenListPerson[j].name,
          // "designation": this.childrenListPerson[i].designation,
          "designation": this.childrenListPerson[j].designation_id,
          "email": this.childrenListPerson[j].emailId,
          "contact": this.childrenListPerson[j].contactNo
        });
      }
      let arrObj = {
        "prjt_name": this.projectDetails.value.projectTitle,
        //"prjt_owner": this.projectDetails.value.projectOwner,
        "prjt_owner": this.OwnerSelected.selected[0].id,
        "prjt_type": this.projectTypeSelected.selected[0].id,
        "prjt_status": this.statusSelected.selected[0].name,
        "prjt_duration": this.projectDurationSelected.selected[0].id,
        "prjt_desc": (this.projectDetails.value.projectdec) ? this.projectDetails.value.projectdec : null,
        "prjt_pon": (this.projectDetails.value.purchaseNo) ? this.projectDetails.value.purchaseNo : null,
        "prjt_po_date": (this.requestedOn) ? this.formatForApi2(this.requestedOn) : null,
        "prjt_sow_no": (this.projectDetails.value.sowNo) ? this.projectDetails.value.sowNo : null,
        "prjt_sow_date": (this.sowDate) ? this.formatForApi2(this.sowDate) : null,
        "prjt_tent_end": (this.tenEndData) ? this.formatForApi2(this.tenEndData) : null,
        "prjt_tent_start": (this.tenStartData) ? this.formatForApi2(this.tenStartData) : null,
        "prjt_actual_start": (this.actStartDate) ? this.formatForApi2(this.actStartDate) : null,
        "prjt_actual_end": (this.actEndDate) ? this.formatForApi2(this.actEndDate) : null,
        "cust_name": (this.cusNameSelected.selected[0]) ? this.cusNameSelected.selected[0].cust_name : null,
        "cust_id": (this.cusNameSelected.selected[0]) ? this.cusNameSelected.selected[0].id : null,
        "cust_display_name": (this.projectDetails.value.cusDisplayName) ? this.projectDetails.value.cusDisplayName : null,
        "cust_email": (this.projectDetails.value.cuscontactEmail) ? this.projectDetails.value.cuscontactEmail : null,
        "cust_contact": (this.projectDetails.value.cusContactNumber) ? this.projectDetails.value.cusContactNumber : null,
        "cust_desc": (this.projectDetails.value.cusdes) ? this.projectDetails.value.cusdes : null,
        "prjt_manager": (this.projectManagerSelect.selected[0]) ? this.projectManagerSelect.selected[0].id : null,
        "contact_person_details": this.tempObjperson,
        "project_tools": this.tempObjtool
      }
      // console.log(arrObj)
      this.projectAddService.addProjectData(arrObj, this.routeActive.snapshot.params['pr_id'], res => {
        if (res.status == "OK") {
          let self = this;
          this.loaderActionsService.display(false);
          //this.location.back();
          setTimeout(function () {
            self.notificationService.alertBoxValue("success", res.message);
          }, 500);

          if (localStorage.getItem("editProjectSection") === null) {
            this.locations.navigate(['/modules/projects/project-list']);
          }
          if (localStorage.getItem('editProjectSection')) {
            let value = localStorage.getItem('editProjectSection')
            if (value == 'projectInfo' || 'customerInfo' || 'contactPersonInfo' || 'projectTool') {
              this.locations.navigate(['/modules/projects/project-detail/' + this.routeActive.snapshot.params['pr_id']])
            }
          }

        }
        else {
          this.loaderActionsService.display(false);
          this.tempObjtool = [];
          this.tempObjperson = [];
          this.notificationService.alertBoxValue("error", res.message);
        }
      });
    }
  }
  cusNameData(event) {
    if (event.selected[0]) {
      if (!this.pageStatus) {
        if (this.editprojData.prjt_customer != this.cusNameSelected.selected[0].id) {
          this.childrenListPerson = [{ person_id: undefined, name: undefined, checkedContactPerson: undefined, checkeddesignation: undefined, disableField: true, designation: undefined, designation_id: undefined, contactNo: undefined, emailId: undefined, nameError: false }];
        }
      }
      this.projectDetails.patchValue({
        cusDisplayName: event.selected[0].cust_disply_name,
        cusContactNumber: event.selected[0].cust_contact,
        cuscontactEmail: event.selected[0].cust_email,
        cusdes: event.selected[0].cust_description
      });
      this.getCusLoader = true;
      this.projectAddService.getcontactData(this.cusNameSelected.selected[0].id, res => {
        if (res.status == "OK") {
          this.contactData = res.data;
          if (!this.pageStatus) {
            for (let i = 0; i < this.contactData.length; i++) {
              for (let j = 0; j < this.childrenListPerson.length; j++) {
                if (this.contactData[i].id == this.childrenListPerson[j].person_id) {
                  this.childrenListPerson[j].checkedContactPerson = [i]
                }
              }
            }
          }
          this.getCusLoader = false;
          this.lazyLoad = false
        }
        else {
          this.contactData = [];
          this.getCusLoader = false;
          this.lazyLoad = false
        }
      });

    }
  }
  contactPersonSelect(event, i) {
    if (event.selected[0]) {

      if (event.selected[0].id) {
        this.childrenListPerson[i].disableField = true;
      }
      else {
        this.childrenListPerson[i].disableField = false;
      }
      if (!event.selected[0].cnct_prsn_designation) {
        this.childrenListPerson[i].checkeddesignation = [];
      }
      for (let j = 0; j < this.listDesignation.length; j++) {
        if (this.listDesignation[j].id == event.selected[0].cnct_prsn_designation) {
          this.childrenListPerson[i].checkeddesignation = [j];
          break;
        }
        else {
          this.childrenListPerson[i].checkeddesignation = [];
        }
      }


      //this.childrenListPerson[i].person_id = (event.selected[0]) ? event.selected[0].id : null;

      // if (this.childrenListPerson.length > 1) {
      //   for (let k = 0; k <= this.childrenListPerson.length; k++) {
      //     if (this.childrenListPerson && this.childrenListPerson[k] && this.childrenListPerson[k].person_id && (this.childrenListPerson[k].person_id == event.selected[0].id)) {
      //       this.duplicateContact = true;
      //       this.notificationService.alertBoxValue("error", "Duplicate Contact Person Found");
      //       break;
      //     }
      //     else {
      //       this.duplicateContact = false;
      //     }
      //   }
      // }

      this.childrenListPerson[i].person_id = (event.selected[0]) ? event.selected[0].id : null;
      this.childrenListPerson[i].name = (event.selected[0]) ? event.selected[0].cnct_prsn_name : null;
      this.childrenListPerson[i].designation = (event.selected[0]) ? event.selected[0].cust_designation_name : null;
      this.childrenListPerson[i].designation_id = (event.selected[0]) ? event.selected[0].cnct_prsn_designation : null;
      this.childrenListPerson[i].contactNo = (event.selected[0]) ? event.selected[0].cnct_prsn_contact : null;
      this.childrenListPerson[i].emailId = (event.selected[0]) ? event.selected[0].cnct_prsn_email : null;

      if (this.childrenListPerson.length > 1) {

        for (var k = 0; k <= this.childrenListPerson.length; k++) {


          for (var j = 0; j < this.childrenListPerson.length; j++) {

            if (k != j) {
              if ((this.childrenListPerson && this.childrenListPerson[k] && this.childrenListPerson[k].person_id && (this.childrenListPerson[k].person_id == this.childrenListPerson[j].person_id)) || (this.childrenListPerson && this.childrenListPerson[k] && this.childrenListPerson[k].name && (this.childrenListPerson[k].name == this.childrenListPerson[j].name))) {
                this.duplicateTool = true;
                this.childrenListPerson[i].checkedContactPerson = [];
                this.childrenListPerson[i].name = '';
                this.childrenListPerson[i].designation = '';
                this.childrenListPerson[i].designation_id = '';
                this.childrenListPerson[i].contactNo = '';
                this.childrenListPerson[i].emailId = '';
                this.notificationService.alertBoxValue("error", "Duplicate Contact Person Found");
                break;
              }
              else {
                this.duplicateTool = false;
              }
            }
          }

        }

      }
    }
    //  for (let k = 0; k <= this.childrenListPerson.length; k++) {
    //   if(this.childrenListPerson && this.childrenListPerson[k] && this.childrenListPerson[k].checkedContactPerson && (this.childrenListPerson[k].checkedContactPerson = undefined && this.childrenListPerson[k].checkedContactPerson.length==0)){
    //     this.childrenListPerson[k].person_id = undefined;
    //     this.childrenListPerson[k].name = undefined
    //   }
    // }
    // this.childrenListPerson[i].person_id = undefined;
    // this.childrenListPerson[i].name = undefined;
    // this.childrenListPerson[i].designation = undefined;
    // this.childrenListPerson[i].designation_id = undefined;
    // this.childrenListPerson[i].contactNo = undefined;
    // this.childrenListPerson[i].emailId = undefined;

  }
  toolCatSelected(event, i) {
    if (event.selected[0]) {
      if (event.selected[0].name) {
        this.toolNameStatus = true;
      } else {
        this.toolNameStatus = false;
      }
      this.childrenListTool[i].toolCategoryId = (event.selected[0]) ? event.selected[0].id : null;
      this.childrenListTool[i].toolCategory = (event.selected[0]) ? event.selected[0] : null;
      //this.childrenListTool[i].toolName = event.selected[0].name;
      this.childrenListTool[i].toolNameError = this.toolNameStatus;
      this.toolNameList = event.selected[0].sub_category;


    }

  }
  toolnameSelecte(event, i) {
    if (event.selected[0]) {
      if (event.selected[0].toolnames) {
        this.toolNameStatus = false;
      } else {
        this.toolNameStatus = true;
      }
      this.childrenListTool[i].id = (event.selected[0]) ? event.selected[0].toolId : null;
      this.childrenListTool[i].toolName = (event.selected[0]) ? event.selected[0].toolnames : null;
      this.childrenListTool[i].toolNameError = this.toolNameStatus;
      if (this.childrenListTool.length > 1) {

        for (var k = 0; k <= this.childrenListTool.length; k++) {


          for (var j = 0; j < this.childrenListTool.length; j++) {

            if (k != j) {
              if ((this.childrenListTool && this.childrenListTool[k] && this.childrenListTool[k].toolCategoryId && (this.childrenListTool[k].toolCategoryId == this.childrenListTool[j].toolCategoryId))
                && (this.childrenListTool && this.childrenListTool[k] && this.childrenListTool[k].id && (this.childrenListTool[k].id == this.childrenListTool[j].id))) {
                this.duplicateTool = true;
                //this.childrenListTool[i].toolCatSelect = [];
                this.toolNameStatus = true;
                this.childrenListTool[i].toolCategorySelect = [];
                this.childrenListTool[i].toolName = undefined
                this.childrenListTool[i].toolNameError = this.toolNameStatus;
                this.notificationService.alertBoxValue("error", "Duplicate Tool Found");
                break;
              }
              else {
                this.duplicateTool = false;
              }
            }
          }

        }

      }
    }
  }
  scrollTop(el: Element) {
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      const input: any = el.querySelector('.form-control');
      if (input) {
        input.focus();
      }
      const firstChild = el.firstChild;
      if (input === firstChild) {
        input.focus();
      }
    }
  }
  checkChildrenWork(i) {
    if (this.childrenListPerson) {
      if (!this.childrenListPerson[i].name) {
        this.childrenListPerson[i].nameError = true;
      }
      else {
        this.childrenListPerson[i].nameError = false;
      }
    }
  }
  addNewPerson() {
    this.moveToSpecificView()
    let stat;
    this.checkChildrenWork(this.childrenListPerson.length - 1);
    for (let i = 0; i < this.childrenListPerson.length; i++) {

      if (!this.childrenListPerson[i].nameError) {
        stat = true;
        this.projectContactError = false;
      }
      else {
        stat = false;

        break;
      }
    }
    if (stat) {
      this.childrenListPerson.push({
        person_id: undefined, name: undefined, checkedContactPerson: undefined, checkeddesignation: undefined, disableField: true, designation: undefined, designation_id: undefined, contactNo: undefined, emailId: undefined, nameError: false
      });
    }
  }
  openConfirmBoxone(childData, i) {

    this.index1 = i;
    this.childcusData = childData;
    this.confirmBox1 = true
    this.contactData
  }
  confirmPopup1(ev) {
    if (ev) {


      this.childrenListPerson.splice(this.index1, 1);
      this.tempObjperson.splice(this.index1, 1);
      this.confirmBox1 = false;

    } else {
      this.confirmBox1 = false;
    }

  }
  checkChildrenTool(i) {
    if (this.childrenListTool) {
      if (!this.childrenListTool[i].toolCategory) {
        this.childrenListTool[i].toolCategoryError = true;
      }
      else {
        this.childrenListTool[i].toolCategoryError = false;
      }
    }
  }
  addTool() {
    let statTool;
    this.checkChildrenTool(this.childrenListTool.length - 1);
    for (let i = 0; i < this.childrenListTool.length; i++) {
      if (!this.childrenListTool[i].toolCategoryError) {
        statTool = true;
      }
      else {
        statTool = false;
        break;
      }
    }
    if (statTool && !this.toolNameStatus) {
      this.childrenListTool.push({
        id: undefined, toolCatSelect: undefined, toolCategorySelect: undefined, toolCategory: undefined, toolCategoryId: undefined, toolName: undefined, toolCategoryError: false, toolNameError: false
      });
    }

    setTimeout(() => {
      const error = document.querySelector('.borderTop');
      if (error) {
        // this.loaderActionsService.display(false);
        this.scrollTop(error);
      }
      return;
    })
    // setTimeout(() => {
    //   debugger
    //   let index :any;
    //  index = 'yy'+ (this.childrenListTool.length - 1);
    //  console.log(index)
    //   document.getElementById("index").focus();
    //   document.getElementById("index").scrollIntoView(true);
    // }, 500);
  }
  openConfirmBoxtwo(i) {
    this.index2 = i;
    this.confirmBox2 = true
  }
  confirmPopup2(ev) {
    if (ev) {
      this.toolNameStatus = false;
      this.childrenListTool[this.index2].toolNameError = this.toolNameStatus;
      this.childrenListTool.splice(this.index2, 1);
      this.tempObjtool.splice(this.index2, 1);
      this.confirmBox2 = false;
    } else
      this.confirmBox2 = false;
  }
  formatForApi2(inputDate) {
    var date = this.timeZone.toLocal(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
      }
      else
        return undefined;
  }
  cancelConfirmPopup() {
    window.history.back();
  }
  designationPersonSelect(event, i) {
    this.childrenListPerson[i].designation = (event.selected[0]) ? event.selected[0].name : null;
    this.childrenListPerson[i].designation_id = (event.selected[0]) ? event.selected[0].id : null;
  }
  showAddNew(event, i) {
    if (event.status) {
      this.childrenListPerson[i].disableField = false;
      let count = this.contactData.length
      // this.new_category={"new_category" : event.value } 
      this.contactData.push({ cnct_prsn_name: event.value })
      this.childrenListPerson[i].checkedContactPerson = [count];
      this.childrenListPerson[i].name = (event.value) ? event.value : null;
      this.childrenListPerson[i].contactNo = (this.contactNo) ? this.contactNo : null;
      this.childrenListPerson[i].emailId = (this.emailId) ? this.emailId : null;

    }
  }
  getDesignationData() {
    // this.loaderActionsService.display(true);
    this.projectAddService.designationList(res => {
      if (res.status == "OK") {
        // this.loaderActionsService.display(false);
        this.listDesignation = res.data;

      }
      else {
        this.listDesignation = [];
        // this.loaderActionsService.display(false);
      }
    });
  }
  checkFromDay(event) {
    this.minToDate = event;
  }
  checkActDay(event) {
    this.minActDate = event;
  }
  contactNumberChange(ev) {
    this.contactNumbervalid = ev;
  }
  contactEmailChange(ev) {
    this.contactEmailvalid = ev;
  }

  matchingIndex(srcArray, compareValue, key) {
    for (var x in srcArray) {
      if (srcArray[x][key] == compareValue) {
        return x;
      }
    }
    return null;
  }
}
