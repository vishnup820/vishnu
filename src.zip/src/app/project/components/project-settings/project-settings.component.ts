import { Component, OnInit, ElementRef, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { ProjectSettingsService } from '../../service/project-settings.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
@Component({
  selector: 'app-project-settings',
  templateUrl: './project-settings.component.html',
  styleUrls: ['../../../../assets/content/css/shift-general-settings.css']
})
export class ProjectSettingsComponent implements OnInit {
  settingsData: any = [];
  generalbreak_time: boolean = false;
  weekbreak_time: boolean = false;
  monthbreak_time: boolean = false;
  settingsDetailError: boolean = false;
  showWarning: boolean = false;
  settingError: boolean = false;
  confirmBoxcancel3: boolean = false;
  confirmBoxcancel2: boolean = false;
  confirmBoxcancel4: boolean = false;
  confirmBoxcancel5: boolean = false;
  hourPerDaySelectData: boolean = false;
  warningShow: any;
  hoursPerDay: any;
  hoursPerWeek: any;
  hoursPerMonth: any;
  inHourSplice: number;
  selectPercentage: any;
  hourPerDaySelect: any;
  resourceOver: any;
  hourSelect: any;
  resourceAllocationData: any;
  percentageSelect: any;
  allocationSelect: any;
  label: any
  statusResource: any;
  statusWarning: any;
  currentHoursPerDay: any;
  warningLabel: any;
  message: any;
  resourceORwarning: any;
  saveORcancel: any;
  svecnclMessge: any;
  resourceAllocation: any = [{ "value": "Hours Per Day (HRS/D)", "id": 1 }, { "value": "Percentage", "nidame": 2 }];
  Percentage: any = [{ "value": 100, "id": 1 }, { "value": 75, "id": 2 }, { "value": 50, "id": 3 }, { "value": 25, "id": 4 }];
  inHour: any = [{ "value": "01", "id": 1 }, { "value": "02", "id": 2 }, { "value": "03", "id": 3 }, { "value": "04", "id": 4 }
    , { "value": "05", "id": 5 }, { "value": "06", "id": 6 }, { "value": "07", "id": 7 }, { "value": "08", "id": 8 }
    , { "value": "09", "id": 9 }, { "value": "10", "id": 10 }, { "value": "11", "id": 11 }, { "value": "12", "id": 12 }, { "value": "13", "id": 13 }
    , { "value": "14", "id": 14 }, { "value": "15", "id": 15 }, { "value": "16", "id": 16 }, { "value": "17", "id": 17 }, { "value": "18", "id": 18 }
    , { "value": "19", "id": 19 }, { "value": "20", "id": 20 }, { "value": "21", "id": 21 }, { "value": "22", "id": 22 }, { "value": "23", "id": 23 }, { "value": "24", "id": 24 }];
  allocation: any = [{ "label": "show", "id": 1, "status": true },
  { "label": "Do not show", "id": 2, "status": false }]
  resourceAllocationRadio: any = [{ "label": "allow", "id": 1, "status": true },
  { "label": "Do Not Allow", "id": 2, "status": false }]
  editProjSettings: boolean = false;


  inHourr: any = [{ "value": "01", "id": 1 }, { "value": "02", "id": 2 }, { "value": "03", "id": 3 }, { "value": "04", "id": 4 }
    , { "value": "05", "id": 5 }, { "value": "06", "id": 6 }, { "value": "07", "id": 7 }, { "value": "08", "id": 8 }
    , { "value": "09", "id": 9 }, { "value": "10", "id": 10 }, { "value": "11", "id": 11 }, { "value": "12", "id": 12 }, { "value": "13", "id": 13 }
    , { "value": "14", "id": 14 }, { "value": "15", "id": 15 }, { "value": "16", "id": 16 }, { "value": "17", "id": 17 }, { "value": "18", "id": 18 }
    , { "value": "19", "id": 19 }, { "value": "20", "id": 20 }, { "value": "21", "id": 21 }, { "value": "22", "id": 22 }, { "value": "23", "id": 23 }, { "value": "24", "id": 24 }];


  constructor(private projectSettingsService: ProjectSettingsService,
    private loaderActionsService: LoaderActionsService,
    private notificationService: NotificationService,
    private locations: Router,) { }

  ngOnInit() {
    this.getSettingsData();
  }
  getSettingsData() {

    this.loaderActionsService.display(true);
    this.projectSettingsService.getSettings(res => {
      if (res.status == "OK") {
        this.settingsData = res.data;
        this.currentHoursPerDay = res.data.hours_per_day;
        this.loaderActionsService.display(false);
        if (this.settingsData.allow_resource_over_allocation == "allow") {
          this.showWarning = true;
        } else {
          this.showWarning = false;
        }
        for (let i = 0; i < this.allocation.length; i++) {
          this.allocation[i].status = false;
          if (this.allocation[i].label == this.settingsData.show_warning_on_over_allocation) {
            setTimeout(() => {
              // this.allocation[i].status = true;
              this.statusWarning = this.allocation[i].label;
              this.warningShow = this.settingsData.show_warning_on_over_allocation;
            });
          }
        }
        for (let i = 0; i < this.resourceAllocationRadio.length; i++) {
          this.resourceAllocationRadio[i].status = false;
          if (this.resourceAllocationRadio[i].label == this.settingsData.allow_resource_over_allocation) {
            setTimeout(() => {
              //this.resourceAllocationRadio[i].status = true;
              //this.statusSelected=true;
              this.statusResource = this.resourceAllocationRadio[i].label;

              this.resourceOver = this.settingsData.allow_resource_over_allocation;
            });
          }

        }
        this.inHour = [{ "value": "01", "id": 1 }, { "value": "02", "id": 2 }, { "value": "03", "id": 3 }, { "value": "04", "id": 4 }
          , { "value": "05", "id": 5 }, { "value": "06", "id": 6 }, { "value": "07", "id": 7 }, { "value": "08", "id": 8 }
          , { "value": "09", "id": 9 }, { "value": "10", "id": 10 }, { "value": "11", "id": 11 }, { "value": "12", "id": 12 }, { "value": "13", "id": 13 }
          , { "value": "14", "id": 14 }, { "value": "15", "id": 15 }, { "value": "16", "id": 16 }, { "value": "17", "id": 17 }, { "value": "18", "id": 18 }
          , { "value": "19", "id": 19 }, { "value": "20", "id": 20 }, { "value": "21", "id": 21 }, { "value": "22", "id": 22 }, { "value": "23", "id": 23 }, { "value": "24", "id": 24 }];
        this.hoursPerDay = this.settingsData.hours_per_day;
        this.hoursPerWeek = this.settingsData.hours_per_week;
        this.hoursPerMonth = this.settingsData.day_per_month;
        this.inHourSplice = Number(this.hoursPerDay)
        this.inHour.splice(0, this.inHourSplice - 1);
        // this.hourSelect=this.settingsData.max_allocation_in_hours;
        // this.percentageSelect=this.settingsData.max_allocation_in_hours;
        // this.allocationSelect=this.settingsData.resource_allocation_unit;
        if (this.settingsData.max_allocation_in_hours == "") {
          //this.hourSelect='';
          for (let i = 0; i < this.inHour.length; i++) {

            if (this.inHour[i].id == Number(this.hoursPerDay)) {
              this.hourSelect = [i]
            }
          }
        }

        for (let i = 0; i < this.inHour.length; i++) {
          if (this.inHour[i].value == this.settingsData.max_allocation_in_hours) {
            this.hourSelect = [i]

          }
        }

        for (let i = 0; i < this.Percentage.length; i++) {
          if (this.Percentage[i].value == this.settingsData.max_allocation_in_percentage) {
            this.percentageSelect = [i]
          }
        }
        for (let i = 0; i < this.resourceAllocation.length; i++) {
          if (this.resourceAllocation[i].value == this.settingsData.resource_allocation_unit) {
            this.allocationSelect = [i]
          }
        }
      }
      else {
        this.settingsData = [];
        this.loaderActionsService.display(false);
      }
    });

  }
  hoursPerDayTimeChange(val) {
    if (val > 24 || val < 0) {
      this.hoursPerDay = null;
    }
    if (val == '' || val == null) {
      this.generalbreak_time = true;
    } else {
      this.generalbreak_time = false;
      this.inHour = [];

      this.inHour = [{ "value": "01", "id": 1 }, { "value": "02", "id": 2 }, { "value": "03", "id": 3 }, { "value": "04", "id": 4 }
        , { "value": "05", "id": 5 }, { "value": "06", "id": 6 }, { "value": "07", "id": 7 }, { "value": "08", "id": 8 }
        , { "value": "09", "id": 9 }, { "value": "10", "id": 10 }, { "value": "11", "id": 11 }, { "value": "12", "id": 12 }, { "value": "13", "id": 13 }
        , { "value": "14", "id": 14 }, { "value": "15", "id": 15 }, { "value": "16", "id": 16 }, { "value": "17", "id": 17 }, { "value": "18", "id": 18 }
        , { "value": "19", "id": 19 }, { "value": "20", "id": 20 }, { "value": "21", "id": 21 }, { "value": "22", "id": 22 }, { "value": "23", "id": 23 }, { "value": "24", "id": 24 }];
      this.inHourSplice = Number(this.hoursPerDay)
      this.inHour.splice(0, this.inHourSplice - 1);
      this.hourSelect = "";
    }

    if (this.showWarning && !this.hourPerDaySelect.selected[0]) {
      this.settingError = true;
    }
    else {
      this.settingError = false;
    }
  }
  hoursPerWeekTimeChange(val) {
    if (val > 168 || val < 0) {
      this.hoursPerWeek = null;
    }
    if (val == '' || val == null) {
      this.weekbreak_time = true;
    } else {
      this.weekbreak_time = false;
    }

  }
  hoursPerMonthTimeChange(val) {
    if (val > 31 || val < 0) {
      this.hoursPerMonth = null;
    }
    if (val == '' || val == null) {
      this.monthbreak_time = true;
    } else {
      this.monthbreak_time = false;
    }
  }

  warningConfirmRadio(label, i) {
    this.resourceORwarning = "warning";
    if (label == "show") {
      //this.confirmBoxcancel5 = true;
      this.confirmBoxcancel3 = true;
      this.message = "Are you sure you want the system to show warning on over-allocation above specified limit?"
      this.warningLabel = label;
    } else {
      this.warningAllocation(label, i);
      this.confirmBoxcancel3 = false;
    }
  }

  showConfirmRadio(label, i) {
    this.resourceORwarning = "resource";
    if (label == "Do Not Allow") {
      this.confirmBoxcancel3 = true;
      this.message = "Are you sure you want the system to restrict over allocation of resource in projects?"
      this.label = label;
    } else {

      this.statusWarning = this.allocation[0].label;
      this.resourceOverAllocation(label, 'i');
      this.confirmBoxcancel3 = false;
    }
  }

  /*  confirmWarningRadio() {
     this.warningAllocation(this.warningLabel, 'i')
   } */
  /*  cancelWarningRadio() {
     this.confirmBoxcancel5 = false;
     this.warningLabel = '';
     this.statusWarning = this.allocation[1].label;
   } */

  confirmRadio() {
    if (this.resourceORwarning == "resource") {
      this.resourceOverAllocation(this.label, 'i')
    }
    else if (this.resourceORwarning == "warning") {
      this.warningAllocation(this.warningLabel, 'i')
    }
    this.confirmBoxcancel3 = false;
  }

  cancelRadio() {
    if (this.resourceORwarning == "resource") {
      this.confirmBoxcancel3 = false;
      this.label = '';
      this.statusResource = this.resourceAllocationRadio[0].label;
    }
    else if (this.resourceORwarning == "warning") {
      this.confirmBoxcancel3 = false;
      this.warningLabel = '';
      this.statusWarning = this.allocation[1].label;
    }

  }

  warningAllocation(label, i) {
    this.warningShow = label;
  }

  resourceOverAllocation(label, i) {
    if (label == "allow") {
      this.showWarning = true;
    }
    else {
      this.showWarning = false;
    }
    this.resourceOver = label;
    this.warningShow = "show";
    for (let i = 0; i < this.allocation.length; i++) {
      this.allocation[i].status = false;
      if (this.allocation[i].label == this.warningShow) {
        setTimeout(() => {
          this.allocation[i].status = true;
          this.warningShow = this.warningShow;
        });
      }
    }
    this.label = '';
  }
  editProjectSettings() {

    this.editProjSettings = !this.editProjSettings
  }
  confirmSave() {
    //debugger
    if (this.showWarning && !this.hourPerDaySelect.selected[0]) {
      this.settingError = true;
      //alert("kkk")
    }
    else if (this.hoursPerDay < this.currentHoursPerDay) {
      this.confirmBoxcancel4 = true;
      this.saveORcancel = "save";
      this.svecnclMessge = "Are you sure you want to reduce the hours per day. This might impact the existing resource allocation?"
    }
    else if (this.hoursPerDay < this.currentHoursPerDay && this.hourPerDaySelect.selected[0]) {
      this.confirmBoxcancel4 = true;
      this.saveORcancel = "save";
      this.svecnclMessge = "Are you sure you want to reduce the hours per day. This might impact the existing resource allocation?"
    }
    
    else {
      this.save();
      this.settingError = false;
    }
  }
  save() {

    if (this.showWarning && !this.hourPerDaySelect.selected[0]) {
      this.settingError = true;
    }
    else {
      this.settingError = false;
    }
    if (this.showWarning && this.hourPerDaySelect.selected[0]) {
      this.hourPerDaySelectData = true;
    } else {
      this.hourPerDaySelectData = true;
    }
    if (!this.generalbreak_time && !this.weekbreak_time && !this.monthbreak_time && this.hourPerDaySelectData && !this.settingError) {
      this.loaderActionsService.display(true);
      if (!this.showWarning) {
        this.hourPerDaySelect = null;
        this.warningShow = "Do not show";
      }
      this.inHour = [];
      let params;
      params = {
        "hours_per_day": (this.hoursPerDay) ? this.hoursPerDay : null,
        "hours_per_week": (this.hoursPerWeek) ? this.hoursPerWeek : null,
        "day_per_month": (this.hoursPerMonth) ? this.hoursPerMonth : null,
        "resource_allocation_unit": (this.resourceAllocationData.selected[0]) ? this.resourceAllocationData.selected[0].value : null,
        "allow_resource_over_allocation": (this.resourceOver) ? this.resourceOver : null,
        "show_warning_on_over_allocation": (this.warningShow) ? this.warningShow : null,
        "max_allocation_in_percentage": null,
        "max_allocation_in_hours": (this.hourPerDaySelect) ? this.hourPerDaySelect.selected[0].value : null
      }
      this.projectSettingsService.addSettings(params, res => {
        if (res.status == "OK") {
          this.loaderActionsService.display(false);
          this.getSettingsData();
          this.notificationService.alertBoxValue("success", res.message);
          this.editProjSettings = false;
        }
        else {
          this.loaderActionsService.display(false);
          this.notificationService.alertBoxValue("error", res.message);
          this.editProjSettings = true;
        }
      });
    }
    else {
      this.settingsDetailError = true;
      this.settingError = true;
      this.loaderActionsService.display(false);
    }
  }

  reset() {
    //debugger
    this.inHour = [{ "value": "01", "id": 1 }, { "value": "02", "id": 2 }, { "value": "03", "id": 3 }, { "value": "04", "id": 4 }
      , { "value": "05", "id": 5 }, { "value": "06", "id": 6 }, { "value": "07", "id": 7 }, { "value": "08", "id": 8 }
      , { "value": "09", "id": 9 }, { "value": "10", "id": 10 }, { "value": "11", "id": 11 }, { "value": "12", "id": 12 }, { "value": "13", "id": 13 }
      , { "value": "14", "id": 14 }, { "value": "15", "id": 15 }, { "value": "16", "id": 16 }, { "value": "17", "id": 17 }, { "value": "18", "id": 18 }
      , { "value": "19", "id": 19 }, { "value": "20", "id": 20 }, { "value": "21", "id": 21 }, { "value": "22", "id": 22 }, { "value": "23", "id": 23 }, { "value": "24", "id": 24 }];
    //this.hourSelect = [];

    for (let i = 0; i < this.inHour.length; i++) {

      if (this.inHour[i].value == this.settingsData.max_allocation_in_hours) {
        this.hourSelect = [i];
       }
    }


    for (let i = 0; i < this.allocation.length; i++) {
      this.allocation[i].status = false;
      if (this.allocation[i].label == this.settingsData.show_warning_on_over_allocation) {
        setTimeout(() => {
          //this.allocation[i].status = true;
          this.statusWarning = this.allocation[i].label;
          this.warningShow = this.settingsData.show_warning_on_over_allocation;
        })
      }
    }
    for (let i = 0; i < this.resourceAllocationRadio.length; i++) {
      this.resourceAllocationRadio[i].status = false;
      if (this.resourceAllocationRadio[i].label == this.settingsData.allow_resource_over_allocation) {
        setTimeout(() => {
          //this.resourceAllocationRadio[i].status = true;
          this.statusResource = this.resourceAllocationRadio[i].label;
          this.resourceOver = this.settingsData.allow_resource_over_allocation
        });
        if (this.settingsData.allow_resource_over_allocation == 'allow') {
          this.showWarning = true;
        }
        else {
          this.showWarning = false;
        }
      }
    }
    this.hoursPerDay = this.settingsData.hours_per_day;
    this.hoursPerWeek = this.settingsData.hours_per_week;
    this.hoursPerMonth = this.settingsData.day_per_month;
    //this.hourPerDaySelect = this.settingsData.max_allocation_in_hours;
    // this.hourSelect=this.settingsData.max_allocation_in_hours;
    // this.percentageSelect=this.settingsData.max_allocation_in_hours;
    // this.allocationSelect=this.settingsData.resource_allocation_unit;




    for (let i = 0; i < this.Percentage.length; i++) {
      if (this.Percentage[i].value == this.settingsData.max_allocation_in_percentage) {
        this.percentageSelect = [i]
      }
    }
    for (let i = 0; i < this.resourceAllocation.length; i++) {
      if (this.resourceAllocation[i].value == this.settingsData.resource_allocation_unit) {
        this.allocationSelect = [i]
      }
    }
    this.confirmBoxcancel3 = false;
    this.confirmBoxcancel4 = false;
    this.confirmBoxcancel5 = false;
  }
  cancel() {
    if (this.saveORcancel == "cancel") {
      this.confirmBoxcancel4 = false;
      this.editProjSettings = !this.editProjSettings;
      this.getSettingsData();
    }
    else if (this.saveORcancel == "save") {
      this.confirmBoxcancel4 = false;
      this.save();
    }
  }
  popupSaveorCancel() {
    this.confirmBoxcancel4 = true;
    this.saveORcancel = "cancel";
    this.svecnclMessge = "The changes will not be saved. Do you want to continue ?"
  }
}