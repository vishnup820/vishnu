import { Component, OnInit, ElementRef, ViewChild, SimpleChanges, NgZone } from '@angular/core';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { ProjectCalendarService } from '../../service/project-calendar/project-calendar.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { CookieService } from 'ngx-cookie-service';
import { MalihuScrollbarService } from 'ngx-malihu-scrollbar';

declare var require: any;
var moment = require('moment');

@Component({
	selector: 'app-project-calendar',
	templateUrl: './project-calendar.component.html',
	styleUrls: ['../../../../assets/content/css/projectCalendar.css', '../../../../assets/content/css/shifts-available.css', '../../../../assets/content/css/shift-monthly.css',
		'../../../../assets/content/css/employee-shift.css']
})
export class ProjectCalendarComponent implements OnInit {
	@ViewChild('searchData') inputEl: ElementRef;
	searchTextBox:boolean =false;
	searchValue:any;
	filterStatus:boolean = false;

	queryObject: any = [];
	calanderData: any = [];
	dateRangeValue: any;
	selectedComp: any;
	minDate: any;
	maxDate: any;
	userData: any;
	lazyLoad: boolean = false;
	currentWeek: any = [];
	dayList: any;
	listMonths: any = [];

	//filters dropdown
	showAdvanceFilter: boolean = false
	filterActive: boolean = false;;
	searchKeyword: any;

	peopleMaster: any;
	projects: any;
	customers: any;
	projectMasters: any;
	managers: any;

	filterList: any = [{ name: "Day", active: false },
	{ name: "Week", active: true }, { name: "Month", active: false }];

	selectedcuscon: any;

	selectdesig: any;
	selectdept: any;
	selectManager: any;
	selectProject: any;
	selectCust: any;
	selectRole: any;
	selectLoc: any;

	sDesig:any;

	//variables for scroll
	userList: HTMLElement;
	actionTableElement: HTMLElement | any;
	actionHeadElement: HTMLElement | any;

	unifiedscrollAmountY: any;
	unifiedscrollAmountX: any;
	scrollbarOptionsListX: any;
	scrollbarOptionsListXY: any;
	scrollbarOptionsStaticPart: any;

	//month view
	prevDate: any;
	dateValues: any;
	weekNumber: any;
	showAvailable: any;
	daysMonth: any;
	dateValue: any;
	monthDays: any;
	selectedDate: any;
	sidebarDisable: boolean = false;

	showDetail: boolean = false;
	showDetailData: any = [];

	//@ViewChild('foc', { static: false }) inputEl: ElementRef;

	constructor(
		private elRef: ElementRef,
		private loaderActionsService: LoaderActionsService,
		private projectCalendarService: ProjectCalendarService,
		private timeZone: TimezoneDetailsService,
		private cookieService: CookieService,
		private mScrollbarService: MalihuScrollbarService,
		private ngZone:NgZone
	) {
		let self = this;
		setTimeout(function () {
			self.selectedComp = document.getElementById("tables");
		}, 3000)
		self.scrollbarOptionsListXY = {
			axis: 'xy', theme: 'minimal-dark', autoHideScrollbar: false, scrollEasing: "linear",
			keyboard: { scrollType: "stepless" },
			//advanced: { updateOnContentResize: true, updateOnSelectorChange: "tr td" },
			callbacks: {
				whileScrolling: function () {
					self.malihuScrollUpdateListenerDataList(this)
				}
			}
		}

		self.scrollbarOptionsStaticPart = {
			axis: 'y', theme: 'minimal-dark', autoHideScrollbar: false, scrollEasing: "linear",
			keyboard: { scrollType: "stepless" },
			//advanced: { updateOnContentResize: true, updateOnSelectorChange: "tr td" },
			callbacks: {
				whileScrolling: function () {
					self.malihuScrollUpdateListenerStaticList(this)
				}
			}
		}

		self.scrollbarOptionsListX = {
			axis: 'x', theme: 'minimal-dark', autoHideScrollbar: false, scrollEasing: "linear",
			keyboard: { scrollType: "stepless" },
			//advanced: { updateOnContentResize: true, updateOnSelectorChange: "tr td" },
			mouseWheel: {
				preventDefault: true,
				enable: false,
			},
			callbacks: {
				whileScrolling: function () {
					self.malihuScrollUpdateListenerHeadList(this);
				}
			}
		}
	}

	ngOnInit() {
		
		this.initialFucntion();

		this.getPeopleMaster();
		this.getProjects();
		this.getCustomer();
		this.getManager();
		this.getProjectMaster();
		this.getManager();
		this.getCustomer;

		this.calanderList();

	}

	ngOnChanges(changes: SimpleChanges) {
	}

	ngAfterViewInit() {
		this.userList = this.elRef.nativeElement.querySelector('#listTable');
		this.actionTableElement = this.elRef.nativeElement.querySelector('[data-scrollbar-target="main-table"]');
		this.actionHeadElement = this.elRef.nativeElement.querySelector('[data-scrollbar-target="head-table"]');

	}

	initialFucntion() {
		this.listMonths = [];
		this.dayList = [];
		this.dateRangeValue = [];
		this.currentWeek = [];
		for (let i = 3; i >= 1; i--) {
			this.listMonths.push({
				value: moment().subtract(i, 'months').format('MMM YYYY'), id: moment().subtract(i, 'months').format("M"),
				date: moment().subtract(i, 'months').format('YYYY-MM-01')
			});
		}
		this.listMonths.push({ value: moment().format('MMM YYYY'), id: moment().format("M"), date: moment().format('YYYY-MM-01') });
		for (let i = 1; i <= 3; i++) {
			this.listMonths.push({ value: moment().add(i, 'months').format('MMM YYYY'), id: moment().add(i, 'months').format("M"), date: moment().add(i, 'months').format('YYYY-MM-01') });
		}

		this.userData = JSON.parse(this.cookieService.get("user-data"));
		this.minDate = this.timeZone.toLocal(this.userData.financialMin_date);
		this.maxDate = this.timeZone.toLocal(this.userData.end_date);
		var currentDate = moment(this.timeZone.getCurrentDate());
		var weekStart = currentDate.clone().startOf('isoweek');
		var days = [];
		for (var i = 0; i <= 6; i++) {
			this.currentWeek.push(new Date(moment(weekStart).add(i, 'days').format("YYYY-MM-DD")));
		}
		this.dateRangeValue = [new Date(this.currentWeek[0]), new Date(this.currentWeek[6])];
		var startDate = this.timeZone.toLocal(this.dateRangeValue[0]);
		var endDate = this.timeZone.toLocal(this.dateRangeValue[1]);
		this.dayList = this.getDateArray(startDate, endDate);
	}

	calanderList() {
		this.lazyLoad = true;
		this.sidebarDisable = false;
		this.projectCalendarService.getCalanderData(this.dateRangeValue, this.queryObject, res => {
			if (res.status == "OK") {
				this.calanderData = res.data;
				let self=this;
				setTimeout(function () {
					self.lazyLoad = false;
				},2000);
				
				//this.loaderActionsService.display(false);
				setTimeout(function () {
					$("#dataTable tr").each(function (i, val) {
					
						$("#userTable tr").eq(i + 1).height($(this).height());
					});
				},2000);
			}
			else {
				this.lazyLoad = false;
				this.calanderData = [];
			}
			let temp = [];
            for (let k = 0; k < this.calanderData.length; k++) {
              for (let j = 0; j < 7; j++) {
                temp.push({});
			  }
              for (let l = 0; l < this.calanderData[k].roster_data.length; l++) {
                for (let n = 0; n < this.currentWeek.length; n++) {
                  if (moment(this.timeZone.getLocalDate(this.calanderData[k].roster_data[l].day + " " + this.calanderData[k].roster_data[l].start_time)).format("MMM Do YY") == moment(this.currentWeek[n]).format("MMM Do YY")) {

                    if(JSON.stringify(temp[n]) === JSON.stringify({}))
                    temp[n] = this.calanderData[k].roster_data[l];
                //   else if(!this.timeView){
                //     temp[n].copiedData = {start_time : this.calanderData[k].user_roster_data[l].start_time,
                //       end_time : this.calanderData[k].user_roster_data[l].end_time,day : this.calanderData[k].user_roster_data[l].day};
                //     temp[n].isRepeated = true;
                //   }
                    // temp[n] = this.tableData[k].user_roster_data[l];
                  }
                }
			  }
			  for(let m=0;m<temp.length;m++){
				if(JSON.stringify(temp[m]) === JSON.stringify({})){
					//   temp[m].push({ "day_status": ""});
					temp[m]['day_status']='';
				  }
			  }
              this.calanderData[k].roster_data = temp;
              temp = [];
            }




		});
	}

	getPeopleMaster() {
		this.projectCalendarService.getPeopleMaster(res => {
			if (res.status == "OK") {
				this.peopleMaster = res.data;
			}
			else {
				this.peopleMaster = [];
			}
		});
	}

	getProjects() {
		this.projectCalendarService.getProjects(res => {
			if (res.status == "OK") {
				this.projects = res.data;
			}
			else {
				this.projects = [];
			}
		});
	}

	getManager() {
		this.projectCalendarService.getManagers(res => {
			if (res.status == "OK") {
				this.managers = res.data;
				for(var i = 0; i <= this.managers.length; i++){
					this.managers[i]['name_code'] = this.managers[i].name+' '+'('+this.managers[i].code+')';
				}
				//console.log(this.managers);
			}
			else {
				this.managers = [];
			}
		});
	}

	getCustomer() {
		this.projectCalendarService.getCustomers(res => {
			if (res.status == "OK") {
				this.customers = res.data;
			}
			else {
				this.customers = [];
			}
		});
	}

	getProjectMaster() {
		this.projectCalendarService.getMasters(res => {
			if (res.status == "OK") {
				this.projectMasters = res.data;
			}
			else {
				this.projectMasters = [];
			}
		});
	}

	selectDropDownAction(event, from) {
		var isSelect = false;
		if (event && event.selected && event.selected.length) {
			isSelect = true;
		}
		if (from == 'desig') {
			if (isSelect) {
				this.queryObject.desig = event.selected[0].id;
			} else {
				this.queryObject.desig = null
			}
		}
		if (from == 'loc') {
			if (isSelect) {
				this.queryObject.loc = event.selected[0].id;
			} else {
				this.queryObject.loc = null
			}
		}
		if (from == 'dept') {
			if (isSelect) {
				this.queryObject.dept = event.selected[0].id;
			} else {
				this.queryObject.dept = null
			}
		}
		if (from == 'mngr') {
			if (isSelect) {
				this.queryObject.mngr = event.selected[0].id;
			} else {
				this.queryObject.mngr = null
			}
		}
		if (from == 'role') {
			if (isSelect) {
				this.queryObject.role = event.selected[0].id;
			} else {
				this.queryObject.role = null
			}
		}
		if (from == 'cust') {
			if (isSelect) {
				this.queryObject.cust = event.selected[0].id;
			} else {
				this.queryObject.cust = null
			}
		}
		if (from == 'prjt') {
			if (isSelect) {
				this.queryObject.prjt = event.selected[0].id;
			} else {
				this.queryObject.prjt = null
			}
		}

		//console.log(this.queryObject);
	}

	appliyFilter() {
		if (
			this.queryObject.desig ||
			this.queryObject.loc ||
			this.queryObject.dept ||
			this.queryObject.mngr ||
			this.queryObject.role ||
			this.queryObject.cust ||
			this.queryObject.prjt
		) {
			this.showAdvanceFilter = false;
			this.filterActive = true;
			this.calanderList();
		} else {
			this.showAdvanceFilter = false;
			this.filterActive = false;
			this.calanderList();
		}
	}

	setActive(index) {
		for (let i = 0; i <= this.filterList.length - 1; i++) {
			if (i == index) {
				this.filterList[i].active = true;
			} else {
				this.filterList[i].active = false;
			}
		}
		//console.log(this.filterList);
		if (this.filterList[2].active) {
			this.initMonthView();
		}
		if (this.filterList[1].active) {
			this.initialFucntion();
			this.calanderList();
		}


	}

	filterCancel() {
		this.queryObject.desig = null;
		this.queryObject.loc = null;
		this.queryObject.dept = null;
		this.queryObject.mngr = null;
		this.queryObject.role = null;
		this.queryObject.cust = null;
		this.queryObject.prjt = null;
		this.showAdvanceFilter = false;
		this.filterActive = false;
		this.selectedcuscon = [];
		this.calanderList();
	}

	search(search) {
		if (search.trim() != '' || this.searchKeyword) {
			this.searchKeyword = search;
			this.queryObject.keyword = this.searchKeyword ? this.searchKeyword : '';
			this.calanderList();
		}
	}

	getDateArray(start, end) {
		var arr = new Array();
		var dt = new Date(start);
		while (dt <= end) {
			arr.push(moment(dt).format('dddd DD'));
			dt.setDate(dt.getDate() + 1);
		}
		return arr;
	}

	dateRangeChange(event) {
		var start = moment(event[0]);
		var end = moment(event[1]);
		this.currentWeek = [];
		for (var i = 0; i <= 6; i++) {
			this.currentWeek.push(new Date(this.timeZone.addDays(new Date(event[0]), i)));
		}
		this.dateRangeValue = [this.timeZone.toLocal(this.currentWeek[0]), this.timeZone.toLocal(this.currentWeek[this.currentWeek.length - 1])];
		this.dayList = this.getDateArray(this.timeZone.toLocal(this.dateRangeValue[0]), this.timeZone.toLocal(this.dateRangeValue[1]));
		this.calanderList();
	}

	private malihuScrollUpdateListenerDataList = (value) => {
		const scrlTop = Math.abs(value.mcs.top);
		if (this.unifiedscrollAmountY !== scrlTop) {
			this.unifiedscrollAmountY = scrlTop;
			$(this.actionTableElement).find('.mCSB_container').css({ top: ('-' + this.unifiedscrollAmountY + 'px') });
			$(this.actionTableElement).mCustomScrollbar('update');
		}

		const scrollLeft = Math.abs(value.mcs.left);
		if (this.unifiedscrollAmountX !== scrollLeft) {
			this.unifiedscrollAmountX = scrollLeft;
			$(this.actionHeadElement).find('.mCSB_container').css({ left: ('-' + this.unifiedscrollAmountX + 'px') });
			$(this.actionHeadElement).mCustomScrollbar('update');
		}
	}

	private malihuScrollUpdateListenerStaticList = (value) => {
		const scrlTop = Math.abs(value.mcs.top);
		if (this.unifiedscrollAmountY !== scrlTop) {
			this.unifiedscrollAmountY = scrlTop;
			$(this.userList).find('.mCSB_container').css({ top: ('-' + this.unifiedscrollAmountY + 'px') });
			$(this.userList).mCustomScrollbar('update');
		}
	}

	private malihuScrollUpdateListenerHeadList = (value) => {
		const scrollLeft = Math.abs(value.mcs.left);
		if (this.unifiedscrollAmountX !== scrollLeft) {
			this.unifiedscrollAmountX = scrollLeft;
			$(this.userList).find('.mCSB_container').css({ left: ('-' + this.unifiedscrollAmountX + 'px') });
			$(this.userList).mCustomScrollbar('update');
		}
	}

	initMonthView() {
		this.weekNumber = 0;
		if (!this.dateValues) {
			for (let i = 0; i < this.listMonths.length; i++) {
				if (this.listMonths[i].value == moment().format("MMM") + " " + moment().format('YYYY')) {
					this.selectedDate = [i];
					this.dateValues = this.listMonths[i];
				}
			}
		}
		//console.log(this.dateValues);
		if (this.prevDate != this.dateValues.date) {
			
			this.prevDate = this.dateValues.date;
		}

		this.showAvailable = false;
		this.userData = JSON.parse(this.cookieService.get("user-data"));
		this.minDate = this.timeZone.toLocal(this.userData.start_date);
		this.maxDate = this.timeZone.toLocal(this.userData.end_date);
		this.daysMonth = [];
		this.dateValue = moment(this.dateValues.date).toDate();

		for (var i = 0; i < Number(moment(this.dateValue).daysInMonth()); i++) {
			this.daysMonth.push(new Date(moment(this.dateValue).startOf('month').add(i, 'days').format("YYYY-MM-DD")));
		}
		this.monthDays = this.getDateArray(this.daysMonth[0], this.daysMonth[this.daysMonth.length - 1]);
		this.currentWeek = [];
		for (let i = this.weekNumber * 7; i < (this.weekNumber + 1) * 7; i++) {
			this.currentWeek.push(this.daysMonth[i]);
		}

		let end;
		for (let i = 0; i < this.currentWeek.length; i++) {
			if (this.currentWeek[i]) {
				end = this.currentWeek[i];
			}
		}
		this.dateRangeValue = [this.timeZone.toLocal(this.currentWeek[0]), this.timeZone.toLocal(end)];
		var startDate = this.timeZone.toLocal(this.dateRangeValue[0]);
		var endDate = this.timeZone.toLocal(this.dateRangeValue[1]);
		this.dayList = this.getDateArray(startDate, endDate);
		this.dayList = this.getDateArray(new Date(this.dateRangeValue[0]), new Date(this.dateRangeValue[1]));
	}

	moveMonth(value) {
		if (value == true && (this.weekNumber <= Math.floor(this.daysMonth.length / 7))) {
			this.weekNumber++;
			if (this.weekNumber > Math.floor(this.daysMonth.length / 7)) {
				this.weekNumber = Math.floor(this.daysMonth.length / 7);
			}
		}
		else if (this.weekNumber > 0 && value == false) {
			this.weekNumber--;
		}

		if ((0 <= this.weekNumber) && (this.weekNumber <= Math.floor(this.daysMonth.length / 7))) {
			let temp = [];
			let months = ["January", "February", "March", "April", "May", "June",
				"July", "August", "September", "October", "November", "December"];
			let selectedMonthName = months[this.dateValues.id - 1];
			this.currentWeek = [];
			for (let i = this.weekNumber * 7; i < (this.weekNumber + 1) * 7; i++) {
				if (i < moment(selectedMonthName, 'MMMM').daysInMonth()) {
					this.currentWeek.push(this.daysMonth[i]);
				}
				temp.push(this.monthDays[i]);
			}
			this.dayList = temp;
			this.dateRangeValue = [this.timeZone.toLocal(this.currentWeek[0]), this.timeZone.toLocal(this.currentWeek[this.currentWeek.length - 1])];
			this.calanderList();
			debugger
			if (this.weekNumber == Math.floor(this.daysMonth.length / 7)) {
				this.sidebarDisable = true;
			}
			else
				this.sidebarDisable = false;
		}
		if(this.daysMonth.length==28 && this.weekNumber==3){
			this.sidebarDisable = true;
		}
	
	}

	selectedMonth(event) {
		if (event.selected[0]) {
			this.dateValues = event.selected[0];
			this.initMonthView();
			this.calanderList();
		}
	}

	showProjectDetails(detailData, pData) {
		this.showDetailData['first_name'] = detailData.first_name;
		this.showDetailData['last_name'] = detailData.last_name;
		this.showDetailData['code'] = detailData.code;
		this.showDetailData['photo'] = detailData.photo;
		this.showDetailData['project_name'] = pData.name
		this.showDetailData['allocation_per'] = pData.allocation_persentage
		this.showDetailData['allocation_hr'] = pData.allocation_hour
		this.showDetail = true;
	}
	setFocus() {
		setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
	}
}
