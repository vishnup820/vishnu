import { Component, OnInit, ElementRef, ViewChild, ChangeDetectorRef  } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { LoaderActionsService } from '../../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../../shared/services/notifications/notification.service';
import { MastersService } from '../../../service/masters/masters.service';
@Component({
  selector: 'app-resource-type',
  templateUrl: './resource-type.component.html',
  styleUrls: ['../../../../../assets/content/css/recruitmentMasters.css']
})
export class ResourceTypeComponent implements OnInit {
  @ViewChild('foc') inputEl: ElementRef;
  projectRoleStatus: any = [{ "value": "Active", "id": 1 }, { "value": "Inactive", "id": 0 }]
  addRole: boolean=false;
  roleError: boolean=false;
  confirmBoxDelete: boolean = false;
  searchTextBox: boolean = false;
  formPosition: boolean = false;
  recordsPerPage: number = 10;
  currentPage: number=1;
  totalRecords: number;
  queryObject: any={};
  filterSort: any = {};
  projectRoleData: any=[];
  checkedStatus: any;
  statusSelected: any;
  searchKeyword: any = "";
  searchD: any;
  deleteRoleId: any;
  updateForm: any;
  projectRoleDetails: FormGroup;
  projectRole: FormControl;
  constructor(private mastersService:MastersService,
    private loader:LoaderActionsService,private notificationService:NotificationService,
    private cdref: ChangeDetectorRef) { }

  ngOnInit() {
    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    this.currentPage = 1;
    this.queryObject.page_limit = this.recordsPerPage;
    this.queryObject.page = this.currentPage;
    this.createFormControls();
    this.createForm();
    this.projectRolelist();
  }
  createFormControls() {
    let beta = "^[a-zA-Z ]+[.]*[a-zA-Z]*$";
    this.projectRole = new FormControl('', [Validators.required, this.noWhitespaceValidator]);
  }
  createForm() {
    this.projectRoleDetails = new FormGroup({
      projectRole: this.projectRole
    });
  }
  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }
  inputfocus() {
    setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
  }
  submit(){
    if (!this.projectRoleDetails.valid || !this.statusSelected.selected[0]) {
      this.roleError = true;
    }
    else{
      this.loader.display(true);
      this.addRole=false;
      let parms : any;
      parms = {
        "name":this.projectRoleDetails.value.projectRole,
        "status":this.statusSelected.selected[0].id
      }
      this.mastersService.addResourceType(parms,this.updateForm,res =>{
        if(res.status=="OK"){
          this.loader.display(false);
          this.projectRolelist();
          this.notificationService.alertBoxValue("success", res.message);
          this.addRole=false;
        }
        else{
          this.loader.display(false);
          this.addRole=true;
          this.notificationService.alertBoxValue("error", res.message);
        }
      })
    }
  }
  projectRolelist(){
    this.loader.display(true);
    this.mastersService.getResourceType(this.queryObject,res => {
      if (res.status == "OK") {
        this.loader.display(false);
        this.projectRoleData = res.data;
        this.totalRecords = res.count;
        this.currentPage = this.queryObject.page;
      }
      else{
        this.loader.display(false);
        this.projectRoleData=[];
      }
    });
  }
  deleteProjectRole(){
    this.confirmBoxDelete=false;
    this.loader.display(true);
    this.mastersService.deleteResourceType(this.deleteRoleId,res => {
      if (res.status == "OK") {
        this.queryObject.page = 1;
        this.loader.display(false);
        this.projectRolelist();
        this.notificationService.alertBoxValue("success", res.message);
      }
      else{
        this.notificationService.alertBoxValue("error", res.message);
      }
    });
  }
  editprojectData(data,event,id){
    let yPosition = event.clientY;
    let innerheight = document.getElementById("userslist").clientHeight;
    if (((innerheight / 2) + 50) < yPosition && (id > 3)) {
      this.formPosition = true;
    }
    else {
      this.formPosition = false;
    }
    if(!this.projectRoleData[id].editStatus){
      for (var i = 0; i < this.projectRoleData.length; i++) {
        if (this.projectRoleData[i].id === data.id) {
          data.editStatus = true;
        }
        else {
          this.projectRoleData[i].editStatus = false;
        }
      }
      // this.projectRoleDetails.patchValue({
      //   projectRole: data.name
      // });
      this.projectRole.setValue(data.name);
      data.status == 1 ? this.checkedStatus = [0] : this.checkedStatus = [1];
      this.cdref.detectChanges();
    }
    
  }
  addProjectData(){
    this.updateForm="";
    this.roleError = false;
    this.projectRoleDetails.reset();
    this.checkedStatus = []
  }
  pageChangeEvent(event) {
    this.currentPage = event;
    this.queryObject['page'] = this.currentPage;
    this.projectRolelist();
  }
  getpage(event) {
    if (event > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      this.queryObject['page'] = this.currentPage
      this.queryObject['page_limit'] = this.recordsPerPage
      this.projectRolelist();

    }
  }
  searchList(keyword){
    if (this.searchKeyword || this.searchD.trim() != '') {
      this.searchKeyword = keyword;
      // this.queryObject.page = 1;
      this.queryObject['page'] = 1;
      this.queryObject.keyword = this.searchKeyword ? this.searchKeyword : '';
      this.projectRolelist();

    }
  }
  sortCategory(label) {
    let currentSortStatus = this.filterSort[label] ? this.filterSort[label].rev : true;
    this.filterSort = {};
    this.filterSort[label] = { rev: !currentSortStatus }
    this.filterSort["label"] = label;
    this.queryObject.sort = `${this.filterSort[label].rev ? '-' : ''}${label}`
    this.projectRolelist();

  }
}
