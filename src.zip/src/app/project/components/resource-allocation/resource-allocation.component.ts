import { Component, OnInit, ElementRef, ViewChild, ChangeDetectorRef, NgZone } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { ResourceAllocationService } from '../../service/resource-allocation/resource-allocation.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
@Component({
  selector: 'app-resource-allocation',
  templateUrl: './resource-allocation.component.html',
  styleUrls: ['./resource-allocation.component.css']
})

export class ResourceAllocationComponent implements OnInit {
  resourceAllocation: any = [{ "value": "Hours Per Day (HRS/D)", name:'HRS/D', "id": 1 }, { "value": "Percentage",name:'%', "id": 2 }];
  inHour: any = [{ "value": "01", "id": 1 }, { "value": "02", "id": 2 }, { "value": "03", "id": 3 }, { "value": "04", "id": 4 }
    , { "value": "05", "id": 5 }, { "value": "06", "id": 6 }, { "value": "07", "id": 7 }, { "value": "08", "id": 8 }
    , { "value": "09", "id": 9 }, { "value": "10", "id": 10 }, { "value": "11", "id": 11 }, { "value": "12", "id": 12 }, { "value": "13", "id": 13 }
    , { "value": "14", "id": 14 }, { "value": "15", "id": 15 }, { "value": "16", "id": 16 }, { "value": "17", "id": 17 }, { "value": "18", "id": 18 }
    , { "value": "19", "id": 19 }, { "value": "20", "id": 20 }, { "value": "21", "id": 21 }, { "value": "22", "id": 22 }, { "value": "23", "id": 23 }, { "value": "24", "id": 24 }];
  Percentage: any = [ { "value": 25, "id": 4 } ,{ "value": 50, "id": 3 }, { "value": 75, "id": 2 },{ "value": 100, "id": 1 }];
  addResource        : any = [];
  multipleaddResource: any = [];
  allocationList     : any = [];
  peopleList        : any = [];
  masterList        : any = [];
  getSetting        : any = [];
  multipleallocationSelected: any;
  maxAllocation     : any = [];
  tmpAllocation     : any = [];
  tmpAllocationSub  : any = [];
  overAllocation    : any = [];
  lastElement       : any = [];
  removeLastData    : any=[];
  index1            : any;
  checkedName       : any;
  allocationProjName: any;
  projectRole       : any;
  projectname       : any;
  typeSelected      : any;
  allocationSelected  : any;
  checkedresAllocation: any;
  checkedinHour     : any;
  checkedPercentage : any;
  config            : any
  configMain        : any
  mainIndex         : any
  projectStart      : any
  projectEnd        : any
  projectId         : any
  cancelData        : any = []
  cancelIndex       : any = []
  allocationIconData: string;
  removeObj         : any = []
  confirmBox1       : boolean = false;
  pageStatus        : boolean = false;
  confirmBox2       : boolean = false;
  allocationError   : boolean = false;
  startValue        : boolean = false;
  endDatachange     : boolean = false;
  multAllocStartData: boolean = false;
  multAllocEndtData : boolean = false;
  multipleAllocation: boolean = false;
  multipleAllocData : boolean = false;
  lazyloader        : boolean = false;
  confirmBox        : boolean = false
  confirmBoxcancel  : boolean = false
  openPop           : boolean  =false;
  confirmBoxMaincancel: boolean= false;
  overAllocationValue: boolean =false;
  lazyLoad           : boolean = false;
  splitError         : boolean = false;

  constructor(
    private routeActive: ActivatedRoute,
    private resourceAllocationService: ResourceAllocationService,
    private loaderActionsService: LoaderActionsService,
    private notificationService: NotificationService,
    private locations: Router,
    private timeZone: TimezoneDetailsService,
    private ngZone   :NgZone
  ) { }

  ngOnInit() {
    this.loaderActionsService.display(true);
    this.listPeople();
    this.listGetMaster();
    this.routeActive.snapshot.params['pr_id'] ?(this.projectId =  this.routeActive.snapshot.params['pr_id']):(this.projectId = '')
    this.routeActive.snapshot.params['pr_id'] ? this.pageStatus = false : this.pageStatus = true;
    this.addResource = [{
      id: undefined,  resourceName: undefined, resourceNameId: undefined, resourceNameError: false, projectRole: undefined, projectRoleId: undefined, projectRoleError: false, type: undefined, typeId: undefined, typeError: false,
      tentativeStart: undefined, ovrAlloctnButton:undefined, tentativeStartError: false, tentativeEnd: undefined, tentativeEndError: false, allocationUnit: undefined,
      allocation: undefined, overallocationmessage:undefined,user_allocated:undefined, inHourSel: undefined, inHourSelError: false
    }];


    this.listAllocation();
  }

  ngAfterViewInit(){
    setTimeout(() => {
      for (let i = 0; i < this.addResource.length; i++) {
      for (let j = 0; j < this.addResource[i].multipleaddResource.length; j++) {
        if (this.addResource[i].allocationUnit ==2){
          for (let k = 0; k < this.Percentage.length; k++) {
           if (this.addResource[i].multipleaddResource[j].prevhour_or_per == this.Percentage[k].value) {
            this.addResource[i].multipleaddResource[j].mulInHourSel = [k];
            }
          }
        }
        else{
            for (let k = 0; k < this.maxAllocation.length; k++) {
              if (this.addResource[i].multipleaddResource[j].prevhour_or_per == this.maxAllocation[k].id) {
                this.addResource[i].multipleaddResource[j].mulInHourSel = [k];
              }
           }
        }
        this.addResource[i].multipleaddResource[j].prevFromDate       =   this.addResource[i].multipleaddResource[j].multipletentativeStart ;
        this.addResource[i].multipleaddResource[j].prevToDate         =   this.addResource[i].multipleaddResource[j].multipletentativeEnd ;
        this.addResource[i].multipleaddResource[j].prevhour_or_per    =   this.addResource[i].multipleaddResource[j].multipleallocation ;
      }
    }

    this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))
    }, 6000);
  }
  listGetMaster() {
    this.resourceAllocationService.getMaster(res => {
      if (res.status == "OK") {
        this.masterList = res.data;
      }
      else {
        this.masterList = [];
      }
    });
  }


  listPeople() {
    this.resourceAllocationService.peopleAllocation(res => {
      if (res.status == "OK") {
        this.peopleList = res.data;
        for (let i = 0; i < this.peopleList.length; i++) {
          this.peopleList[i]['fullName'] = this.peopleList[i].name + '' + '(' + this.peopleList[i].code + ')'
        }
      }
      else {
        this.peopleList = [];
      }
    });
  }
  listAllocation() {
    this.resourceAllocationService.editAllocationData(this.routeActive.snapshot.params['pr_id'], res => {
      if (res.status == "OK") {
        this.getProjectSettings();
        this.allocationList = res.data;
        let self = this;
        this.allocationProjName=res.prjtName;
        if(res.overAllocation.length !=0){
        this.overAllocation=res.overAllocation;
       
        this.removeLastData=[...this.overAllocation.initial]
        if(this.overAllocation.initial.length>3){
          this.removeLastData.splice(-1,1)
        }
        
        this.lastElement = this.overAllocation.initial[this.overAllocation.initial.length - 1];
      }
         if(  res.projectEnd=='0000-00-00' || res.projectEnd==null || res.projectEnd==undefined ){
            res.projectEnd=null
           }
         if( res.projectStart=='0000-00-00' || res.projectStart==null ||res.projectStart==undefined ){
             res.projectStart=null
          }
          if(res.projectStart && !res.projectEnd ){
            res.projectEnd = res.projectStart
          }else if(!res.projectStart && res.projectEnd ){
            res.projectStart = res.projectEnd
          }
        this.projectStart  = this.timeZone.getLocalDate(res.projectStart);
        this.projectEnd    = this.timeZone.getLocalDate( res.projectEnd);
        this.addResource[0].tentativeStart = this.projectStart
        this.addResource[0].tentativeEnd = this.projectEnd
        if (this.allocationList.length) {
          this.lazyLoad =true;
          this.addResource = [];
          if (this.allocationList.length && !this.pageStatus) {
            for (let i = 0; i < this.allocationList.length; i++) {
              for (let j = 0; j < this.allocationList[i].allocation.length; j++) {
                if( this.allocationList[i].allocation[j].from==''||  this.allocationList[i].allocation[j].from=='0000-00-00' || this.allocationList[i].allocation[j].from==null ||this.allocationList[i].allocation[j].from==undefined ){
                  this.allocationList[i].allocation[j].from=null
                }
                if(this.allocationList[i].allocation[j].to==''||  this.allocationList[i].allocation[j].to=='0000-00-00' || this.allocationList[i].allocation[j].to==null ||this.allocationList[i].allocation[j].to==undefined ){
                  this.allocationList[i].allocation[j].to=null
                }
                if( this.allocationList[i].allocation[j].from && !this.allocationList[i].allocation[j].to ){
                  this.allocationList[i].allocation[j].to   = this.allocationList[i].allocation[j].from
                }else if(!this.allocationList[i].allocation[j].from && this.allocationList[i].allocation[j].to){
                  this.allocationList[i].allocation[j].from = this.allocationList[i].allocation[j].to
                }

                  this.allocationList[i].allocation[j].from = this.timeZone.toLocal( this.allocationList[i].allocation[j].from)              
                  this.allocationList[i].allocation[j].to = this.timeZone.toLocal( this.allocationList[i].allocation[j].to)              
                }
            }
         
            for (let i = 0; i < this.allocationList.length; i++) {
              for (let j = 0; j < this.allocationList[i].allocation.length; j++) {
                if(Number(this.allocationList[i].allocation[j].term)==2 ||  Number(this.allocationList[i].allocation[j].term) == 0){
                  if(Number(this.allocationList[i].allocation[j].user_hrs_allocated)==0)
                  this.allocationList[i].allocation[j].user_hrs_allocated=null

                  if(this.allocationList[i].allocation[j].alloc_percentage == 0){
                     this.allocationList[i].allocation[j].alloc_percentage = null;
                     this.allocationList[i].allocation[j].alloc_in_hours = null
                     this.allocationList[i].allocation[j].alloc_percentage = this.allocationList[i].allocation[j].user_hrs_allocated
                  }else{
                    // next 1st line not need for implementing new api
                    // this.allocationList[i].allocation[j].user_hrs_allocated = this.allocationList[i].allocation[j].alloc_percentage
                    this.allocationList[i].allocation[j].alloc_percentage = this.allocationList[i].allocation[j].user_hrs_allocated
                  }
                }else{
                  if(this.allocationList[i].allocation[j].alloc_percentage == 0){
                      this.allocationList[i].allocation[j].alloc_percentage = null; 
                      this.allocationList[i].allocation[j].alloc_in_hours = this.allocationList[i].allocation[j].user_hrs_allocated
                  }
                  else{
                        // next 1st line not need for implementing new api
                    // this.allocationList[i].allocation[j].user_hrs_allocated = this.allocationList[i].allocation[j].alloc_in_hours
                    this.allocationList[i].allocation[j].alloc_in_hours = this.allocationList[i].allocation[j].user_hrs_allocated

                  }
                }
              }

            }

            for (let i = 0; i < this.allocationList.length; i++) {
              this.addResource.push({
                id: undefined,ovrAlloctnButton:undefined, overallocationmessage:undefined,user_allocated:undefined, 
                 resourceNameSelect: undefined, resourceName: undefined, resourceNameId: undefined, 
                 resourceNameError: false, projectRoleSelect: undefined, projectRole: undefined,
                  projectRoleId: undefined, projectRoleError: false, typeSelect: undefined,
                   type: undefined, typeId: undefined, typeError: false,
                tentativeStart: undefined, tentativeStartError: false, tentativeEnd: undefined, tentativeEndError: false, allocationUnit: undefined,
                allocation: undefined, inHourSel: undefined, multipleaddResource: []
             });
              for (let j = 0; j < this.allocationList[i].allocation.length; j++) {
                this.addResource[i].ovrAlloctnButton   = this.allocationList[i].allocation[0].user_over_allocation
                this.addResource[i].overallocationmessage = this.allocationList[i].allocation[0].user_over_allocation_message
                this.addResource[i].user_allocated        = this.allocationList[i].allocation[0].user_hrs_allocated 
                this.addResource[i].tentativeEnd       = this.allocationList[i].allocation[0].to  
                this.addResource[i].tentativeStart     =this.allocationList[i].allocation[0].from
                if(Number(this.allocationList[i].allocation[j].term == 1)){
                  this.allocationList[i].allocation[j].term = 1
                }
                else{
                  this.allocationList[i].allocation[j].term = 2
                }
                if(Number(this.allocationList[i].allocation[0].term )===2 ||  Number(this.allocationList[i].allocation[j].term) == 0){
                  this.addResource[i].allocation = this.allocationList[i].allocation[0].alloc_percentage
                  this.addResource[i].allocationUnit = 2
                }else{
                  this.addResource[i].allocation = this.allocationList[i].allocation[0].alloc_in_hours
                  this.addResource[i].allocationUnit = 1
                }
              }
              this.addResource[i].resourceNameId= this.allocationList[i].id;
              this.addResource[i].type= this.allocationList[i].billable,
              this.addResource[i].projectRoleId= this.allocationList[i].role
            }

            for (let j = 0; j < this.addResource.length; j++) {
                this.addResource[j].tentativeStart = this.timeZone.getLocalDate(this.addResource[j].tentativeStart)
                this.addResource[j].tentativeEnd = this.timeZone.getLocalDate(this.addResource[j].tentativeEnd)

            }

            setTimeout(() => {
              for (let i = 0; i < this.peopleList.length; i++) {
                for (let j = 0; j < this.addResource.length; j++) {
                  if (this.peopleList[i].id == this.addResource[j].resourceNameId) {
                    this.addResource[j].resourceNameSelect = [i]
                  }

                }
              }
            }, 3000);
            setTimeout(() => {
              for (let i = 0; i < this.masterList.prjt_roles.length; i++) {
                for (let j = 0; j < this.addResource.length; j++) {
                  if (this.masterList.prjt_roles[i].id == this.addResource[j].projectRoleId) {
                    this.addResource[j].projectRoleSelect = [i]
                  }else 
                  if( (this.addResource[j].resourceNameSelect!==null || this.addResource[j].resourceNameSelect!==undefined) && 
                   (this.addResource[j].projectRoleSelect==null || this.addResource[j].projectRoleSelect==undefined) ){
                    if ('Project Manager'=== this.masterList.prjt_roles[i].name) {
                      this.addResource[j].projectRoleSelect = [i]
                    }
                  }

                }
              }
            }, 3000);
            setTimeout(() => {
              for (let i = 0; i < this.masterList.prjt_resource_types.length; i++) {
                for (let j = 0; j < this.addResource.length; j++) {
                  if (this.masterList.prjt_resource_types[i].id == this.addResource[j].type) {
                    this.addResource[j].typeSelect = [i]
                  }
                }
              }
              for (let i = 0; i < this.masterList.prjt_resource_types.length; i++) {
                for (let j = 0; j < this.addResource.length; j++) {     
                  if( (this.addResource[j].resourceNameSelect!==null || this.addResource[j].resourceNameSelect!==undefined) && 
                   (this.addResource[j].typeSelect==null || this.addResource[j].typeSelect==undefined) ){
                    if ("Billable"=== this.masterList.prjt_resource_types[i].name) {
                      this.addResource[j].typeSelect = [i]
                    }
                  }

                }
              }
              this.lazyLoad = false;
            }, 3000);

            for (let i = 0; i < this.allocationList.length; i++) {

              for (let j = 0; j < this.allocationList[i].allocation.length; j++) {

                for (let k = 0; k < this.addResource.length; k++) {
                  if (this.allocationList[i].id == this.addResource[k].resourceNameId) {
                    if(  Number(this.allocationList[i].allocation[0].term ==2)  ||  Number(this.allocationList[i].allocation[j].term) == 0){

                    this.addResource[k].multipleaddResource.push({
                      resourceNameId: this.allocationList[i].allocation[j].people_id, multipletentativeStart: this.allocationList[i].allocation[j].from, multipletentativeStartError: false,
                      multipletentativeEnd: this.allocationList[i].allocation[j].to, multipletentativeEndError: false, multipleallocationUnit: this.allocationList[i].allocation[j].term, multipleallocation: this.allocationList[i].allocation[j].alloc_percentage, allocationId: this.allocationList[i].allocation[j].alloc_id,
                      mulInHourSel: undefined,prevFromDate:this.allocationList[i].allocation[j].from, prevhour_or_per: undefined,prevToDate:this.allocationList[i].allocation[j].to,prevterm:this.allocationList[i].allocation[j].term
                      ,ovrAlloctnButton:this.allocationList[i].allocation[j].user_over_allocation,
                      overallocationmes: this.allocationList[i].allocation[j].user_over_allocation_message,
                      user_allocated : this.allocationList[i].allocation[j].user_hrs_allocated,multipleallocError:false
                    })
                  }else{
                    this.addResource[k].multipleaddResource.push({
                      resourceNameId: this.allocationList[i].allocation[j].people_id, multipletentativeStart: this.allocationList[i].allocation[j].from, multipletentativeStartError: false,
                      multipletentativeEnd: this.allocationList[i].allocation[j].to, multipletentativeEndError: false, multipleallocationUnit: this.allocationList[i].allocation[j].term, multipleallocation: this.allocationList[i].allocation[j].alloc_in_hours, allocationId: this.allocationList[i].allocation[j].alloc_id,
                      ovrAlloctnButton:this.allocationList[i].allocation[j].user_over_allocation,
                      overallocationmes: this.allocationList[i].allocation[j].user_over_allocation_message,multipleallocError:false,
                      user_allocated : this.allocationList[i].allocation[j].user_hrs_allocated, mulInHourSel: undefined,prevFromDate:this.allocationList[i].allocation[j].from, prevhour_or_per: undefined,prevToDate:this.allocationList[i].allocation[j].to,prevterm:this.allocationList[i].allocation[j].term
                    })
                  }
                }
                  if (this.addResource[k].multipleaddResource.length > 1) {
                    this.addResource[k].count = true;
                  }
                  else {
                    this.addResource[k].count = false;
                  }
                }

              }
            }
          }
        }
        
        this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))
      }
      else {
        this.allocationList = [];
      }
    });

  }


  getProjectSettings() {
    this.resourceAllocationService.getSettings(res => {
      if (res.status == "OK") {
        this.getSetting = res.data;
           this.maxAllocation = [];
          if(this.allocationList.length!==0){
            for (let i = 0; i < this.allocationList.length; i++) {
              for (let j = 0; j < this.allocationList[i].allocation.length; j++) {   
              if(Number(this.allocationList[i].allocation[j].term) == 2 ||  Number(this.allocationList[i].allocation[j].term) == 0) {
              this.allocationIconData='Percentage';
              let inHourCount: any
              inHourCount = Number(this.getSetting.hours_per_day) + 1;
              for (let i = 0; i <= this.inHour.length; i++) {
                if (this.inHour && this.inHour[i] && (this.inHour[i].value != inHourCount)) {
                  this.maxAllocation.push({
                    "value": this.inHour[i].value, "id": this.inHour[i].id
                  })
                  }  else {
                  break;
                }
              }

              for (let k = 0; k < this.Percentage.length; k++) {
                if( this.allocationIconData === "Percentage"){
                  if(j==0){
                    this.addResource[i].allocationUnit = 2
                    this.addResource[i].checkedresAllocation= [1]
                  }
                  this.addResource[i].multipleaddResource[j].checkedresAllocation= [1]
                  if(this.allocationList[i].allocation[0].alloc_percentage == 0 || this.allocationList[i].allocation[0].alloc_percentage ==null){
                    if (this.allocationList[i].allocation[0].alloc_percentage == this.Percentage[k].value) {
                      if(j==0)
                      {
                      this.addResource[i].inHourSel = [k];
                      this.addResource[i].multipleaddResource[j].mulInHourSel = [k];
                      break;
                      }
                    }
                    else{
                    if(j==0){
                       this.addResource[i].allocation = null
                       this.addResource[i].multipleallocation = null
                     }

                    }
                  }
                  else{
                    if((Number(this.allocationList&&this.allocationList[i] &&this.allocationList[i].allocation && this.allocationList[i].allocation[0].term) ==2 ) ||
                      (Number(this.allocationList&&this.allocationList[i] &&this.allocationList[i].allocation && this.allocationList[i].allocation[0].term) ==0 ) ){

                      if (this.allocationList[i].allocation[0].alloc_percentage == this.Percentage[k].value) {
                        if(j==0){
                          this.addResource[i].inHourSel = [k];
                          break;
                        }
                      }else{
                        if(j==0)
                        this.addResource[i].allocation = null
                      }
                    }
                  }
                }
              }
            }else{
              if(j==0){
                this.addResource[i].allocationUnit = 1
                this.addResource[i].checkedresAllocation= [0]
              }
              this.addResource[i].multipleaddResource[j].checkedresAllocation= [0]
              this.maxAllocation = [];
              this.allocationIconData='Hours Per Day (HRS/D)'
              let inHourCount: any
              inHourCount = Number(this.getSetting.hours_per_day) + 1;
              for (let i = 0; i <= this.inHour.length; i++) {
                if (this.inHour && this.inHour[i] && (this.inHour[i].value != inHourCount)) {
                  this.maxAllocation.push({
                    "value": this.inHour[i].value, "id": this.inHour[i].id
                  })
                  }  else {
                  break;
                }
              }

             for (let k = 0; k < this.maxAllocation.length; k++) {
              if (this.allocationList[i].allocation[0].alloc_in_hours == this.maxAllocation[k].value) {
                 if(j==0){
                  this.addResource[i].multipleaddResource[0].mulInHourSel = [k];
                  this.addResource[i].inHourSel = [k];
                 }
                  break;
                }else{
                  if(j==0){
                    this.addResource[i].allocation = null
                    this.addResource[i].multipleaddResource[0].multipleallocation = null
                  }
                }
              }

            }
          }
           }  
          }
          else{
            if (this.getSetting.resource_allocation_unit == "Percentage") {
              this.allocationIconData='Percentage';
              this.addResource[0].checkedresAllocation= [1]
              this.addResource[0].multipleaddResource[0].checkedresAllocation= [1]
                for (let k = 0; k < this.Percentage.length; k++) {
                  if( this.allocationIconData === "Percentage"){
                      if (100 == this.Percentage[k].value) {
                        this.addResource[0].inHourSel = [k];
                        this.addResource[0].multipleaddResource[0].mulInHourSel = [k];
                        break;
                      }else{
                        this.addResource[0].allocation = null
                        this.addResource[0].multipleaddResource[0].multipleallocation = null
                      }
                  }
                }
                let inHourCount: any
                inHourCount = Number(this.getSetting.hours_per_day) + 1
                for (let i = 0; i <= this.inHour.length; i++) {
                  if (this.inHour && this.inHour[i] && this.inHour[i].value != inHourCount) {
                   this.maxAllocation.push({
                   "value": this.inHour[i].value, "id": this.inHour[i].id
                  })
                  }else {
                 break;
                }
              }
              }
               else{
                this.addResource[0].checkedresAllocation= [0]
                this.addResource[0].multipleaddResource[0].checkedresAllocation= [0]    
                this.allocationIconData='Hours Per Day (HRS/D)'
                let inHourCount: any
                this.maxAllocation = [];

                inHourCount = Number(this.getSetting.hours_per_day) + 1
                for (let i = 0; i <= this.inHour.length; i++) {
                  if (this.inHour && this.inHour[i] && this.inHour[i].value != inHourCount) {
                   this.maxAllocation.push({
                   "value": this.inHour[i].value, "id": this.inHour[i].id
                  })
                  }else {
                 break;
                }
              }
             for (let k = 0; k < this.maxAllocation.length; k++) {
                if (this.getSetting.hours_per_day == this.maxAllocation[k].id) {
                    this.addResource[0].inHourSel = [k];
                    this.addResource[0].mulInHourSel = [k]
                } else{
                  this.addResource[0].allocation = null
                  this.addResource[0].multipleaddResource[0].multipleallocation = null
                }         
             }

            }
          }
 
       
          for (let i = 0; i < this.allocationList.length; i++) {
            for (let j = 1; j <this.allocationList[i].allocation.length; j++) {
              // for (let k = 0; k < this.maxAllocation.length; k++) {
                if((Number(this.allocationList &&this.allocationList[i]&&this.allocationList[i].allocation &&this.allocationList[i].allocation[j].term) ==2)||  
                  (Number(this.allocationList &&this.allocationList[i]&&this.allocationList[i].allocation &&this.allocationList[i].allocation[j].term) ==0)){ 
                  for (let k = 0; k < this.Percentage.length; k++) {
                  if (this.allocationList[i].allocation[j].alloc_percentage == this.Percentage[k].value) {
                  this.addResource[i].multipleaddResource[j].mulInHourSel = [k];
                  this.addResource[i].multipleaddResource[j].multipleallocation = this.Percentage[k].value
                  break
                  }else{
                    this.addResource[i].multipleaddResource[j].multipleallocation = null
                  }
                }
              }
              else{
                for (let k = 0; k < this.maxAllocation.length; k++) {
                  if(this.allocationList[i].allocation[j].alloc_in_hours  == this.maxAllocation[k].value) {
                      this.addResource[i].multipleaddResource[j].mulInHourSel = [k];
                      this.addResource[i].multipleaddResource[j].multipleallocation = this.maxAllocation[k].value
                      break;
                  }else{
                    this.addResource[i].multipleaddResource[j].multipleallocation = null
                  }
                }
              }
            //}
            }
          }
        setTimeout(() => {
          this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))
          this.loaderActionsService.display(false);
        },1000)
      }
      else {
        this.getSetting = [];
         this.loaderActionsService.display(false);
      }
    });
  }
  projectNameData(event, i) {
    if (event.selected[0]) {
      for (let p = 0; p < this.addResource.length; p++) {
        if( (i !== p )&& (this.addResource[p].resourceNameId == event.selected[0].id)){
          this.addResource[i].resourceNameError =false;
          this.addResource[i].repeatUser =true;
          break;
        }else{
          this.addResource[i].repeatUser =false;
          this.addResource[i].resourceNameId = event.selected[0].id;
          this.addResource[i].resourceName = event.selected[0].fullName;
          if( this.addResource&&this.addResource[i]&& this.addResource[i].multipleaddResource&& this.addResource[i].multipleaddResource.length){
          for (let j = 0; j < this.addResource[i].multipleaddResource.length; j++) {
            this.addResource[i].multipleaddResource[j].resourceNameId = this.addResource[i].resourceNameId;
           }
          }
        }
       }
       this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))
    }
  }
  projectRoleData(event, i) {
    if (event.selected[0]) {
      this.addResource[i].projectRoleId = event.selected[0].id;
      this.addResource[i].projectRole = event.selected[0].name;
      this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))
    }
  }
  typeData(event, i) {
    if (event.selected[0]) {
      this.addResource[i].typeId = event.selected[0].id;
      this.addResource[i].type = event.selected[0].name;
      this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))
    }
  }

  startDateChange(event, i,dateFrom,dateTo) {
    if (event) {
      this.startValue = true;
      this.addResource[i].tentativeStart = event;
      this.addResource[i]['minDate'] = this.timeZone.toLocal(event);
      this.addResource[i].multipleaddResource[0].multipletentativeStart = event;
      if(this.timeZone.toLocal(event)>=this.timeZone.toLocal( dateTo)){
        this.addResource[i].tentativeEnd = this.addResource[i].tentativeStart;
      }
      this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))
 
    }
    else {
      this.startValue = false;
    }
  }
  unitSelectedData(event, i) {
    if (event.selected[0]) {
      if(this.addResource[i] && this.addResource[i].allocationUnit){
        if(  Number(this.addResource[i].allocationUnit) !== Number ( event.selected[0].id)){
          this.addResource[i].allocation = null;
          this.addResource[i].inHourSel = null;
          for(let j =0;j< this.addResource[i].multipleaddResource.length;j++){
            this.addResource[i].multipleaddResource[j].multipleallocation = null;
            this.addResource[i].multipleaddResource[j].prevhour_or_per    = null;
            this.addResource[i].multipleaddResource[j].mulInHourSel = null;
          }
        }
      }
      this.addResource[i].allocationUnit = event.selected[0].id;
      this.addResource[i].multipleaddResource[0].multipleallocationUnit = event.selected[0].id;
      if(Number(this.addResource[i].allocationUnit) == 2 ){
        // this.addResource[i].checkedresAllocation= [1]
        this.addResource[i].multipleaddResource[0].checkedresAllocation= [1]
      }else
      this.addResource[i].multipleaddResource[0].checkedresAllocation= [0]

      this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))
    }
  }
  allocationData(event, i) {
      if (event.selected[0]) {
        this.addResource[i].allocation = event.selected[0].value;
        this.addResource[i].inHourSelError =false;
        this.addResource[i].multipleaddResource[0].multipleallocation = event.selected[0].value;
        this.addResource[i].multipleaddResource[0].prevhour_or_per    = event.selected[0].value;
        if(this.addResource[i].allocationUnit==1 ){
          for (let j = 0; j < this.maxAllocation.length; j++) {
            if (this.maxAllocation[j].value == event.selected[0].value) {
              this.addResource[i].multipleaddResource[0].mulInHourSel = [j];
              break
            }
          }
        }else{
          for (let j = 0; j < this.Percentage.length; j++) {
            if (this.Percentage[j].value == event.selected[0].value) {
              this.addResource[i].multipleaddResource[0].mulInHourSel = [j];
              break
            }
          }
        }

        this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))
      } 
  }

  multipleStartDateChange(event,dateFrom,dateTo, i, j) {
    if(event){
      this.addResource[i].multipleaddResource[j].multipletentativeStart = event;
      this.addResource[i].multipleaddResource[j]['multipleMinDate'] = this.timeZone.toLocal(event);
      if(this.timeZone.toLocal(event)>=this.timeZone.toLocal( dateTo)){
        this.addResource[i].multipleaddResource[j].multipletentativeEnd = this.addResource[i].multipleaddResource[j].multipletentativeStart;
      }
      this.multAllocStartData=true;
      this.addResource[i].multipleaddResource[j].multipletentativeStartError = false;
      this.addResource[i].multipleaddResource[j].multipletentativeStart = event;
    }
    else{
      this.multAllocStartData=false;
    }
  }
  multipleendDateChange(event,dateFrom,dateTo, i, j) {
    if(event){
      this.addResource[i].multipleaddResource[j].multipletentativeEnd = event;
      this.multAllocEndtData=true;
      let k =   new Date (dateFrom)
      let p =   new Date (dateTo)
      this.addResource[i].multipleaddResource[j].multipletentativeEndError = false;
      if(this.timeZone.toLocal(dateFrom)>=this.timeZone.toLocal( dateTo)){
        this.addResource[i].multipleaddResource[j].multipletentativeEnd = this.addResource[i].multipleaddResource[j].multipletentativeStart;
      }
    }
    else{
      this.multAllocEndtData=false;
    }
  }
  multipleunitSelectedData(event, i, j) {
  if(event&& event.selected[0]){
    if(this.addResource[i] && this.addResource[i].multipleaddResource && this.addResource[i].multipleaddResource[j] &&  this.addResource[i].multipleaddResource[j].multipleallocationUnit ){
      if(  Number(this.addResource[i].multipleaddResource[j].multipleallocationUnit )!== Number ( event.selected[0].id)){
          this.addResource[i].multipleaddResource[j].multipleallocation = null;
          this.addResource[i].multipleaddResource[j].prevhour_or_per    = null;
          this.addResource[i].multipleaddResource[j].mulInHourSel = null;
      }
  }
 

    this.addResource[i].multipleaddResource[j].multipleallocationUnit = event.selected[0].id;
  }


  }
  multipleallocationData(event, i, j) {
      if(event&& event.selected[0]){
        this.addResource[i].multipleaddResource[j].multipleallocation = event.selected[0].value;
   //     if(j==0)
    //    this.addResource[i].allocation = event.selected[0].value;
     // }
    if(event.selected[0]){
      this.multipleAllocData=true
    }else{
      this.multipleAllocData=false
    }
  }
  }
  checkChildrenWork(i) {
    if (this.addResource) {
      if (!this.addResource[i].resourceName) {
        this.addResource[i].resourceNameError = true;
      }
      else {
        this.addResource[i].resourceNameError = false;
      }
      if (!this.addResource[i].projectRole) {
        this.addResource[i].projectRoleError = true;
      }
      else {
        this.addResource[i].projectRoleError = false;
      }
      if (!this.addResource[i].type) {
        this.addResource[i].typeError = true;
      }
      else {
        this.addResource[i].typeError = false;
      }
      if (!this.addResource[i].tentativeStart) {
        this.addResource[i].tentativeStartError = true;
      }
      else {
        this.addResource[i].tentativeStartError = false;
      }
      if (!this.addResource[i].tentativeEnd) {
        this.addResource[i].tentativeEndError = true;
      }
      else {
        this.addResource[i].tentativeEndError = false;
      }
      if (!this.addResource[i].allocation ) {
        this.addResource[i].inHourSelError = true;
        // this.addResource[i].allocation = null
        // ||!this.addResource[i].inHourSel
      }
      else {
        this.addResource[i].inHourSelError = false;
      }
    }
  }

  addResourceAllocation() {
    this.allocationError = false;
    this.startValue = false;
    this.endDatachange = false;
    let stat;
    this.checkChildrenWork( 0);
    for (let i = 0; i < this.addResource.length; i++) {
      if (!this.addResource[i].resourceNameError && !this.addResource[i].repeatUser && !this.addResource[i].projectRoleError && !this.addResource[i].typeError && !this.addResource[i].tentativeStartError && !this.addResource[i].tentativeEndError && !this.addResource[i].inHourSelError) {
        stat = true;
      }
      else {
        stat = false;
        break;
      }
    }
    if (stat) {
        if(this.getSetting.resource_allocation_unit === "Percentage"){
          this.addResource.unshift({
            id: undefined,ovrAlloctnButton:undefined,overallocationmessage:undefined,user_allocated:undefined, resourceName: undefined, resourceNameId: undefined, resourceNameError: false, projectRole: undefined, projectRoleId: undefined, projectRoleError: false, type: undefined, typeId: undefined, typeError: false,
            tentativeStart: this.projectStart, multipleaddResource:[],tentativeStartError: false, tentativeEnd:this.projectEnd, tentativeEndError: false, allocationUnit: undefined, allocation: undefined, inHourSel: undefined, inHourSelError: false
          });
          this.addResource[0].multipleaddResource.push({
            resourceNameId: undefined, multipletentativeStart: undefined, multipletentativeStartError: false,
            multipletentativeEnd: undefined, multipletentativeEndError: false, multipleallocationUnit: undefined, multipleallocation: undefined, allocationId: undefined, mulInHourSel: undefined,
            multipleallocError: false,ovrAlloctnButton:undefined,overallocationmes:undefined,user_allocated : undefined
          })
          this.addResource[0].multipleaddResource[0].tentativeStart = this.projectStart
          this.addResource[0].multipleaddResource[0].tentativeEnd   = this.projectEnd
          this.addResource[0].multipleaddResource[0].multipleallocationUnit   = (this.getSetting.resource_allocation_unit  === "Percentage")?2:1
        
          this.addResource[0].checkedresAllocation= [1]
          this.addResource[0].multipleaddResource[0].checkedresAllocation= [1]

        
          for (let k = 0; k < this.maxAllocation.length; k++) {
            if( this.getSetting.resource_allocation_unit  === "Percentage"){
                if (100 == this.Percentage[k].value) {
                  this.addResource[0].inHourSel = [k];
                  this.addResource[0].multipleaddResource[0].mulInHourSel= [k];
                  break;
                }
            }
          }
        }
        else{
          this.addResource.unshift({
            id: undefined, resourceName: undefined, resourceNameId: undefined, resourceNameError: false, projectRole: undefined, projectRoleId: undefined, projectRoleError: false, type: undefined, typeId: undefined, typeError: false,
            tentativeStart: this.projectStart, multipleaddResource:[],tentativeStartError: false, tentativeEnd:this.projectEnd, tentativeEndError: false, allocationUnit: undefined, allocation: undefined, inHourSel: undefined, inHourSelError: false
          });
          this.addResource[0].multipleaddResource.push({
            resourceNameId: undefined, multipletentativeStart: undefined, multipletentativeStartError: false,
            multipletentativeEnd: undefined, multipletentativeEndError: false, multipleallocationUnit: undefined, multipleallocation: undefined, allocationId: undefined, mulInHourSel: undefined,
            multipleallocError: false,ovrAlloctnButton:undefined,overallocationmes:undefined,user_allocated : undefined
          })
          this.addResource[0].multipleaddResource[0].tentativeStart = this.projectStart
          this.addResource[0].multipleaddResource[0].tentativeEnd   = this.projectEnd
          this.addResource[0].multipleaddResource[0].multipleallocationUnit   = (this.getSetting.resource_allocation_unit === "Percentage")?2:1
          let inHourCount: any
          this.maxAllocation = [];

          inHourCount = Number(this.getSetting.hours_per_day) + 1
          for (let i = 0; i <= this.inHour.length; i++) {
           if (this.inHour && this.inHour[i] && this.inHour[i].value != inHourCount) {
             this.maxAllocation.push({
               "value": this.inHour[i].value, "id": this.inHour[i].id
             })
           } else {
             break;
           }
         }
         this.addResource[0].checkedresAllocation= [0]
         this.addResource[0].multipleaddResource[0].checkedresAllocation= [0]   
                for (let k = 0; k < this.maxAllocation.length; k++) {
              if(this.getSetting.resource_allocation_unit === "Hours Per Day (HRS/D)"){
                if(this.getSetting.allow_resource_over_allocation == "allow"){
                  if (this.getSetting.hours_per_day == this.maxAllocation[k].id) {
                    this.addResource[0].inHourSel = [k];
                    this.addResource[0].multipleaddResource[0].mulInHourSel= [k];
                    break;
                    }
                }
               else{
                  if (this.getSetting.hours_per_day == this.maxAllocation[k].id) {
                  this.addResource[0].inHourSel = [k];
                  this.addResource[0].multipleaddResource[0].mulInHourSel= [k];
                  break;
                  }
               }
              }
            }
            
        }
      // }
      for (let j = 0; j < this.addResource.length; j++) {
        this.addResource[j].tentativeStart = this.timeZone.getLocalDate(this.addResource[j].tentativeStart)
        this.addResource[j].tentativeEnd = this.timeZone.getLocalDate(this.addResource[j].tentativeEnd)
        if(j!==0){
        if(this.addResource[j].allocationUnit == 1 ){
          for (let k = 0; k < this.maxAllocation.length; k++) {
            if (this.maxAllocation[k].value == this.addResource[j].allocation) {
              this.addResource[j].inHourSel = [k];
              this.addResource[j].multipleaddResource[0].mulInHourSel = [k];
              break
            }
          }
        }else{
          for (let k = 0; k < this.Percentage.length; k++) {
            if (this.Percentage[k].value ==this.addResource[j].allocation) {
              this.addResource[j].inHourSel = [k];
              this.addResource[j].multipleaddResource[0].mulInHourSel = [k];
              break
            }
          }
        }
      }
      }
    this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))

    }


  }
  checkChildrenMultipleWork(i, j) {
    if (this.addResource[i].multipleaddResource) {
      if (!this.addResource[i].multipleaddResource[j].multipletentativeStart) {
        this.addResource[i].multipleaddResource[j].multipletentativeStartError = true;
      }
      else {
        this.addResource[i].multipleaddResource[j].multipletentativeStartError = false;
      }
      if (!this.addResource[i].multipleaddResource[j].multipletentativeEnd) {
        this.addResource[i].multipleaddResource[j].multipletentativeEndError = true;
      }
      else {
        this.addResource[i].multipleaddResource[j].multipletentativeEndError = false;
      }     
      if (!this.addResource[i].multipleaddResource[j].multipleallocation) {
        this.addResource[i].multipleaddResource[j].multipleallocError = true;
      }
      else {
        this.addResource[i].multipleaddResource[j].multipleallocError = false;
      }
    }
  }
  addMultipleResourceAllocation(data, main, j) {
    let stat   : boolean = false;
    // this.checkChildrenMultipleWork(i, this.addResource[i].multipleaddResource.length - 1);
    let gfStatus : boolean = false
    let Status   : boolean = false
    let fStatus  : boolean = false

    // for (let j = 0; j < this.addResource.length; j++) {
      for(let i=0;i<this.addResource[main].multipleaddResource.length;i++){

        if(this.addResource[main].multipleaddResource[i].multipleallocation==undefined ||
           this.addResource[main].multipleaddResource[i].multipleallocation==null
          ){
          this.addResource[main].multipleaddResource[i].multipleallocError = true 
          this.addResource[main].allocation = null
          gfStatus = true
          break;
        }
        else
        gfStatus  = false
      }
  
      for(let i=0;i<this.addResource[main].multipleaddResource.length;i++){
        if(this.addResource[main].multipleaddResource[i].multipletentativeStart==undefined ||
           this.addResource[main].multipleaddResource[i].multipletentativeStart==null){
          this.addResource[main].multipleaddResource[i].multipletentativeStartError=true 
          fStatus = true
          break;
        }
        else
        fStatus  = false
      }
  
      for(let i=0;i<this.addResource[main].multipleaddResource.length;i++){
        if(this.addResource[main].multipleaddResource[i].multipletentativeEnd==undefined ||
           this.addResource[main].multipleaddResource[i].multipletentativeEnd==null){
          this.addResource[main].multipleaddResource[i].multipletentativeEndError=true 
          Status = true
          break;
        }
        else
        Status  = false
      }
    // }
    if(gfStatus|| fStatus|| Status){
      stat = false;
    }
    else
    stat = true;
    if (stat) {
      this.addResource[main].multipleaddResource.push({
        resourceNameId: undefined, multipletentativeStart: undefined, multipletentativeStartError: false,
        multipletentativeEnd: undefined,ovrAlloctnButton:undefined,overallocationmes:undefined,user_allocated : undefined, multipletentativeEndError: false, multipleallocationUnit: (this.getSetting.resource_allocation_unit  === "Percentage")?2:1 , multipleallocation: undefined, allocationId: undefined, mulInHourSel: undefined,
        multipleallocError: false,checkedresAllocation:(this.getSetting.resource_allocation_unit  === "Percentage")?[1]:[0]
      })
    }


    for (let j = 0; j < this.addResource[main].multipleaddResource.length; j++) {
      this.addResource[main].multipleaddResource[j].resourceNameId = this.addResource[main].resourceNameId;
    }
    if (this.addResource[main].multipleaddResource.length > 1) {
      this.addResource[main].count = true;
    }
    else {
      this.addResource[main].count = false;
    }
 }

  submit() {
  if (this.addResource.length == 1) {
      this.startValue = true;
      this.endDatachange = true;
    }
    let cstat : boolean = false
    for (let i = 0; i < this.addResource.length; i++) {
      if(this.addResource[i].repeatUser){
        cstat= true
        break;

      }else
      cstat= false

    }
    let dstat : boolean = false

    for (let i = 0; i < this.addResource.length; i++) {
      if(this.addResource[i].resourceName=='' ||this.addResource[i].resourceName==undefined ||this.addResource[i].resourceName==null){
        dstat= true
        break;

      }else
      dstat= false

    }

    let estat : boolean = false

    for (let i = 0; i < this.addResource.length; i++) {
      if(this.addResource[i].projectRole==null ||this.addResource[i].projectRole==undefined || this.addResource[i].projectRole==''){
        estat= true
        break;

      }else
      estat= false

    }
    let fstat : boolean = false

    for (let i = 0; i < this.addResource.length; i++) {
      if(this.addResource[i].type == null ||this.addResource[i].type == undefined || this.addResource[i].type == '' ){
        fstat= true
        break;

      }else
      fstat= false

    }
    let mstat : boolean = false
    for (let i = 0; i < this.addResource.length; i++) {
      if(!this.addResource[i].tentativeStart ||this.addResource[i].tentativeStartError){
        mstat= true
        break;

      }else
      mstat= false

    }
    let kstat : boolean = false
    for (let i = 0; i < this.addResource.length; i++) {
      if(!this.addResource[i].tentativeEnd ||this.addResource[i].tentativeEndError){
        kstat= true
        break;

      }else
      kstat= false

    }
    let gstat : boolean = false
    for (let i = 0; i < this.addResource.length; i++) {
      if(this.addResource[i].allocation == null||this.addResource[i].allocation == undefined||this.addResource[i].allocation == '' ){
        gstat= true
        break;

      }else
      gstat= false

    }

    let gfStatus : boolean = false
    let Status   : boolean = false
    let fStatus  : boolean = false

    for (let j = 0; j < this.addResource.length; j++) {
      for(let i=0;i<this.addResource[j].multipleaddResource.length;i++){
        if(this.addResource[j].multipleaddResource[i].multipleallocation==undefined ||
           this.addResource[j].multipleaddResource[i].multipleallocation==null
          ){
          this.addResource[j].multipleaddResource[i].multipleallocError = true 
          this.addResource[j].allocation = null
          gfStatus = true
          break;
        }
        else
        gfStatus  = false
      }
  
      for(let i=0;i<this.addResource[j].multipleaddResource.length;i++){
        if(this.addResource[j].multipleaddResource[i].multipletentativeStart==undefined ||
           this.addResource[j].multipleaddResource[i].multipletentativeStart==null){
          this.addResource[j].multipleaddResource[i].multipletentativeStartError=true 
          fStatus = true
          break;
        }
        else
        fStatus  = false
      }
  
      for(let i=0;i<this.addResource[j].multipleaddResource.length;i++){
        if(this.addResource[j].multipleaddResource[i].multipletentativeEnd==undefined ||
           this.addResource[j].multipleaddResource[i].multipletentativeEnd==null){
          this.addResource[j].multipleaddResource[i].multipletentativeEndError=true 
          Status = true
          break;
        }
        else
        Status  = false
      }
    }
    if(gfStatus|| fStatus|| Status)
    this.splitError =true
    else
    this.splitError =false

    if (dstat || gfStatus|| fStatus|| Status||  cstat|| estat || fstat || mstat || kstat|| gstat) {
      this.allocationError = true;
    }
    else {
      this.tmpAllocation = [];
      for (let i = 0; i < this.addResource.length; i++) {

        this.tmpAllocation.push({
          "id": this.addResource[i].resourceNameId,
          "role": this.addResource[i].projectRoleId,
          "billable": this.addResource[i].typeId,
          "allocation": []
        });
      }
      for (let i = 0; i < this.addResource.length; i++) {
        for (let j = 0; j < this.addResource[i].multipleaddResource.length; j++) {
          for (let k = 0; k < this.tmpAllocation.length; k++) {
            if (this.tmpAllocation[k].id == this.addResource[i].multipleaddResource[j].resourceNameId) {
              this.tmpAllocation[k].allocation.push({
                "alloc_id": (this.addResource[i].multipleaddResource[j].allocationId) ? this.addResource[i].multipleaddResource[j].allocationId : "",
                "from": this.formatForApi2(this.addResource[i].multipleaddResource[j].multipletentativeStart),
                "to": this.formatForApi2(this.addResource[i].multipleaddResource[j].multipletentativeEnd),
                "hour_or_per": this.addResource[i].multipleaddResource[j].multipleallocation,
                "term": this.addResource[i].multipleaddResource[j].multipleallocationUnit
              })
            }

          }
        }
      }
      let obj;
      obj = {
        "project_id": this.routeActive.snapshot.params['pr_id'],
        'over_allocation_overide':this.overAllocationValue,
        "project_allocations": this.tmpAllocation
      }
      this.loaderActionsService.display(true);
      this.resourceAllocationService.allocationData(obj, res => {
        if (res.status == "OK") {
          this.overAllocationValue = false;
          this.loaderActionsService.display(false);
          let self = this;
          setTimeout(function () {
            self.notificationService.alertBoxValue("success", res.message);
          });
          if (localStorage.getItem("editProjectSection") === null) {
            this.locations.navigate(['/modules/projects/project-list']);
          }
          if (localStorage.getItem('editProjectSection')) {
            let value = localStorage.getItem('editProjectSection')
            if (value == 'resourceInfo') {
              this.locations.navigate(['/modules/projects/project-detail/' + this.routeActive.snapshot.params['pr_id']])
            }
          }
        }
        else if(res.status=='FAIL' &&res.allocationValidation&&res.allocationValidation.confirmation=='true'  ) {
          this.loaderActionsService.display(false);
          this.tmpAllocation = [];
          this.confirmBoxMaincancel = true;
          this.configMain = res.allocationValidation.message
        }
        else if(res.status=='FAIL' &&res.allocationValidation&&res.allocationValidation.confirmation=='false'  ) {
          this.loaderActionsService.display(false);
          this.tmpAllocation = [];
          let self = this;
          setTimeout(function () {
            self.notificationService.alertBoxValue("error", res.allocationValidation.message);
          });
        }
        else if(res.status=='FAIL'){
          if(res.allocationValidation&&res.allocationValidation.message)
          this.notificationService.alertBoxValue("error", res.allocationValidation.message);
          else if(res.message&& !("allocationValidation" in res))
          this.notificationService.alertBoxValue("error", res.message.message);
          this.loaderActionsService.display(false);
          this.tmpAllocation = [];

        }
      });
    }
  }
  getCancelMainConfirm(event){
    this.confirmBoxMaincancel = false;
    if (event == true) {
      this.overAllocationValue = true;
      this.submit()
    }
  }
  allocationDelete(data, i) {
    this.index1 = i;
    if (this.addResource.length > 1) {
      this.confirmBox1 = true;
    }

  }
  confirmPopup1(ev) {
    if (ev) {
      this.startValue = true;
      this.endDatachange = true;
      this.addResource.splice(this.index1, 1);
      this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))

      this.confirmBox1 = false;
    }
    else {
      this.confirmBox1 = false;
    }
  }
  confirmPopup2(ev) {
    if (ev) {
      this.confirmBox2 = false;
      this.locations.navigate(['/modules/projects/project-list']);
    }
    else {
      this.confirmBox2 = false;
    }
  }
  removeMultipleResourceAllocation(data, i, j) {
  this.multAllocEndtData  = true;
  this.multAllocStartData = true;
  this.multipleAllocData  = true;

  this.addResource[i].multipleaddResource.splice(j, 1);


    if (this.addResource[i].multipleaddResource.length > 1) {
      this.addResource[i].count = true;
    }
    else {
      this.addResource[i].count = false;
    }
  }
  splitWorkPopUp(data, index) {
    for (let i = 0; i < this.addResource.length; i++) {
      if (this.addResource[i].resourceNameId == data.resourceNameId && this.addResource[i].resourceNameId && this.addResource[i].tentativeEnd) {
        this.addResource[i].editSplit = true;
      }
      else {
        this.addResource[i].editSplit = false;
       }
      }
  }
  endDateChange(event, i,dateFrom,dateTo) {
    if (event) {
      this.endDatachange = true;
      this.addResource[i].tentativeEnd = event;
      if (!this.addResource[i]['multipleaddResource']) {
        this.addResource[i]['multipleaddResource'] = [];

        this.addResource[i].multipleaddResource = [{
          resourceNameId: undefined, multipletentativeStart: undefined, multipletentativeStartError: false,
          multipletentativeEnd: undefined, multipletentativeEndError: false, multipleallocationUnit: undefined, multipleallocation: undefined, allocationId: undefined
        }]
        this.addResource[i].multipleaddResource[0].multipletentativeStart = this.addResource[i].tentativeStart;
        this.addResource[i].multipleaddResource[0].multipletentativeEnd = this.addResource[i].tentativeEnd;
        this.addResource[i].multipleaddResource[0].resourceNameId = this.addResource[i].resourceNameId;
        this.addResource[i].multipleaddResource[0].multipleallocationUnit = this.addResource[i].allocationUnit;
        this.addResource[i].multipleaddResource[0].multipleallocation = this.addResource[i].allocation;
        
      }

      if(this.timeZone.toLocal(dateFrom)>=this.timeZone.toLocal( dateTo)){
        this.addResource[i].tentativeEnd = this.addResource[i].tentativeStart;
      }
      this.addResource[i].multipleaddResource[0].multipletentativeEnd = event;
      this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))

    }
    else {
      this.endDatachange = false;
    }
  }
  

  getCancelConfirm(event){
      this.confirmBoxcancel = false;
      if (event == true) {
        this.cancelPop()
      }
  }
  cancelPop(){
    let data = this.cancelData;
    let index = this.cancelIndex
    let temp  =   this.tmpAllocationSub[index].multipleaddResource.length
    this.multipleAllocation=false;

    if(temp!==this.addResource[index].multipleaddResource.length){
      this.addResource[index].multipleaddResource.length      = temp ;
      this.addResource[index].multipleaddResource =  this.addResource[index].multipleaddResource.filter(function (el) {
        return el != null;
      });
    }
    this.addResource[index].multipleaddResource = Object.assign([], this.tmpAllocationSub[index].multipleaddResource);
    for(let j=0;j<this.addResource[index].multipleaddResource.length;j++){
      this.addResource[index].multipleaddResource[j].multipletentativeStart      =    new Date( this.addResource[index].multipleaddResource[j].multipletentativeStart)
      this.addResource[index].multipleaddResource[j].multipletentativeEnd        =    new Date( this.addResource[index].multipleaddResource[j].multipletentativeEnd )
      this.addResource[index].multipleaddResource[j].multipleallocation          =     this.addResource[index].multipleaddResource[j].prevhour_or_per 
      this.addResource[index].multipleaddResource[j].multipleallocationUnit      =     this.addResource[index].multipleaddResource[j].prevterm 
      this.addResource[index].multipleaddResource[j].multipletentativeStartError= false;
      this.addResource[index].multipleaddResource[j].multipleallocError=false
      this.addResource[index].multipleaddResource[j].multipletentativeEndError= false;
    }

    for(let j=0;j<this.addResource[index].multipleaddResource.length;j++){
      if( Number(this.addResource[index].multipleaddResource[j].multipleallocationUnit) == 1 ){
        for (let k = 0; k < this.maxAllocation.length; k++) {
            if (this.addResource[index].multipleaddResource[j].multipleallocation  == this.maxAllocation[k].id) {
              this.addResource[index].multipleaddResource[j].mulInHourSel = [k];
              this.addResource[index].multipleaddResource[j].checkedresAllocation = [0];
            }               
        }
      }

        else{
          for (let k = 0; k < this.Percentage.length; k++) {
          if (this.addResource[index].multipleaddResource[j].multipleallocation == this.Percentage[k].value) {
            this.addResource[index].multipleaddResource[j].mulInHourSel = [k];
             this.addResource[index].multipleaddResource[j].checkedresAllocation = [1];
            }
        }
      }
    }



    this.addResource[index].editSplit = false;
    if (this.addResource[index].multipleaddResource.length > 1) {
      this.addResource[index].count = true;
    }
    else {
      this.addResource[index].count = false;
    }
    this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))

  }
  cancelsplitWorkPopUp(data, i) { 
  this.cancelData = data;
  this.cancelIndex = i;
  this.confirmBoxcancel   = true;
  }
  
  formatForApi2(inputDate) {
    var date = this.timeZone.toLocal(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
      }
      else
        return undefined;
  }

  saveMultipleAllocation(index){
    this.lazyloader=true;
    this.mainIndex = index
    let gfStatus: boolean =false
    for(let i=0;i<this.addResource[index].multipleaddResource.length;i++){
      if(this.addResource[index].multipleaddResource[i].multipleallocation==undefined || this.addResource[index].multipleaddResource[i].multipleallocation==null
        ){
        this.addResource[index].multipleaddResource[i].multipleallocError = true 
        this.addResource[index].allocation = null
        gfStatus = true
        break;
      }
      else
      gfStatus  = false
    }

    let fStatus: boolean =false
    for(let i=0;i<this.addResource[index].multipleaddResource.length;i++){
      if(this.addResource[index].multipleaddResource[i].multipletentativeStart==undefined || this.addResource[index].multipleaddResource[i].multipletentativeStart==null){
        this.addResource[index].multipleaddResource[i].multipletentativeStartError=true 
        fStatus = true
        break;
      }
      else
      fStatus  = false
    }

    let Status: boolean =false
    for(let i=0;i<this.addResource[index].multipleaddResource.length;i++){
      if(this.addResource[index].multipleaddResource[i].multipletentativeEnd==undefined || this.addResource[index].multipleaddResource[i].multipletentativeEnd==null){
        this.addResource[index].multipleaddResource[i].multipletentativeEndError=true 
        Status = true
        break;
      }
      else
      Status  = false
    }

    if( fStatus || Status || gfStatus){
      this.multipleAllocation=true;
      this.addResource[index].editSplit = true;
      this.lazyloader=false;

    }
    else{
      this.tmpAllocation = {};
        this.tmpAllocation={
          "user_id": this.addResource[index].resourceNameId,
         "prjt_id" : this. projectId,
          'allocation':[]
        };
      for (let i = 0; i < this.addResource.length; i++) {
        for (let j = 0; j < this.addResource[i].multipleaddResource.length; j++) {
            if (this.addResource[index].resourceNameId == this.addResource[i].multipleaddResource[j].resourceNameId) {
              this.tmpAllocation.allocation.push({
                "from": this.formatForApi2(this.addResource[i].multipleaddResource[j].multipletentativeStart),
                "to": this.formatForApi2(this.addResource[i].multipleaddResource[j].multipletentativeEnd),
                "hour_or_per": this.addResource[i].multipleaddResource[j].multipleallocation,
                "term": this.addResource[i].multipleaddResource[j].multipleallocationUnit
              })
            }
        }
      }
      this.resourceAllocationService.getSave(this.tmpAllocation,res=>{
        if(res.status =='OK'){

          for(let j=0;j<this.addResource[index].multipleaddResource.length;j++){
            this.addResource[index].multipleaddResource[j].prevFromDate       =   this.addResource[index].multipleaddResource[j].multipletentativeStart ;
            this.addResource[index].multipleaddResource[j].prevToDate         =   this.addResource[index].multipleaddResource[j].multipletentativeEnd ;
            this.addResource[index].multipleaddResource[j].prevterm           =   this.addResource[index].multipleaddResource[j].multipleallocationUnit ;
            this.addResource[index].multipleaddResource[j].prevhour_or_per    =   this.addResource[index].multipleaddResource[j].multipleallocation ;
          if(j ==0){
            this.addResource[index].tentativeStart =  this.addResource[index].multipleaddResource[j].multipletentativeStart ;
            this.addResource[index].tentativeEnd   =  this.addResource[index].multipleaddResource[j].multipletentativeEnd ;
            this.addResource[index].allocation     =  this.addResource[index].multipleaddResource[j].multipleallocation ;
            this.addResource[index].allocationUnit     =  this.addResource[index].multipleaddResource[j].multipleallocationUnit;
            if( Number(this.addResource[index].multipleaddResource[j].multipleallocationUnit)==1){
              this.addResource[index].checkedresAllocation = [0];
            }else{
              this.addResource[index].checkedresAllocation = [1];

            }
          }     
        }

          if( Number(this.addResource[index].multipleaddResource[0].multipleallocationUnit) == 1 ){
            for (let k = 0; k < this.maxAllocation.length; k++) {
                if (this.addResource[index].multipleaddResource[0].multipleallocation  == this.maxAllocation[k].id) {
                  this.addResource[index].inHourSel = [k];
                  break;
                }               
            }
          }else{
            for (let k = 0; k < this.Percentage.length; k++) {
              if (this.addResource[index].multipleaddResource[0].multipleallocation  == this.Percentage[k].value) {
                this.addResource[index].inHourSel = [k];
                break;
              }               
            } 
          }

          for(let j=0;j<this.addResource[index].multipleaddResource.length;j++){
            if( Number(this.addResource[index].multipleaddResource[j].multipleallocationUnit) == 1 ){
              for (let k = 0; k < this.maxAllocation.length; k++) {
                  if (this.addResource[index].multipleaddResource[j].multipleallocation  == this.maxAllocation[k].id) {
                    this.addResource[index].multipleaddResource[j].mulInHourSel = [k];
                    this.addResource[index].multipleaddResource[j].checkedresAllocation = [0];
                  }               
              }
            }
      
              else{
                for (let k = 0; k < this.Percentage.length; k++) {
                if (this.addResource[index].multipleaddResource[j].multipleallocation == this.Percentage[k].value) {
                  this.addResource[index].multipleaddResource[j].mulInHourSel = [k];
                   this.addResource[index].multipleaddResource[j].checkedresAllocation = [1];
                  }
              }
            }
          }

            this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))

          setTimeout(() => {
            this.lazyloader= false;
             this.notificationService.alertBoxValue("success",res.message);
            this.addResource[index].editSplit = false;
          }, 500);
        }else if(res.status=='FAIL'&& res.message && res.message.confirmation=='true' ){

          this.confirmBox  = true;
          this.config      = res.message.message
          this.lazyloader  = false;
        }else if(res.status=='FAIL'&& res.message && res.message.confirmation=='false'){      
            for(let j=0;j<this.addResource[index].multipleaddResource.length;j++){
              this.addResource[index].multipleaddResource[j].prevFromDate       =   this.addResource[index].multipleaddResource[j].multipletentativeStart ;
              this.addResource[index].multipleaddResource[j].prevToDate         =   this.addResource[index].multipleaddResource[j].multipletentativeEnd ;
              this.addResource[index].multipleaddResource[j].prevterm           =   this.addResource[index].multipleaddResource[j].multipleallocationUnit ;
              this.addResource[index].multipleaddResource[j].prevhour_or_per    =   this.addResource[index].multipleaddResource[j].multipleallocation ;
            if(j ==0){
              this.addResource[index].tentativeStart =  this.addResource[index].multipleaddResource[j].multipletentativeStart ;
              this.addResource[index].tentativeEnd   =  this.addResource[index].multipleaddResource[j].multipletentativeEnd ;
              this.addResource[index].allocation     =  this.addResource[index].multipleaddResource[j].multipleallocation ; 
             this.addResource[index].allocationUnit     =  this.addResource[index].multipleaddResource[j].multipleallocationUnit;
            if( Number(this.addResource[index].multipleaddResource[j].multipleallocationUnit)==1){
              this.addResource[index].checkedresAllocation = [0];
            }else{
              this.addResource[index].checkedresAllocation = [1];

               }
             }   
            }
            if( Number(this.addResource[index].multipleaddResource[0].multipleallocationUnit) == 1 ){
              for (let k = 0; k < this.maxAllocation.length; k++) {
                  if (this.addResource[index].multipleaddResource[0].multipleallocation  == this.maxAllocation[k].id) {
                    this.addResource[index].inHourSel = [k];
                    break;
                  }               
              }
            }else{
              for (let k = 0; k < this.Percentage.length; k++) {
                if (this.addResource[index].multipleaddResource[0].multipleallocation  == this.Percentage[k].value) {
                  this.addResource[index].inHourSel = [k];
                  break;
                }               
              } 
            }
  
            for(let j=0;j<this.addResource[index].multipleaddResource.length;j++){
              if( Number(this.addResource[index].multipleaddResource[j].multipleallocationUnit) == 1 ){
                for (let k = 0; k < this.maxAllocation.length; k++) {
                    if (this.addResource[index].multipleaddResource[j].multipleallocation  == this.maxAllocation[k].id) {
                      this.addResource[index].multipleaddResource[j].mulInHourSel = [k];
                      this.addResource[index].multipleaddResource[j].checkedresAllocation = [0];
                    }               
                }
              }
        
                else{
                  for (let k = 0; k < this.Percentage.length; k++) {
                  if (this.addResource[index].multipleaddResource[j].multipleallocation == this.Percentage[k].value) {
                    this.addResource[index].multipleaddResource[j].mulInHourSel = [k];
                     this.addResource[index].multipleaddResource[j].checkedresAllocation = [1];
                    }
                }
              }
            }
  
            this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))  
          setTimeout(() => {
            this.lazyloader   = false;
            this.notificationService.alertBoxValue("error",res.message.message); 
            this.addResource[index].editSplit = false;
          }, 500)
        }else if(res.status=='FAIL'){
          this.lazyloader= false;
          if(res.message && res.message.message)
          this.notificationService.alertBoxValue("error",res.message.message);
          else if (res.message &&! res.message.message)
          this.notificationService.alertBoxValue("error",res.message);

        }
      })
    }
  }

  getPopupConfirm(event){
    this.confirmBox = false;
    if(event == true){
      for(let j=0;j<this.addResource[this.mainIndex].multipleaddResource.length;j++){
        this.addResource[this.mainIndex].multipleaddResource[j].prevFromDate       =   this.addResource[this.mainIndex].multipleaddResource[j].multipletentativeStart ;
        this.addResource[this.mainIndex].multipleaddResource[j].prevToDate         =   this.addResource[this.mainIndex].multipleaddResource[j].multipletentativeEnd ;
        this.addResource[this.mainIndex].multipleaddResource[j].prevterm           =   this.addResource[this.mainIndex].multipleaddResource[j].multipleallocationUnit ;
        this.addResource[this.mainIndex].multipleaddResource[j].prevhour_or_per    =   this.addResource[this.mainIndex].multipleaddResource[j].multipleallocation ;
        if(j ==0){
        this.addResource[this.mainIndex].tentativeStart =  this.addResource[this.mainIndex].multipleaddResource[j].multipletentativeStart ;
        this.addResource[this.mainIndex].tentativeEnd   =  this.addResource[this.mainIndex].multipleaddResource[j].multipletentativeEnd ;
        this.addResource[this.mainIndex].allocation     =  this.addResource[this.mainIndex].multipleaddResource[j].multipleallocation ; 
        this.addResource[this.mainIndex].allocationUnit     =  this.addResource[this.mainIndex].multipleaddResource[j].multipleallocationUnit;
        if( Number(this.addResource[this.mainIndex].multipleaddResource[j].multipleallocationUnit)==1){
          this.addResource[this.mainIndex].checkedresAllocation = [0];
        }else{
          this.addResource[this.mainIndex].checkedresAllocation = [1];

           }
      }    
      }
    if( Number(this.addResource[this.mainIndex].multipleaddResource[0].multipleallocationUnit) == 1 ){
      for (let k = 0; k < this.maxAllocation.length; k++) {
          if (this.addResource[this.mainIndex].multipleaddResource[0].multipleallocation  == this.maxAllocation[k].id) {
            this.addResource[this.mainIndex].inHourSel = [k];
            break;
          }               
      }
    }else{
      for (let k = 0; k < this.Percentage.length; k++) {
        if (this.addResource[this.mainIndex].multipleaddResource[0].multipleallocation  == this.Percentage[k].value) {
          this.addResource[this.mainIndex].inHourSel = [k];
          break;
        }               
      } 
    }

    for(let j=0;j<this.addResource[this.mainIndex].multipleaddResource.length;j++){
      if( Number(this.addResource[this.mainIndex].multipleaddResource[j].multipleallocationUnit) == 1 ){
        for (let k = 0; k < this.maxAllocation.length; k++) {
            if (this.addResource[this.mainIndex].multipleaddResource[j].multipleallocation  == this.maxAllocation[k].id) {
              this.addResource[this.mainIndex].multipleaddResource[j].mulInHourSel = [k];
              this.addResource[this.mainIndex].multipleaddResource[j].checkedresAllocation = [0];
            }               
        }
      }

        else{
          for (let k = 0; k < this.Percentage.length; k++) {
          if (this.addResource[this.mainIndex].multipleaddResource[j].multipleallocation == this.Percentage[k].value) {
            this.addResource[this.mainIndex].multipleaddResource[j].mulInHourSel = [k];
             this.addResource[this.mainIndex].multipleaddResource[j].checkedresAllocation = [1];
            }
        }
      }
    }

    this.tmpAllocationSub = JSON.parse(JSON.stringify(this.addResource))
    this.addResource[this.mainIndex].editSplit = false;
    this.notificationService.alertBoxValue("success",'Allocation Saved Successfully'); 
    }
  }
  ngOnDestroy(){

  }
    
}

