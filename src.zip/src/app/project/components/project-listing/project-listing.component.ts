import { Component, OnInit, ElementRef, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { ProjectAddService } from '../../service/project-add/project-add.service';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';
@Component({
  selector: 'app-project-listing',
  templateUrl: './project-listing.component.html',
  styleUrls: ['../../../../assets/content/css/recruitment.css']
})
export class ProjectListingComponent implements OnInit {
  @ViewChild('foc') inputEl: ElementRef;
  projectStatus: any = [{ "value": "New", "name": 1 }, { "value": "In Progress", "name": 2 }, { "value": "Completed", "name": 3 }, { "value": "On Hold", "name": 4 }, { "value": "Withdrawn", "name": 5 }];
  projectType: any = [{ "value": "Confirmed", "name": 1 }, { "value": "Lead", "name": 2 }]
  projectData: any = [];
  listCustomer: any=[]
  projectMaster: any=[];
  recordsPerPage: number = 10;
  currentPage: number=1;
  totalRecords: number;
  queryObject: any = {};
  searchD: any;
  selcatType: any;
  selStatus: any;
  deleteProj: any;
  selcusName: any;
  currentProId: any;
  maxdate           : any;
  selectProjectType: any;
  selectCustomerType: any;
  userData: any;
  currentStatusId: any;
  currentId: any;
  selectStatus: any;
  searchKeyword: any = "";
  filterActive: boolean=false;
  showAdvanceFilter: boolean= false;
  confirmBoxDelete: boolean= false;
  searchTextBox: boolean = false;
  adminRole: boolean = false;
  alocationPermission: boolean = false;
  editProjectPermission: boolean = false;
  projectStatusPermission: boolean = false;
  userPermission: boolean = false;
  statusIconRemove: boolean = false;
  constructor(
    private projectAddService: ProjectAddService,
    private loaderActionsService: LoaderActionsService,
    private notificationService: NotificationService,
    private AclVerificationService:AclVerificationService,
    private router: Router,
    private cookieService: CookieService) { }

  ngOnInit() {
    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    this.currentPage = 1;
    this.queryObject.page_limit = this.recordsPerPage;
    this.queryObject.page = this.currentPage;
    this.projectList();
    this.getMasters();
    this.getcustomerData();
    this.adminRole = this.AclVerificationService.checkAclDummy('project-management');
    this.alocationPermission = this.AclVerificationService.checkAclDummy('project-allocation');
    this.editProjectPermission = this.AclVerificationService.checkAclDummy('project-edit');
    this.projectStatusPermission = this.AclVerificationService.checkAclDummy('project-status-change');
    this.userData = JSON.parse(this.cookieService.get("user-data"));
    
  }
  projectList(){
    this.loaderActionsService.display(true);
    this.projectAddService.listprojectData(this.queryObject,res => {
      if (res.status == "OK") {
        this.projectData=res.data;
        this.totalRecords = res.count;
        this.currentPage = this.queryObject.page;
        this.loaderActionsService.display(false);
        if(this.adminRole || this.editProjectPermission || this.alocationPermission || this.projectStatusPermission){
          this.userPermission=true;
        }
        else{
          this.userPermission=false
        }
        for(let i=0;i<this.projectData.length;i++){
          if((this.alocationPermission && this.projectData[i].prjt_manager == this.userData.user_id) || this.adminRole){
            this.projectData[i].statusIconRemove=true
          }
          else{
            this.projectData[i].statusIconRemove=false
          }
        }
   
        // let self = this;
        // setTimeout(function () {
        //   self.notificationService.alertBoxValue("success", res.message);
        // });
        // this.locations.navigate(['/modules/customer/customer-list']);
      }
      else {
        this.loaderActionsService.display(false);
        this.projectData=[];
        // this.notificationService.alertBoxValue("error", res.message);
      }
    });
  }
  showStausData(items){
    if(items){
      
      for(let i=0;i<this.projectData.length;i++){
        if(items.id == this.projectData[i].id){
          this.projectData[i].showDiv=true;
        }else{
          this.projectData[i].showDiv=false;
        }
      }
      
    }
  }
  getMasters() {
    this.projectAddService.getMaster(res => {
      if (res.status == "OK") {
        this.projectMaster = res.data;
      }
      else {
        this.projectMaster = [];
      }
    });
  }
  getCustomerList(event) {
    this.currentPage = event;
    this.queryObject['page'] = this.currentPage;
    this.projectList();
  }
  getpage(event) {
    if (event > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      this.queryObject['page'] = this.currentPage
      this.queryObject['page_limit'] = this.recordsPerPage
      this.projectList();

    }
  }
  inputfocus() {
    setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
  }
  searchList(keyword){
    if (this.searchKeyword || this.searchD.trim() != '') {
      this.searchKeyword = keyword;
      // this.queryObject.page = 1;
      this.queryObject['page'] = 1;
      this.queryObject.keyword = this.searchKeyword ? this.searchKeyword : '';
      this.projectList();

    }
  }
  addCustomer() {
    this.router.navigate(['/modules/projects/add-project']);
  }
  selectedProjectType(event){
    if (event && event.selected && event.selected.length) {
      let x = [];
      for (let i = 0; i < this.projectMaster.prjt_types.length; i++) {
        for (var j = 0; j < event.selected.length; j++) {
          if (this.projectMaster.prjt_types[i].id == event.selected[j].id) {
            x.push(this.projectMaster.prjt_types[i].id);
          }
        }
      }
      this.currentProId = x + '';
      this.queryObject.prjtType = this.currentProId;
    }
    else {
      this.queryObject.prjtType = null;
    }
  }
  selectedCusName(event){
    if (event && event.selected && event.selected.length) {
      let x = [];
      for (let i = 0; i < this.listCustomer.length; i++) {
        for (var j = 0; j < event.selected.length; j++) {
          if (this.listCustomer[i].id == event.selected[j].id) {
            x.push(this.listCustomer[i].id);
          }
        }
      }
      this.currentId = x + '';
      this.queryObject.prjtCust = this.currentId;
    }
    else {
      this.queryObject.prjtCust = null;
    }
  }
  selectedStatus(event){
    if (event && event.selected && event.selected.length) {
      let x = [];
      for (let i = 0; i < this.projectStatus.length; i++) {
        for (var j = 0; j < event.selected.length; j++) {
          if (this.projectStatus[i].name == event.selected[j].name) {
            x.push(this.projectStatus[i].name);
          }
        }
      }
      this.currentStatusId = x + '';
      this.queryObject.prjtStat = this.currentStatusId;
    }
    else {
      this.queryObject.prjtStat = null;
    }
  }
  filterApply(){
    if (this.selcatType && this.selcatType.selected && this.selcatType.selected.length || this.selcusName && this.selcusName.selected && this.selcusName.selected.length || this.selStatus && this.selStatus.selected && this.selStatus.selected.length ) {
      this.filterActive = true;
      this.showAdvanceFilter = false;
      this.queryObject.page = 1;
      // this.addTimeSheet = [];
      this.projectList();
      
    }
  }
  filterCancel(){
    if (this.selcatType && this.selcatType.selected && this.selcatType.selected.length || this.selcusName && this.selcusName.selected && this.selcusName.selected.length || this.selStatus && this.selStatus.selected && this.selStatus.selected.length ) {
      this.queryObject['page'] = 1;
      this.filterActive = false;
      this.queryObject.prjtType = null;
      this.queryObject.prjtCust = null;
      this.queryObject.prjtStat = null;
      this.selectProjectType = [];
      this.selectCustomerType = [];
      this.selectStatus = [];
      this.projectList();
    }
  }
  editProject(pr_id){
    localStorage.removeItem('editProjectSection');
    this.router.navigate(['/modules/projects/add-project/' + pr_id]);
  }
  deleteProject(){
    this.confirmBoxDelete=false;
    this.loaderActionsService.display(true);
    this.projectAddService.deleteproject(this.deleteProj, res => {
      this.loaderActionsService.display(false);
      if (res.status == "OK") {
        this.queryObject.page = 1;
        this.projectList();
       
        this.notificationService.alertBoxValue("success", res.message);
      }
      else {
        this.notificationService.alertBoxValue("success", res.message);
      }
    });
  }
  changeStatus(statusId,proj_id){
    this.loaderActionsService.display(true);
    let arrObj = {
      "prjt_status": statusId
    }
    this.projectAddService.ProjectStatus(proj_id,arrObj, res => {
      if (res.status == "OK") {
        this.loaderActionsService.display(false);
        this.projectList();
          this.notificationService.alertBoxValue("success", res.message);
      }
      else {
        this.loaderActionsService.display(false);

        this.notificationService.alertBoxValue("error", res.message);
      }
    });
  }
  getcustomerData(){
    this.loaderActionsService.display(true);
    this.projectAddService.getcustomerData(res => {
      if (res.status == "OK") {
        this.loaderActionsService.display(false);
        this.listCustomer=res.data;
         
      }
      else {
        this.listCustomer=[];
        this.loaderActionsService.display(false);
      }
    });
  }
  ProjectAllocation(pr_id){
    localStorage.removeItem('editProjectSection');
    this.router.navigate(['/modules/projects/resource-allocation/'+ pr_id]);
  }
  viewProjectDetails(proj_id){
    this.router.navigate(['/modules/projects/project-detail/'+ proj_id]);
  }
}
