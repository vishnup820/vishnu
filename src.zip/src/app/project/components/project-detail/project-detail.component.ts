import { Component, OnInit, ElementRef, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { ProjectAddService } from '../../service/project-add/project-add.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';
@Component({
  selector: 'app-project-detail',
  templateUrl: './project-detail.component.html',
  styleUrls: ['../../../../assets/content/css/training-listing.css','../../../../assets/content/css/recruitment.css']
})
export class ProjectDetailComponent implements OnInit {
  pageStatus: boolean=false;
  public scrollbarOptionsForCalenderTwo: any;
  public scrollbarOptionsForCalenderOne: any;
  scrollLeft: boolean = false;
  scrollEnd: boolean = false;
  whileScroll: boolean = false;
  onescrollLeft: boolean = false;
  bottomspace: boolean = false;
  onescrollEnd: boolean = false;
  onewhileScroll: boolean = false;
  duplicateTool: any =[];
  subDuplicateTool: any =[];
  projData: any=[];
  userData: any;
  adminRole: boolean = false;
  alocationPermission: boolean = false;
  editProjectPermission: boolean = false;
  constructor(private timeZone: TimezoneDetailsService,
    private projectAddService: ProjectAddService,
    private loaderActionsService: LoaderActionsService,
    private notificationService: NotificationService,
    private locations: Router,
    private routeActive: ActivatedRoute,
    private chRef: ChangeDetectorRef,
    private AclVerificationService:AclVerificationService,
    private cookieService: CookieService) {
      let   self = this;
      this.scrollbarOptionsForCalenderTwo = {
        axis: 'y', scrollInertia: 0, theme: 'dark', autoHideScrollbar: false, scrollButtons: { enable: true },
        callbacks: {
          onTotalScroll: function () {
            self.scrollEnd = true;
            self.chRef.detectChanges();
          },
          whileScrolling: function (this) {
            self.scrollLeft = false;
            self.scrollEnd = false;
            self.whileScroll = true;
            self.chRef.detectChanges();
          },
          onTotalScrollBack: function () {
            self.scrollLeft = true;
            self.chRef.detectChanges();
          }
        }
      }
      this.scrollbarOptionsForCalenderOne = {
        axis: 'x', scrollInertia: 0, theme: 'dark', autoHideScrollbar: false, scrollButtons: { enable: true },
        callbacks: {
          onTotalScroll: function () {
            self.onescrollEnd = true;
            self.chRef.detectChanges();
          },
          whileScrolling: function (this) {
            self.onescrollLeft = false;
            self.onescrollEnd = false;
             self.onewhileScroll = true;
            self.chRef.detectChanges();
          },
          onTotalScrollBack: function () {
            self.onescrollLeft = true;
            self.chRef.detectChanges();
          }
        }
      }
     }

  ngOnInit() {
    this.routeActive.snapshot.params['proj_id'] ? this.pageStatus = false : this.pageStatus = true;
    this.projectData();
    this.adminRole = this.AclVerificationService.checkAclDummy('project-management');
    this.alocationPermission = this.AclVerificationService.checkAclDummy('project-allocation');
    this.editProjectPermission = this.AclVerificationService.checkAclDummy('project-edit');
    this.userData = JSON.parse(this.cookieService.get("user-data"));
  }
  projectData() {
    if (!this.pageStatus) {
      this.loaderActionsService.display(true);
      this.projectAddService.editProjectData(this.routeActive.snapshot.params['proj_id'], res => {
        if (res.status == "OK") {
          this.projData = res.data;
          this.loaderActionsService.display(false);
       //   console.log( this.projData)
        //   for(let i=0;i<this.projData.allocation_data.length;i++){
        //   if(this.projData.allocation_data[i].allocation[0].term==1){
        //     this.projData.allocation_data[i]['alloc_in_hoursStat']="0";
        //   }
        //   else{
        //     this.projData.allocation_data[i]['alloc_in_hoursStat']="1";
        //   }
        // }
          
        }
      });
    }
  }
  bacKToList(){
    this.locations.navigate(['/modules/projects/project-list']);
  }
  editProject(sectionName){
    localStorage.setItem('editProjectSection', sectionName);
  	this.locations.navigate(['/modules/projects/add-project/' +this.routeActive.snapshot.params['proj_id']])
  }
  editResource(sectionName){
    localStorage.setItem('editProjectSection', sectionName);
  	this.locations.navigate(['/modules/projects/resource-allocation/' +this.routeActive.snapshot.params['proj_id']])
  }
  getClassByValue(index) {
    switch (index % 10) {
        case 0: return "default-avatar islamic-green";
        case 1: return "default-avatar limerick";
        case 2: return "default-avatar chilean-fire";
        case 3: return "default-avatar persian-pink";
        case 4: return "default-avatar deep-magenta";
        case 5: return "default-avatar gigas";
        case 6: return "default-avatar endeavour";
        case 7: return "default-avatar dodger-blue";
        case 8: return "default-avatar jordy-blue";
        case 9: return "default-avatar Light-sea-green";
        case 10: return "emp-profileimage";
    }
}
}
