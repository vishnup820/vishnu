import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';
@Injectable({
  providedIn: 'root'
})
export class ProjectToolService {
  apiBaseUrl: string;
  constructor( private http: HttpClient,
    private cookies: CookieService
  ) { this.apiBaseUrl = globalVariables.apiBaseUrl; }



  generateQuery(qobj) {
    let query = `?page=${qobj['page']?qobj['page']: ''}&page_limit=${qobj['page_limit'] ? qobj['page_limit'] : ''}${qobj.keyword ? '&keyword=' + qobj.keyword : ''}${qobj.catId ? '&catId=' + qobj.catId : ''}${qobj.sort ? '&sort=' + qobj.sort : ''}`
    return query;
  }
  gettooltData(qobj, cb) {
    let url: string = this.apiBaseUrl + apiList.projects.toolList;
    url = url + this.generateQuery(qobj);
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  getcategorytData(cb){
    let url: string = this.apiBaseUrl + apiList.projects.gettoolCategory;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  aadCategory(cat_name,cb){
    let url: string = this.apiBaseUrl + apiList.projects.addtoolCategory;
    let promise: any = new Promise((resolve, reject) => {
      this.http.post(url,cat_name)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  addTool(parms,editToolId,cb){
    let url: string = this.apiBaseUrl + apiList.projects.toolList;
    if(editToolId){
      let promise: any = new Promise((resolve, reject) => {
        this.http.put(url + '/' + editToolId,parms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    else{
      let promise: any = new Promise((resolve, reject) => {
        this.http.post(url,parms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
 
  }
  deleteTool(tool_id,cb){
    let url: string = this.apiBaseUrl + apiList.projects.toolList;
    let promise: any = new Promise((resolve, reject) => {
			this.http.delete(url + "/" + tool_id)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
  }
  editToolData(toolEd_id,cb){
    let url: string = this.apiBaseUrl + apiList.projects.toolList;
    let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "/" + toolEd_id)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
  }
}
