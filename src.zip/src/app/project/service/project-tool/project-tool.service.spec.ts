import { TestBed } from '@angular/core/testing';

import { ProjectToolService } from './project-tool.service';

describe('ProjectToolService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProjectToolService = TestBed.get(ProjectToolService);
    expect(service).toBeTruthy();
  });
});
