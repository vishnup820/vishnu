import { TestBed } from '@angular/core/testing';

import { ProjectSettingsService } from './project-settings.service';

describe('ProjectSettingsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProjectSettingsService = TestBed.get(ProjectSettingsService);
    expect(service).toBeTruthy();
  });
});
