import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root'
})
export class MastersService {
  apiBaseUrl: string;
  constructor(private http: HttpClient,
    private cookies: CookieService) { this.apiBaseUrl = globalVariables.apiBaseUrl; }


  
  generateQuery(qobj) {
    let query = `?page=${qobj['page']?qobj['page']: ''}&page_limit=${qobj['page_limit'] ? qobj['page_limit'] : ''}${qobj.keyword ? '&keyword=' + qobj.keyword : ''}${qobj.catId ? '&catId=' + qobj.catId : ''}${qobj.sort ? '&sort=' + qobj.sort : ''}`
    return query;
  }
  // project role
  getprojectRole(qobj, cb) {
    let url: string = this.apiBaseUrl + apiList.projectsMasters.projectRoles;
    url = url + this.generateQuery(qobj);
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  addProjectRole(prms,update_id, cb){
    if(update_id){
      let url: string = this.apiBaseUrl + apiList.projectsMasters.projectRolesAdd;
      let promise: any = new Promise((resolve, reject) => {
        this.http.put(url + '/' + update_id,prms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    else{
      let url: string = this.apiBaseUrl + apiList.projectsMasters.projectRolesAdd;
      let promise: any = new Promise((resolve, reject) => {
        this.http.post(url,prms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }

  }
  deleteProjectRole(del_id, cb){
    let url: string = this.apiBaseUrl + apiList.projectsMasters.deleteProjectRole;
    let promise: any = new Promise((resolve, reject) => {
      this.http.delete(url + "/" + del_id)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  // Resource Type
  getResourceType(qobj, cb) {
    let url: string = this.apiBaseUrl + apiList.projectsMasters.projectResourceType;
    url = url + this.generateQuery(qobj);
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  addResourceType(prms,update_id, cb){
    if(update_id){
      let url: string = this.apiBaseUrl + apiList.projectsMasters.projectResourceTypeAdd;
      let promise: any = new Promise((resolve, reject) => {
        this.http.put(url + '/' + update_id,prms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    else{
      let url: string = this.apiBaseUrl + apiList.projectsMasters.projectResourceTypeAdd;
      let promise: any = new Promise((resolve, reject) => {
        this.http.post(url,prms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }

  }
  deleteResourceType(del_id, cb){
    let url: string = this.apiBaseUrl + apiList.projectsMasters.deleteResourceType;
    let promise: any = new Promise((resolve, reject) => {
      this.http.delete(url + "/" + del_id)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  // Project Type

  getProjectType(qobj, cb) {
    let url: string = this.apiBaseUrl + apiList.projectsMasters.projectType;
    url = url + this.generateQuery(qobj);
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  addProjectType(prms,update_id, cb){
    if(update_id){
      let url: string = this.apiBaseUrl + apiList.projectsMasters.projectTypeAdd;
      let promise: any = new Promise((resolve, reject) => {
        this.http.put(url + '/' + update_id,prms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    else{
      let url: string = this.apiBaseUrl + apiList.projectsMasters.projectTypeAdd;
      let promise: any = new Promise((resolve, reject) => {
        this.http.post(url,prms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }

  }
  deleteProjectType(del_id, cb){
    let url: string = this.apiBaseUrl + apiList.projectsMasters.deleteProjectType;
    let promise: any = new Promise((resolve, reject) => {
      this.http.delete(url + "/" + del_id)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  // Project Duration

  getProjectDuration(qobj, cb) {
    let url: string = this.apiBaseUrl + apiList.projectsMasters.projectDuration;
    url = url + this.generateQuery(qobj);
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  addProjectDuration(prms,update_id, cb){
    if(update_id){
      let url: string = this.apiBaseUrl + apiList.projectsMasters.projectDurationAdd;
      let promise: any = new Promise((resolve, reject) => {
        this.http.put(url + '/' + update_id,prms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    else{
      let url: string = this.apiBaseUrl + apiList.projectsMasters.projectDurationAdd;
      let promise: any = new Promise((resolve, reject) => {
        this.http.post(url,prms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }

  }
  deleteProjectduration(del_id, cb){
    let url: string = this.apiBaseUrl + apiList.projectsMasters.deleteProjectduration;
    let promise: any = new Promise((resolve, reject) => {
      this.http.delete(url + "/" + del_id)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
}