import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';

@Injectable({
	providedIn: 'root'
})
export class ProjectCalendarService {

	apiBaseUrl: string;

	constructor(
		private http: HttpClient,
		private cookies: CookieService
	) {
		this.apiBaseUrl = globalVariables.apiBaseUrl;
	}

	getCalanderData(dateRangeValue, queryObject, cb) {
		let url: string = this.apiBaseUrl + apiList.projects.calanderList;
		url = url + "?rStartDate=" + this.formatForApi(dateRangeValue[0]) + "&rEndDate=" + this.formatForApi(dateRangeValue[1]);

		if (queryObject.keyword) {
		  url = url + "&keyword=" + queryObject.keyword;
		}

		if (queryObject.dept) {
		  url = url + "&dept=" + queryObject.dept;
		}
		if (queryObject.desig) {
			url = url + "&desig=" + queryObject.desig;
		}
		if (queryObject.loc) {
			url = url + "&loc=" + queryObject.loc;
		}
		if (queryObject.mngr) {
			url = url + "&mngr=" + queryObject.mngr;
		}
		if (queryObject.role) {
			url = url + "&role=" + queryObject.role;
		}
		if (queryObject.cust) {
			url = url + "&cust=" + queryObject.cust;
		}
		if (queryObject.prjt) {
			url = url + "&prjt=" + queryObject.prjt;
		}

		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	formatForApi(inputDate) {
		var date = new Date(inputDate);
		if (!isNaN(date.getTime())) {
			if ((Number(date.getMonth()) + 1) < 10) {
				if (Number(date.getDate() < 10)) {
					return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
				}
				else {
					return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
				}
			}
			else {
				if (Number(date.getDate() < 10)) {
					return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
				}
				else {
					return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
				}
			}
		}
	}

	getPeopleMaster(cb) {
		let url: string = this.apiBaseUrl + apiList.people.master;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	getManagers(cb) {
		let url: string = this.apiBaseUrl + apiList.projects.peoplesWithAdmin;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	getProjects(cb) {
		let url: string = this.apiBaseUrl + apiList.projects.projectsData;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	getMasters(cb) {
		let url: string = this.apiBaseUrl + apiList.projects.masterList;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	getCustomers(cb) {
		let url: string = this.apiBaseUrl + apiList.projects.customerList;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}
}
