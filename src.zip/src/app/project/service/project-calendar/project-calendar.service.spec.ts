import { TestBed } from '@angular/core/testing';

import { ProjectCalendarService } from './project-calendar.service';

describe('ProjectCalendarService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProjectCalendarService = TestBed.get(ProjectCalendarService);
    expect(service).toBeTruthy();
  });
});
