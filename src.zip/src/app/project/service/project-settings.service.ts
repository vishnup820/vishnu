import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../shared/constants/globals';
import { apiList } from '../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';
@Injectable({
  providedIn: 'root'
})
export class ProjectSettingsService {
  apiBaseUrl: string;
  constructor(private http: HttpClient,
    private cookies: CookieService) { this.apiBaseUrl = globalVariables.apiBaseUrl; }


    getSettings(cb) {
      let url: string = this.apiBaseUrl + apiList.projects.getProjectSettings;
      let promise: any = new Promise((resolve, reject) => {
        this.http.get(url)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }

    addSettings(params,cb) {
      let url: string = this.apiBaseUrl + apiList.projects.addProjectSettings;
      let promise: any = new Promise((resolve, reject) => {
        this.http.post(url,params)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
}
