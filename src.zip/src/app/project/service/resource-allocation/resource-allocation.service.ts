import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';
@Injectable({
  providedIn: 'root'
})
export class ResourceAllocationService {
  apiBaseUrl: string;
  constructor(private http: HttpClient,
    private cookies: CookieService) {this.apiBaseUrl = globalVariables.apiBaseUrl;  }
  
  allocationData(parms,cb){
    let url: string = this.apiBaseUrl + apiList.projects.allocationData;
    let promise: any = new Promise((resolve, reject) => {
      this.http.post(url ,parms)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  editAllocationData(pr_id,cb){
    let url: string = this.apiBaseUrl + apiList.projects.allocationData;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url + "/" + pr_id)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  peopleAllocation(cb){
    let url: string = this.apiBaseUrl + apiList.projects.allocationPeoples;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  getMaster(cb){
    let url: string = this.apiBaseUrl + apiList.projects.masterList;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  getSettings(cb) {
    let url: string = this.apiBaseUrl + apiList.projects.getProjectSettings;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

  getSave(obj,cb) {
    let url: string = this.apiBaseUrl + apiList.projects.allocationValid;
    // let promise: any = new Promise((resolve, reject) => {
    //   this.http.post(obj,url)
    //     .toPromise()
    //     .then(res => {
    //       console.log(res)
    //       cb(res);

    //     })
    // })

    let promise: any = new Promise((resolve, reject) => {
      this.http.post(url ,obj)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  
}
