import { TestBed } from '@angular/core/testing';

import { ProjectAddService } from './project-add.service';

describe('ProjectAddService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProjectAddService = TestBed.get(ProjectAddService);
    expect(service).toBeTruthy();
  });
});
