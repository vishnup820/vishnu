import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';
@Injectable({
  providedIn: 'root'
})
export class ProjectAddService {
  apiBaseUrl: string;
  constructor(private http: HttpClient,
    private cookies: CookieService) {this.apiBaseUrl = globalVariables.apiBaseUrl;  }
    generateQuery(qobj) {
      let query = `?page=${qobj['page']?qobj['page']: ''}&page_limit=${qobj['page_limit'] ? qobj['page_limit'] : ''}${qobj.keyword ? '&keyword=' + qobj.keyword : ''}${qobj.prjtType ? '&prjtType=' + qobj.prjtType : ''}${qobj.prjtCust ? '&prjtCust=' + qobj.prjtCust : ''}${qobj.prjtStat ? '&prjtStat=' + qobj.prjtStat : ''}`
      return query;
    }
    getcustomertData(cb) {
      let url: string = this.apiBaseUrl + apiList.projects.customerList;
      let promise: any = new Promise((resolve, reject) => {
        this.http.get(url)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    getcontactData(cusId,cb) {
      let url: string = this.apiBaseUrl + apiList.projects.contactList+"?custId="+cusId;
      let promise: any = new Promise((resolve, reject) => {
        this.http.get(url)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    getTool(cb) {
      let url: string = this.apiBaseUrl + apiList.projects.toolDataList;
      let promise: any = new Promise((resolve, reject) => {
        this.http.get(url)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    getToolCat(cb) {
      let url: string = this.apiBaseUrl + apiList.projects.gettoolCategory;
      let promise: any = new Promise((resolve, reject) => {
        this.http.get(url)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    addProjectData(parms,editProjectId,cb) {
      if(editProjectId){
        let url: string = this.apiBaseUrl + apiList.projects.projectsData;
        let promise: any = new Promise((resolve, reject) => {
          this.http.put(url + '/' + editProjectId,parms)
            .toPromise()
            .then(res => {
              cb(res);
            })
        })
      }
      else{
        let url: string = this.apiBaseUrl + apiList.projects.projectsData;
        let promise: any = new Promise((resolve, reject) => {
          this.http.post(url,parms)
            .toPromise()
            .then(res => {
              cb(res);
            })
        })
      }

    }
    listprojectData(qobj,cb){
      let url: string = this.apiBaseUrl + apiList.projects.projectsData;
      url = url + this.generateQuery(qobj);
      let promise: any = new Promise((resolve, reject) => {
        this.http.get(url)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    editProjectData(projEd_id,cb){
      let url: string = this.apiBaseUrl + apiList.projects.projectsData;
      let promise: any = new Promise((resolve, reject) => {
        this.http.get(url + "/" + projEd_id)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    projectManager(cb){
      let url: string = this.apiBaseUrl + apiList.projects.peoples;;
      let promise: any = new Promise((resolve, reject) => {
        this.http.get(url)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    deleteproject(delete_id,cb){
      let url: string = this.apiBaseUrl + apiList.projects.projectsData;
      let promise: any = new Promise((resolve, reject) => {
        this.http.delete(url + "/" + delete_id)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    ProjectStatus(editProjectId,parms,cb) {
     let url: string = this.apiBaseUrl + apiList.projects.statusChange;
        let promise: any = new Promise((resolve, reject) => {
          this.http.put(url + '/' + editProjectId,parms)
            .toPromise()
            .then(res => {
              cb(res);
            })
        })
      }
      designationList(cb){
        let url: string = this.apiBaseUrl + apiList.projects.getdesignation;
        let promise: any = new Promise((resolve, reject) => {
          this.http.get(url)
            .toPromise()
            .then(res => {
              cb(res);
            })
        })
      }
      getcustomerData(cb) {
        let url: string = this.apiBaseUrl + apiList.projects.getCustomerList;
        let promise: any = new Promise((resolve, reject) => {
          this.http.get(url)
            .toPromise()
            .then(res => {
              cb(res);
            })
        })
      }
      getMaster(cb){
        let url: string = this.apiBaseUrl + apiList.projects.masterList;
        let promise: any = new Promise((resolve, reject) => {
          this.http.get(url)
            .toPromise()
            .then(res => {
              cb(res);
            })
        })
      }
}

