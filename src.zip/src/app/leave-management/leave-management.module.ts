import { NgModule,ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { ClickOutsideModule } from 'ng4-click-outside';
import { BsDatepickerModule,BsDatepickerConfig} from 'ngx-bootstrap/datepicker';
import { HolidayCalanderComponent } from './component/holiday-calander/holiday-calander.component';
import { AddHolidayComponent   } from './component/add-holiday/add-holiday.component';
import { HolidayDetailsService } from './services/holiday-details.service';
import { CalenderListService } from './services/calender-list.service';
import { ExceptionalDetailsService } from './services/exceptional-details.service';
import { EmployeeRegularisationService } from './services/employee-regularisation/employee-regularisation.service';
import { RegularisationApprovalService } from './services/regularisation-approval/regularisation-approval.service';
import { HrCompensatoryApprovalService } from './services/hr-compensatory-approval/hr-compensatory-approval.service';
import { CalenderSettingsService } from './services/calender-settings.service';
import { CalenderSettingsComponent } from './component/calender-settings/calender-settings.component';
import { CalenderListComponent } from './component/calender-list/calender-list.component';
import { ExceptionalCalenderComponent } from './component/exceptional-calender/exceptional-calender.component';
import { AddExceptionalComponent } from './component/add-exceptional/add-exceptional.component';
import { ManagerCompensatoryComponent } from './component/manager-compensatory/manager-compensatory.component';
import { LeavetypeListComponent } from './component/leavetype-list/leavetype-list.component';
import { LeavetypeDetailsService } from './services/leave-type/leavetype-details.service';
import { EmployeeLeaveDetailsService } from './services/employee-leave/employee-leave-details.service';
import { AddTypeComponent } from './component/add-type/add-type.component';
import { HrCompensatoryApprovalComponent } from './component/hr-compensatory-approval/hr-compensatory-approval.component';
import { EmployeeRegularisationComponent } from './component/employee-regularisation/employee-regularisation.component';
import { EmployeeLeaveListComponent } from './component/employee-leave-list/employee-leave-list.component';
import { ManagerLeaveComponent } from './component/manager-leave/manager-leave.component';
import { RegularisationApprovalComponent } from './component/regularisation-approval/regularisation-approval.component';
import { ManagerApproveService } from './services/manager-approve/manager-approve.service';
import { EmpHoliCalenderComponent } from './component/emp-holi-calender/emp-holi-calender.component';
import { EmpHoliCalenderService } from './services/emp-holi-calender.service';
import { AuthGuardService } from '../shared/services/auth-guard/auth-guard.service';
import { RoleGuardService } from '../shared/services/role-guard/role-guard.service';
import { MyTeamListComponent } from './component/my-team-list/my-team-list.component';
import { MyTeamListService } from './services/team-list/my-team-list.service';
import { EmployeeExceptionalComponent } from './component/employee-exceptional/employee-exceptional.component';
import { AutoFocusDirective } from './directives/auto-focus.directive';
import { GlobalErrorHandlerService } from '../global-error-handler.service';
import { PayPeriodSettingsComponent } from './component/pay-period-settings/pay-period-settings.component'
@NgModule({
  declarations: [HolidayCalanderComponent,
      AddTypeComponent,
      AddHolidayComponent,
      CalenderSettingsComponent,
      CalenderListComponent,
      ExceptionalCalenderComponent,
      AddExceptionalComponent,
      ManagerCompensatoryComponent,
      LeavetypeListComponent,
      HrCompensatoryApprovalComponent,
      EmployeeRegularisationComponent,
      EmployeeLeaveListComponent,
      ManagerLeaveComponent,
      RegularisationApprovalComponent,
      EmpHoliCalenderComponent,
      MyTeamListComponent,
      EmployeeExceptionalComponent,
      AutoFocusDirective,
      PayPeriodSettingsComponent
    ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    ClickOutsideModule,
    BsDatepickerModule.forRoot(),
    RouterModule.forChild([
      {
        path       : 'holiday-calender',
        canActivate : [RoleGuardService],
        component  :  HolidayCalanderComponent,
      },
      {
        path       : 'calender-settings',
        canActivate : [RoleGuardService],
        component  : CalenderSettingsComponent,
      },
      {
        path       : 'calender-list',
        canActivate : [RoleGuardService],
        component  : CalenderListComponent,
      },
      {
        path       : 'exceptional-calender',
        canActivate : [RoleGuardService],
        component  : ExceptionalCalenderComponent,
      },
      {
        path      :  'compensatory',
        component : ManagerCompensatoryComponent,
        canActivate : [RoleGuardService],
      },
      {
        path      :  'leave-type',
        canActivate : [RoleGuardService],
        component : LeavetypeListComponent
      },
      {
        path      :  'manager-leave',
        canActivate : [RoleGuardService],
        component : ManagerLeaveComponent
      },
      {
        path      :  'add-leave/:id',
        canActivate : [RoleGuardService],
        component : AddTypeComponent
      },
      {
        path      :  'add-leave',
        canActivate : [RoleGuardService],
        component : AddTypeComponent
      },
      {
        path      :  'hr-compensatory-approval',
        component :  HrCompensatoryApprovalComponent,
        canActivate : [RoleGuardService],
      },
      {
        path      :  'employee_regularisation',
        component :   EmployeeRegularisationComponent,
        canActivate : [RoleGuardService],
      },
      {
        path       : 'employee-leave',
        canActivate : [RoleGuardService],
        component  : EmployeeLeaveListComponent,
      },
      {
        path       : 'regularisation-approval',
        canActivate : [RoleGuardService],
        component  : RegularisationApprovalComponent,
      },
      {
        path       : 'emp-holi-calender',
        canActivate : [RoleGuardService],
        component  : EmpHoliCalenderComponent,
      },
      {
        path       : 'exceptional-days',
        canActivate : [RoleGuardService],
        component  : EmployeeExceptionalComponent,
      },
      {
        path       : 'my-team-list',
        canActivate: [RoleGuardService],
        component  : MyTeamListComponent,
      },
      {
        path       : '',
        redirectTo : 'calender-list',
        canActivate : [RoleGuardService],
        pathMatch  : 'full'
      },
      {
        path       : 'pay-period-settings',
        canActivate: [RoleGuardService],
        component  : PayPeriodSettingsComponent,
      }
    ])
  ],
  providers : [HolidayDetailsService,
       CalenderSettingsService,
       ExceptionalDetailsService,
       LeavetypeDetailsService,
       ExceptionalDetailsService,
       HrCompensatoryApprovalService,
       EmployeeRegularisationService,
       EmployeeLeaveDetailsService,
       RegularisationApprovalService,
       ManagerApproveService,
       AuthGuardService,
       RoleGuardService,
       EmpHoliCalenderService,
       MyTeamListService,
        {
         provide  : ErrorHandler,
         useClass : GlobalErrorHandlerService,
        }
       ]
})
export class LeaveManagementModule { }
