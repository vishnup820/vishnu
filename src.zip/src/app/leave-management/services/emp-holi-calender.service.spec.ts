import { TestBed } from '@angular/core/testing';

import { EmpHoliCalenderService } from './emp-holi-calender.service';

describe('EmpHoliCalenderService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EmpHoliCalenderService = TestBed.get(EmpHoliCalenderService);
    expect(service).toBeTruthy();
  });
});
