/*
*  @desc   : service dealing get and post api calls for employee leave list
*  @author : dipin
*/
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import {apiList}  from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

@Injectable({
  providedIn: 'root'
})
export class EmployeeLeaveDetailsService {

  userData   : any;
  apiBaseUrl : string;
	constructor(
		private http: HttpClient,private timeZone : TimezoneDetailsService, private cookies : CookieService) { this.apiBaseUrl = globalVariables.apiBaseUrl; }

     /*
      author : dipin
      desc   : get employee details based on empid
    */
    getEmpDetails(empId,role_id,search,cb) {
        let url: string;
        if(role_id != 2)
          url = this.apiBaseUrl + "/api/v1/people/"+empId+"/myteam?stat=1&sort=f_name&keyword="+search;
        else
          url = this.apiBaseUrl+apiList.leaveManagement.getAdminData+"&keyword="+search;

        let promise: any = new Promise((resolve, reject) => {
            this.http.get(url)
                .toPromise()
                .then(res => {
                    cb(res);
                })
        })
    }

    /*
      author : dipin
      desc   : get leave details
    */
  getLeaveList(page, per_page, advanceFilterData, sort,id,cb) {
    let sortValue: any;
    let url: string;
    let params = "";
    if (advanceFilterData) {
      if (advanceFilterData.range) {
        params = params + "&req_start=" + this.formatForApi(advanceFilterData.range[0]) + "&req_end=" + this.formatForApi(advanceFilterData.range[1]);
      }
      if(advanceFilterData.status)
      if ( advanceFilterData.status && advanceFilterData.status.selected && advanceFilterData.status.selected.length) {
        if (advanceFilterData.status.selected[0].value == 'Approved')
          params = params + "&lstate=2";
        if (advanceFilterData.status.selected[0].value == 'Pending')
          params = params + "&lstate=1";
        if (advanceFilterData.status.selected[0].value == 'Rejected')
          params = params + "&lstate=3";
        if (advanceFilterData.status.selected[0].value == 'Cancelled')
          params = params + "&lstate=4";
      }
    }
    sort ? sortValue = sort : sortValue = "";

    if(id != "All")
     url = this.apiBaseUrl + apiList.leaveManagement.employeeLeave + "?page=" + page + "&page_limit=" + per_page + "&uid=" + id + params + sortValue;
    else if(id == "All" && JSON.parse(this.cookies.get('user-data')).role_id == 2)
     url = this.apiBaseUrl + apiList.leaveManagement.employeeLeave + "?page=" + page + "&page_limit=" + per_page + params + sortValue;
    else if(id == "All" && JSON.parse(this.cookies.get('user-data')).role_id == 4)
     url = this.apiBaseUrl + apiList.leaveManagement.managerRequest + JSON.parse(this.cookies.get('user-data')).user_id + "/leaverequest/approvals?page=" + page + "&page_limit=" + per_page +"&fetch_type=list" + params + sortValue;

    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

     /*
  *  @desc   :method deleting get api call for delete one item
  *  @author :dipin
  */
  deleteLeaveDetails(obj,callBack) {
    let url: string = this.apiBaseUrl + apiList.leaveManagement.employeeLeave +"/"+obj;
    let promise = new Promise((resolve, reject) => {
      this.http.delete(url)
        .toPromise()
        .then(res => {
          if (res) callBack(res)
        })
    })
    return promise;
  }

       /*
  *  @desc   :method deleting get api call for delete one item
  *  @author :dipin
  */
  editLeaveDetails(obj,callBack) {
    let url: string = this.apiBaseUrl + apiList.leaveManagement.employeeLeave +"/"+obj;
    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) callBack(res)
        })
    })
    return promise;
  }

  /*
  *  @desc   :method deleting get api call for delete one item
  *  @author :dipin
  */
  getLeaveTypes(id,callBack) {
    let url: string = this.apiBaseUrl +"/api/v1/people/"+id+"/leavetypes";
    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) callBack(res)
        })
    })
    return promise;
  }

  /*
  *  @desc   :get validations for selected leave type
  *  @author :dipin
  */
  getValidations(uId,vId,cb){
    let url: string = this.apiBaseUrl +apiList.leaveManagement.leaveType+"/"+vId+"/restrictions/"+uId;
    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }

    /*
  *  @desc   :method put api call for add leave
  *  @author :dipin
  */
  addLeaveRequest(obj, type,id,editId,cb) {
    if (type == true) {
      let url: string = this.apiBaseUrl + apiList.leaveManagement.employeeLeave+"/"+editId;
      let promise = new Promise((resolve, reject) => {
        this.http.put(url, obj)
          .toPromise()
          .then(res => {
            if (res) cb(res)
          })
      })
      return promise;
    }
    else {
      let url: string = this.apiBaseUrl + apiList.leaveManagement.employeeLeave;
      let promise = new Promise((resolve, reject) => {
        this.http.post(url, obj)
          .toPromise()
          .then(res => {
            if (res) cb(res)
          })
      })
      return promise;
    }
  }

    /*
  *  @desc   : make date to the format 'dd-mm-yyyy'
  *  @author : dipin
  */
  formatForApi(inputDate) {
    var date = this.timeZone.toLocal(inputDate);
    if(date)
    if (!isNaN(date.getTime())) {
      if ((Number(date.getMonth()) + 1) < 10) {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
      else {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
    }
    else
      return undefined;
  }

    /*
  *  @desc   :method get people list for admin drop down
  *  @author :dipin
  */
  getPeople(callBack){
      if(this.cookies.get("user-data")){
         this.userData =  JSON.parse(this.cookies.get("user-data"));
       }
    let url: string;
    if(this.userData.role_id == "2"){
       url = this.apiBaseUrl+apiList.leaveManagement.getAdminData;
    }
    else
        url= `${this.apiBaseUrl}${apiList.people.details}/${this.userData.user_id}/myteam`;

    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url + "?stat=1")
        .toPromise()
        .then(res => {
          callBack(res);
        })
    })
  }

    /*
  *  @desc   :method export file data downloading
  *  @author :dipin
  */
  exportExcelData(id,advanceFilterData,cb){
    let url : string;
    let sortValue: any;
    let params = "";
    if (advanceFilterData) {
      if (advanceFilterData.range) {
        params = params + "req_start=" + this.formatForApi(advanceFilterData.range[0]) + "&req_end=" + this.formatForApi(advanceFilterData.range[1]);
      }
      if(advanceFilterData.status)
      if ( advanceFilterData.status && advanceFilterData.status.selected && advanceFilterData.status.selected.length) {
        if (params != '') {
          if (advanceFilterData.status.selected[0].value == 'Approved')
            params = params + "&lstate=2";
          if (advanceFilterData.status.selected[0].value == 'Pending')
            params = params + "&lstate=1";
          if (advanceFilterData.status.selected[0].value == 'Rejected')
            params = params + "&lstate=3";
          if (advanceFilterData.status.selected[0].value == 'Cancelled')
            params = params + "&lstate=4";
        }
        else{
           if (advanceFilterData.status.selected[0].value == 'Approved')
            params = params + "lstate=2";
          if (advanceFilterData.status.selected[0].value == 'Pending')
            params = params + "lstate=1";
          if (advanceFilterData.status.selected[0].value == 'Rejected')
            params = params + "lstate=3";
          if (advanceFilterData.status.selected[0].value == 'Cancelled')
            params = params + "lstate=4";
        }
      }
    }

    if(id == "All"){
      url = this.apiBaseUrl + apiList.leaveManagement.exportLeave + "?" + params;
    }
    else{
      url = this.apiBaseUrl + apiList.leaveManagement.exportLeave + "/" + id + "?" + params;
    }

    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

    /*
  *  @desc   :method export file data downloading
  *  @author :dipin
  */
  attachemntDownload(id,leaveId,cb){
    let url : string;
      url = this.apiBaseUrl +apiList.leaveManagement.getLeaveAttachment+"/"+id+"?lid="+leaveId;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

  /*
  *  @desc   :api call for show message
  *  @author :dipin
  */
  showMessage(id,cb){
    let url : string;
      url = this.apiBaseUrl +"/api/v1/people/"+JSON.parse(this.cookies.get("user-data")).user_id+"/leavemessage/"+id;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

     /*
     author : dipin
     desc   : add class based on index
    */
    getClassByValue(index) {
        switch (index % 10) {
            case 0: return "default-avatar islamic-green";
            case 1: return "default-avatar limerick";
            case 2: return "default-avatar chilean-fire";
            case 3: return "default-avatar persian-pink";
            case 4: return "default-avatar deep-magenta";
            case 5: return "default-avatar gigas";
            case 6: return "default-avatar endeavour";
            case 7: return "default-avatar dodger-blue";
            case 8: return "default-avatar jordy-blue";
            case 9: return "default-avatar Light-sea-green";
            case 10: return "emp-profileimage";
        }
    }

  /*
  *  @desc   :method put api call for add leave
  *  @author :dipin
  */
  addMessage(obj,cb) {
    let url: string = this.apiBaseUrl +"/api/v1/leave-message-submit";
    let promise = new Promise((resolve, reject) => {
      this.http.post(url, obj)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }


  /*
  *  @desc   : get all users email id
  *  @author : dipin
  */
  emailListing(cb) {
    let url: string;
    url = this.apiBaseUrl +"/api/v1/people?fields=email&sort=email";
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

    /*
  *  @desc   : export leave balance
  *  @author : dipin
  */
  exportLeaveBalance(id,cb) {
    let url: string;
    if(id == "All")
      url = this.apiBaseUrl +"/api/v1/export-leavebalance";
    else
      url = this.apiBaseUrl +"/api/v1/export-leavebalance/"+id;

    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

   /*
  *  @desc   : delete chat
  *  @author : dipin
  */
  deleteChat(id,messageId,cb) {
    let url: string = this.apiBaseUrl +"/api/v1/people/"+id+"/delmessage/"+messageId;
    let promise = new Promise((resolve, reject) => {
      this.http.delete(url)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }
}
