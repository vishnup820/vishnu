import { TestBed } from '@angular/core/testing';

import { EmployeeLeaveDetailsService } from './employee-leave-details.service';

describe('EmployeeLeaveDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EmployeeLeaveDetailsService = TestBed.get(EmployeeLeaveDetailsService);
    expect(service).toBeTruthy();
  });
});
