import { TestBed } from '@angular/core/testing';

import { ExceptionalDetailsService } from './exceptional-details.service';

describe('ExceptionalDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ExceptionalDetailsService = TestBed.get(ExceptionalDetailsService);
    expect(service).toBeTruthy();
  });
});
