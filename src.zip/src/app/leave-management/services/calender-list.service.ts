/*
*  @desc   :service dealing get and post api calls for calender list
*  @author :dipin
*/
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from './../../shared/constants/globals';
import {apiList}  from './../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class CalenderListService {
apiBaseUrl  : string;
  constructor(
		private http: HttpClient) { this.apiBaseUrl = globalVariables.apiBaseUrl;}

   /*
	*  @desc   :method dealing get api call for calender list details
	*  @author :dipin
	*/
	getCalanderDetails(page, per_page, obj, advanceFilterData, callBack) {
		let temp = "", params;
		if (obj)
			temp = (obj.type) ? "-" + obj.department : obj.department;
		if (advanceFilterData) {
			if (advanceFilterData.calstatus &&advanceFilterData.calstatus.selected && advanceFilterData.calstatus.selected.length )
				params = "&status="+ advanceFilterData.calstatus.selected[0].value;
			

		}
		if (!params)
			params = "";

		let url: string = this.apiBaseUrl + apiList.leaveManagement.getCalenderList + "?page=" + page + "&page_limit=" + per_page + params + "&sort=" + temp;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	 /*
	*  @desc   :method deleting get api call for delete one item from calender list
	*  @author :dipin
	*/
	deleteCalenderDetails(obj,callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.deleteCalenderList+obj;
		let promise = new Promise((resolve, reject) => {
			this.http.delete(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	 /*
	*  @desc   :method deleting post api call for delete multiple item from calender list
	*  @author :dipin
	*/
	deleteMultipleCalender(obj,cb) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.deleteCalenderMultipleList;
		let promise = new Promise((resolve, reject) => {
		this.http.request("delete",url,{ body : obj })
				.toPromise()
				.then(res => {
					cb(res);
			})
		})
		return promise;
	}

     /*
	*  @desc   :method deleting get api call for delete one item from holida calender list
	*  @author :dipin
	*/
	addCalenderDetails(obj,callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.addCalenderSettings;
		let promise = new Promise((resolve, reject) => {
			this.http.post(url,obj)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}


    /*
	*  @desc   :method for api call to get holiday calender year
	*  @author :dipin
	*/
	listCalenderYear(callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.getFinancialYear;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}


	  /*
	*  @desc   :method for sorting table emelents based on columns
	*  @author :dipin
	*/
	sortCalenderDetails(obj, page, advanceFilterData,callBack) {
		let params;
		let recordsPerPage;
		if (localStorage.getItem("itemsperpage")) {
			recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			recordsPerPage = 10;
		}
		let temp = (obj.type) ? "-" + obj.department : obj.department;
		if (advanceFilterData && advanceFilterData.calstatus.selected.length>0 ) {
			if (advanceFilterData.calstatus.selected[0].name == 'Upcoming'){
				params = "&status=2";
			}
			else if (advanceFilterData.calstatus.selected[0].name == 'Past '){
				params = "&status=0";
			}
			else if (advanceFilterData.calstatus.selected[0].name == 'Active'){
				params = "&status=1";
			}
			else if (advanceFilterData.calstatus.selected[0].name == 'Inactive'){
				params = "&status=3";
			}
		}
		if (!params)
			params = "";
		let url: string = this.apiBaseUrl + apiList.leaveManagement.sorCalenderList + "page=" + page + "&page_limit=" + recordsPerPage + params + "&sort=" + temp;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}
}
