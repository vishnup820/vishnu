/*
*  @desc   : service dealing get and post api calls for Manger list
*  @author : Arun johnson
*/
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import {apiList}  from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';
@Injectable({
  providedIn: 'root'
})
export class EmployeeRegularisationService {

  apiBaseUrl: string;
	constructor(
		private http             : HttpClient,
		private cookies          : CookieService,) { this.apiBaseUrl = globalVariables.apiBaseUrl; }

	/*
  *  @desc   : method dealing get api call for manger list details
  *  @author : arunjohnson
  */
	getEmployeeList(page, per_page, searchValue, advanceFilterData, cb) {
		let serchFilter: any = null;;
		searchValue ? serchFilter = "&keyword=" + searchValue : serchFilter = " ";
		let advanceFilter: any = null;
		advanceFilterData ? advanceFilter = this.advanceFilterApi(advanceFilterData) : advanceFilter = "";
		let url: string = this.apiBaseUrl + apiList.regularisation.details;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url +"/" + JSON.parse(this.cookies.get('user-data')).user_id+"/regularizations" +"?page=" + page + "&page_limit=" + per_page + advanceFilter + serchFilter)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
		// } else {
		// 	let url : string = this.apiBaseUrl + apiList.regularisation.admin;
		// 	let promise: any = new Promise((resolve, reject) => {
		// 	this.http.get(url  +"?page=" + page + "&page_limit=" + per_page + advanceFilter + serchFilter)
		// 		.toPromise()
		// 		.then(res => {
		// 			cb(res);
		// 		})
		// })
		// }
	}

  /*
    author : dipin
    desc   : get employee financial year details
  */
  getValidations(uid,loc,zone,cb){
  	// JSON.parse(this.cookies.get('user-data')).user_id
    let url: string = this.apiBaseUrl +apiList.leaveManagement.leaveType+"/"+0+"/restrictions/"+uid;
    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }

    /*
      author : Arun Johnson
      desc   : get employee details based on empid
    */
	getEmpDetails(cb) {
		let uid;
		let url
		uid = JSON.parse(this.cookies.get('user-data')).role_id
		if(uid == '2'){
			url = this.apiBaseUrl + apiList.regularisation.serchMyTeam+"?stat=1";
			let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
		}
		else{
			url = this.apiBaseUrl + apiList.regularisation.serchMyTeam;
			let promise: any = new Promise((resolve, reject) => {
			this.http.get(url +"/"+JSON.parse(this.cookies.get('user-data')).user_id+"/myteam?stat=1")
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
		}

	}


    /*
      author : Arun Johnson
      desc   : Advance Filter
    */
	advanceFilterApi(data) {
		let status: any;
			(data.status && data.status.selected &&  data.status.selected.length&& data.status.selected[0]) ? status = "&rgz_st=" + data.status.selected[0].name : status = "";
		
		let sdate: any;
		let edate: any;

		(data.range&& data.range[0]) ? sdate = "&sdate=" + this.formateDate(data.range[0]): sdate = "";
	  (data.range && data.range[1]) ? edate = "&edate=" + this.formateDate(data.range[1]) : edate = "";

		let parms: any = null;
			parms =  sdate +edate +status;
		return parms;
	}

    /*
      author : Arun Johnson
      desc   : delete People
    */
	deletePeople(selectedPeople, cb) {
		let url: string = this.apiBaseUrl + apiList.regularisation.deletePeople;
		let promise: any = new Promise((resolve, reject) => {
			this.http.delete(url + "/" + selectedPeople.basic.id)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

    /*
      author : Arun Johnson
      desc   : format date
    */
	formateDate(date) {
		if (date) {
			var curr_date = date.getDate();
			var curr_month = date.getMonth() + 1; //Months are zero based
			var curr_year = date.getFullYear();
			return (curr_year + "-" + curr_month + "-" + curr_date)
		}
	}

    /*
      author : Arun Johnson
      desc   : Get regularisation details of each id
    */
	regularizationIdDetails(id, cb) {
		let url: string = this.apiBaseUrl + apiList.regularisation.deletePeople;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "/" + id)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

    /*
      author : Arun Johnson
      desc   : edit Regularisation
    */
	editRegularisation(editData, dateArray, reason, empId, cb) {
		let url: string = this.apiBaseUrl + apiList.regularisation.deletePeople;
		let data: any = []
		for (let i = 0; i < dateArray.length; i++) {
			data.push({
				"applied_date": this.formateDate(dateArray[i].start_date),
				"application_type": dateArray[i].type_value,
				"application_attendance": dateArray[i].type_Attendance
			});
		}
		let object: any = {
			user_id: editData.basic.user_id,
			requested_by: JSON.parse(this.cookies.get('user-data')).user_id,
			detail: data,
			reason_for_request: reason
		}
		let promise: any = new Promise((resolve, reject) => {
			this.http.put(url + "/" + editData.basic.id, object)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

    /*
      author : Arun Johnson
      desc   : add new regularisation
    */
	addRegularisation(empDetails, dateArray, reason, cb) {
		let data: any = [];
		let requested_by : any ;
		let roleId;
		let user_id;
		if(this.cookies.get('user-data')) {
			roleId = JSON.parse(this.cookies.get('user-data')).role_id;
		}
		let url: string = this.apiBaseUrl + apiList.regularisation.deletePeople;
		let object;
		// requested_by =  empDetails.id
		if(roleId != 1 && empDetails && empDetails.id)  {
			user_id = empDetails.id

		} else {
			user_id = JSON.parse(this.cookies.get('user-data')).user_id;
		}
		// roleId != 1 ? user_id = empDetails.id : user_id = JSON.parse(this.cookies.get('user-data')).user_id;
		requested_by = JSON.parse(this.cookies.get('user-data')).user_id;
		for (let i = 0; i < dateArray.length; i++) {
			data.push({
				"applied_date": this.formateDate(dateArray[i].start_date),
				"application_type": dateArray[i].type_value,
				"application_attendance": dateArray[i].type_Attendance
			})
			object = {
				user_id: user_id,
				requested_by: requested_by,
				detail: data,
				reason_for_request: reason
			}
		}
		let promise: any = new Promise((resolve, reject) => {
				this.http.post(url, object)
					.toPromise()
					.then(res => {
						cb(res);
					})
			})
	}

     /*
  *  @desc   :api call for show message
  *  @author :dipin
  */
  showMessage(id,cb){
    let url : string;
      url = this.apiBaseUrl +"/api/v1/people/"+JSON.parse(this.cookies.get('user-data')).user_id+"/regularizationmessage/"+id;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

  /*
  *  @desc   :method put api call for add leave
  *  @author :dipin
  */
  addMessage(obj,cb) {
    let url: string = this.apiBaseUrl +"/api/v1/regularization-message-submit";
    let promise = new Promise((resolve, reject) => {
      this.http.post(url, obj)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }

   /*
  *  @desc   : delete chat
  *  @author : dipin
  */
  deleteChat(id,messageId,cb) {
    let url: string = this.apiBaseUrl +"/api/v1/people/"+id+"/delregularizationmessage/"+messageId;
    let promise = new Promise((resolve, reject) => {
      this.http.delete(url)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }
}
