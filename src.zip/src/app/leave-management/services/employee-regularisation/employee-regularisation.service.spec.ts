import { TestBed } from '@angular/core/testing';

import { EmployeeRegularisationService } from './employee-regularisation.service';

describe('EmployeeRegularisationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EmployeeRegularisationService = TestBed.get(EmployeeRegularisationService);
    expect(service).toBeTruthy();
  });
});
