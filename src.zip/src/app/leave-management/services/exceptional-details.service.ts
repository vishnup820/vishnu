/*
*  @desc   :service dealing get and post api calls for holiday calender
*  @author :dipin
*/
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from './../../shared/constants/globals';
import {apiList}  from './../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class ExceptionalDetailsService {

 apiBaseUrl      : string;
  constructor(
		private http: HttpClient) { this.apiBaseUrl = globalVariables.apiBaseUrl;}

    /*
	*  @desc   :method dealing get api call for Exceptional calender details
	*  @author :dipin
	*/
	getCalanderDetails(page,per_page,obj,advanceFilterData,callBack) {
		let temp = "", params;
		if (obj)
			temp = (obj.type) ? "-" + obj.department : obj.department;
		if (advanceFilterData) {
			if(advanceFilterData.stat.selected.length>0){
				if (advanceFilterData.stat.selected[0].value == '1')
				params = "&fy_stat=1";
			else
				params = "&fy_stat=2";

			}
			

		}
		if (!params)
			params = "";

		let url: string = this.apiBaseUrl+apiList.leaveManagement.listExceptional+"?page="+page+"&page_limit="+per_page+params+"&sort="+temp;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	 /*
	*  @desc   :method deleting get api call for delete one item from holida calender list
	*  @author :dipin
	*/
	deleteCalenderDetails(obj,callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.deleteExceptional+obj;
		let promise = new Promise((resolve, reject) => {
			this.http.delete(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	 /*
	*  @desc   :method deleting post api call for delete multiple item from holida calender list
	*  @author :dipin
	*/
	deleteMultipleCalender(obj,cb) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.deleteMultiExceptional;
		let promise = new Promise((resolve, reject) => {
		this.http.request("delete",url,{ body : obj })
				.toPromise()
				.then(res => {
					cb(res);
			})
		})
		return promise;
	}

     /*
	*  @desc   :method deleting get api call for delete one item from Exceptional calender list
	*  @author :dipin
	*/
	addCalenderDetails(obj,callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.addExceptional;
		let promise = new Promise((resolve, reject) => {
			this.http.post(url,obj)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}


    /*
	*  @desc   :method for api call to get holiday calender year
	*  @author :dipin
	*/
	listCalenderYear(callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.getFinancialYear;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}


	  /*
	*  @desc   :method for sorting tablr Exceptional based on columns
	*  @author :dipin
	*/
	sortCalenderDetails(obj,page,advanceFilterData,callBack) {
		let params;
		let temp = (obj.type) ? "-" + obj.department : obj.department;
		let recordsPerPage;
		if (localStorage.getItem("itemsperpage")) {
			recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			recordsPerPage = 10;
		}
		if (advanceFilterData) {
			if (advanceFilterData.stat == '1')
				params = "&fy_stat=1";
			else
				params = "&fy_stat=2";
		}
		if (!params)
			params = "";
		let url: string = this.apiBaseUrl+apiList.leaveManagement.sortExceptional+"page="+page+"&page_limit="+recordsPerPage+params+"&sort="+temp;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	  /*
	*  @desc   :method for sorting update Details
	*  @author :dipin
	*/
	updateCalenderDetails(obj,id,callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.addExceptional+"/"+id;
		let promise = new Promise((resolve, reject) => {
			this.http.put(url,obj)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

}
