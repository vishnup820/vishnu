import { TestBed } from '@angular/core/testing';

import { CalenderSettingsService } from './calender-settings.service';

describe('CalenderSettingsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CalenderSettingsService = TestBed.get(CalenderSettingsService);
    expect(service).toBeTruthy();
  });
});
