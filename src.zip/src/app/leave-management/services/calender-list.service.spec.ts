import { TestBed } from '@angular/core/testing';

import { CalenderListService } from './calender-list.service';

describe('CalenderListService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CalenderListService = TestBed.get(CalenderListService);
    expect(service).toBeTruthy();
  });
});
