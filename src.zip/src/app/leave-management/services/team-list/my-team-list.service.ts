/*
*  @desc   :component for display tealist and management
*  @author :dipin
*/
import { Injectable ,OnInit} from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList }  from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root'
})
export class MyTeamListService implements OnInit {

  apiBaseUrl:any;
  usedata:any;

  constructor(private http : HttpClient,
  	private cookieService: CookieService) {
  	this.apiBaseUrl = globalVariables.apiBaseUrl;

  }

  ngOnInit() {

  }

  /*
 *  @desc   :component for display tealist and management
 *  @author :dipin
 */
  advanceFilterApi(data) {
		let role: any = (data.role && data.role.selected[0]) ? "role=" + data.role.selected[0].id + "&" : "";
		let location: any = (data.location && data.location.selected[0]) ? "loc=" + data.location.selected[0].id + "&" : "";
		let designation: any = (data.designation && data.designation.selected[0]) ? "desg=" + data.designation.selected[0].id + "&" : "";
		let department: any = (data.department && data.department.selected[0]) ? "dept=" + data.department.selected[0].id + "&" : "";
		let parms: any = "&" + role + location + designation + department;
		return parms.substring(0, parms.length - 1);
	}

 /*
 *  @desc   :component for display tealist and management
 *  @author :dipin
 */
  getPeople(cPage,rPage,filterData,searchKey,qObj,callBack){
  		if(this.cookieService.get("user-data")){
  			 this.usedata =	JSON.parse(this.cookieService.get("user-data"));
   		}
  	    let sortValue: any;
		qObj.sort ? sortValue =  '&sort='+qObj.sort : sortValue = "";
		let serchFilter: any;
		searchKey ? serchFilter = "&keyword=" + searchKey : serchFilter = "";
		let params: any
		filterData ? params = this.advanceFilterApi(filterData) : params = "";
		let url: string;
  			url= `${this.apiBaseUrl}${apiList.people.details}/${this.usedata.user_id}/myteamlist`;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "?page=" + cPage + "&page_limit=" + rPage + params + serchFilter + sortValue+"&stat=1")
				.toPromise()
				.then(res => {
					callBack(res);
				})
		})

  }

}
