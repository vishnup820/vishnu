import { TestBed } from '@angular/core/testing';

import { MyTeamListService } from './my-team-list.service';

describe('MyTeamListService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MyTeamListService = TestBed.get(MyTeamListService);
    expect(service).toBeTruthy();
  });
});
