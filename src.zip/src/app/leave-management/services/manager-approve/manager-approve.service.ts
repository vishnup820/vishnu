/*
*  @desc   : service dealing get and post api calls for manager approval
*  @author : dipin
*/
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import {apiList}  from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

@Injectable({
  providedIn: 'root'
})
export class ManagerApproveService {

  apiBaseUrl: string;
	constructor(
		private http: HttpClient,private cookies : CookieService,private timeZone : TimezoneDetailsService) { this.apiBaseUrl = globalVariables.apiBaseUrl; }

	/*
      author : dipin
      desc   : get manager details based on id
    */
  getEmpDetails(selectedList,page, per_page, advanceFilterData, sort, searchValue, id, callBack) {
    let sortValue : any;
    let serchFilter : any;
    let params = "";
    sort ? sortValue = "&sort="+sort : sortValue = "";
    searchValue ? serchFilter = "&keyword=" + searchValue : serchFilter = "";
    if (advanceFilterData) {
      if (advanceFilterData.range) {
        params = params + "&req_start=" + this.formatForApi(advanceFilterData.range[0]) + "&req_end=" + this.formatForApi(advanceFilterData.range[1]);
      }
      if (advanceFilterData.status)
        if (advanceFilterData.status.selected.length) {
          if (advanceFilterData.status.selected[0].value == 'Approved')
            params = params + "&lstate=2";
          if (advanceFilterData.status.selected[0].value == 'Pending')
            params = params + "&lstate=1";
          if (advanceFilterData.status.selected[0].value == 'Rejected')
            params = params + "&lstate=3";
          if (advanceFilterData.status.selected[0].value == 'Cancelled')
            params = params + "&lstate=4";
        }
        if (advanceFilterData.department)
          if (advanceFilterData.department.selected.length) {
             params = params + "&dep_id="+advanceFilterData.department.selected[0].id;
          }
        if (advanceFilterData.designation)
          if (advanceFilterData.designation.selected.length) {
             params = params + "&des_id="+advanceFilterData.designation.selected[0].id;
          }
        if (advanceFilterData.location)
          if (advanceFilterData.location.selected.length) {
             params = params + "&loc_id="+advanceFilterData.location.selected[0].id;
          }
    }

    if(JSON.parse(this.cookies.get('user-data')).role_id == 2){
      if(selectedList == "Other"){
        params = params + "&fetch_type=all"
      }
      else{
        params = params + "&fetch_type=team"
      }
    }

    let url: string = this.apiBaseUrl + apiList.leaveManagement.managerRequest + id + "/leaverequest/approvals" + "?page=" + page + "&page_limit=" + per_page + params + serchFilter + sortValue;
    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) callBack(res)
        })
    })
    return promise;
  }

  /*
    author : dipin
    desc   : sort
    */
  sorting(data) {
    let passValue: any;
    data.value == "+" ? passValue = "&sort=" + data.name : passValue = "&sort=" + data.value + data.name;
    return passValue;
  }

  multiReject(id,obj,callBack) {
    let url: string = this.apiBaseUrl + apiList.leaveManagement.employeeLeave + "/" + id;
    let promise = new Promise((resolve, reject) => {
      this.http.patch(url,obj)
        .toPromise()
        .then(res => {
          if (res) callBack(res)
        })
    })
    return promise;
  }

   singleReject(id,obj,detailId,callBack) {
    let url: string = this.apiBaseUrl + apiList.leaveManagement.employeeLeave + "/" + id+"?details_id="+detailId;
    let promise = new Promise((resolve, reject) => {
      this.http.patch(url,obj)
        .toPromise()
        .then(res => {
          if (res) callBack(res)
        })
    })
    return promise;
  }

  sortDetails(team,obj,page, per_page, advanceFilterData, sort, searchValue,callBack) {
    let temp = (obj.type) ? "-" + obj.department : obj.department;
    let sortValue: any;
    let serchFilter: any;
    let params = "";
    sort ? sortValue = this.sorting(sort) : sortValue = "";
    searchValue ? serchFilter = "&keyword=" + searchValue : serchFilter = "";
    if (advanceFilterData) {
      if (advanceFilterData.range) {
        params = params + "&req_start=" + this.formatForApi(advanceFilterData.range[0]) + "&req_end=" + this.formatForApi(advanceFilterData.range[1]);
      }
      if (advanceFilterData.status)
        if (advanceFilterData.status.selected.length) {
          if (advanceFilterData.status.selected[0].value == 'Approved')
            params = params + "&lstate=2";
          if (advanceFilterData.status.selected[0].value == 'Pending')
            params = params + "&lstate=1";
          if (advanceFilterData.status.selected[0].value == 'Rejected')
            params = params + "&lstate=3";
          if (advanceFilterData.status.selected[0].value == 'Cancelled')
            params = params + "&lstate=4";
        }
      if (advanceFilterData.department)
        if (advanceFilterData.department.selected.length) {
          params = params + "&dep_id=" + advanceFilterData.department.selected[0].id;
        }
      if (advanceFilterData.designation)
        if (advanceFilterData.designation.selected.length) {
          params = params + "&des_id=" + advanceFilterData.designation.selected[0].id;
        }
      if (advanceFilterData.location)
        if (advanceFilterData.location.selected.length) {
          params = params + "&loc_id=" + advanceFilterData.location.selected[0].id;
        }
    }
    if(!temp)
        temp = "";


    if(JSON.parse(this.cookies.get('user-data')).role_id == 2){
      if(team == "Other"){
        params = params + "&fetch_type=all"
      }
      else{
        params = params + "&fetch_type=team"
      }
    }

    let url: string = this.apiBaseUrl + apiList.leaveManagement.managerRequest + JSON.parse(this.cookies.get('user-data')).user_id + "/leaverequest/approvals" + "?page=" + page + "&page_limit=" + per_page + params + serchFilter + "&sort=" + temp;
    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) callBack(res)
        })
    })
    return promise;
  }

      /*
  *  @desc   : make date to the format 'dd-mm-yyyy'
  *  @author : dipin
  */
  formatForApi(inputDate) {
   var date = this.timeZone.toLocal(inputDate);
    if(date)
    if (!isNaN(date.getTime())) {
      if ((Number(date.getMonth()) + 1) < 10) {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
      else {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
    }
    else
      return undefined;
  }

      /*
  *  @desc   :method export file data downloading
  *  @author :dipin
  */
 attachemntDownload(id,leaveId,cb){
    let url : string;
      url = this.apiBaseUrl +apiList.leaveManagement.getLeaveAttachment+"/"+id+"?lid="+leaveId;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

    /*
  *  @desc   :api call for show message
  *  @author :dipin
  */
  showMessage(id,cb){
    let url : string;
      url = this.apiBaseUrl +"/api/v1/people/"+JSON.parse(this.cookies.get('user-data')).user_id+"/leavemessage/"+id;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

  /*
  *  @desc   :method put api call for add leave
  *  @author :dipin
  */
  addMessage(obj,cb) {
    let url: string = this.apiBaseUrl +"/api/v1/leave-message-submit";
    let promise = new Promise((resolve, reject) => {
      this.http.post(url, obj)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }

   /*
  *  @desc   : delete chat
  *  @author : dipin
  */
  deleteChat(id,messageId,cb) {
    let url: string = this.apiBaseUrl +"/api/v1/people/"+id+"/delmessage/"+messageId;
    let promise = new Promise((resolve, reject) => {
      this.http.delete(url)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }

    /*
  *  @desc   : get payperiod details
  *  @author : dipin
  */
  getPeriod(cb) {
    let url: string = this.apiBaseUrl +apiList.leaveManagement.getPayperiod;
    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }
}
