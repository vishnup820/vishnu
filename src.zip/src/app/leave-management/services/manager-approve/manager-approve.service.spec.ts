import { TestBed } from '@angular/core/testing';

import { ManagerApproveService } from './manager-approve.service';

describe('ManagerApproveService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ManagerApproveService = TestBed.get(ManagerApproveService);
    expect(service).toBeTruthy();
  });
});
