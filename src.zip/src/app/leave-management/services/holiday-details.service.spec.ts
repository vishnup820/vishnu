import { TestBed } from '@angular/core/testing';

import { HolidayDetailsService } from './holiday-details.service';

describe('HolidayDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HolidayDetailsService = TestBed.get(HolidayDetailsService);
    expect(service).toBeTruthy();
  });
});
