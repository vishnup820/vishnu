/*
*  @desc   : service dealing get and post api calls for Manger list
*  @author : Arun johnson
*/
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';

import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import {apiList}  from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

@Injectable({
  providedIn: 'root'
})
export class RegularisationApprovalService {

    apiBaseUrl : string;
	constructor(
		private http              : HttpClient,
        private cookies           : CookieService,
        private timeZone          : TimezoneDetailsService) { this.apiBaseUrl = globalVariables.apiBaseUrl; }

    /*
	*  @desc   : method dealing get api call for hr compensatory list details
	*  @author : arunjohnson
	*/
    getDetails(page, per_page, searchValue , advanceFilterData, userId ,  cb) {
        let serchFilter: any;
        searchValue ? serchFilter = "&keyword=" + searchValue : serchFilter = "";
        let value: any
        advanceFilterData ? value = this.advanceFilterApi(advanceFilterData) : value = "";
        let url: string = this.apiBaseUrl + apiList.regularisationApprove.details;
        if(JSON.parse(this.cookies.get('user-data')).role_id == 4 || JSON.parse(this.cookies.get('user-data')).role_id == 1) {
        let promise: any = new Promise((resolve, reject) => {
            this.http.get(url +"/" + JSON.parse(this.cookies.get('user-data')).user_id + "/" + "regularizations/approvals" + "?page=" + page + "&page_limit=" + per_page + serchFilter + value )
                .toPromise()
                .then(res => {
                    cb(res);
                })
        })
        } else {
            let url : string = this.apiBaseUrl + apiList.regularisation.admin;
            let promise: any = new Promise((resolve, reject) => {
            this.http.get(url  +"?page=" + page + "&page_limit=" + per_page  + serchFilter + value)
                .toPromise()
                .then(res => {
                    cb(res);
                })
        })
        }
    }


    /*
    *  @desc   : Advance Filter api
    *  @author : arunjohnson
    */
    getAdvanceDetails(page, per_page,  advanceFilterData , cb) {
        let AdvanceParams: any;
        advanceFilterData ? AdvanceParams = this.advanceFilterApi(advanceFilterData) : AdvanceParams = "";
        let url: string = this.apiBaseUrl + apiList.regularisationApprove.advanceApi;
        let promise: any = new Promise((resolve, reject) => {
            // this.http.get(url +  "?page=" + page + "&page_limit=" + per_page  + AdvanceParams)
            this.http.get(url +"/" + JSON.parse(this.cookies.get('user-data')).user_id + "/" + "regularizations/approvals" + "?page=" + page + "&page_limit=" + per_page +  AdvanceParams )
                .toPromise()
                .then(res => {
                    cb(res);
            })
        })
    }

    /*
	*  @desc   : single date delete
	*  @author : arunjohnson
	*/
    singleDateDelete(data,compensatoryDatesId,userId,cb) {
    	 let url: string = this.apiBaseUrl + apiList.regularisationApprove.singleDate;
    	 let object = {
    	 	"applied_date_status" : 'R',
    	 	"comments" : data
    	 }
        let promise: any = new Promise((resolve, reject) => {
            this.http.request("put",url+"/date/"+compensatoryDatesId,{ body:object})
                .toPromise()
                .then(res => {
                    cb(res);
                })
        })
    }

    /*
	*  @desc   : commpensatory to approve by hr
	*  @author : arunjohnson
	*/
    approve(approveId,comments,cb) {
    	let url: string;
    	let object;

        if(JSON.parse(this.cookies.get('user-data')).role_id == 2){
          url = this.apiBaseUrl + apiList.regularisationApprove.approveReject;
          object = {
             "status"        : 2,
            "processed_by"   : JSON.parse(this.cookies.get('user-data')).user_id,
            "comments"       : comments
          }
        }
        else if(JSON.parse(this.cookies.get('user-data')).role_id == 4){
          url = this.apiBaseUrl + apiList.regularisationApprove.approveManager;
          object = {
             "moderate"     : 1,
            "processed_by"  : JSON.parse(this.cookies.get('user-data')).user_id
          }
        }

    	let promise: any = new Promise((resolve, reject) => {
            this.http.put(url+"/"+approveId,object)
                .toPromise()
                .then(res => {
                    cb(res);
                })
        })
    }

    /*
	*  @desc   : commpensatory to reject
	*  @author : arunjohnson
	*/
    rejectData(data,userId ,cb) {
    	let url: string = this.apiBaseUrl + apiList.regularisationApprove.approveReject;
    	 let object = {
    	 	"status" : 3,
             "processed_by"  : JSON.parse(this.cookies.get('user-data')).user_id,
    	 	"comments" : data
    	 }
    	let promise: any = new Promise((resolve, reject) => {
            this.http.put(url+"/"+userId,object)
                .toPromise()
                .then(res => {
                    cb(res);
                })
        })
    }

       /*
	*  @desc   : commpensatory to cancel
	*  @author : ashiq
	*/
  cancelData(userId ,data ,cb) {
    let url: string = this.apiBaseUrl + apiList.regularisationApprove.approveReject;
     let object = {
       "status" : "5",
       "processed_by"  : JSON.parse(this.cookies.get('user-data')).user_id,
       "comments" : data
     }
    let promise: any = new Promise((resolve, reject) => {
          this.http.put(url+"/"+userId,object)
              .toPromise()
              .then(res => {
                  cb(res);
              })
      })
  }


  singlecCancelData(id,selectDate, data ,cb){
    let url: string = this.apiBaseUrl + apiList.regularisationApprove.singleCancel;
     let object = {
      "applied_date_status": "C",
      "comments": data 
     }
     let promise: any = new Promise((resolve, reject) => {
      this.http.put(url+"/"+"date"+"/"+id,object)
          .toPromise()
          .then(res => {
              cb(res);
          })
  })

  }

   /*
      author : Arun Johnson
      desc   : Advance Filter
    */
    advanceFilterApi(data) {
        let sdate: any = (data.range && data.range[0]) ? "sdate=" + this.formatForApi(data.range[0]) + "&" : "";
        let edate: any = (data.range &&data.range[1]) ? "edate=" + this.formatForApi(data.range[1]) + "&" : "";

         let status: any = (data.status && data.status.selected[0]) ? "rgz_st=" + data.status.selected[0].name + "&" : "";
        let role: any = (data.group && data.group.selected[0]) ? "grp=" + data.group.selected[0].id + "&" : "";
        let location: any = (data.location && data.location.selected[0]) ? "loc=" + data.location.selected[0].id + "&" : "";
        let designation: any = (data.designation && data.designation.selected[0]) ? "desg=" + data.designation.selected[0].id + "&" : "";
        let department: any = (data.department && data.department.selected[0]) ? "dept=" + data.department.selected[0].id + "&" : "";
        let parms: any = "&" + status + role + location + designation + department +sdate +edate;
        return parms.substring(0, parms.length - 1);
    }

    cancel (userId,cb) {
        let url: string = this.apiBaseUrl + apiList.regularisationApprove.approveReject;
        let object = {
             "status" : 4,
        }
        let promise: any = new Promise((resolve, reject) => {
            this.http.put(url+"/"+userId,object)
                .toPromise()
                .then(res => {
                    cb(res);
                })
        })
    }

    /*
       author : Arun Johnson
       desc   : add class based on index
    */
    getClassByValue(index) {
        switch (index % 10) {
            case 0: return "default-avatar islamic-green";
            case 1: return "default-avatar limerick";
            case 2: return "default-avatar chilean-fire";
            case 3: return "default-avatar persian-pink";
            case 4: return "default-avatar deep-magenta";
            case 5: return "default-avatar gigas";
            case 6: return "default-avatar endeavour";
            case 7: return "default-avatar dodger-blue";
            case 8: return "default-avatar jordy-blue";
            case 9: return "default-avatar Light-sea-green";
            case 10: return "emp-profileimage";
        }
    }
   /*
	*  @desc   : make date to the format 'dd-mm-yyyy'
	*  @author : dipin
	*/
	formatForApi(inputDate) {
		var date = this.timeZone.toLocal(inputDate);
		if(date)
		if (!isNaN(date.getTime())) {
			if ((Number(date.getMonth()) + 1) < 10) {
				if (Number(date.getDate() < 10)) {
					return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
				}
				else {
					return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
				}
			}
			else {
				if (Number(date.getDate() < 10)) {
					return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
				}
				else {
					return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
				}
			}
		}
	  else
	  	return undefined;
	}

     /*
  *  @desc   :api call for show message
  *  @author :dipin
  */
  showMessage(id,cb){
    let url : string;
      url = this.apiBaseUrl +"/api/v1/people/"+JSON.parse(this.cookies.get('user-data')).user_id+"/regularizationmessage/"+id;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

  /*
  *  @desc   :method put api call for add leave
  *  @author :dipin
  */
  addMessage(obj,cb) {
    let url: string = this.apiBaseUrl +"/api/v1/regularization-message-submit";
    let promise = new Promise((resolve, reject) => {
      this.http.post(url, obj)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }

   /*
  *  @desc   : delete chat
  *  @author : dipin
  */
  deleteChat(id,messageId,cb) {
    let url: string = this.apiBaseUrl +"/api/v1/people/"+id+"/delregularizationmessage/"+messageId;
    let promise = new Promise((resolve, reject) => {
      this.http.delete(url)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }
}
