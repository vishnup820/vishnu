import { TestBed } from '@angular/core/testing';

import { RegularisationApprovalService } from './regularisation-approval.service';

describe('RegularisationApprovalService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RegularisationApprovalService = TestBed.get(RegularisationApprovalService);
    expect(service).toBeTruthy();
  });
});
