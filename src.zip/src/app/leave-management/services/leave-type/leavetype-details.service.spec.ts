import { TestBed } from '@angular/core/testing';

import { LeavetypeDetailsService } from './leavetype-details.service';

describe('LeavetypeDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LeavetypeDetailsService = TestBed.get(LeavetypeDetailsService);
    expect(service).toBeTruthy();
  });
});
