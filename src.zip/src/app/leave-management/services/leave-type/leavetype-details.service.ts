/*
*  @desc   :service dealing get and post api calls for holiday calender
*  @author :dipin
*/
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import {apiList}  from '../../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class LeavetypeDetailsService {
  selectedValues : any = [];
  selectedService: any = [];
  statusService  : boolean = false;
  apiBaseUrl     : string;
  constructor(
		private http: HttpClient) { this.apiBaseUrl = globalVariables.apiBaseUrl;}

    /*
	*  @desc   :method dealing get api call for leave type details
	*  @author :dipin
	*/
	getCalanderDetails(page, per_page, advanceFilterData, searchValue, obj,callBack) {
		let sortValue: any;
		let serchFilter: any;
		let params: any;
		let stat ="";
        let temp = "";
		if(obj)
		  temp = (obj.type)?"&sort=-"+obj.department:"&sort="+obj.department;

		searchValue ? serchFilter = "&keyword=" + searchValue : serchFilter = "";
		advanceFilterData ? params = this.advanceFilterApi(advanceFilterData) : params = "";

		if(advanceFilterData){
         stat = (advanceFilterData.stat == 1 || advanceFilterData.stat == 0)?"&stat="+advanceFilterData.stat:"";
		}

		let url: string;
		if(page == 0 && per_page == 0)
			url = this.apiBaseUrl + apiList.leaveManagement.leaveType;
		else
		    url = this.apiBaseUrl + apiList.leaveManagement.leaveType+"?page="+page+"&page_limit="+per_page+temp+ params + serchFilter+stat;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	 /*
	*  @desc   :method deleting get api call for delete one item from leave type list
	*  @author :dipin
	*/
	deleteCalenderDetails(obj,callBack) {
		let url: string = this.apiBaseUrl + apiList.leaveManagement.leaveType+"/"+obj;
		let promise = new Promise((resolve, reject) => {
			this.http.delete(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	 /*
	*  @desc   :method deleting post api call for delete multiple item from holida calender list
	*  @author :dipin
	*/
	deleteMultipleCalender(obj,cb) {
		let url: string = this.apiBaseUrl+ apiList.leaveManagement.leaveType;
		let promise = new Promise((resolve, reject) => {
		this.http.request("delete",url,{ body : obj })
				.toPromise()
				.then(res => {
					cb(res);
			})
		})
		return promise;
	}

     /*
	*  @desc   :method deleting get api call for delete one item from holida calender list
	*  @author :dipin
	*/
	getEditData(id,callBack){
      let url: string = this.apiBaseUrl+ apiList.leaveManagement.leaveType+"/"+id;
	  let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

     /*
	*  @desc   :method deleting get api call for delete one item from holida calender list
	*  @author :dipin
	*/
	addCalenderDetails(obj,callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.leaveType;
		let promise = new Promise((resolve, reject) => {
			this.http.post(url,obj)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	  /*
	*  @desc   :method deleting get api call for delete one item from holida calender list
	*  @author :dipin
	*/
	updateCalenderDetails(obj,id,callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.leaveType+"/"+id;
		let promise = new Promise((resolve, reject) => {
			this.http.put(url,obj)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}


    /*
	*  @desc   :method for api call to get holiday calender year
	*  @author :dipin
	*/
	listCalenderYear(callBack) {
		let url = "";
		// let url: string = this.apiBaseUrl+apiList.leaveManagement.holidayCalenderYear;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}


	  /*
	*  @desc   :method for sorting tablr emelents based on columns
	*  @author :dipin
	*/
	sortCalenderDetails(obj,page,callBack) {
		let recordsPerPage;
		if (localStorage.getItem("itemsperpage")) {
			recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			recordsPerPage = 10;
		}

		let temp = (obj.type)?"-"+obj.department:obj.department;
		let url: string = this.apiBaseUrl+apiList.leaveManagement.leaveType+"?page="+page+"&page_limit="+recordsPerPage+"&sort="+temp;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	 /*
	*  @desc   :method for api call to search title with entered term
	*  @author :dipin
	*/
	searchTitle(term,callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.holidayCalenderYear+"?l_n="+term;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	/*
 	 author : dipin
 	 desc   : sort
    */
	sorting(data) {
		let passValue: any;
		data.value == "+" ? passValue = "&sort=" + data.name : passValue = "&sort=" + data.value + data.name;
		return passValue;
	}

	/*
 	 author : dipin
 	 desc   : Advance Filter
    */
	advanceFilterApi(data) {
		let temp,status;
		if(data.stat && data.stat.selected[0])
          temp = (data.stat.selected[0].name == "Active")?1:2;
        else
          temp = null;

        if(temp != null){
          status = "stat=" + temp + "&";
        }
        else{
          status="";
        }

		let location: any = (data.location && data.location.selected[0]) ? "loc_id=" + data.location.selected[0].id + "&" : "";
		let designation: any = (data &&data.designation &&data.designation.selected && data.designation.selected[0]) ? "des_id=" + data.designation.selected[0].id + "&" : "";
		let department: any = (data&& data.department && data.department.selected && data.department.selected[0]) ? "dep_id=" + data.department.selected[0].id + "&" : "";
		let parms: any = "&" + status + location + designation +department;
		return parms.substring(0, parms.length - 1);
	}

    getAddLeaveData(callBack){
    	let url: string = this.apiBaseUrl+apiList.company.details+"?fields=set,set_t,set_m,set_v&set_t=2";
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
    }

}
