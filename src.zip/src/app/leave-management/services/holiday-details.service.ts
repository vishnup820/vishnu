/*
*  @desc   :service dealing get and post api calls for holiday calender
*  @author :dipin
*/
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from './../../shared/constants/globals';
import {apiList}  from './../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class HolidayDetailsService {
	apiBaseUrl      : string;
	status          : any = 0;

  constructor(
		private http: HttpClient) { this.apiBaseUrl = globalVariables.apiBaseUrl;}

    /*
	*  @desc   :method dealing get api call for holiday calender details
	*  @author :dipin
	*/
	getCalanderDetails(page,per_page,obj,year,callBack) {
        let temp = "";
		if(obj)
		  temp = (obj.type)?"-"+obj.department:obj.department;
		let url: string = this.apiBaseUrl + apiList.leaveManagement.holidayCalender+"?page="+page+"&page_limit="+per_page+"&sort="+temp+"&year="+year;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	 /*
	*  @desc   :method deleting get api call for delete one item from holida calender list
	*  @author :dipin
	*/
	deleteCalenderDetails(obj,callBack) {
		let url: string = this.apiBaseUrl + apiList.leaveManagement.holidayCalenderDeleteOne+obj;
		let promise = new Promise((resolve, reject) => {
			this.http.delete(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	 /*
	*  @desc   :method deleting post api call for delete multiple item from holida calender list
	*  @author :dipin
	*/
	deleteMultipleCalender(obj,cb) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.holidayCalenderDeleteMulti;
		let promise = new Promise((resolve, reject) => {
		this.http.request("delete",url,{ body : obj })
				.toPromise()
				.then(res => {
					cb(res);
			})
		})
		return promise;
	}

     /*
	*  @desc   :method deleting get api call for delete one item from holida calender list
	*  @author :dipin
	*/
	addCalenderDetails(obj,callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.holidayCalenderAdd;
		let promise = new Promise((resolve, reject) => {
			this.http.post(url,obj)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	  /*
	*  @desc   :method deleting get api call for delete one item from holida calender list
	*  @author :dipin
	*/
	updateCalenderDetails(obj,id,callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.holidayCalenderAdd+"/"+id;
		let promise = new Promise((resolve, reject) => {
			this.http.put(url,obj)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}


    /*
	*  @desc   :method for api call to get holiday calender year
	*  @author :dipin
	*/
	listCalenderYear(callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.holidayCalenderYear;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}


	  /*
	*  @desc   :method for sorting tablr emelents based on columns
	*  @author :dipin
	*/
	sortCalenderDetails(obj,page, year ,callBack) {
		let recordsPerPage;
		if (localStorage.getItem("itemsperpage")) {
			recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			recordsPerPage = 10;
		}
		let temp = (obj.type)?"-"+obj.department:obj.department;
		let url: string = this.apiBaseUrl+apiList.leaveManagement.sortHolidayCalander+"page="+page+"&page_limit="+recordsPerPage+"&sort="+temp+"&year="+year;;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}
  /*
  * @ desc   :  method to check value receving from filter is same or not
  * @ author  : nilena alexander
  */

 checkFilterStatus(stat) {

    let ret = true;
    if (stat == 0 && (this.status == stat)
    ) {
      ret = false;
    }
    this.status = stat;
    return ret;
  }

	/*
  * @ desc   :  method to check value receving from filter is same or not with previous val
  * @ author  : nilena alexander
  */
  checkFilterCanCancel() {

    let ret = true;
    if (this.status == 0) {
      return false;
    }
    return true;
  }
	/*
  * @ desc   :  method to clear filter
  * @ author  : nilena alexander
  */

  clearFilterStatus() {
    this.status = 0;
  }


}
