import { TestBed } from '@angular/core/testing';

import { ManagerCompensatoryService } from './manager-compensatory.service';

describe('ManagerCompensatoryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ManagerCompensatoryService = TestBed.get(ManagerCompensatoryService);
    expect(service).toBeTruthy();
  });
});
