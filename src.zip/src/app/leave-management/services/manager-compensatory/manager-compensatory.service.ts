/*
*  @desc   : service dealing get and post api calls for Manger list
*  @author : Arun johnson
*/
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

import 'rxjs/add/operator/toPromise';

import { globalVariables } from '../../../shared/constants/globals';
import {apiList}  from '../../../shared/constants/apilist';

import { CookieService } from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root'
})
export class ManagerCompensatoryService {

	apiBaseUrl: string;
	constructor(
		private http                 : HttpClient,
        private cookies              : CookieService,) { this.apiBaseUrl = globalVariables.apiBaseUrl; }

    /*
	*  @desc   : method dealing get api call for manger list details
	*  @author : arunjohnson
	*/
    getMangerDetails(page, per_page, searchValue ,advanceFilterData, cb) {
        let userId;
        this.cookies.get('user-data') ? userId = JSON.parse(this.cookies.get('user-data')).user_id : null;
        let serchFilter : any = null;
        searchValue ? serchFilter = "&keyword=" + searchValue : serchFilter = " ";
        let advanceFilter: any = null;
        advanceFilterData ? advanceFilter = this.advanceFilterApi(advanceFilterData) : advanceFilter = "";
        let url: string = this.apiBaseUrl + apiList.manager.details;
        let promise: any = new Promise((resolve, reject) => {
            this.http.get(url + "/" +userId + "/compensatory-requests" + "?page=" + page + "&page_limit=" + per_page + advanceFilter + serchFilter)
                .toPromise()
                .then(res => {
                    cb(res);
                })
        })
    }

    /*
    *  @desc   : get financialyears
    *  @author : arunjohnson
    */
    financialyears(id,cb) {
        let url: string = this.apiBaseUrl +apiList.leaveManagement.leaveType+"/"+0+"/restrictions/"+id;
        let promise: any = new Promise((resolve, reject) => {
            this.http.get(url)
                .toPromise()
                .then(res => {
                    cb(res);
                })
        })
    }

    /*
      author : Arun Johnson
      desc   : delete People
    */
    deletePeople(selectedPeople, cb) {
        let url: string = this.apiBaseUrl + apiList.manager.delete;
        let promise: any = new Promise((resolve, reject) => {
            this.http.delete(url + "/" + selectedPeople.id)
                .toPromise()
                .then(res => {
                    cb(res);
                })
        })
    }


    /*
      author : Arun Johnson
      desc   : Advance Filter
    */
    advanceFilterApi(data) {
        let status: any;
        (data.status && data.status.selected[0]) ? status="&stat="+data.status.selected[0].name:status= "";
        let date : any;
        (data.bsValue) ? date="&date="+this.formateDate(data.bsValue):date = "";
        let parms: any = null;
        parms = status + date;
        return parms;
    }

    /*
      author : Arun Johnson
      desc   : Get Manger data
    */
    getManagerData(id, cb) {
        let url: string = this.apiBaseUrl + apiList.manager.edit;
        let promise: any = new Promise((resolve, reject) => {
            this.http.get(url + "/" + id)
                .toPromise()
                .then(res => {
                    cb(res);
                })
        })
    }

    /*
      author : Arun Johnson
      desc   : edit compensatory
    */
    editCompensatory(id, dateArray, reason, empId, expDate, cb) {
        let url: string = this.apiBaseUrl + apiList.manager.edit;
        let data  : any = []
        for(let i=0;i<dateArray.length;i++) {
            data.push({"from":this.formateDate(dateArray[i].start_date),"to":this.formateDate(dateArray[i].end_date),"application_type":dateArray[i].type})
        }
        let object: any = {
            employee_id: empId,
            date: data,
            expired_date: this.formateDate(expDate),
            description: reason
        }
        let promise: any = new Promise((resolve, reject) => {
            this.http.put(url + "/" + id, object)
                .toPromise()
                .then(res => {
                    cb(res);
                })
        })
    }

    /*
      author : Arun Johnson
      desc   : add new form data
    */
    addCompensatory(empDetails,dateArray, reason, empId, expDate, cb) {
        let data  : any = []
        for(let i=0;i<dateArray.length;i++) {
            data.push({"from":this.formateDate(dateArray[i].start_date),"to":this.formateDate(dateArray[i].end_date),"application_type":dateArray[i].type})
        }
        let url: string = this.apiBaseUrl + apiList.manager.edit;
        let object: any = {
            employee_id: empDetails.code,
            date: data,
            expired_date: this.formateDate(expDate),
            description: reason
        }
        let promise: any = new Promise((resolve, reject) => {
            this.http.post(url, object)
                .toPromise()
                .then(res => {
                    cb(res);
                })
        })
    }

    /*
      author : Arun Johnson
      desc   : get employee details based on empid
    */
    getEmpDetails(empId, cb) {

        let role_id = JSON.parse(this.cookies.get('user-data')).role_id;
        if (role_id == 2) {
            let url: string = this.apiBaseUrl + apiList.manager.adminList;
            let promise: any = new Promise((resolve, reject) => {
                this.http.get(url + "?keyword=" + empId)
                    .toPromise()
                    .then(res => {
                        cb(res);
                    })
            })
        } else {
            let url: string = this.apiBaseUrl + apiList.manager.details;
            let promise: any = new Promise((resolve, reject) => {
                this.http.get(url + "/" + JSON.parse(this.cookies.get('user-data')).user_id + "/compensatory-users?keyword=" + empId)
                    .toPromise()
                    .then(res => {
                        cb(res);
                    })
            })
        }
    }

    /*
      author : Arun Johnson
      desc   : format date
    */
    formateDate(date) {
        if (date) {
            var curr_date = date.getDate();
            var curr_month = date.getMonth() + 1; //Months are zero based
            var curr_year = date.getFullYear();
            return (curr_year + "-" + curr_month + "-" + curr_date)
        }
    }

    /*
       author : Arun Johnson
       desc   : add class based on index
    */
    getClassByValue(index) {
        switch (index % 10) {
            case 0: return "default-avatar islamic-green";
            case 1: return "default-avatar limerick";
            case 2: return "default-avatar chilean-fire";
            case 3: return "default-avatar persian-pink";
            case 4: return "default-avatar deep-magenta";
            case 5: return "default-avatar gigas";
            case 6: return "default-avatar endeavour";
            case 7: return "default-avatar dodger-blue";
            case 8: return "default-avatar jordy-blue";
            case 9: return "default-avatar Light-sea-green";
            case 10: return "emp-profileimage";
        }
    }
}
