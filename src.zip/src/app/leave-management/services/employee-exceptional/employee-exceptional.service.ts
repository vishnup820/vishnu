/*
*  @desc   :service dealing get and post api calls for holiday calender
*  @author :dipin
*/
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from './../../../shared/constants/globals';
import {apiList}  from './../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root'
})
export class EmployeeExceptionalService {

  apiBaseUrl      : string;

	constructor(private http: HttpClient) {
		this.apiBaseUrl = globalVariables.apiBaseUrl;
	
	}

    /*
	*  @desc   :method dealing get api call for Exceptional calender details
	*  @author :dipin
	*/
	getCalanderDetails(page,per_page, uid, callBack) {
		let url: string = this.apiBaseUrl+"/api/v1/people/"+uid+"/exceptional-workings"+"?page="+page+"&page_limit="+per_page;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

    /*
	*  @desc   :method for sorting tablr Exceptional based on columns
	*  @author :dipin
	*/
	sortCalenderDetails(obj,uid,callBack) {
		let temp = (obj.type)?"-"+obj.department:obj.department;
		let url: string = this.apiBaseUrl+"/api/v1/people/"+uid+"/exceptional-workings?sort="+temp;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}
}
