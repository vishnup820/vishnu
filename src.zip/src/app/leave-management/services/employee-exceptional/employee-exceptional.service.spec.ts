import { TestBed } from '@angular/core/testing';

import { EmployeeExceptionalService } from './employee-exceptional.service';

describe('EmployeeExceptionalService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EmployeeExceptionalService = TestBed.get(EmployeeExceptionalService);
    expect(service).toBeTruthy();
  });
});
