import { TestBed } from '@angular/core/testing';

import { HrCompensatoryApprovalService } from './hr-compensatory-approval.service';

describe('HrCompensatoryApprovalService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HrCompensatoryApprovalService = TestBed.get(HrCompensatoryApprovalService);
    expect(service).toBeTruthy();
  });
});
