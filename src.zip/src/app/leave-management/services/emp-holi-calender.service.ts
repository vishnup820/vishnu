/*
*  @desc   :service dealing get and post api calls for holiday calender for employee
*  @author :hashid
*/

import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from './../../shared/constants/globals';
import {apiList}  from './../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class EmpHoliCalenderService {
	apiBaseUrl      : string;
	status          : any = 0;

  constructor(
  	private http: HttpClient) {
  	this.apiBaseUrl = globalVariables.apiBaseUrl;
  
  }



		  /*
	*  @desc   :method for sorting tablr emelents based on columns
	*  @author :hashid
	*/


  	getEmploHoliDetails(page,per_page,year,userid,cb) {
        let url = this.apiBaseUrl + apiList.leaveManagement.employeeholiday+ userid + "/" + "holidays"+"?page="+page+"&page_limit="+per_page+"&year="+year;
		// url = url + this.generateQuery(queryObject);
		let promise: any = new Promise((resolve, reject) => {
	  		this.http.get(url)
				.toPromise()
				.then(res => {
					res && res['status'] == 'OK' && cb(res)
				})
		})
  	}

    /*
	*  @desc   :method for api call to get holiday calender year
	*  @author :dipin
	*/
	listCalenderYear(callBack) {
		let url: string = this.apiBaseUrl+apiList.leaveManagement.holidayCalenderYear;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}


		  /*
	*  @desc   :method for sorting tablr emelents based on columns
	*  @author :hashid
	*/
	sortCalenderDetails(obj,year,userid,callBack) {
		let temp = (obj.type)?"-"+obj.department:obj.department;
		let url: string = this.apiBaseUrl+apiList.leaveManagement.employeeholiday+ userid + "/" + "holidays?"+"&year="+year+"sort="+obj.sort;
		// url = url + this.generateQuery(queryObject);;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

    /*
	*  @desc   :sort data
	*  @author :vinod.k
	*/
	getSortValue(page,per_page,qobj,year,userid,callBack){
		let url: string = this.apiBaseUrl+apiList.leaveManagement.employeeholiday+ userid + "/" + "holidays?"+"page="+page+"&page_limit="+per_page+"&year="+year+qobj.sort;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}
  /*
  * @ desc   :  method to check value receving from filter is same or not
  * @ author  : nilena alexander
  */

 checkFilterStatus(stat) {

    let ret = true;
    if (stat == 0 && (this.status == stat)
    ) {
      ret = false;
    }
    this.status = stat;
    return ret;
  }

	/*
  * @ desc   :  method to check value receving from filter is same or not with previous val
  * @ author  : nilena alexander
  */
  checkFilterCanCancel() {

    let ret = true;
    if (this.status == 0) {
      return false;
    }
    return true;
  }
	/*
  * @ desc   :  method to clear filter
  * @ author  : nilena alexander
  */

  clearFilterStatus() {
    this.status = 0;
  }



}
