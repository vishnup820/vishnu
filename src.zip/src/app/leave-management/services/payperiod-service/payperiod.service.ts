import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { apiList } from '../../../shared/constants/apilist';
import { globalVariables } from '../../../shared/constants/globals';

@Injectable({
  providedIn: 'root'
})
export class PayperiodService {
  apiBaseUrl  : string;
  constructor(private http:HttpClient) {
  	this.apiBaseUrl = globalVariables.apiBaseUrl;
   }

   getAllPayperiod(qObj,cb) {
		let url: string = this.apiBaseUrl+apiList.payperiod.payperiodListing;
		url = url + this.generateQuery(qObj)
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res)
					// res['status'] && res['data'] && res['data'].length? cb(res) : cb(null);
				})
		})
	}
	generateQuery(queryObject) {
		let query = `?page=${queryObject.page?queryObject.page: ''}&page_limit=${queryObject['page_limit']?queryObject['page_limit']: ''}${queryObject.st?'&st=' + queryObject.st:''}${queryObject.keyword?'&keyword=' + queryObject.keyword: ''}`

		return query;
	}
	deletePayperiod(id,cb){
		let url: string = this.apiBaseUrl+apiList.payperiod.payperiodListing + "/" + id;
		let promise: any = new Promise((resolve, reject) => {
			this.http.delete(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}
	submitPayPeriodMaster(id,label,obj,callback){
		if(label == "Add"){
			let url: string = this.apiBaseUrl+apiList.payperiod.payperiodListing;
			let promise: any = new Promise((resolve, reject) => {
			this.http.post(url,obj)
				.toPromise()
				.then(res => {
					callback(res)
					// res['status'] && res['data'] && res['data'].length? cb(res) : cb(null);
				})
			})
		}else{
			let url: string = this.apiBaseUrl+apiList.payperiod.payperiodListing + "/" + id;
			let promise: any = new Promise((resolve, reject) => {
			this.http.put(url,obj)
				.toPromise()
				.then(res => {
					callback(res)
					// res['status'] && res['data'] && res['data'].length? cb(res) : cb(null);
				})
			})
		}
	}

	getAllEditedDatas(id,call_back){
		let url: string = this.apiBaseUrl+apiList.payperiod.payperiodListing + "/" + id;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					call_back(res)
					// res['status'] && res['data'] && res['data'].length? cb(res) : cb(null);
				})
		})	
	}
}
