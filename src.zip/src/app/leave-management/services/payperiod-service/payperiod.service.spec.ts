import { TestBed } from '@angular/core/testing';

import { PayperiodService } from './payperiod.service';

describe('PayperiodService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PayperiodService = TestBed.get(PayperiodService);
    expect(service).toBeTruthy();
  });
});
