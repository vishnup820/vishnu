import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[leaveAutoFocus]'
})
export class AutoFocusDirective {
 constructor(private elementRef: ElementRef) { };

  ngOnInit(): void {
    this.elementRef.nativeElement.focus();
    this.elementRef.nativeElement.scrollIntoView({behavior:"smooth"});
  }
}
