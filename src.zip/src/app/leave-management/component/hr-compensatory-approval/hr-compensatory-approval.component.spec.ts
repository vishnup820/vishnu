import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HrCompensatoryApprovalComponent } from './hr-compensatory-approval.component';

describe('HrCompensatoryApprovalComponent', () => {
  let component: HrCompensatoryApprovalComponent;
  let fixture: ComponentFixture<HrCompensatoryApprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HrCompensatoryApprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HrCompensatoryApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
