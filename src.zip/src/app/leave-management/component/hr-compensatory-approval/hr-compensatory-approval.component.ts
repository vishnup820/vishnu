import { Component, OnInit } from '@angular/core';

import { HrCompensatoryApprovalService } from '../../services/hr-compensatory-approval/hr-compensatory-approval.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { PendingListService } from '../../../shared/services/pending-list/pending-list.service';
import { CookieService } from 'ngx-cookie-service';
@Component({
  selector: 'app-hr-compensatory-approval',
  templateUrl: './hr-compensatory-approval.component.html',
  styleUrls: ['../../../../assets/content/css/policy-listing.css']
})
export class HrCompensatoryApprovalComponent implements OnInit {

  advanceFilterData     : any;
  searchValue           : any;
  approvalDetails       : any;
  approveId             : any;
  config                : any;
  userData              : any;
  rejectPopUp           : boolean = false;
  searchTextBox         : boolean = false;
  filterStatus          : boolean = false;
  currentPage           : number = 1;
  recordsPerPage        : number = 10;
  totalRecords          : number;
  compensatoryDatesId   : number;
  userId                : number;

  rejectStatus          : boolean = false;
  nodata                : boolean = false;
  confirmBox            : boolean = false;

  minDate               : any
  maxDate               : any
  dateValue             : Date = new Date();

  constructor(
    private notificationService           : NotificationService,
  	private hrCompensatoryApprovalService : HrCompensatoryApprovalService,
  	private loaderActionsService          : LoaderActionsService,
    private timeZone                      : TimezoneDetailsService,
     private PendingListService           : PendingListService,
     private cookieService                : CookieService) { }

  ngOnInit() {
    this.dateValue = this.timeZone.getCurrentDate();
    this.loaderActionsService.display(true);
  	this.config = "Are You Sure You Want To Confirm?";
    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    if (this.cookieService.get("user-data")) {
      this.userData = JSON.parse(this.cookieService.get("user-data"));
      this.minDate= this.timeZone.toLocal(this.userData.end_date);
      this.maxDate= this.timeZone.toLocal(this.userData.end_date);
    }
  	this.getDetails(this.currentPage);
  }


 /*
  *  @desc   :update local storage acl data for notification count
  *  @author : ashiq
 */
  updateList(){
    this.PendingListService.getPendingList(response => {
      if (response) {
            let pendata = response;
          let aclData=  JSON.parse(localStorage.getItem("acl"));
          if(aclData.acl.length>0){
            for(let i=0; i<aclData.acl.length;i++){
              if(aclData.acl[i].name=='Approvals'){
                aclData.acl[i].acl.pending=pendata.total_pending;
                for(let j=0;j<aclData.acl[i].child.length; j++){
                    if(aclData.acl[i].child[j].name=='Compensatory Approval'){
                      aclData.acl[i].child[j].acl.pending=pendata.compensatory[0].pending;
                    }
                  }
              }
            }
          }
          localStorage.setItem('acl',JSON.stringify(aclData))
          this.PendingListService.setAclData(aclData);
        }
    })
  }

  /*
  *  @desc   : get approval details
  *  @author : arunjohnson
 */
  getDetails(page) {
  	this.currentPage = page;
  	this.loaderActionsService.display(true);
  	this.hrCompensatoryApprovalService.getDetails(this.currentPage,this.recordsPerPage,this.searchValue,this.advanceFilterData,res=>{
  		if (res.status == "OK" && res.data && res.data.length) {
        	this.totalRecords         = res.count;
        	this.approvalDetails      = res.data;
          this.loaderActionsService.display(false);
        }
        else {
        this.approvalDetails  = [];
        this.nodata           = true;
        this.loaderActionsService.display(false);
      }
  	})
  }

  /*
	*  @desc   : commpensatory single date details
	*  @author : arunjohnson
 */
  singleDateDetails(comp_request_details_id,id) {
  	this.compensatoryDatesId = comp_request_details_id;
  	this.userId              = id;
  	this.rejectPopUp         = true;
  }

  /*
	*  @desc   : commpensatory reject  by hr
	*  @author : arunjohnson
 */
  dateDelete(event) {
	  if (this.rejectStatus) {
        this.rejectPopUp = false;
        this.loaderActionsService.display(true);
      this.hrCompensatoryApprovalService.singleDateDelete(event.value, this.compensatoryDatesId, this.userId, res => {
        this.loaderActionsService.display(false);
        if(res.status == "OK") {
          this.updateList();
          this.notificationService.alertBoxValue("success",res.message);
          this.getDetails(this.currentPage);
        } else {
          this.updateList();
          this.notificationService.alertBoxValue("error",res.message);
          this.getDetails(this.currentPage);
          this.rejectPopUp = false;
        }
		  })
	  } else {
      this.rejectPopUp = false;
      this.loaderActionsService.display(true);
      this.hrCompensatoryApprovalService.rejectData(event.value, this.userId, res => {
        this.loaderActionsService.display(false);
        if(res.status == "OK") {
          this.updateList();
          this.notificationService.alertBoxValue("success",res.message);
          this.getDetails(this.currentPage);
        } else {
          this.updateList();
          this.notificationService.alertBoxValue("error",res.message);
          this.getDetails(this.currentPage);
          this.rejectPopUp = false;
        }
		})
	  }
  }

  /*
	*  @desc   : commpensatory approve by hr
	*  @author : arunjohnson
  */
  approveCompensatory(event) {
    this.confirmBox = false;
    if (event.status == true) {
      this.loaderActionsService.display(true);
      this.hrCompensatoryApprovalService.approve(this.approveId,event.value,res => {
        this.loaderActionsService.display(false);
        if (res.status == "OK") {
          this.updateList();
          this.notificationService.alertBoxValue("success", res.message);
          this.getDetails(this.currentPage);
        } else {
          this.updateList();
          this.notificationService.alertBoxValue("error", res.message);
          this.getDetails(this.currentPage);
        }
      })
    }
  }

  /*
   author : Arun Johnson
   desc   : Search  when enter key is pressed
  */
  search(value) {
   if (value.trim() != '' || (this.searchValue != '' && this.searchValue)) {
    this.searchValue = value;
    this.currentPage = 1;
    this.getDetails(this.currentPage);
   }
  }

   /*
   author : Arun Johnson
   desc   : send Filter Data
   params :
  */
  filterData(data) {
    if(data||  this.advanceFilterData  ){
      this.advanceFilterData  = data;
      this.currentPage        = 1;
      this.getDetails(this.currentPage);
    }else{
      this.advanceFilterData = undefined;
    }

   }

  /*
  author : Arun Johnson
  desc   : Expiry date change
  params :
   */
  changeDate(event, index) {
    // // this.approvalDetails[index]['expired_date'] = this.formatForApi(event);
  }

  formatForApi(inputDate) {
    var date = this.timeZone.toLocal(inputDate);
    if(date)
    if (!isNaN(date.getTime())) {
      if ((Number(date.getMonth()) + 1) < 10) {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
      else {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
    }
    else
      return undefined;
  }


  /*
  author : Arun Johnson
  desc   : add class based on index
 */
  getClassByValue(index) {
    return this.hrCompensatoryApprovalService.getClassByValue(index);

  }

  setFocus() {
    window.setTimeout(function() {
      document.getElementById('searchField').focus();
    }, 1);
  }

      /*
  *  @desc   :method for pagination
  *  @author :dipin
  */
  getpage(event) {
    if (event > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      this.getDetails(this.currentPage);
    }
  }
}
