/*
*  @desc   :component for add holiday popup
*  @author :dipin
*/
import { Component, OnInit,Input,Output,EventEmitter,OnChanges,SimpleChanges } from '@angular/core';
import { FormGroup,FormControl, Validators,FormBuilder } from '@angular/forms';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { HolidayDetailsService } from '../../services/holiday-details.service';
import {apiList}  from '../../../shared/constants/apilist';
import { MalihuScrollbarService } from 'ngx-malihu-scrollbar';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'hris-holiday',
  templateUrl: './add-holiday.component.html',
  styleUrls: ['./add-holiday.component.css']
})
export class AddHolidayComponent implements OnInit,OnChanges {
 @Input()  addStatus  : boolean;
 @Input()  editStatus : boolean;
 @Input()  editConfig : any;
 @Output() valueChange = new EventEmitter();
 @Output() successPro  = new EventEmitter();

 addForm     : FormGroup;
 yearField   : FormControl;
 titleField  : FormControl;
 dateField   : FormControl;
 statusField : FormControl;

  submitted      : boolean = false;
  setApplicable  : boolean = false;
  lazyLoad       : boolean = false;
  isOpen         : boolean = false;
  minDate        : Date = new Date();
  maxDate        : any;
  yearList       : any     = [];
  statusList     : any     = [];
  statusSelected : any     = [];
  yearSelected   : any     = [];
  selectedYear   : any;
  selectedData   : any;
  scrollbar      : any;
  uCurrent       : any;
  predefinedId   : any     = [];
  dateSelected :any
  userData :any 
  constructor(private apiService: HolidayDetailsService,
    private notifications : NotificationService,
    private mScrollbarService: MalihuScrollbarService,
    private timezone       : TimezoneDetailsService,
    private cookieService  : CookieService) { }

  ngOnInit() {
    let self = this;
    if (this.cookieService.get("user-data")) {
      this.userData = JSON.parse(this.cookieService.get("user-data"));
      this.maxDate = this.timezone.toLocal(this.userData.end_date)
    }
    this.scrollbar = {
      axis: 'y', theme: 'minimal-dark', autoHideScrollbar: false, advanced: { autoScrollOnFocus: 'false' }, callbacks: {
        onScrollStart: function() {
          self.isOpen = false;
        }.bind(self)
      }
    }
    let date = this.timezone.getCurrentDate();
    this.minDate = this.timezone.getCurrentDate();
    this.statusList = [{ value: 'Active' }, { value: 'Inactive' }];
    this.statusSelected = [0];
    this.yearSelected = [0];
    this.createFormControls();
    this.createForm();
    this.predefinedId = [{
      id: 1, name: "location"
    },
    { id: 2, name: "user" },
    { id: 3, name: "group" },
    { id: 4, name: "department" },
    { id: 5, name: "designation"}
    ]
     this.uCurrent = apiList.leaveManagement.holidayCalenderDeleteOne;
  }

  ngOnChanges(changes: SimpleChanges) {
    let date = this.timezone.getCurrentDate();
    window.scrollTo(0, 0);
    this.submitted = false;
    this.lazyLoad = true;
    if(this.addStatus){
    this.apiService.listCalenderYear(response => {
      if (response.status == "OK") {
        this.yearList = response.data;
        if (this.editStatus) {
          let tempDate = this.timezone.toLocal(this.editConfig.day);
          this.uCurrent = apiList.leaveManagement.holidayCalenderDeleteOne;
          this.addForm.patchValue({
            yearField: tempDate.getFullYear(),
            titleField: this.editConfig.title,
            dateField: this.timezone.toLocal(this.editConfig.day),
          });
          this.statusSelected = (this.editConfig.status == 1) ? [0] : [1];
          for(var i = 0;i < this.yearList.length;i++){
            if(this.yearList[i].year == this.timezone.toLocal(this.editConfig.day).getFullYear()){
               this.yearSelected = [i];
               let temp = new Date(new Date(this.yearList[i].year.toString()).getFullYear(), 11, 31);
               this.maxDate = this.timezone.toLocal(temp);
            }
          }
          this.lazyLoad = false;
        }
        else {
          if (this.addForm) {
            this.addForm.reset();
            this.statusSelected = [0];
            this.submitted = false;
            for (var i = 0; i < this.yearList.length; i++) {
              if (this.yearList[i].year == date.getFullYear()) {
                this.yearSelected = [i];
                let temp = new Date(new Date(this.yearList[i].year.toString()).getFullYear(), 11, 31);
                this.maxDate = this.timezone.toLocal(temp);
              }
            }
          }
          this.lazyLoad = false;
        }
      }
      else {
        this.yearList = [];
        this.lazyLoad = false;
      }
    })
   }
  }

  /*
  *  @desc   :Create and define form controls of createNew form
  *  @author :dipin
  */
  createFormControls() {
    this.yearField = new FormControl('', [Validators.required]);
    this.titleField = new FormControl('', [Validators.required,this.noWhitespaceValidator]);
    this.dateField = new FormControl('', [Validators.required]);
    this.statusField = new FormControl('', [Validators.required]);
  }

  /*
*  @desc   :create form itemForm and addForm
*  @author :dipin
*/
  createForm() {
    this.addForm = new FormGroup({
      yearField: this.yearField,
      titleField: this.titleField,
      dateField: this.dateField,
      statusField: this.statusField
    });
  }

  /*
  *  @desc   :hide popup and emit false value for parent component
  *  @author :dipin
  */
  cancelPopup() {
    this.addStatus = false;
    this.addForm.reset();
    this.valueChange.emit(false);
  }

  /*
  *  @desc   : validating submited data send t the server using api call
  *  @author : dipin
  */
  addHoliday() {
    let outputData = [];
    let nonOutData = [];
    this.submitted = true;

    if (this.selectedData) {
      for (var i = 0; i < this.selectedData.applicable.length; i++) {
        for (var j = 0; j < this.predefinedId.length; j++) {
          if (this.predefinedId[j].name == this.selectedData.applicable[i].name) {
            if (this.selectedData.applicable[i].selectedAll == true) {
              outputData.push({ category: this.predefinedId[j].id, reference_id: 0 });
            }
            else {
              for (var k = 0; k < this.selectedData.applicable[i].list.length; k++) {
                if (this.selectedData.applicable[i].list[k].is_selected == 1) {
                  outputData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.applicable[i].list[k].id });
                }
              }
            }
          }
        }
      }

      for (var i = 0; i < this.selectedData.notApplicable.length; i++) {
        for (var j = 0; j < this.predefinedId.length; j++) {
          if (this.predefinedId[j].name == this.selectedData.notApplicable[i].name) {
            if (this.selectedData.notApplicable[i].selectedAll == true) {
              nonOutData.push({ category: this.predefinedId[j].id, reference_id: 0 });
            }
            else {
              for (var k = 0; k < this.selectedData.notApplicable[i].list.length; k++) {
                if (this.selectedData.notApplicable[i].list[k].is_selected == 1) {
                  nonOutData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.notApplicable[i].list[k].id });
                }
              }
            }
          }
        }
      }
    }
  
    this.addForm.controls['dateField'].setErrors(null);
    this.addForm.updateValueAndValidity()
   if (this.addForm.invalid || outputData.length == 0) {
      if(outputData.length == 0 && this.addForm.valid){
        this.setApplicable = true;
        this.notifications.alertBoxValue("error", "Select Options For Applicable For");
      }
      if (!this.titleField.valid) {
        this.mScrollbarService.scrollTo("top",document.getElementById("last-name"),{scrollInertia:0});
        document.getElementById("last-name").focus();
      }
      else if (!this.dateField.valid) {
        this.mScrollbarService.scrollTo("top",document.getElementById("date-of-joing"),{scrollInertia:0});
        document.getElementById("date-of-joing").focus();
      }
      return;
    }
    else{
       this.setApplicable = false;
      let temp = {
        calendar_id           : this.selectedYear.id,
        title                 : this.titleField.value.trim(),
        day                   : this.formatForApi(this.dateField.value),
        status                : (this.statusField.value == "Active")?1:2,
        applicable_for        : outputData,
        not_applicable_for    : nonOutData
      }
      if(this.editStatus){
        this.lazyLoad = true;
        this.apiService.updateCalenderDetails(temp,this.editConfig.id,response=>{
                  if(response.status == "OK"){
                    this.notifications.alertBoxValue("success", "Holiday Updated Successfully");
                     setTimeout(() => {
                       this.cancelPopup();
                       this.successPro.emit(true);
                       this.lazyLoad = false;
                     }, 600);
                  }
                  else{
                     this.notifications.alertBoxValue("error", response.message);
                      this.successPro.emit(false);
                      this.lazyLoad = false;
                  }
          })
      }
      else{
        this.lazyLoad = true;
         this.apiService.addCalenderDetails(temp,response=>{
                  if(response.status == "OK"){
                    this.notifications.alertBoxValue("success", "Holiday Added Successfully");
                     setTimeout(() => {
                       this.cancelPopup();
                       this.successPro.emit(true);
                       this.lazyLoad = false;
                     }, 600);
                  }
                  else{
                     this.notifications.alertBoxValue("error", response.message);
                     this.lazyLoad = false;
                     this.successPro.emit(false);
                  }
          })
      }
    }
  }
  dateChange(event){
  //   let year= event.getFullYear()
  //   for(let i =0 ;i<this.yearList.length;i++){
  //   }
  }
  /*
  *  @desc   : method deal with year field single selection
  *  @author : dipin
  */
  selectedDataYear(event) {
    this.selectedYear = event.selected[0];
  

    if(!this.editStatus){
       this.minDate=null;
      let dateSelected= new Date();
      if(this.selectedYear.year <= dateSelected.getFullYear() ){
        let maxYear= dateSelected.getFullYear()
        this.minDate = this.timezone.getCurrentDate();
        let temp = new Date(new Date(maxYear.toString()).getFullYear(), 11, 31); 
        this.maxDate = this.timezone.toLocal(temp); 
        this.addForm.patchValue({
          dateField:  this.minDate 
        })
      }else{
        let c = '1/01/'+ this.selectedYear.year;
        this.dateSelected= new Date(c );
        let temp = new Date(new Date(this.selectedYear.year.toString()).getFullYear(), 11, 31); 
        this.maxDate = this.timezone.toLocal(temp); 
        let temp1 = new Date(new Date(this.selectedYear.year.toString()).getFullYear(), 0, 1); 
        this.minDate = this.timezone.toLocal(temp1); 
      }
      }else{
        let dateSelected= new Date();
        if(this.selectedYear.year <= dateSelected.getFullYear() ){
          let maxYear= dateSelected.getFullYear()
          this.minDate = this.timezone.getCurrentDate();
          let temp = new Date(new Date(maxYear.toString()).getFullYear(), 11, 31); 
          this.maxDate = this.timezone.toLocal(temp); 
        }
        else{
        let c = this.timezone.toLocal(this.editConfig.day);

        this.dateSelected= new Date(c );
        let temp = new Date(new Date(this.selectedYear.year.toString()).getFullYear(), 11, 31); 
        this.maxDate = this.timezone.toLocal(temp); 
        // let temp1 = new Date(new Date(this.selectedYear.year.toString()).getFullYear(), 0, 1); 
        // this.minDate = this.timezone.toLocal(temp1); 
                  this.minDate = this.timezone.getCurrentDate();

      }
    }
     
    
    if (event.selected.length)
      this.addForm.patchValue({
        yearField: event.selected[0].year
      })
    else
      this.addForm.patchValue({
        yearField: ""
      })
  }

  /*
 *  @desc   : method deal with year field single selection
 *  @author : dipin
 */
  selectedStatusList(event) {
    if (event.selected.length)
      this.addForm.patchValue({
        statusField: event.selected[0].value
      })
    else
      this.addForm.patchValue({
        statusField: ""
      })
  }

  /*
 *  @desc   : method deal with conversion of date format
 *  @author : dipin
 */
 formatDate(inputDate) {
    var date = this.timezone.toLocal(inputDate);
    if (!isNaN(date.getTime())) {
      if ((Number(date.getMonth()) + 1) < 10) {
        if (Number(date.getDate() < 10)) {
          return "0" + date.getDate() + "-0" + (Number(date.getMonth()) + 1) +"-"+ date.getFullYear();
        }
        else {
         return date.getDate() + "-0" + (Number(date.getMonth()) + 1) +"-"+ date.getFullYear();
        }
      }
      else {
        if (Number(date.getDate() < 10)) {
         return date.getDate() +"-"+ (Number(date.getMonth()) + 1) +"-"+ date.getFullYear();
        }
        else {
          return date.getDate() +"-"+ (Number(date.getMonth()) + 1) +"-"+ date.getFullYear();
        }
      }
    }
  }

  formatForApi(inputDate) {
   var date = this.timezone.toLocal(inputDate);
    if(date)
    if (!isNaN(date.getTime())) {
      if ((Number(date.getMonth()) + 1) < 10) {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
      else {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
    }
    else
      return undefined;
  }

 /*
    author : dipin
    desc   : validation for white space in form
    params :
  */
  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }
}
