/*
*  @desc   :component for display manager leave and approve
*  @author :dipin
*/
import { Component, OnInit,OnDestroy,ViewChild,ElementRef,AfterViewInit } from '@angular/core';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { ManagerApproveService } from '../../services/manager-approve/manager-approve.service';
import { MalihuScrollbarService } from 'ngx-malihu-scrollbar';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

import * as FileSaver from 'file-saver';
import { PendingListService } from '../../../shared/services/pending-list/pending-list.service';
import { ConstantServicesService } from '../../../shared/services/constant/constant-services.service';
declare var require: any;
var moment = require('moment');
@Component({
  selector: 'app-manager-leave',
  templateUrl: './manager-leave.component.html',
  styleUrls: ['./manager-leave.component.css']
})
export class ManagerLeaveComponent implements OnInit,OnDestroy {
 rejectPopUp  : boolean = false;
 filterStatus : boolean = false;
 forDay       : boolean = false;
 forDate      : boolean = false;
 forWorkDay   : boolean = false;
 chatLoad     : boolean = false;
 cancelBox    : boolean = false;
 entryBlock   : boolean = false;
 rejectBox    : boolean = true;
 responceLoad : boolean = true;
  tableData     : any;
  addStatus     : boolean = false;
  editStatus    : boolean = false;
  chatConfirm    : boolean = false;
  confirmBox    : boolean;
  deleteBox     : boolean;
  searchTextBox : boolean = false;
  totalSelected : any = 0;
  currentPage   : number  = 1;
  recordsPerPage: number  = 10;
  totalRecords  : number;
  empId         : any;
  testTemp      : any;
  selectedList  : any;
  selectedStatus : any;
  payPeriodDay  : any;
  payPeriodOver : any;
  selectChat    : any;
  configDelete  : any;
  userData      : any;
  advanceFilterData : any;
  config      : any;
  setIndex    : any;
  selectedChat : any;
  timer       : any;
  messageData : any;
  searchValue : any;
  chatMessage : any = "";
  selectedId  : any;
  subId       : any;
  sort        : any;

  constructor(private apiService    : ManagerApproveService,
            private notifications : NotificationService,
            private loaderService : LoaderActionsService,
            private cookieService : CookieService,
            private mScrollbarService: MalihuScrollbarService,
            private PendingListService: PendingListService,
            private timeZone : TimezoneDetailsService,
            private ConstantServicesService: ConstantServicesService) { }

  ngOnInit() {
    let self = this;
    this.confirmBox = false;
    this.deleteBox = false;
    this.selectedList = "My Team";
    this.loaderService.display(true);

    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    this.config = "Are You Sure You Want To Approve?";
    this.configDelete = "Are You Sure You Want To Reject?";
    if (this.cookieService.get("user-data")) {
      this.userData = JSON.parse(this.cookieService.get("user-data"));
      this.empId = this.userData.user_id;
      this.apiService.getPeriod(response => {
        if (response.status == "OK") {
          let temp = response.data;
          for(let i = 0 ; i < temp.length;i++){
            if(temp[i].meta_key == 'pay_period_day'){
              this.payPeriodDay = Number(temp[i].meta_value);
            }
            if(temp[i].meta_key == 'pay_period_override_days'){
               this.payPeriodOver = Number(temp[i].meta_value);
            }
          }
           this.getData(this.currentPage);
        }
        else {
          this.tableData = [];
        }
      })
    }
    this.timer = setInterval(() => {
      self.setMessageIcon();
    }, 1000);
  }

  ngOnDestroy() {
    clearInterval(this.timer);
  }


  updateList(){
    this.PendingListService.getPendingList(response => {
      if (response) {
            let pendata = response;
          let aclData=  JSON.parse(localStorage.getItem("acl"));
          if(aclData.acl.length>0){
            for(let i=0; i<aclData.acl.length;i++){
              if(aclData.acl[i].name=='Approvals'){
                aclData.acl[i].acl.pending=pendata.total_pending;
                for(let j=0;j<aclData.acl[i].child.length; j++){
                    if(aclData.acl[i].child[j].name=='Leave Approval'){
                      aclData.acl[i].child[j].acl.pending=pendata.leave[0].pending;
                    }
                  }
              }
            }
          }
          localStorage.setItem('acl',JSON.stringify(aclData))
          this.PendingListService.setAclData(aclData);

        }
    })
  } 

    /*
  *  @desc   :method to update list by api call
    *  @author :dipin
  */
  getData(page) {
    this.loaderService.display(true);
    this.currentPage = page;
    this.apiService.getEmpDetails(this.selectedList, this.currentPage, this.recordsPerPage, this.advanceFilterData, this.sort, this.searchValue, this.empId, response => {
      if (response.status == "OK") {
        if (response.data) {
          this.tableData = response.data;
          for (let i = 0; i < this.tableData.length; i++) {
            this.tableData[i].messageStatus = false;
            this.tableData[i].chatLoad = false;
          }
        }
        else
          this.tableData = [];
        let tempArray = [];
        for (var i = 0; i < this.tableData.length; i++) {
          let secondHand = [];
          this.tableData[i].display = false;
          for (var j = 0; j < this.tableData[i].leave_details.length; j++) {
            secondHand.push({ date: this.tableData[i].leave_details[j].applied_date, status: this.tableData[i].leave_details[j].status });
          }
          tempArray.push(secondHand);
        }
        let checkDate, date = this.timeZone.getCurrentDate();
        if (this.userData.role_id == 2) {
          checkDate = moment(this.timeZone.toLocal(date.getFullYear() + "-"+Number(date.getMonth() + 1) + "-" + Number(this.payPeriodDay)), 'MM-DD-YYYY HH:mm').add(Number(this.payPeriodOver + 1), 'days');
          checkDate = checkDate.toDate();
          let tempStart, tempEnd, calValue, calEnd;
          tempStart = this.timeZone.toLocal(date.getFullYear() +"-"+Number(date.getMonth()) + "-" + 1 );
          tempEnd = this.timeZone.toLocal(date.getFullYear() + "-"+Number(date.getMonth()) + "-" + Number(moment(date.getFullYear() + "-" + Number(date.getMonth() + 1), "YYYY-MM").daysInMonth()));
          calValue = moment(checkDate).diff(moment(tempEnd), 'days') - 1;
          calEnd = moment(tempEnd, 'MM-DD-YYYY HH:mm').add(Number(calValue), 'days');
          calEnd = new Date(calEnd.toDate());
          for (var i = 0; i < tempArray.length; i++) {
            for (var j = 0; j < tempArray[i].length; j++) {
              if (((moment(tempArray[i][j].date).isBetween(tempStart, calEnd, null, '[]') && moment(date).isBefore(checkDate)) || moment(tempArray[i][j].date).isAfter(tempEnd)) && tempArray[i][j].status != 'R') {
                this.tableData[i].display = true;
                break;
              }
              else {
                this.tableData[i].display = false;
              }
            }
          }
        }
        else {
          checkDate = this.timeZone.getCurrentDate();
            for (var i = 0; i < tempArray.length; i++) {
              for (var j = 0; j < tempArray[i].length; j++) {
                if ((moment(checkDate).isBefore(moment(moment(tempArray[i][j].date).add('days', 1))) || this.timeZone.checkWithDynamicZone(tempArray[i][j].date,this.tableData[i].time_zone)) && tempArray[i][j].status != 'R') {
                  this.tableData[i].display = true;
                  break;
                }
                else {
                  this.tableData[i].display = false;
                }
              }
            }

          this.testTemp = tempArray;
            for (var i = 0; i < tempArray.length; i++) {
              for (var j = 0; j < tempArray[i].length; j++) {
                if ((moment(checkDate).isBefore(moment(moment(tempArray[i][j].date).add('days', 1))) || this.timeZone.checkWithDynamicZone(tempArray[i][j].date,this.tableData[i].time_zone)) && tempArray[i][j].status != 'R') {
                  this.testTemp[i][j].dateS = true;
                }
                else {
                  this.testTemp[i][j].dateS = false;
                }
              }
            }
          }


        this.totalRecords = response.count;
        for (var i = 0; i < this.tableData.length; i++) {
          this.tableData[i].checked = false;
        }
        this.loaderService.display(false);
      }
      else {
        this.tableData = [];
        this.loaderService.display(false);
      }
    })
  }


  /*
 *  @desc   :method for apply sorting using api and update the table list
   *  @author :dipin
 */
  applySort(value) {
    let type = 0;
    if (value == 'uname')
      if (this.forDay == true) {
        type = 1;
        this.forDay = false;
      }
      else {
        type = 0;
        this.forDay = true;
      }

    if (value == 'ltid')
      if (this.forWorkDay == true) {
        type = 1;
        this.forWorkDay = false;
      }
      else {
        type = 0;
        this.forWorkDay = true;
      }

    if (value == 'req_on')
      if (this.forDate == true) {
        type = 1;
        this.forDate = false;
      }
      else {
        type = 0;
        this.forDate = true;
      }

    this.sort = (type) ? "-" + value : value;
    this.loaderService.display(true);
    this.apiService.sortDetails(this.selectedList, { department: value, type: type }, this.currentPage, this.recordsPerPage, this.advanceFilterData, this.sort, this.searchValue, response => {
      if (response.status == "OK") {
        this.tableData = response.data;
        let tempArray = [];
        for (var i = 0; i < this.tableData.length; i++) {
          let secondHand = [];
          this.tableData[i].display = false;
          for (var j = 0; j < this.tableData[i].leave_details.length; j++) {
            secondHand.push({ date: this.tableData[i].leave_details[j].applied_date, status: this.tableData[i].leave_details[j].status });
          }
          tempArray.push(secondHand);
        }
        let checkDate, date = this.timeZone.getCurrentDate();

        if (this.userData.role_id == 2) {
          checkDate = moment(this.timeZone.toLocal(date.getFullYear() + "-"+Number(date.getMonth() + 1) + "-" + Number(this.payPeriodDay)), 'MM-DD-YYYY HH:mm').add(Number(this.payPeriodOver + 1), 'days');
          checkDate = checkDate.toDate();
          let tempStart, tempEnd, calValue, calEnd;
          tempStart = this.timeZone.toLocal(date.getFullYear() +"-"+ Number(date.getMonth()) + "-" + 1 );
          tempEnd = this.timeZone.toLocal(date.getFullYear() +"-"+Number(date.getMonth()) + "-" + Number(moment(date.getFullYear() + "-" + Number(date.getMonth() + 1), "YYYY-MM").daysInMonth()));
          calValue = moment(checkDate).diff(moment(tempEnd), 'days') - 1;
          calEnd = moment(tempEnd, 'MM-DD-YYYY HH:mm').add(Number(calValue), 'days');
          calEnd = new Date(calEnd.toDate());
          for (var i = 0; i < tempArray.length; i++) {
            for (var j = 0; j < tempArray[i].length; j++) {
              if (((moment(tempArray[i][j].date).isBetween(tempStart, calEnd, null, '[]') && moment(date).isBefore(checkDate)) || moment(tempArray[i][j].date).isAfter(tempEnd)) && tempArray[i][j].status != 'R') {
                this.tableData[i].display = true;
                break;
              }
              else {
                this.tableData[i].display = false;
              }
            }
          }
        }
        else {
          for (var i = 0; i < tempArray.length; i++) {
            for (var j = 0; j < tempArray[i].length; j++) {
              if ((moment(checkDate).isBefore(moment(moment(tempArray[i][j].date).add('days', 1))) || this.timeZone.checkWithDynamicZone(tempArray[i][j].date,this.tableData[i].time_zone)) && tempArray[i][j].status != 'R') {
                this.tableData[i].display = true;
                break;
              }
              else {
                this.tableData[i].display = false;
              }
            }
          }
        }
        this.totalRecords = response.count;
        this.loaderService.display(false);
      }
      else {
        this.notifications.alertBoxValue("error", response.message);
        this.tableData = [];
        this.loaderService.display(false);
      }
    })
  }

  toApprove(index) {
    this.confirmBox = true;
    this.selectedId = this.tableData[index].id;
  }

  toReject(index) {
    this.selectedId = this.tableData[index].id;
    this.rejectPopUp = true;
  }

  dateDelete(event) {
    this.rejectPopUp = false;
    this.loaderService.display(true);
    this.apiService.multiReject(this.selectedId, {
      "processed_by": this.empId,
      "comments": event.value, "status": "3"
    }, response => {
      if (response.status == "OK") {
        this.updateList();
        this.notifications.alertBoxValue("success", "Leave Rejected Successfully");
        this.currentPage = 1;
        this.getData(this.currentPage);
      }
      else {
        this.updateList();
        this.notifications.alertBoxValue("error", response.message);
        this.currentPage = 1;
        this.getData(this.currentPage);
      
      }
    })
  }

  /*
  author : dipin
  desc   : send Filter Data
  params :
   */
  filterData(event) {
   if (event || this.advanceFilterData) {
    this.advanceFilterData = event;
    this.currentPage = 1;
    this.getData(this.currentPage);
   }
   else
     this.advanceFilterData = undefined;
  }

  deleteSingle(i, j,status) {
    this.selectedId = this.tableData[i].id;
    this.selectedStatus = status;
    this.subId = this.tableData[i].leave_details[j].id;
    if(status != 2){
      this.rejectBox = true;
      this.deleteBox = true;
      this.cancelBox = false;
    }else{
      this.rejectBox = false;
      this.cancelBox = true;
      this.deleteBox = false;
    }
  }

  /*
   *  @desc   :method to get responce from the confirm popup component
   *  @author :dipin
   */
  getPopupConfirm(event) {
    this.confirmBox = false;
    if (event.status == true) {
      this.loaderService.display(true);
      this.apiService.multiReject(this.selectedId, {
        "processed_by": this.empId, "status": "2", "comments": event.value
      }, response => {
        if (response.status == "OK") {
          this.updateList();
          this.notifications.alertBoxValue("success", "Leave Approved Successfully");
          this.currentPage = 1;
          this.getData(this.currentPage);
        }
        else {
          this.updateList();
          this.currentPage = 1;
          this.getData(this.currentPage);
          this.loaderService.display(false);
          this.notifications.alertBoxValue("error", response.message);
        }
      })
    }
  }

  getDeleteConfirm(event) {
    this.deleteBox = false;
    this.loaderService.display(true);
    this.apiService.singleReject(this.selectedId, {
      "processed_by": this.empId,
      "comments": event.value, "status": "R"
    }, this.subId, response => {
      if (response.status == "OK") {
        this.updateList();
        this.notifications.alertBoxValue("success", "Leave Rejected Successfully");
        this.currentPage = 1;
        this.getData(this.currentPage);
      }
      else {
        this.updateList();
        this.currentPage = 1;
        this.getData(this.currentPage);
        this.loaderService.display(false);
        this.notifications.alertBoxValue("error", response.message);
      }
    })
  }

  search(value, set) {
    if (value.trim() != '' || (this.searchValue != '' && this.searchValue)) {
      this.searchValue = value;
      this.currentPage = 1;
      this.getData(this.currentPage);
    }
  }

  getCancelConfirm(event) {
    this.cancelBox = false;
    if (event.status == true) {
      this.loaderService.display(true);
      if (this.rejectBox) {
        this.apiService.multiReject(this.selectedId, {
          "processed_by": this.empId, "status": "4", "comments": event.value
        }, response => {
          if (response.status == "OK") {
            this.updateList();
            this.notifications.alertBoxValue("success", "Leave Cancelled Successfully");
            this.currentPage = 1;
            this.getData(this.currentPage);
          }
          else {
            this.updateList();
            this.notifications.alertBoxValue("error", response.message);
            this.currentPage = 1;
            this.getData(this.currentPage);
            this.loaderService.display(false);
            
          }
        })
      }
      else {
        this.rejectBox = true;
        this.apiService.singleReject(this.selectedId, {
          "processed_by": this.empId,
          "comments": event.value, "status": "R"
        }, this.subId, response => {
          if (response.status == "OK") {
            this.updateList();
            this.notifications.alertBoxValue("success", "Leave Cancelled Successfully");
            this.currentPage = 1;
            this.getData(this.currentPage);
          }
          else {
            this.updateList();
            this.notifications.alertBoxValue("error", response.message);
            this.currentPage = 1;
            this.getData(this.currentPage);
            this.loaderService.display(false);
            
          }
        })
      }
    }
  }

  /*
  *  @desc   :method send messages to the server with sender's id
  *  @author :dipin
  */
  toCancel(i) {
    this.selectedId = this.tableData[i].id;
    this.cancelBox = true;
  }

  /*
  *  @desc   :method send messages to the server with sender's id
  *  @author :dipin
  */
  setFocus() {
    window.setTimeout(function() {
      document.getElementById('searchField').focus();
    }, 1);
  }

  /*
  *  @desc   :method to add random classes bsed on index
  *  @author :dipin
  */
  getClassByValue(index) {
    switch (index % 10) {
      case 0: return "default-avatar islamic-green";
      case 1: return "default-avatar limerick";
      case 2: return "default-avatar chilean-fire";
      case 3: return "default-avatar persian-pink";
      case 4: return "default-avatar deep-magenta";
      case 5: return "default-avatar gigas";
      case 6: return "default-avatar endeavour";
      case 7: return "default-avatar dodger-blue";
      case 8: return "default-avatar jordy-blue";
      case 9: return "default-avatar Light-sea-green";
      case 10: return "emp-profileimage";
    }
  }

  /*
  *  @desc   :download attachment form leave list
  *  @author :dipin
  */
  attachmentDownloadCommon(id, leaveId, i, j, value) {
    var tempI = i;
    var tempJ = j;
    this.loaderService.display(true);
    this.apiService.attachemntDownload(id, leaveId, res => {
      if (res.status != "success") {
        this.loaderService.display(false);
      }
      else {
        let binary_string: any = window.atob(res.data);
        let types;
        if (value == false)
          if (this.tableData[tempI].file_details[tempJ].file_type == "png" || this.tableData[tempI].file_details[tempJ].file_type == "jpg" || this.tableData[tempI].file_details[tempJ].file_type == "jpeg") {
            types = 'image/png';
          }
          else if (this.tableData[tempI].file_details[tempJ].file_type == "pdf") {
            types = 'application/pdf';
          }
          else {
            types = "application/octet-stream";
          }
        else {
          types = "application/zip";
        }
        let len: any = binary_string.length;
        let bytes: any = new Uint8Array(len);
        for (var i = 0; i < len; i++) {
          bytes[i] = binary_string.charCodeAt(i);
        }
        let file: any = new Blob([bytes.buffer], { type: types });
        if (value == false)
          FileSaver.saveAs(file, this.tableData[tempI].file_details[tempJ].file_name);
        else
          FileSaver.saveAs(file, "document " + this.timeZone.getCurrentDate().toDateString());
        this.loaderService.display(false);
      }
    })
  }

    /*
  *  @desc   :show previous messages using api call
  *  @author :dipin
  */
  showMessage(index, id) {
    for (let i = 0; i < this.tableData.length; i++) {
      if (index == i) {
        this.tableData[i].messageStatus = !this.tableData[i].messageStatus;
        if (this.tableData[i].messageStatus) {
          this.messageData = [];
          this.responceLoad = true;
          this.tableData[index].chatLoad = true;
          this.apiService.showMessage(id, res => {
            if (res.status == "OK") {
              let self = this;
              this.messageData = res.data;
              for (var i = 0; i < this.messageData.length; i++) {
                let diff = Math.abs((moment.utc(this.messageData[i].send_time).toDate().getTime() - moment.utc().toDate().getTime()) / 1000);
                          diff = Math.abs(diff);
                if (Number(diff) >= 300) {
                  this.messageData[i].deleteIcon = false;
                }
                else {
                  this.messageData[i].deleteIcon = true;
                }
              }
              this.tableData[index].chatLoad = false;
              this.responceLoad = false;
              setTimeout(function() {
                $("#top-chat").mCustomScrollbar("scrollTo", "bottom");
                if (document.getElementById("chatBox")) {
                  if (self.selectedChat == id) {
                      document.getElementById("chatBox").innerHTML = self.chatMessage;
                  }
                  else {
                    self.selectedChat = id;
                    self.chatMessage = '';
                  }
                      document.getElementById("chatBox").focus();
                }
              });
            }
            else {
              this.tableData[index].chatLoad = false;
              this.responceLoad = false;
            }
          })
        }
      }
      else {
        this.tableData[i].messageStatus = false;
      }
    }
  }

  /*
  *  @desc   :method send messages to the server with sender's id
  *  @author :dipin
  */
  sendMessage(index, id) {
    if (this.chatMessage != '' && this.chatMessage.trim() != '') {
      this.entryBlock = true;
      let obj = {
        "user_id": this.userData.user_id,
        "leave_id": id,
        "message": this.chatMessage.trim()
      };
      document.getElementById("chatBox").innerHTML = '';
      setTimeout(function() {
        document.getElementById("chatBox").focus();
      });
      this.messageData.push({
        'id': '',
        "first_name": this.userData.first_name,
        "last_name": this.userData.last_name,
        "message": this.chatMessage.trim(),
        "photo": this.userData.photo,
        "send_time": moment.utc().toDate().getTime(),
        "user_id": this.userData.user_id,
        'status' : 1
      });
      this.chatMessage = '';
      this.messageData[this.messageData.length - 1].sent = true;
      setTimeout(function() {
        $("#top-chat").mCustomScrollbar("scrollTo", "bottom");
      });
      this.apiService.addMessage(obj, res => {
        if (res.status == "Success") {
          this.messageData[this.messageData.length - 1].sent = false;
          this.messageData[this.messageData.length - 1].id = res.id;
          this.messageData[this.messageData.length - 1].deleteIcon = true;
          this.entryBlock = false;
        }
        else {
          this.notifications.alertBoxValue("error", res.message);
          this.entryBlock = false;
          this.messageData.pop();
          this.messageData[this.messageData.length - 1].sent = false;
          this.messageData[this.messageData.length - 1].deleteIcon = false;
        }
      })
    }
  }

  /*
  *  @desc   :method to close all the popup of chat message while hovet on messages
  *  @author :dipin
  */
  closeAllPopup() {
    this.chatConfirm = false;
    for (let i = 0; i < this.tableData.length; i++) {
      this.tableData[i].messageStatus = false;
    }
  }

  /*
  *  @desc   :method to display selected type of list
  *  @author :dipin
  */
  selectedDataList(event) {
    if (event) {
      this.selectedList = event.selected[0].value;
      this.getData(1);
    }
  }

  /*
   *  @desc   :method to display selected type of list
   *  @author :dipin
   */
  deleteMessage() {
    this.messageData[this.selectChat].sent = true;
    this.apiService.deleteChat(this.userData.user_id, this.messageData[this.selectChat].id, res => {
      if (res.status == "Success") {
        for (let i = 0; i < this.messageData.length; i++) {
          if (this.messageData[i].id == res.message_id) {
            this.messageData[i].sent = false;
            this.messageData[i].delete = true;
          }
        }
      }
      else {
        this.notifications.alertBoxValue("error", res.message);
        this.messageData[this.selectChat].sent = false;
        this.messageData[this.selectChat].delete = false;
      }
    })
  }

  /*
  *  @desc   :method to display selected type of list
  *  @author :dipin
  */
  formatDate(date) {
    var strTime = date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds();
    return date.getFullYear() + "-" + Number(date.getMonth() + 1) + "-" + date.getDate() + "  " + strTime;
  }

  setMessageIcon() {
    if (this.messageData)
      if (this.messageData.length) {
        for (var i = 0; i < this.messageData.length; i++) {
            let diff = Math.abs((moment.utc(this.messageData[i].send_time).toDate().getTime() - moment.utc().toDate().getTime()) / 1000);
            diff = Math.abs(diff);
          if (Number(diff) >= 300) {
            this.messageData[i].deleteIcon = false;
          }
          else {
            this.messageData[i].deleteIcon = true;
          }
        }
      }
  }

  /*
 *  @desc   :method for pagination
 *  @author :dipin
 */
  getpage(event) {
    if (event > 0) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      this.getData(this.currentPage);
    }
    else {
      this.recordsPerPage = 10;
      this.currentPage = 1;
      this.getData(this.currentPage);
    }
  }
}
