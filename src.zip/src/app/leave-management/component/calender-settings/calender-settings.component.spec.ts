import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CalenderSettingsComponent } from './calender-settings.component';

describe('CalenderSettingsComponent', () => {
  let component: CalenderSettingsComponent;
  let fixture: ComponentFixture<CalenderSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CalenderSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalenderSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
