/*
*  @desc   :component for settings calender management
*  @author :dipin
*/
import { Component, OnInit,Input,Output,EventEmitter,OnChanges,SimpleChanges,OnDestroy } from '@angular/core';
import { FormGroup,FormControl, Validators,FormBuilder } from '@angular/forms';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { CalenderSettingsService } from '../../services/calender-settings.service';
import {apiList}  from '../../../shared/constants/apilist';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'

@Component({
  selector: 'hris-calender-settings',
  templateUrl: './calender-settings.component.html',
  styleUrls: ['../../../../assets/content/css/calendarsettings.css']
})
export class CalenderSettingsComponent implements OnInit,OnDestroy {
	weekDays          : any = [];
	quarters          : any = [];
	financialData 	  : any = [];
	selectedweekStart : any = [];
	weekEnd           : any = [];
	weekStart         : any = [];
	workingOnQ        : any = [];
	workingOnD        : any = [];
	nonWorkingQ       : any = [];
	nonWorkingD       : any = [];
	fSelected         : any = [];
	predefinedId      : any = [];
	selectedData      : any;
	uCurrent          : any;
	setApplicable     : boolean = false;
	submitted         : boolean = false;
	settingsForm      : FormGroup;
	workStart         : FormControl;
	workEnd           : FormControl;
	workingOn         : FormControl;
	nonWorking        : FormControl;
	workingQuarter    : FormControl;
	nonworkingQuarter : FormControl;
	fYear             : FormControl;
	calenderName      : FormControl;

	constructor(public apiService : CalenderSettingsService,
		        private router     : Router,
		        private notifications : NotificationService,
		        private loaderService : LoaderActionsService,
		        private timezone       : TimezoneDetailsService) { }

	ngOnInit() {
		this.uCurrent = apiList.leaveManagement.deleteCalenderList;
		this.loaderService.display(true);
		this.apiService.getCalanderFinancialYear(response => {
			if (response.status == "OK") {
				if(response.data){
                  this.financialData = response.data;
					this.settingsForm.patchValue({
							calenderName: (this.apiService.selectedService && this.apiService.selectedService[0])?this.apiService.selectedService[0].calendar_name:null
					})

				}
				else
				   this.financialData = [];
				if (this.apiService.statusService) {
					for (var i = 0; i < this.financialData.length; i++) {
						if (this.financialData[i].year_title == this.apiService.selectedService[0].year_title) {
							this.fSelected = [i];
						}
					}
				}
				 this.loaderService.display(false);
			}
			else {
				this.financialData = [];
				this.loaderService.display(false);
			}
		})

		this.predefinedId = [{
			id: 1, name: "location"
		},
		{ id: 2, name: "user" },
		{ id: 3, name: "group" },
		{ id: 4, name: "department" },
		{ id: 5, name: "designation" }
		]

		this.weekDays = [{ value: "Sunday" }, { value: "Monday" },
		{ value: "Tuesday" }, { value: "Wednesday" },
		{ value: "Thursday" }, { value: "Friday" },
		{ value: "Saturday" }];

		this.quarters = [{ value: "First" }, { value: "Second" },
		{ value: "Third" }, { value: "Last" }];
		this.createFormControls();
		this.createForm();
		if (this.apiService.statusService) {
			for (var j = 0; j < this.weekDays.length; j++) {
				if (this.apiService.selectedService[0].work_start_day == this.weekDays[j].value) {
					this.selectedweekStart = [j];
				}
				if (this.apiService.selectedService[0].work_end_day == this.weekDays[j].value) {
					this.weekEnd = [j+1];
				}
				if (this.apiService.selectedService[0].calendar_working_day == this.weekDays[j].value) {
					this.workingOnD = [j+1];
				}
				if (this.apiService.selectedService[0].calendar_off_day == this.weekDays[j].value) {
					this.nonWorkingD = [j+1];
				}
			}
			for (var j = 0; j < this.quarters.length; j++) {
				if (this.apiService.selectedService[0].calendar_working_term == this.quarters[j].value) {
					this.workingOnQ = [j];
				}
				if (this.apiService.selectedService[0].calendar_off_term == this.quarters[j].value) {
					this.nonWorkingQ = [j+1];
				}
			}
		}
	}

	ngOnDestroy(){
		this.apiService.selectedService = [];
		this.apiService.statusService = false;
		this.settingsForm.reset();
	}

	/*
    *  @desc   :Create and define form controls of createNew form
    *  @author :dipin
    */
    createFormControls(){
      this.calenderName		 = new FormControl('', [Validators.required]);
  	  this.workStart         = new FormControl('', [Validators.required]);
   	  this.workEnd           = new FormControl('', [Validators.required]);
      this.workingOn   	     = new FormControl('');
      this.nonWorking   	 = new FormControl('');
      this.workingQuarter    = new FormControl('');
      this.nonworkingQuarter = new FormControl('');
      this.fYear             = new FormControl('', [Validators.required]);
    }

    /*
    *  @desc   :create form itemForm and addForm
    *  @author :dipin
    */
    createForm() {
      this.settingsForm = new FormGroup({
      	   calenderName		 : this.calenderName,
           workStart         : this.workStart,
           workEnd           : this.workEnd,
           workingOn         : this.workingOn,
           nonWorking        : this.nonWorking,
           workingQuarter    : this.workingQuarter,
           nonworkingQuarter : this.nonworkingQuarter,
           fYear             : this.fYear
      });
    }

    /*
  	*  @desc   : validating submited data send t the server using api call
  	*  @author : dipin
  	*/
	addSettings() {
		let outputData = [];
		let nonOutData = [];
		this.submitted = true;
		for (var i = 0; i < this.selectedData.applicable.length; i++) {
      for (var j = 0; j < this.predefinedId.length; j++) {
        if (this.predefinedId[j].name == this.selectedData.applicable[i].name) {
          if (this.selectedData.applicable[i].selectedAll == true) {
            outputData.push({ category: this.predefinedId[j].id, reference_id: 0 });
          }
          else {
            for (var k = 0; k < this.selectedData.applicable[i].list.length; k++) {
              if (this.selectedData.applicable[i].list[k].is_selected == 1) {
                outputData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.applicable[i].list[k].id });
              }
            }
          }
        }
      }
    }

    for (var i = 0; i < this.selectedData.notApplicable.length; i++) {
      for (var j = 0; j < this.predefinedId.length; j++) {
        if (this.predefinedId[j].name == this.selectedData.notApplicable[i].name) {
          if (this.selectedData.notApplicable[i].selectedAll == true) {
            nonOutData.push({ category: this.predefinedId[j].id, reference_id: 0 });
          }
          else {
            for (var k = 0; k < this.selectedData.notApplicable[i].list.length; k++) {
              if (this.selectedData.notApplicable[i].list[k].is_selected == 1) {
                nonOutData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.notApplicable[i].list[k].id });
              }
            }
          }
        }
      }
    }

		if (this.calenderName.value == null || ((this.workingOn.value+this.workingQuarter.value == this.nonWorking.value+this.nonworkingQuarter.value) && this.workingOn.value != null && this.workingQuarter.value != null) ||this.settingsForm.invalid || outputData.length == 0 || (this.workStart.value == this.workEnd.value)) {
			if (outputData.length == 0 && this.settingsForm.valid) {
				this.setApplicable = true;
				this.notifications.alertBoxValue("error", "Select Options For Applicable For");
			}
			else if((this.workStart.value == this.workEnd.value) && this.settingsForm.valid) {
                this.notifications.alertBoxValue("error", "Invalid Calender Definition");
			}
			else if(((this.workingOn.value+this.workingQuarter.value == this.nonWorking.value+this.nonworkingQuarter.value) && this.workingOn.value != null && this.workingQuarter.value != null) && this.settingsForm.valid) {
                this.notifications.alertBoxValue("error", "Invalid Weekend Definition");
			}
			return;
		}
		else {
			this.loaderService.display(true);
			this.setApplicable = false;
			this.submitted = false;
			let temp = {
				calendar_name	 : this.calenderName.value,
				financial_year_id: this.fYear.value,
				work_start_day: this.workStart.value,
				work_end_day: this.workEnd.value,
				calendar_working_term: this.workingQuarter.value,
				calendar_working_day: this.workingOn.value,
				calendar_off_term: this.nonworkingQuarter.value,
				calendar_off_day: this.nonWorking.value,
				applicable_for: outputData,
				not_applicable_for    : nonOutData
			}
			if (this.apiService.statusService) {
				this.apiService.updateCalanderSettingsDetails(temp, this.apiService.selectedService[0].id, response => {
					if (response.status == "OK") {
						this.apiService.selectedService = [];
	                 	this.apiService.statusService = false;
		                this.settingsForm.reset();
		                this.router.navigate(['/modules/leave/calender-list']);
						setTimeout(() => {
							this.loaderService.display(false);
							this.notifications.alertBoxValue("success", "Calendar Settings Updated Successfully");
						}, 600);
					}
					else {
						this.notifications.alertBoxValue("error", response.message);
						this.loaderService.display(false);
					}
				})
			}
			else {
				this.apiService.AddCalanderSettingsDetails(temp, response => {
					if (response.status == "OK") {
						this.settingsForm.reset();
						this.apiService.selectedService = [];
		                this.apiService.statusService = false;
		                this.router.navigate(['/modules/leave/calender-list']);
						setTimeout(() => {
							this.loaderService.display(false);
							this.notifications.alertBoxValue("success", "Calendar Settings Added Successfully");
						}, 600);
					}
					else {
						this.settingsForm.reset();
						this.router.navigate(['/modules/leave/calender-list']);
						setTimeout(() => {
							this.loaderService.display(false);
							this.notifications.alertBoxValue("error", response.message);
						}, 600);
					}
				})
			}
		}
	}

	/*
    *  @desc   : method deal with year field single selection
    *  @author : dipin
    */
	selectedDataYear(event, type) {
		switch (type) {
			case "wStart":
				if (event.selected.length)
					this.settingsForm.patchValue({
						workStart: event.selected[0].value
					})
				else
					this.settingsForm.patchValue({
						workStart: null
					})
				break;
			case "wEnd":
				if (event.selected.length)
					this.settingsForm.patchValue({
						workEnd: event.selected[0].value
					})
				else
					this.settingsForm.patchValue({
						workEnd: null
					})
				break;
			case "wOn":
				if (event.selected.length)
					this.settingsForm.patchValue({
						workingOn: event.selected[0].value
					})
				else
					this.settingsForm.patchValue({
						workingOn: null
					})
				break;
			case "wQuartor":
				if (event.selected.length)
					this.settingsForm.patchValue({
						workingQuarter: event.selected[0].value
					})
				else
					this.settingsForm.patchValue({
						workingQuarter: null
					})
				break;
			case "nOn":
				if (event.selected.length)
					this.settingsForm.patchValue({
						nonWorking: event.selected[0].value
					})
				else
					this.settingsForm.patchValue({
						nonWorking: null
					})
				break;
			case "nQuartor":
				if (event.selected.length)
					this.settingsForm.patchValue({
						nonworkingQuarter: event.selected[0].value
					})
				else
					this.settingsForm.patchValue({
						nonworkingQuarter: null
					})
				break;
			case "fyear":
				if (event.selected.length)
					this.settingsForm.patchValue({
						fYear : event.selected[0].id
					})
				else
					this.settingsForm.patchValue({
						fYear: null
					})
				break;
		}
	}

    /*
	*  @desc   :method to go back from the currrent page to history
  	*  @author :dipin
	*/
	back(){
		this.apiService.selectedService = [];
		this.apiService.statusService = false;
		this.settingsForm.reset();
		window.history.back();
	}
}
