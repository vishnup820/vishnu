/*
*  @desc   :component for display leave type and management
*  @author :dipin
*/
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'

import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LeavetypeDetailsService } from './../../services/leave-type/leavetype-details.service';

@Component({
  selector: 'app-leavetype-list',
  templateUrl: './leavetype-list.component.html',
  styleUrls: ['../../../../assets/content/css/policy-listing.css']
})
export class LeavetypeListComponent implements OnInit {

    tableData     : any = [];
	editConfig    : any;
	config        : any;
	addStatus     : boolean = false;
	filterStatus  : boolean = false;
	editStatus    : boolean = false;
	checkAll      : boolean = false;
	multiDelete   : boolean = false;
	searchTextBox : boolean = false;
	forTitle      : boolean = false;
	forStatus     : boolean = false;
	confirmBox    : boolean;
	totalSelected : any = 0;
	currentPage   : number  = 1;
    recordsPerPage: number  = 10;
    totalRecords  : number;
    setIndex      : any;
    setStack      : any;
    searchValue       : any = "";
    advanceFilterData : any;
    sort              : any;

	constructor(private apiService    : LeavetypeDetailsService,
		        private notifications : NotificationService,
		        private loaderService : LoaderActionsService,
		        private router     : Router) { }

	ngOnInit() {
		this.confirmBox  = false;
		this.config = "Are You Sure You Want To Delete?";
		if (localStorage.getItem("itemsperpage")) {
			this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			this.recordsPerPage = 10;
		}
		this.getData(this.currentPage);
	}

    /*
	*  @desc   :method to update list by api call
  	*  @author :dipin
	*/
	getData(page){
		this.loaderService.display(true);
		this.currentPage = page;
		let temp = [];
      this.apiService.getCalanderDetails(this.currentPage,this.recordsPerPage,this.advanceFilterData,this.searchValue,this.sort,response => {
			if (response.status == "OK") {
				if(response.data){
                 this.tableData = response.data;
                  for(var i = 0 ; i < this.tableData.length;i++){
                   this.tableData[i].vStatus = false;
                   this.tableData[i].listAppl = [];
                 }
                 for (var i = 0; i < this.tableData.length; i++) {
							for (var j = 0; j < this.tableData[i].applicable_for.length; j++) {
								for (var k = 0; k < this.tableData[i].applicable_for[j].list.length; k++) {
									  if(this.tableData[i].applicable_for[j].list[k] != "")
										this.tableData[i].listAppl.push(this.tableData[i].applicable_for[j].list[k]);
								}
							}
						}
				}
				else{
				  this.tableData = [];
				}

				this.totalRecords = response.count;
				for (var i = 0; i < this.tableData.length; i++) {
					this.tableData[i].checked = false;
                    temp.push({"id" : this.tableData[i].id,"name":this.tableData[i].name});
				}
				this.apiService.selectedValues = temp;
				this.checkSelected();
				this.loaderService.display(false);
			}
			else {
				this.tableData = [];
				this.loaderService.display(false);
			}
		})
	}

	setFalse(index){
     for(var i = 0 ; i < this.tableData.length;i++){
           if(index == i ){
             this.tableData[i].vStatus = !this.tableData[i].vStatus;
           }
           else
            this.tableData[i].vStatus = false;
      }
	}

    /*
	*  @desc   :toggle display of popup based on the add button click
  	*  @author :dipin
	*/
	setAdd() {
	  this.router.navigate(['/modules/leave/add-leave']);
	}

	 /*
	*  @desc   :show or hide edit-form for selected index
  	*  @author :dipin
	*/
	showEdit(index){
      this.router.navigate(['/modules/leave/add-leave/'+this.tableData[index].id]);
	}

     /*
	*  @desc   :select all the rows listed in the table
  	*  @author :dipin
	*/
	selectAll(value){
		for(var i = 0 ; i < this.tableData.length;i++){
			this.tableData[i].checked = value;
		}
		this.checkSelected();
	}

     /*
	*  @desc   :select row using the index of the table
  	*  @author :dipin
	*/
	selectTableValue(index){
	   this.tableData[index].checked = !this.tableData[index].checked;
	   this.checkSelected();
	}

     /*
	*  @desc   :method for apply sorting using api and update the table list
  	*  @author :dipin
	*/
	applySort(value){
		let type = 0;

		if(value == 'l_n')
		if (this.forTitle == true) {
			type = 1;
			this.forTitle = false;
		}
		else {
			type = 0;
			this.forTitle = true;
		}

        if(value == 'stat')
		if (this.forStatus == true) {
			type = 1;
			this.forStatus = false;
		}
		else {
			type = 0;
			this.forStatus = true;
		}
      this.sort = {department : value,type:type};
	  this.loaderService.display(true);
	  this.apiService.sortCalenderDetails({department : value,type:type},this.currentPage,response=>{
                  if(response.status == "OK"){
                    this.tableData = response.data;
                    for (var i = 0; i < this.tableData.length; i++) {
						this.tableData[i].vStatus = false;
						this.tableData[i].listAppl = [];
					}
						for (var i = 0; i < this.tableData.length; i++) {
							for (var j = 0; j < this.tableData[i].applicable_for.length; j++) {
								for (var k = 0; k < this.tableData[i].applicable_for[j].list.length; k++) {
									if(this.tableData[i].applicable_for[j].list[k] != "")
										this.tableData[i].listAppl.push(this.tableData[i].applicable_for[j].list[k]);
								}
							}
						}
                    this.loaderService.display(false);
                  }
                  else{
                    this.tableData = [];
                    this.loaderService.display(false);
                  }
          })
	}

     /*
	*  @desc   :method to check all the rows in the list are selected or not
  	*  @author :dipin
	*/
	checkSelected(){
	let selected = 0;
      for(var j = 0 ; j < this.tableData.length;j++){
          if(this.tableData[j].checked){
          	this.checkAll = true;
          }
          else{
          	this.checkAll = false;
          	break;
          }
	   }
	   for(var j = 0 ; j < this.tableData.length;j++){
          if(this.tableData[j].checked){
          	selected = selected + 1;
          }
	   }
	   this.totalSelected = selected;
	}

	 /*
	*  @desc   :method to delete element from the list
  	*  @author :dipin
	*/
	deleteSelected(index){
		this.loaderService.display(true);
		this.apiService.deleteCalenderDetails(this.tableData[index].id,response=>{
                  if(response.status == "Success"){
                  	this.loaderService.display(false);
                  	this.currentPage = 1;
                   this.getData(this.currentPage);
                   this.notifications.alertBoxValue("success", "Leave Type Deleted Successfully");
                  }
                  else{
                  	this.loaderService.display(false);
                   this.notifications.alertBoxValue("error", response.message);
                  }
          })
	}

	 /*
	*  @desc   :method to delete multipile selected element from the list
  	*  @author :dipin
	*/
	deleteMultiSelected() {
		this.loaderService.display(true);
		let temp = [];
		for (var i = 0; i < this.tableData.length; i++) {
			if (this.tableData[i].checked) {
				temp.push(this.tableData[i].id);
			}
		}
		this.apiService.deleteMultipleCalender({ "id": temp }, response => {
			if (response.status == "Success") {
				this.loaderService.display(false);
				this.currentPage = 1;
				this.getData(this.currentPage);
				this.notifications.alertBoxValue("success", "Leave Type Deleted Successfully");
			}
			else {
				this.loaderService.display(false);
				this.notifications.alertBoxValue("error", response.message);
			}
		})
	}

    /*
	*  @desc   :method to update list after popup confirmation
  	*  @author :dipin
	*/
	updateList(event){
		if(event){
		 this.getData(this.currentPage);
		}
	}

    /*
	*  @desc   :method to get responce from the confirm popup component
  	*  @author :dipin
	*/
	getPopupConfirm(event){
		this.confirmBox = false;
		if(event == true){
		  if(this.multiDelete == true)
            this.deleteMultiSelected();
          else
          	this.deleteSelected(this.setIndex);
		}
	}

	/*
   author : dipin
   desc   : Search  when enter key is pressed
  */
	search(value, set) {
		if (value.trim() != '' || (this.searchValue != '' && this.searchValue)) {
			this.searchValue = value;
			this.sort = undefined;
			this.currentPage = 1;
			this.getData(this.currentPage);
		}
	}

  /*
   author : dipin
   desc   : send Filter Data
   params :
  */
  filterData(event) {
   if (event || this.advanceFilterData) {
    this.advanceFilterData  = event;
    this.currentPage        = 1;
    this.getData(this.currentPage);
   }
   else
     this.advanceFilterData = undefined;
  }

	setFocus() {
		window.setTimeout(function() {
			document.getElementById('searchField').focus();
		}, 1);
	}

      /*
  *  @desc   :method for pagination
  *  @author :dipin
  */
  getpage(event) {
    if (event > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      this.getData(this.currentPage);
    }
  }

}
