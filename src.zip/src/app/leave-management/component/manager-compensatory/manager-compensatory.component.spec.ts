import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerCompensatoryComponent } from './manager-compensatory.component';

describe('ManagerCompensatoryComponent', () => {
  let component: ManagerCompensatoryComponent;
  let fixture: ComponentFixture<ManagerCompensatoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagerCompensatoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerCompensatoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
