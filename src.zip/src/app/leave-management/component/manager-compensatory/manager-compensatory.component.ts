import { Component, OnInit , Renderer , OnDestroy } from '@angular/core';
import { BsDatepickerDirective } from 'ngx-bootstrap/datepicker';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { CookieService } from 'ngx-cookie-service';

import { ManagerCompensatoryService } from '../../services/manager-compensatory/manager-compensatory.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';

@Component({
  selector: 'app-manager-compensatory',
  templateUrl: './manager-compensatory.component.html',
  styleUrls: ['../../../../assets/content/css/manager_compensatory.css']
})
export class ManagerCompensatoryComponent implements OnInit , OnDestroy{

   currentPage           	  : number = 1;
   recordsPerPage        	  : number = 10;
   totalRecords          	  : number;
   deleteIndex              : number;
   deleteStatus             : number;

   addEditStatus            : boolean = false;

   deleteIconStatus      	  : boolean = false;
   lazyLoad                 : boolean = false;
   filterStatus          	  : boolean = false;
   addStatus             	  : boolean = false;
   checkBoxValue            : boolean = false;
   confirmBox               : boolean = false;
   searchTextBox            : boolean = false;
   filterTextBox            : boolean = false;
   emitData                 : boolean = true;
   formerror                : boolean = false;
   editFormDateStatus       : boolean = false;
   expDateStatus            : boolean = false;
   empExit                  : boolean = false;
   dynamicFormError         : boolean = false;

   minDate                  : Date;
   dateValue                : Date = new Date();
   maxDate                  : Date;

   managerData              : any;
   searchValue              : any;
   listenFunc               : any;
   empSearch                : any;
   empDetails               : any;
   advanceFilterData        : any;
   empId                    : any;
   empCode                  : any;
   reason                   : any;
   dayTime                  : any = [{"id" : 1, "name" : "Full Day"},{"id" : 2, "name" : "Half day(1st Half)"},{"id" : 3, "name" : "Half day(2nd Half)"}];
   dayTimeSelected          : any;
   dateArray                : any = [];
   expDate                  : any;
   editdata                 : any;
   empList                  : any;
   userData                 : any;

   config                   : string;

  constructor(
  	private managerCompensatoryService : ManagerCompensatoryService,
  	private notificationService        : NotificationService,
  	private renderer                   : Renderer,
  	private loaderService              : LoaderActionsService,
    private timeZone : TimezoneDetailsService,
    private cookieService				: CookieService) { }

  ngOnInit() {
    this.dateValue = this.timeZone.getCurrentDate();
    this.config = "Are You Sure You Want To Delete?";
    this.currentPage = 1;
    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    if (this.cookieService.get("user-data")) {
			this.userData = JSON.parse(this.cookieService.get("user-data"));
    }
    this.minDate= this.timeZone.toLocal(this.userData.financialMin_date);
    this.maxDate= this.timeZone.toLocal(this.userData.end_date);
    this.loaderService.display(true);
    this.managerCompensatoryService.getMangerDetails(this.currentPage, this.recordsPerPage, this.searchValue, this.advanceFilterData, res => {
      this.loaderService.display(false);
      if (res.status == "OK" && res.data && res.data.length) {
        this.managerData = res.data;
        this.totalRecords = res.count;
      }
      else {
        this.managerData = [];
        this.deleteIconStatus = false;
      }
    });
  }

   ngOnDestroy() {
	   this.listenFunc;
   }

  /*
   author : Arun Johnson
   desc   : get compensatory details
   params : page no
  */
  getManagerData(page : number) {
  	this.currentPage = page;
  	this.loaderService.display(true);
  	this.managerCompensatoryService.getMangerDetails(this.currentPage,this.recordsPerPage,this.searchValue,this.advanceFilterData,res=>{
  		this.loaderService.display(false);
  		if (res.status == "OK" && res.data && res.data.length) {
  			this.managerData     = res.data;
  			this.totalRecords    = res.count;
  		}
  		else {
  			this.managerData     = [];
        this.deleteIconStatus = false;
    		}
  	});
  }

   /*
   author : Arun Johnson
   desc   : edit Form
   params : index of check box
  */
  editForm(data,event) {
  	this.searchTextBox = false;
  	this.addEditStatus = false;
  	this.editdata = data;
  	this.addStatus = true;
  	this.lazyLoad  = true;
  	this.managerCompensatoryService.getManagerData(data.id,res=>{
      this.editFormDateStatus = false;
  		if(res.status == "OK") {
  			this.dateArray   = [];
  			this.empId       = data.user_name +" ("+data.code+")";
  			this.empCode     = data.code;
  			this.reason      = res.data[0].description;
  			let dateArray    = res.data[0].date;
  			this.expDate     = this.timeZone.toLocal (res.data[0].expired_date);
  			for(let i=0;i<(dateArray && dateArray.length);i++) {
  				let index;
  				dateArray[i].application_type == 1 ? index = 0 : dateArray[i].application_type == 2 ? index = 1 :   dateArray[i].application_type == 3 ? index = 2 : index = null;
  				if (dateArray[i].applied_date_status != "Rejected" || dateArray[i].applied_date_status != "R") {
          this.dateArray.push({
  					"start_date"        : this.timeZone.toLocal (dateArray[i].start_date),
  					"end_date"          : this.timeZone.toLocal (dateArray[i].end_date) ,
  					"application_type"  : [index],
            "change_end_date"   : false,
            "start_date_status" : false,
            "end_date_status"   : false,
  					"type"              : index});
         }
         if (this.dateArray.length == 0) {
           this.dateArray.push({"change_end_date" : true,"start_date": null,"end_date": null , "application_type" : [0] ,"type" :null,"start_date_status" : false,"end_date_status" : false});
          }
          let self = this;
          self.lazyLoad  = false;
          self.editFormDateStatus = true;
  			}
  		}
  	})
  }

   /*
   author : Arun Johnson
   desc   : create new form for date
  */
  addNewForm(index) {
    this.formerror        = false;
    this.dynamicFormError = false;
    for(let i=0;i<this.dateArray.length;i++) {
      if(!this.dateArray[i].start_date) {
        this.dynamicFormError = true;
      }

      if(!this.dateArray[i].end_date) {
        this.dynamicFormError = true;
      }
      if(this.dateArray[i].type.length == 0||!this.dateArray[i].type) {
        this.dynamicFormError = true;
      }
      if(this.dateArray[i].end_date_status) {
        this.dynamicFormError = true;
      }
      if(this.dateArray[i].start_date_status) {
        this.dynamicFormError = true;
      }
    }
    if(!this.dynamicFormError) {
      this.dateArray.push({"change_end_date" : true,"start_date": null,"end_date": null , "application_type" : [0] ,"type" :null,"start_date_status" : false,"end_date_status" : false});
    }
  }

   /*
   author : Arun Johnson
   desc   : new Add Form
  */
  dateForm() {
    this.editFormDateStatus = true;
  	this.reason    = null;
  	this.empId     = null;
  	this.empSearch = null;
  	this.empCode   = null;
    this.expDate   = null;
  	this.dateArray = [];
  	this.dateArray.push({"change_end_date" : true,"start_date": null,"end_date": null , "application_type" : [0],"type" :null,"start_date_status" : false,"end_date_status" : false});
  }

   /*
   author : Arun Johnson
   desc   : delete form
  */
  deleteForm(index) {
  	this.dateArray.splice(index, 1);
  }

  /*
   author : Arun Johnson
   desc   : select date from multiselect
  */
  dayTimeEvent(event,index) {
    event.selected.length !==0  ? this.dateArray[index]['type'] = event.selected[0].id : this.dateArray[index]['type'] = [];
  }

  /*
   author : Arun Johnson
   desc   : from date from date picker
  */
  toFrom(index, date, event) {
    if (this.editFormDateStatus) {
      this.addStatus = true;
      this.dateArray[index]['start_date'] = date;
      this.dateArray[index]['minDate'] = this.timeZone.toLocal(date);
      for (let i = 0; i < this.dateArray.length; i++) {
        let CurrentDate = this.timeZone.toLocal(this.managerCompensatoryService.formateDate(date));
        let fromDate = this.timeZone.toLocal(this.managerCompensatoryService.formateDate(this.dateArray[i].start_date));
        let toDate = this.timeZone.toLocal(this.managerCompensatoryService.formateDate(this.dateArray[i].end_date));
        if (i != index && ((fromDate <= CurrentDate && CurrentDate <= toDate)) && date) {
          this.dateArray[index]['start_date_status'] = true;
          break;
        } else if (date) {
          if (this.dateArray[index]['change_end_date'] || toDate < fromDate) {
            this.dateArray[index]['change_end_date'] = false;
            this.dateArray[index]['end_date'] = date;
          }
          this.dateArray[index]['start_date_status'] = false;
        }
        if(this.dateArray[index].end_date) {
          let endDate = this.timeZone.toLocal(this.managerCompensatoryService.formateDate(this.dateArray[index].end_date));
          if (i != index && ((fromDate <= endDate && CurrentDate <= endDate)) && date) {
             this.dateArray[index]['end_date_status'] = true;
          }
        }

      }
    }
  }

  /*
   author : Arun Johnson
   desc   : to date from date picker
  */
  toDate(index, date, event) {
    if (this.editFormDateStatus) {
      this.dateArray[index]['end_date'] = date;
      for (let i = 0; i < this.dateArray.length; i++) {

        let CurrentDate = this.timeZone.toLocal(this.managerCompensatoryService.formateDate(date));
        let fromDate = this.timeZone.toLocal(this.managerCompensatoryService.formateDate(this.dateArray[i].start_date));
        let toDate = this.timeZone.toLocal(this.managerCompensatoryService.formateDate(this.dateArray[i].end_date));

        if (i != index && (CurrentDate >= fromDate && CurrentDate <= toDate) && date) {
          this.dateArray[index]['end_date_status'] = true;
          break;
        } else if (date) {
          this.dateArray[index]['end_date'] = date;
          this.dateArray[index]['end_date_status'] = false;
        }
      }
    }
  }

  /*
   author : Arun Johnson
   desc   : submit form
  */
  submitForm() {
    this.formerror         = false;
    this.expDateStatus     = false;
    this.dynamicFormError  = false;
  	// if((!this.empId || !this.empDetails) && !this.addEditStatus) {
  	// 	this.formerror = true;
  	// }
    if(!this.empId || this.empId.length == 0) {
      this.formerror = true;
    }
   for(let i=0;i<this.dateArray.length;i++) {
     let exp  = this.timeZone.toLocal(this.managerCompensatoryService.formateDate(this.expDate));
     let startDate = this.timeZone.toLocal(this.managerCompensatoryService.formateDate(this.dateArray[i].start_date));
      if((exp) < (startDate)) {
        this.formerror = true;
        this.expDateStatus = true;
        break;
      }
   }
  	for(let i=0;i<this.dateArray.length;i++) {
  		if(!this.dateArray[i].start_date) {
  			this.dynamicFormError = true;
  		}

  		if(!this.dateArray[i].end_date) {
  			this.dynamicFormError = true;
  		}
      if(this.dateArray[i].type.length == 0||!this.dateArray[i].type) {
        this.dynamicFormError = true;
      }
      if(this.dateArray[i].end_date_status) {
        this.dynamicFormError = true;
      }
      if(this.dateArray[i].start_date_status) {
        this.dynamicFormError = true;
      }
  	}
  	if(!this.expDate) {
  		this.formerror = true;
  	}
  	if(!this.reason || this.reason.trim() == "") {
      this.reason = null;
      // this.reason = this.reason.trim();
  		this.formerror = true;
  	}
  	if(!this.addEditStatus && !this.formerror && !this.dynamicFormError){
  		this.loaderService.display(true);
  		this.managerCompensatoryService.editCompensatory(this.editdata.id,this.dateArray,this.reason.trim(),this.empCode,this.expDate,res=>{
  			this.loaderService.display(false);
  			if(res.status =="OK") {
           this.formerror = false;
  				 this.notificationService.alertBoxValue("success",res.message);
  				 this.addStatus = false;
  				 this.getManagerData(this.currentPage);
  			} else {
          this.addStatus = false;
  				this.notificationService.alertBoxValue("error",res.errors);
  			}
  		})
  	} else if(!this.formerror && !this.dynamicFormError){
  		this.loaderService.display(true);
  		this.managerCompensatoryService.addCompensatory(this.empDetails,this.dateArray,this.reason.trim(),this.empCode,this.expDate,res=>{
  			this.loaderService.display(false);
  			if(res.status =="OK") {
          this.formerror = false;
           this.addStatus = false;
  				 this.notificationService.alertBoxValue("success",res.message);
  				 this.getManagerData(this.currentPage);
  			} else {
          this.addStatus = false;
  				this.notificationService.alertBoxValue("error",res.errors);
  			}
  		})
  	}
  }

  /*
   author : Arun Johnson
   desc   : get emp details
  */
  getEmpList(list) {
    this.empDetails = list;
    this.searchTextBox = false;
    this.empId = list.first_name + " " + list.last_name + " (" + this.empDetails.code + ")";
    this.empSearch = null;
    this.empList = [];
    this.lazyLoad = true;
    this.managerCompensatoryService.financialyears(list.id,res => {
      if (res.status == "OK") {
        this.minDate  = this.timeZone.toLocal(res.data.financialYear.start_date);
        this.maxDate  = this.timeZone.toLocal(res.data.financialYear.end_date);
        this.lazyLoad = false;
      }
    })
  }

   /*
   author : Arun Johnson
   desc   : get emp details  from api
  */
  getEmpDetails() {
  	if(this.empSearch) {
      // this.loaderService.display(true);
  	this.managerCompensatoryService.getEmpDetails(this.empSearch,res=>{
      this.empList = [];
      // this.loaderService.display(false);
  		if(res.message == "No data found") {
  			this.empList = [];
        this.empExit = true;

  		}
  		else {
        this.empExit = false;
  			this.empList = res.data;
  		}
  	})
  	} else {
  		this.empList = [];
  	}
  }

   /*
   author : Arun Johnson
   desc   : confirm popup
  */
  confirmPopup() {
    this.confirmBox = false;
    // this.deleteIconStatus = false;
    if (this.deleteStatus == 1) {
      this.deleteindividualPeople();
    }
    //  else {
    //   this.multipleDelete();
    // }
  }

    /*
   author : Arun Johnson
   desc   : delete the people
   params : index of check box
  */
  deleteindividualPeople() {
  	let selectedPeople : any = this.managerData[this.deleteIndex];
    this.loaderService.display(true);
  	this.managerCompensatoryService.deletePeople(selectedPeople,res=>{
      this.loaderService.display(false);
      if(res.status == "OK") {
        this.notificationService.alertBoxValue("success",res.message);
  		  this.getManagerData(1);
      } else {
          this.notificationService.alertBoxValue("error",res.message);
          // this.nodata = true;
      }
  	});
  }

  /*
   author : Arun Johnson
   desc   : Search  when enter key is pressed
  */
  search(value) {
   if (value.trim() != '' || (this.searchValue != '' && this.searchValue)) {
    this.searchValue = value;
    this.currentPage = 1;
    this.getManagerData(this.currentPage);
   }
  }

  /*
   author : Arun Johnson
   desc   : send Filter Data
   params :
  */
  filterData(event) {
    this.advanceFilterData = event;
    this.currentPage = 1;
    this.getManagerData(this.currentPage);
  }

  /*
  author : Arun Johnson
  desc   : add class based on index
 */
  getClassByValue(index) {
    return this.managerCompensatoryService.getClassByValue(index);

  }

  setFocus() {
    window.setTimeout(function() {
      document.getElementById('searchField').focus();
    }, 1);
  }

    /*
  *  @desc   :method for pagination
  *  @author :dipin
  */
  getpage(event) {
    if (event > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      this.getManagerData(this.currentPage);
    }
  }
}
