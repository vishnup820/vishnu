import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeExceptionalComponent } from './employee-exceptional.component';

describe('EmployeeExceptionalComponent', () => {
  let component: EmployeeExceptionalComponent;
  let fixture: ComponentFixture<EmployeeExceptionalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeExceptionalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeExceptionalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
