import { Component, OnInit } from '@angular/core';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'

import { EmployeeExceptionalService } from '../../services/employee-exceptional/employee-exceptional.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { CookieService } from 'ngx-cookie-service';
@Component({
  selector: 'app-employee-exceptional',
  templateUrl: './employee-exceptional.component.html',
  styleUrls: ['./employee-exceptional.component.css']
})
export class EmployeeExceptionalComponent implements OnInit {

    tableData     :     any = [];
	forDay        : boolean = false;
	forWorkDay    : boolean = false;
	forEtitle     : boolean = false;
	confirmBox    : boolean;
	totalSelected :     any = 0;
	currentPage   : number  = 1;
    recordsPerPage: number  = 10;
    totalRecords  : any;
    setIndex      : any;
	setStack      : any;
	userData      : any;

	constructor(private apiService    : EmployeeExceptionalService,
		        private notifications : NotificationService,
				private loaderService : LoaderActionsService,
			    private cookieService : CookieService) { }

	ngOnInit() {
		if (localStorage.getItem("itemsperpage")) {
			this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			this.recordsPerPage = 10;
		}
		if (this.cookieService.get("user-data")) {
			this.userData = JSON.parse(this.cookieService.get("user-data")).user_id;
		}
		this.getData(this.currentPage);
	}

    /*
	*  @desc   :method to update list by api call
  	*  @author :dipin
	*/
	getData(page){
	this.loaderService.display(true);
	this.currentPage = page;
      this.apiService.getCalanderDetails(this.currentPage,this.recordsPerPage,this.userData,response => {
			if (response.status == "OK") {
				if(response.data){
                 this.tableData = response.data;
                 this.totalRecords = response.count;
                 this.loaderService.display(false);
				}
				else{
				  this.tableData = [];
				  this.loaderService.display(false);
				}
			}
			else {
				this.tableData = [];
			}
		})
	}

     /*
	*  @desc   :method for apply sorting using api and update the table list
  	*  @author :dipin
	*/
	applySort(value){
		this.loaderService.display(true);
		let type = 0;
		if (value == 'ed')
			if (this.forDay == true) {
				type = 1;
				this.forDay = false;
			}
			else {
				type = 0;
				this.forDay = true;
			}

		if (value == 'cd')
			if (this.forWorkDay == true) {
				type = 1;
				this.forWorkDay = false;
			}
			else {
				type = 0;
				this.forWorkDay = true;
			}

        if (value == 'title')
			if (this.forEtitle == true) {
				type = 1;
				this.forEtitle = false;
			}
			else {
				type = 0;
				this.forEtitle = true;
			}

	  this.apiService.sortCalenderDetails({department : value,type:type},this.userData,response=>{
                  if(response.status == "OK"){
                    this.tableData = response.data;
                    this.loaderService.display(false);
                  }
                  else{
                  	this.notifications.alertBoxValue("error", response.message);
                    this.tableData = [];
                    this.loaderService.display(false);
                  }
          })
	}

   /*
  *  @desc   :method for pagination
  *  @author :dipin
  */
	getpage(event) {
		if (event > 10 || this.recordsPerPage != 10) {
			this.recordsPerPage = event;
			this.currentPage = 1;
			this.getData(this.currentPage);
		}
	}
}
