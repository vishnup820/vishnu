/*
*  @desc   :component for employee leave application
*  @author :dipin
*/
import { Component, OnInit,AfterViewChecked, ElementRef, ViewChild,AfterViewInit,OnDestroy} from '@angular/core';
import * as FileSaver from 'file-saver';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { EmployeeLeaveDetailsService } from '../../services/employee-leave/employee-leave-details.service';
import { ExceptionalDetailsService } from '../../services/exceptional-details.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { CookieService } from 'ngx-cookie-service';
import { MalihuScrollbarService } from 'ngx-malihu-scrollbar';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';
declare var require: any;
var moment = require('moment');
@Component({
	selector: 'app-employee-leave-list',
	templateUrl: './employee-leave-list.component.html',
	styleUrls: ['./employee-leave-list.component.css']
})
export class EmployeeLeaveListComponent implements OnInit,AfterViewInit,OnDestroy{
	tableData         : any = [];
	leaveList         : any = [];
	dispLeave         : any = [];
	tableEdit         : any = [];
	fileData          : any = [];
	type              : any = [];
	selectedEmail     : any = [];
	payPeriod         : any;
	listId			  : any;
	fileDetails       : any;
	messageData       : any;
	selectedEmailData : any;
	lopListCount      : any;
	payExtraPeriod    : any;
	selectedChat      : any;
	dispListLeave     : any;
	emailData         : any;
	selectChat        : any;
	lopCount          : any;
	editConfig        : any;
	chatMessage       : any = "";
	userList          : any;
	empIdSearch       : any = "";
	fileName          : any = [];
	selectedItems     : any = [];
	leaveDaySelected  : any = [];
	displayAdd		  : boolean = false;
	entryBlock		  : boolean = false;
	responceLoad      : boolean = true;
	lazyLoad		  : boolean = false;
	viewTooltip		  : boolean = false;
	editStatus	      : boolean = false;
	filterStatus	  : boolean = false;
	addStatus	      : boolean = false;
	formerror         : boolean = false;
	chatLoad		  : boolean  = false;
	searchTextBox	  : boolean = false;
	aclPermission     : boolean = false;
	chatConfirm       : boolean = false;
	userType		  : boolean = true;
	halfEnable		  : boolean = false;
	empExit			  : boolean = false;
	confirmBox        : boolean;
	totalSelected     : number = 0;
	currentPage       : number = 1;
	recordsPerPage    : number = 10;
	totalRecords      : number;

	minDate: Date = new Date();
	managerData       : any;
	leaveSelected	  : any;
	totalCount	      : any = 0;
	maxLeave		  : any;
	documntM		  : any;
	leaveDays		  : any;
	typeLeave         : any = "";
	selectedId        : any;
	empDetails        : any;
	editId            : any;
	empEditId	      : any;
	setIndex	      : any;
	config            : any;
	setStack		  : any;
	timer             : any;
	startDate		  : any;
	endDate			  : any;
	restrictData	  : any;
	leaveTypeValue	  : any;
	advanceFilterData : any;
	chatScollbar      : any;
	fileURL 		  : any;
	empId             : any;
	sort              : any;
	empCode           : any;
	reason            : any;
	dayTime           : any = [{ "id": 1, "name": "Full Day" }, { "id": 2, "name": "Half day(First Half)" }, { "id": 3, "name": "Half day(Second Half)" }];
	dayTimeSelected   : any;
	dateArray         : any = [];
	expDate           : any;
	userData          : any;
	editdata          : any;
	empList           : any = [];
	currentFYSatrtDate:any
	currentFYendDate  :any
	rangevalue        :any
	initialcall       :boolean =false
	constructor(
		private apiService        : ExceptionalDetailsService,
		private notifications     : NotificationService,
		private loaderService     : LoaderActionsService,
		private cookieService     : CookieService,
		private dataService       : EmployeeLeaveDetailsService,
		private router			  : Router,
		private mScrollbarService : MalihuScrollbarService,
		private acl               : AclVerificationService,
		private timeZone          : TimezoneDetailsService) {
		this.chatScollbar = {
			axis: 'y', theme: 'minimal-dark', autoHideScrollbar: false, callbacks: {
				whileScrolling : function() {

				}
			}
		}
	}

	ngOnInit() {
		this.loaderService.display(true);
		this.initialcall = true;
		let checkDate = this.timeZone.getCurrentDate();
		this.aclPermission = this.acl.checkAcl('/modules/case/case-list');
		let self = this;
		if (localStorage.getItem("itemsperpage")) {
			this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			this.recordsPerPage = 10;
		}
		this.confirmBox = false;
		this.config = "Are You Sure You Want To Cancel?";
		this.dateArray.push({
			"change_end_date": true,
			"start_date": null,
			"end_date": null,
			"application_type": 0,
			"type": null,
			"start_date_status": false,
			"start_invalid": false,
			"end_invalid": false,
			"end_date_status": false,
			"prior_stat_start": false,
			"prior_stat_end": false,
			"count": 0,
			"submitted": false
		});
		this.leaveDaySelected.push([0]);
		if (this.cookieService.get("user-data")) {
			this.userData = JSON.parse(this.cookieService.get("user-data"));
			this.currentFYSatrtDate = this.timeZone.toLocal(this.userData.start_date);
			this.currentFYendDate   = this.timeZone.toLocal(this.userData.end_date);
			setTimeout(() => {
				this.rangevalue = [this.currentFYSatrtDate, this.currentFYendDate];
			}, 500);
			this.empDetails = this.empDetails = {
				id: "",
				name: this.userData.first_name + ' ' + this.userData.last_name,
				code: this.userData.employee_id
			};
			if (this.userData.role_id == 1 || this.userData.role_id == 3) {
				this.initialcall = false;
				this.empId = this.userData.user_id;
				this.selectedId = this.userData.user_id;
				this.listId = this.userData.user_id;
				this.empEditId = this.userData.first_name + ' ' + this.userData.last_name + ' (' + this.userData.employee_id + ')';
			}
			else if (this.userData.role_id == 4 || this.userData.role_id == 2) {
				this.empId = this.userData.user_id;
				this.selectedId = this.userData.user_id;
				this.listId = this.userData.user_id;
				this.empEditId = this.userData.first_name + ' ' + this.userData.last_name + ' (' + this.userData.employee_id + ')';
				this.empIdSearch = this.empEditId;
				this.empDetails.id = this.userData.user_id;
			}
			if (this.userData.role_id == 4 || this.userData.role_id == 2) {
				this.dataService.getPeople(response => {
					if (response.status == "OK") {
						if (response.data) {
							this.userList = response.data;
							for (var i = 0; i < this.userList.length; i++) {
								this.userList[i].name = this.userList[i].first_name + " " + this.userList[i].last_name + " ("+this.userList[i].code+")";
							}
							if (this.userData.role_id == 2 || this.userData.role_id == 4) {
								this.userList.splice(0, 0, {
									name: "All",
									id: "All",
									role: "Administrator",
									role_id: "2",
									status: "1"
								});
							}

							for (var i = 0; i < this.userList.length; i++) {
								if (this.userData.user_id == this.userList[i].id) {
									this.selectedItems = [i];
									break;
								}
							}
						}
						// else {
						// 	this.loaderService.display(false);
						// }
					}
				})
			}
			else {
				// console.log(true,5)
				// this.getData(this.currentPage);
			}
		}

		this.timer = setInterval(() => {
			self.setMessageIcon();
		}, 1000);
	}

	ngAfterViewInit() {
		this.mScrollbarService.scrollTo("bottom", document.getElementById("emp-chat"), { scrollInertia: 0 });
	}

	ngOnDestroy() {
		clearInterval(this.timer);
	}

	/*
	*  @desc   :method to update list by api call
		*  @author :dipin
	*/
	getData(page) {
		this.loaderService.display(true);
		this.currentPage = page;
		this.initialcall=false;
		this.dataService.getLeaveList(this.currentPage, this.recordsPerPage, this.advanceFilterData, this.sort, this.listId, response => {
			if (response.status == "OK") {
				if (response.data) {
					this.tableData = response.data;
					let tempArray = [];
					for (let i = 0; i < this.tableData.length; i++) {
						this.tableData[i].messageStatus = false;
						this.tableData[i].chatLoad = false;
						this.tableData[i].display = false;
						let secondHand = [];
						for (var j = 0; j < this.tableData[i].leave_details.length; j++) {
							secondHand.push({ date: this.tableData[i].leave_details[j].applied_date, status: this.tableData[i].leave_details[j].status });
						}
						tempArray.push(secondHand);
					}
					let checkDate = this.timeZone.getCurrentDate();
					for (var i = 0; i < tempArray.length; i++) {
						for (var j = 0; j < tempArray[i].length; j++) {
							if (moment(checkDate).isBefore(moment(moment(tempArray[i][j].date).add('days', 1))) && tempArray[i][j].status != 'R') {
								this.tableData[i].display = true;
								break;
							}
							else {
								this.tableData[i].display = false;
							}
						}
					}
				}
				else {
					this.tableData = [];
				}
				if (this.userData.role_id != 2 && this.userData.role_id != 4) {
					this.dataService.getLeaveTypes(this.listId, res => {
						if (res.message == "No data found") {
							this.lopListCount = undefined;
							this.dispListLeave = [];
							this.loaderService.display(false);
						}
						else {
							this.dispListLeave = res.data;
							this.lopListCount = res.lopCount;
							this.loaderService.display(false);
						}
					})
				}
				else
					this.loaderService.display(false);
				this.totalRecords = response.count;
			}
			else {
				this.tableData = [];
				this.loaderService.display(false);
			}
		})
	}

	/*
   *  @desc   :select all the rows listed in the table
	   *  @author :dipin
   */
	selectAll(value) {
		for (var i = 0; i < this.tableData.length; i++) {
			this.tableData[i].checked = value;
		}
	}

	/*
   *  @desc   :method to delete element from the list
	   *  @author :dipin
   */
	deleteSelected(index) {
		this.loaderService.display(true);
		this.dataService.deleteLeaveDetails(this.tableData[index].id, response => {
			if (response.status == "Success") {
				this.currentPage = 1;
				this.dataService.getLeaveTypes(this.userData.user_id, res => {
					if (res.message == "No data found") {
						this.loaderService.display(false);
						this.lopListCount = undefined;
						this.dispListLeave = [];
					}
					else {
						this.dispListLeave = res.data;
						this.lopListCount = res.lopCount;
						this.getData(this.currentPage);
					}
				})
				this.notifications.alertBoxValue("success", "Leave Cancelled Successfully");
			}
			else {
				this.loaderService.display(false);
				this.notifications.alertBoxValue("error", response.message);
			}
		})
	}

	/*
   *  @desc   :method to handle popup confirmation
	   *  @author :dipin
   */
	getPopupConfirm(event) {
		this.confirmBox = false;
		if (event == true) {
			this.deleteSelected(this.setIndex);
		}
	}
	getlastday(y,m){
		return  new Date(y, m, 0).getDate();
	}

	/*
	 author : dipin
	 desc   : get emp details
   */
	selectedValue(event) {
		let val = false;
		let last = false;
		if (event.selected.length) {
			this.leaveTypeValue = event.selected[0].id;
			this.typeLeave = event.selected[0].name;
			if (!this.editStatus) {
				this.dateArray = [{
					"change_end_date": true,
					"start_date": null,
					"end_date": null,
					"application_type": 0,
					"type": null,
					"start_date_status": false,
					"end_date_status": false,
					"prior_stat_start": false,
					"prior_stat_end": false,
					"start_invalid": false,
					"end_invalid": false,
					"count": 0,
					"submitted": false
				}];
				this.leaveDaySelected = [];
				this.leaveDaySelected.push([0]);
			}
			if (this.selectedId != undefined && this.leaveTypeValue != undefined) {
				this.lazyLoad = true;
				this.dataService.getValidations((this.userType == true) ? this.selectedId : this.empDetails.id, this.leaveTypeValue, res => {
					if (res.message == "No data found" || res.status == "Failed") {
						this.restrictData = [];
						this.lazyLoad = false;
					}
					else {
						let date = this.timeZone.getCurrentDate();
						let tempDate = moment(this.timeZone.toLocal(date.getFullYear() + "-"+ Number(date.getMonth() + 1) + "-" + Number(this.payPeriod)), 'MM-DD-YYYY HH:mm').add((this.payExtraPeriod != undefined)?(this.payExtraPeriod + 1):1, 'days');
						let nextCycleStart = tempDate.toDate()
						let nextMonthStart = this.timeZone.toLocal(date.getFullYear() + "-" +Number(date.getMonth() + 1) + "-" + (Number(this.payPeriod)+1))
						if(this.payPeriod == "29"){
							last = true;
							this.payPeriod = this.getlastday(date.getFullYear(),(date.getMonth()))
							// tempDate = moment(this.timeZone.toLocal(date.getFullYear() + "-"+ Number(date.getMonth() + 1) + "-" + Number(this.payPeriod)), 'MM-DD-YYYY HH:mm').add((this.payExtraPeriod != undefined)?(this.payExtraPeriod + 1):1, 'days')
						}
						let tempDate2 = moment(this.timeZone.toLocal(date.getFullYear() + "-"+ Number(date.getMonth()) + "-" + Number(this.payPeriod)), 'MM-DD-YYYY HH:mm').add(this.payExtraPeriod, 'days');
						this.restrictData = res.data;

						if (!this.userType) {
							if (this.userData.role_id == 2 || this.userData.role_id == 4) {
								if (date.getDate() >= Number(this.payPeriod)) {
									if (Date.parse(tempDate.toDate()) >= Date.parse(moment(this.timeZone.getCurrentDate(), 'MM-DD-YYYY HH:mm').toDate())) {
										this.startDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth()) + "-" + (Number(this.payPeriod)+1));
										this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
									}
									else {
										if(last ){
											this.startDate = this.timeZone.toLocal(date.getFullYear() + "-" +Number(date.getMonth() ) + "-" +(Number(this.payPeriod)+1));
											this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
										}
									
										else{
											this.startDate = this.timeZone.toLocal(date.getFullYear() + "-" +Number(date.getMonth()+1 ) + "-" +(Number(this.payPeriod)+1));
											this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
										}									
									}
								}
								else {
									if((nextCycleStart != undefined) || (nextCycleStart! = null) || (nextCycleStart != "Invalid Date")){
										let currentDay = new Date(date.getFullYear(),date.getMonth(),date.getDate())
										let lastdaywithExtapayprd = new Date(tempDate2.toDate().getFullYear(),tempDate2.toDate().getMonth(),tempDate2.toDate().getDate())
										// if(Number(y.getMonth()) > Number(t.getMonth()) && (date<tempDate2.toDate())){
										if(Number(nextCycleStart.getMonth()) > Number(nextMonthStart.getMonth()) && (currentDay<=lastdaywithExtapayprd)){
											val = true;
										}
										// else if(Number(y.getMonth())==1 && Number(t.getMonth())==12 && (date<tempDate2.toDate())){
										else if(Number(nextCycleStart.getMonth())==0 && Number(nextMonthStart.getMonth())==11 && (currentDay<=lastdaywithExtapayprd)){
											val = true;
										}
									}
									if(val){
										if(last){
											// this.minDate = this.timeZone.toLocal(date.getFullYear()+"-"+ Number(date.getMonth()) + "-" + 1);
											this.startDate = this.timeZone.toLocal(date.getFullYear()+"-"+ Number(date.getMonth()) + "-" + 1);
											this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
										}
										else{
											this.startDate = this.timeZone.toLocal(date.getFullYear()+"-"+ Number(date.getMonth()-1) + "-" + (Number(this.payPeriod)+1));
											this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
										}
										// this.startDate = this.timeZone.toLocal(date.getFullYear()+"-"+ Number(date.getMonth()-1) + "-" + (Number(this.payPeriod)+1));
										// this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
									}else{
										let currentDay = new Date(date.getFullYear(),date.getMonth(),date.getDate())
										let lastdaywithExtapayprd = new Date(tempDate2.toDate().getFullYear(),tempDate2.toDate().getMonth(),tempDate2.toDate().getDate())
										if(currentDay<=lastdaywithExtapayprd){
											this.startDate = this.timeZone.toLocal(date.getFullYear()+"-"+ Number(date.getMonth()-1) + "-" + (Number(this.payPeriod)+1));

											// this.startDate = this.timeZone.toLocal(date.getFullYear()+"-"+ Number(date.getMonth()) + "-" + (Number(this.payPeriod)+1));
											this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
										}else
										{
											 this.startDate = this.timeZone.toLocal(date.getFullYear()+"-"+ Number(date.getMonth()) + "-" + (Number(this.payPeriod)+1));
											this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
										}
									
									}
								}
							}
							else {
								if (date.getDate() > Number(this.payPeriod)) {
									this.startDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth() + 1) + "-" + (Number(this.payPeriod)+1));
									this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
								}
								else {
									this.startDate = this.timeZone.toLocal(date.getFullYear() +"-"+Number(date.getMonth()) + "-" + (Number(this.payPeriod)+1));
									this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
								}
							}
						}
						else {
							if(this.restrictData && this.restrictData.financialYear && this.restrictData.financialYear.end_date != undefined){
								this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
							}else{
								// this.endDate = this.timeZone.getCurrentDate();
							}
							this.startDate = this.timeZone.getCurrentDate();
						}
						this.halfEnable = (this.restrictData.leaveRestrictions[0].halfday_provision == "1") ? true : false;
						this.maxLeave = this.restrictData.leaveRestrictions[0].max_consecutive_leaves;
						this.leaveDays = this.restrictData.leaveDates;
						this.documntM = {
							status: (this.restrictData.leaveRestrictions[0].document_mandatory == "1") ? true : false,
							days: (this.restrictData.leaveRestrictions[0].document_mandatory == "1") ? this.restrictData.leaveRestrictions[0].document_submission_days : 0
						}

						if (this.halfEnable == true) {
							this.dayTime = [
								{ "id": 1, "name": "Full Day" },
								{ "id": 2, "name": "Half day(First Half)" },
								{ "id": 3, "name": "Half day(Second Half)" }
							];
						}
						else {
							this.dayTime = [
								{ "id": 1, "name": "Full Day" }
							];
						}
					}
					this.lazyLoad = false;
				})
			}
		}
		else {
			this.typeLeave = "";
			this.leaveTypeValue = "";
		}
	}

	/*
	 author : dipin
	 desc   : get edit details
   */
	getEditDetails(index) {
		window.scrollTo(0, 0);
		this.userType = true;
		this.leaveDaySelected = [];
		this.lazyLoad = true;
		if (this.cookieService.get("user-data")) {
			this.userData = JSON.parse(this.cookieService.get("user-data"));
			if (this.userData.role_id == 1 || this.userData.role_id == 3) {
				this.empId = this.userData.user_id;
				this.selectedId = this.userData.user_id;
				this.empEditId = this.userData.first_name + ' ' + this.userData.last_name + ' (' + this.userData.employee_id + ')';
				this.empIdSearch = this.empEditId;
			}
			else if (this.userData.role_id == 2 || this.userData.role_id == 4) {
				this.empId = this.userData.user_id;
				this.selectedId = this.userData.user_id;
				this.empEditId = this.userData.first_name + ' ' + this.userData.last_name + ' (' + this.userData.employee_id + ')';
				this.empIdSearch = this.empEditId;
			}
		}
		this.totalCount = 0;
		this.editStatus = true;
		this.dataService.getLeaveTypes((this.userType == true) ? this.selectedId : this.empDetails.id, res => {
			if (res.message == "No data found") {
				this.notifications.alertBoxValue("error", res.message);
				this.lazyLoad = false;
			}
			else {
				let temp = res.data;
				this.dispLeave = res.data;
				this.lopCount = res.lopCount;
				this.payPeriod = res.payPeriodDay;
				(res.payPeriodExtendDays) ? this.payExtraPeriod = Number(res.payPeriodExtendDays) : undefined;

				this.dataService.editLeaveDetails(this.tableData[index].id, res => {
					if (res.message == "No data found" || res.status == "Failed") {
						this.tableEdit = [];
						this.dateArray = [];
						this.notifications.alertBoxValue("error", res.message);
						this.lazyLoad = false;;
					}
					else {
						this.dateArray = [];
						this.tableEdit = (res.data.length) ? res.data[0] : {};
						if (this.tableEdit.file_details && this.tableEdit.file_details.length) {
							this.fileData = [];
							for (let i = 0; i < this.tableEdit.file_details.length; i++) {
								this.fileData.push({
									file_id: this.tableEdit.file_details[i].file_id,
									fileName: this.tableEdit.file_details[i].file_name,
									type: this.tableEdit.file_details[i].file_type,
									file_size: this.tableEdit.file_details[i].file_size
								});
							}
						}
						this.reason = this.tableEdit.reason_for_leave;
						this.editId = this.tableEdit.id;

						for (var i = 0; i < this.tableEdit.leave_details.length; i++) {
							if (this.tableEdit.leave_details[i].sandwitch_status == '1' && (this.tableEdit.leave_details[i].start_date == this.tableEdit.leave_details[i].end_date)) {
							}
							else {
								this.dateArray.push({
									"change_end_date": true,
									"start_date":this.timeZone.toLocal(this.tableEdit.leave_details[i].start_date),
									"end_date": this.timeZone.toLocal(this.tableEdit.leave_details[i].end_date),
									"application_type": this.tableEdit.leave_details[i].application_type,
									"type": null,
									"start_date_status": false,
									"end_date_status": false,
									"start_invalid": false,
									"end_invalid": false,
									"count": 0,
									"prior_stat_start": false,
									"prior_stat_end": false,
									"submitted": false
								});
								this.leaveDaySelected.push([]);
							}
						}
						this.leaveList = [{
							name: this.tableEdit.leave_type,
							id: this.tableEdit.leave_type_id
						}
						];
						this.leaveSelected = [0];

						for (var j = 0; j < this.dateArray.length; j++) {
							for (var i = 0; i < this.dayTime.length; i++) {
								if (this.dateArray[j].application_type == this.dayTime[i].id) {
									this.leaveDaySelected[j] = [i];
								}
							}
						}
						if (!this.emailData) {
							this.dataService.emailListing(response => {
								if (response.status == "OK") {
									if (response.data) {
										this.emailData = response.data;
										for (let i = 0; i < this.emailData.length; i++) {
											if (this.emailData[i].email.trim() == "" || this.emailData[i].email == this.userData.rm_email || this.emailData[i].email == this.userData.email) {
												this.emailData.splice(i, 1);
											}
										}
										this.lazyLoad = false;
									}
								}
							})
						}
						if (this.tableEdit.notified_peoples)
							this.selectedEmail = this.tableEdit.notified_peoples.split(',');
						this.lazyLoad = false;
					}
				})
			}
		})
	}

	/*
   author : dipin
   desc   : get emp details
   */
	getEmpList(list) {
		this.selectedId = list.id;
		this.empEditId = list.code;
		this.empIdSearch = this.empEditId;
		if (this.empEditId != this.userData.employee_id) {
			this.userType = false;
		}
		else {
			this.userType = true;
		}
		this.empDetails = list;
		this.getLeaveTypes();
		this.searchTextBox = false;
		this.empEditId = list.first_name + " " + list.last_name + " (" + this.empDetails.code + ")";
		this.empIdSearch = this.empEditId;
		this.empIdSearch = list.first_name + " " + list.last_name + " (" + this.empDetails.code + ")";
	}

	/*
   author : dipin
   desc   : send Filter Data
   params :
  */
	filterData(event) {
	 if (event || this.advanceFilterData) {
		this.advanceFilterData = event;
		this.currentPage = 1;
		if(this.listId){
			if((this.userData.role_id!='4'|| this.userData.role_id!='2')&&(!this.initialcall)){
				this.getData(this.currentPage);

			}
		}
	 }
	 else{
	 	this.advanceFilterData = undefined;
	 }
	}

	/*
	author : dipin
	desc   : add Tab open
	*/
	addTab() {
		this.formerror = false;
		this.dateArray = [];
		this.reason = "";
		this.empCode = null;
		this.dateArray = [];
		this.tableEdit = [];
		this.totalCount = 0;
		this.dateArray.push({
			"change_end_date": true, "end_invalid": false, "start_date": null, "end_date": null, "application_type": 0, "type": null, "start_date_status": false, "end_date_status": false, count: 0, "submitted": false, "prior_stat_start": false,
			"prior_stat_end": false, "start_invalid": false,
		});
		this.leaveDaySelected = [];
		this.leaveDaySelected.push([0]);
	}

	/*
	 author : dipin
	 desc   : get emp details  from api
	*/
	getEmpDetails() {
		this.lazyLoad = true;
		this.dataService.getEmpDetails(this.empId, this.userData.role_id, this.empIdSearch, res => {
			if (res.message == "No data found" || res.status == "Failed" || res.data.length == 0) {
				this.empList = [];
				this.lazyLoad = false;
				this.empExit = true;
			}
			else {
				this.empList = res.data;
				this.lazyLoad = false;
				this.empExit = false;
			}
		})
		if (this.empEditId != this.userData.employee_id) {
			this.userType = false;
		}
		else {
			this.userType = true;
		}
	}

	/*
	author : dipin
	desc   : add class based on index
	*/
	getClassByValue(index) {
		return this.dataService.getClassByValue(index);
	}

	/*
	author : dipin
	desc   : lop report download as excel
	*/
	exportExcel() {
		this.loaderService.display(true);
		this.dataService.exportExcelData(this.listId, this.advanceFilterData, res => {
			if (res && res.data) {
				let binary_string: any = window.atob(res.data);
				let len: any = binary_string.length;
				let bytes: any = new Uint8Array(len);
				for (var i = 0; i < len; i++) {
					bytes[i] = binary_string.charCodeAt(i);
				}

				let file: any = new Blob([bytes.buffer], { type: "application/vnd.ms-excel" });
				let filename: any = 'Leave Report ' + this.timeZone.getCurrentDate().toDateString() + '.xlsx';
				FileSaver.saveAs(file, filename);
				this.loaderService.display(false);
			}
			else {
				this.notifications.alertBoxValue("error", res.message);
				this.loaderService.display(false);
			}
		})
	}

	/*
	author : dipin
	desc   : create new form for seperate for edit and add
	*/
	addNewForm() {
		var index = this.dateArray.length - 1;
		this.dateArray[index].submitted = true;
		if (this.dateArray[index].application_type != 0 && this.dateArray[index].start_date != null) {
			if (!this.dateArray[index].start_date_status && !this.dateArray[index].end_date_status && !this.dateArray[index].start_invalid && !this.dateArray[index].end_invalid && this.dateArray[index].type && !this.dateArray[index].prior_stat_end && !this.dateArray[index].prior_stat_start) {
				this.dateArray.push({
					"change_end_date": true, "start_date": null, "end_date": null,
					"application_type": 0, "prior_stat_start": false,
					"prior_stat_end": false,
					"type": null, "start_date_status": false, "end_invalid": false,
					"end_date_status": false, "count": 0, "submitted": false, "start_invalid": false,
				});
				this.leaveDaySelected.push([0]);
			}
		}
	}

	/*
	author : dipin
	desc   : from date from date picker
   */
	toFrom(index, date, event) {
		let cStatus = false;
		let eStatus = false;
		let xStatus = false;
		let checkstatus = false;
		if (this.leaveDays) {
			for (let j = 0; j < this.leaveDays.holiday.length; j++) {
				if (this.formatForApi(this.dateArray[index].start_date) == this.leaveDays.holiday[j]) {
					this.dateArray[index].start_invalid = true;
					cStatus = true;
					break;
				}
				else {
					cStatus = false;
					this.dateArray[index].start_invalid = false;
				}
			}
			if (!cStatus)
				for (let j = 0; j < this.leaveDays.weekend.length; j++) {
					if (this.formatForApi(this.dateArray[index].start_date) == this.leaveDays.weekend[j]) {
						this.dateArray[index].start_invalid = true;
						eStatus = true;
						break;
					}
					else {
						eStatus = false;
						this.dateArray[index].start_invalid = false;
					}
				}
			if (this.dateArray[index].start_date && this.userType && this.restrictData.leaveRestrictions[0].prior_request_days) {
				var dateB = moment(this.formatForApi(this.dateArray[index].start_date));
				var dateC = this.timeZone.getCurrentDate();
				var countDate = dateB.diff(dateC, 'days');
				if (countDate + 1 >= Number(this.restrictData.leaveRestrictions[0].prior_request_days)) {
					xStatus = false;
					this.dateArray[index].prior_stat_start = false;
				}
				else {
					this.dateArray[index].prior_stat_start = true;
					xStatus = true;
				}
			}
		}

		if (!cStatus && !eStatus && !xStatus) {
			this.addStatus = true;
			this.dateArray[index]['start_date'] = date;
			this.dateArray[index]['minDate'] = this.timeZone.toLocal(date);
			for (let i = 0; i < this.dateArray.length; i++) {
				if (i != index && date >= this.dateArray[i].start_date && date <= this.dateArray[i].end_date && date) {
					this.dateArray[index]['start_date_status'] = true;
					break;
				} else if (date) {
					if (this.dateArray[index]['change_end_date'] || this.dateArray[index]['end_date'] < this.dateArray[index]['start_date']) {
						this.dateArray[index]['change_end_date'] = false;
						if (!this.editStatus)
							this.dateArray[index]['end_date'] = date;
					}
					this.dateArray[index]['start_date_status'] = false;
				}
			}
		}

		if(this.editStatus){
			if (!cStatus && !eStatus && !xStatus) {
				this.dateArray[index]['start_date'] = date;
	
				for (let i = 0; i < this.dateArray.length; i++) {
					let removeTime = moment(this.dateArray[i].start_date, 'MM-DD-YYYY HH:mm').toDate();
					removeTime.setHours(0);
					removeTime.setMinutes(0);
					removeTime.setSeconds(0);
					let newDate = moment(date, 'MM-DD-YYYY HH:mm').toDate();
					newDate.setHours(0);
					newDate.setMinutes(0);
					newDate.setSeconds(0);
					if(this.timeZone.toLocal(this.dateArray[index].start_date)>=this.timeZone.toLocal(this.dateArray[index].end_date)){
						this.dateArray[index].end_date = this.dateArray[index].start_date;
				   }
					if (i != index && newDate.getTime() === removeTime.getTime()) {
						this.dateArray[index]['start_date_status'] = true;
						break;
					} else if (date) {
						this.dateArray[index]['start_date'] = date;
						this.dateArray[index]['start_date_status'] = false;
					}
				}
			}
		}

	}
	/*
	author : dipin
	desc   : to date from date picker
	*/
	toDate(index, date, event) {
		let cStatus = false;
		let eStatus = false;
		let xStatus = false;
		if (this.leaveDays) {
			for (let j = 0; j < this.leaveDays.holiday.length; j++) {
				if (this.formatForApi(this.dateArray[index].end_date) == this.leaveDays.holiday[j]) {
					this.dateArray[index].end_invalid = true;
					cStatus = true;
					break;
				}
				else {
					cStatus = false;
					this.dateArray[index].end_invalid = false;
				}
			}
			if (!cStatus)
				for (let j = 0; j < this.leaveDays.weekend.length; j++) {
					if (this.formatForApi(this.dateArray[index].end_date) == this.leaveDays.weekend[j]) {
						this.dateArray[index].end_invalid = true;
						eStatus = true;
						break;
					}
					else {
						eStatus = false
						this.dateArray[index].end_invalid = false;
					}
				}
			if (this.dateArray[index].end_date && this.userType && this.restrictData.leaveRestrictions[0].prior_request_days) {
				var dateB = moment(this.formatForApi(this.dateArray[index].end_date));
				var dateC = this.timeZone.getCurrentDate();
				var countDate = dateB.diff(dateC, 'days');
				if (countDate + 1 >= Number(this.restrictData.leaveRestrictions[0].prior_request_days)) {
					xStatus = false;
					this.dateArray[index].prior_stat_end = false;
				}
				else {
					this.dateArray[index].prior_stat_end = true;
					xStatus = true;
				}
			}
		}

		if (!cStatus && !eStatus && !xStatus) {
			this.dateArray[index]['end_date'] = date;
			for (let i = 0; i < this.dateArray.length; i++) {
				if (i != index && date >= this.dateArray[i].start_date && date <= this.dateArray[i].end_date && date) {
					this.dateArray[index]['end_date_status'] = true;
					break;
				} else if (date) {
					this.dateArray[index]['end_date'] = date;
					this.dateArray[index]['end_date_status'] = false;
				}
			}
		}
	}

	/*
   author : dipin
   desc   : select date from multiselect
  */
	dayTimeEvent(event, i) {
		(event.selected[0]) ? this.dateArray[i]['application_type'] = event.selected[0].id : null;
		(event.selected[0]) ? this.dateArray[i]['type'] = event.selected[0].id : null;
	}

	/*
   author : dipin
   desc   : delete form
  */
	deleteForm(index) {
		this.dateArray.splice(index, 1);		 	
		for(let i =0 ;i< this.dateArray.length;i++){
			this.toFrom(i, this.dateArray[i].start_date,null)
			this.toDate(i, this.dateArray[i].end_date,null)
		}
	}

	/*
	 author : dipin
	 desc   : add form
	*/
	submitForm() {
		let cStatus = false;
		let eStatus = false;
		let yStatus = false;
		let vStartStatus = false;
		let vEndStatus = false;
		let xStatus = false;
		var index = this.dateArray.length - 1;
		for (var i = 0; i < this.dateArray.length; i++) {
			this.dateArray[i].submitted = true;
			if (!this.dateArray[i].start_date || this.dateArray[i].start_date_status) {
				cStatus = true;
				break;
			}
			else
				cStatus = false;

			if (!this.dateArray[i].end_date || this.dateArray[i].end_date_status) {
				eStatus = true;
				break;
			}
			else
				eStatus = false;

			if (this.dateArray[i].start_invalid) {
				vStartStatus = true;
				break;
			}
			else
				vStartStatus = false;

			if (this.dateArray[i].end_invalid) {
				vEndStatus = true;
				break;
			}
			else
				vEndStatus = false;
			if (this.dateArray[i].prior_stat_end || this.dateArray[index].prior_stat_start) {
				xStatus = true;
				break;
			}
			else {
				xStatus = false;
			}

			if (this.dateArray[i].application_type == 0) {
				yStatus = true;
				break;
			}
			else {
				yStatus = false;
			}
		}
		if (!this.empEditId || !this.leaveTypeValue || !this.reason || xStatus || cStatus || eStatus || vStartStatus || vEndStatus || yStatus) {
			this.formerror = true;
			return;
		}
		else {
			let self = this;
			setTimeout(function() {
				self.formerror = false;
				self.tableEdit = [];
				let tempDetails = [], tempEmail = [];
				for (var i = 0; i < self.dateArray.length; i++) {
					tempDetails.push({
						"from": self.formatForApi(self.dateArray[i].start_date),
						"to": self.formatForApi(self.dateArray[i].end_date),
						"application_type": self.dateArray[i].application_type
					});
				}
				if (self.selectedEmailData)
					for (let i = 0; i < self.selectedEmailData.length; i++) {
						tempEmail.push(self.selectedEmailData[i].label);
					}

				let tempData = {
					"details": {
						"user_id": (self.userType == true) ? self.empId : self.empDetails.id,
						"leave_type_id": self.leaveTypeValue,
						"notified_peoples": (tempEmail.length) ? tempEmail.toString() : '',
						"reason_for_leave": self.reason.trim(),
						"requested_by": self.empId
					},
					"dateDetails": tempDetails,
					"file_details": self.fileData
				}
				self.lazyLoad = true;
				self.dataService.addLeaveRequest(tempData, self.editStatus, self.empId, self.editId, res => {
					if (res.message == "No data found" || res.status == "Failed") {
						self.lazyLoad = false;
						let temp = "";
						if (typeof res.message == 'object') {
							for (var i = 0; i < res.message.length; i++) {
								temp = temp + res.message[i].message;
								temp = temp + ",";
							}
							self.notifications.alertBoxValue("error", temp);
						}
						else {
							self.notifications.alertBoxValue("error", res.message);
						}
					}
					else {
						self.lazyLoad = false;
						self.notifications.alertBoxValue("success", res.message);
						self.fileData = undefined;
						self.reason = "";
						self.tableEdit = [];
						self.dateArray = [];
						self.formerror = false;
						self.listId = self.userData.user_id;
						if (self.empId == self.userData.user_id) {
							if (self.userData.role_id == 2 || self.userData.role_id == 4)
								self.dataService.getLeaveTypes(self.userData.user_id, res => {
									if (res.message == "No data found") {
										self.loaderService.display(false);
										self.lopListCount = undefined;
										self.dispListLeave = [];
									}
									else {
										self.dispListLeave = res.data;
										self.lopListCount = res.lopCount;

										if (self.userList)
											for (var i = 0; i < self.userList.length; i++) {
												if (self.userData.user_id == self.userList[i].id) {
													self.selectedItems = [i];
													break;
												}
											}
									}
									self.editStatus = false;
									self.displayAdd = false;
									self.userType = true;
									self.empIdSearch = '';
									self.empList = [];
									self.selectedEmailData = undefined;
									self.selectedEmail = [];
								});
							else {
								self.editStatus = false;
								self.displayAdd = false;
								self.userType = true;
								self.empIdSearch = '';
								self.empList = [];
								self.selectedEmailData = undefined;
								self.selectedEmail = [];
								self.getData(self.currentPage);

							}
						}
						else {
							self.editStatus = false;
							self.displayAdd = false;
						}
					}
				})
			});
		}
	}

	/*
	*  @desc   :method to update list by api call
		*  @author :dipin
	*/
	getLeaveTypes() {
		this.lazyLoad = true;
		this.dataService.getLeaveTypes((this.userType == true) ? this.selectedId : this.empDetails.id, res => {
			if (res.message == "No data found") {
				this.leaveList = [];
				this.dispLeave = [];
				this.lopCount = undefined;
				this.lazyLoad = false;
			}
			else {
				let temp = res.data;
				// this.payExtraPeriod = undefined;
				this.payPeriod = res.payPeriodDay;
				this.payExtraPeriod = (res.payPeriodExtendDays != null) ?  Number(res.payPeriodExtendDays) : undefined;
				this.lopCount = res.lopCount;
				this.dispLeave = temp;
				if (temp)
					for (var i = 0; i < temp.length; i++) {
						if (temp[i].leaveBalance <= 0 && temp[i].allow_beyond_limit != "1" && temp[i].leave_balance_calculate_on == "Date of request") {
							temp.splice(i, 1);
						}
					}
				this.leaveList = temp;
				this.lazyLoad = false;
			}
		})
	}

	/*
	*  @desc   : method deal with conversion of date format
	*  @author : dipin
	*/
	formatDateForPicker(inputDate) {
		var date = this.timeZone.toLocal(inputDate);
		if (!isNaN(date.getTime())) {
			return date.getDate() + '-' + (Number(date.getMonth()) + 1) + '-' + date.getFullYear();
		}
	}

	/*
	*  @desc   : get details for edit-form
	*  @author : dipin
	*/
	viewAdd() {
		this.dateArray = [];
		this.displayAdd = !this.displayAdd;
		this.empEditId = "";
		this.empIdSearch = this.empEditId;
		this.editStatus = false;
		if (this.cookieService.get("user-data")) {
			this.userData = JSON.parse(this.cookieService.get("user-data"));
			if (this.userData.role_id == 1 || this.userData.role_id == 3) {
				this.empId = this.userData.user_id;
				this.selectedId = this.userData.user_id;
				this.empEditId = this.userData.first_name + ' ' + this.userData.last_name + ' (' + this.userData.employee_id + ')';
				this.empIdSearch = this.empEditId;
			}
			else if (this.userData.role_id == 2 || this.userData.role_id == 4) {
				this.empId = this.userData.user_id;
				this.selectedId = this.userData.user_id;
				this.empEditId = this.userData.first_name + ' ' + this.userData.last_name + ' (' + this.userData.employee_id + ')';
				this.empIdSearch = this.empEditId;
			}
		}
		if (this.displayAdd) {
			this.dateArray = [{
				"change_end_date": true,
				"start_date": null,
				"end_date": null,
				"application_type": 0,
				"type": null,
				"start_date_status": false,
				"end_date_status": false,
				"start_invalid": false,
				"end_invalid": false,
				"prior_stat_start": false,
				"prior_stat_end": false,
				"count": 0,
				"submitted": false
			}];
			this.leaveDaySelected = [];
			this.leaveDaySelected.push([0]);
			this.getLeaveTypes();
			if (!this.emailData)
				this.dataService.emailListing(response => {
					if (response.status == "OK") {
						if (response.data) {
							this.emailData = response.data;
							for (let i = 0; i < this.emailData.length; i++) {
								if (this.emailData[i].email.trim() == "" || this.emailData[i].email == this.userData.rm_email || this.emailData[i].email == this.userData.email) {
									this.emailData.splice(i, 1);
								}
							}
						}
					}
				})
		}
	}

	/*
	*  @desc   : make date to the format 'dd-mm-yyyy'
	*  @author : dipin
	*/
	formatForApi(inputDate) {
		var date = this.timeZone.toLocal(inputDate);
		if(date)
		if (!isNaN(date.getTime())) {
			if ((Number(date.getMonth()) + 1) < 10) {
				if (Number(date.getDate() < 10)) {
					return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
				}
				else {
					return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
				}
			}
			else {
				if (Number(date.getDate() < 10)) {
					return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
				}
				else {
					return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
				}
			}
		}
	  else
	  	return undefined;
	}

	/*
	*  @desc   : calculate number of day in date range
	*  @author : dipin
	*/
	getDates(startDate, endDate) {
		var dates = [],
			currentDate = startDate,
			addDays = function(days) {
				var date = this.timeZone.toLocal(this.valueOf());
				date.setDate(date.getDate() + days);
				return date;
			};
		while (currentDate <= endDate) {
			dates.push(this.formatForApi(currentDate));
			currentDate = addDays.call(currentDate, 1);
		}
		return dates;
	}

	/*
*  @desc   : method deal with conversion of date format
*  @author : dipin
*/
	formatDate(inputDate) {
		var date = this.timeZone.toLocal(inputDate);
		if (!isNaN(date.getTime())) {
			if ((Number(date.getMonth()) + 1) < 10) {
				if (Number(date.getDate() < 10)) {
					return "0" + date.getDate() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
				}
				else {
					return date.getDate() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
				}
			}
			else {
				if (Number(date.getDate() < 10)) {
					return date.getDate() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
				}
				else {
					return date.getDate() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
				}
			}
		}
	}

	/*
	*  @desc   :method to prevent spce from specified textbox
	*  @author :dipin
	*/
	checkSpace(event, value) {
		if (event.keyCode == 32 && value == "") {
			event.preventDefault();
		}
	}

	/*
	 *  @desc   :method to update list by api call
		 *  @author :dipin
	*/
	changeListener($event): void {
		this.readThis($event.target);
	}

	/*
	*  @desc   :method to check file input
	*  @author :dipin
	*/
	readThis(inputValue: any): void {
		let self = this;
		let fileSize: number = 0;
		let prevFileData;
		if (inputValue) {
			if (this.fileData)
				for (let i = 0; i < this.fileData.length; i++) {
					fileSize = fileSize + Number(this.fileData[i].file_size);
				}

			for (let i = 0; i < inputValue.files.length; i++) {
				fileSize = fileSize + Number(inputValue.files[i].size);
			}
			if ((inputValue.files.length <= 5) && (!this.fileData || (this.fileData && (this.fileData.length + inputValue.files.length) <= 5)) && (Number(fileSize) <= 4194304)) {
				if (!this.fileData) {
					this.fileData = [];
					prevFileData = 0;
				}
				else {
					prevFileData = this.fileData.length;
				}
				let maxCount = Number(inputValue.files.length + this.fileData.length);
				let startCount = Number(this.fileData.length);

				for (let i = startCount; i < maxCount; i++) {
					var file: File;
					file = inputValue.files[i - prevFileData];
					if (file != undefined) {
						self.fileData.push({});
						self.fileData[i] = { fileName: "", type: "", file_data: "", file_size: "" };
						self.fileData[i].type = inputValue.files[i - prevFileData].name.split('.').pop();
						self.fileData[i].fileName = file.name;
						self.fileData[i].file_size = file.size;
						self.uploadProcess(file, i);
					}
					else {
						self.fileData[i] = undefined;
						self.fileName[i] = "";
					}
				}
			}
			else {
				if (Number(fileSize) > 4194304) {
					this.notifications.alertBoxValue("error", "You Can Only Upload A Maximum Of Size 4 MB");
				}
				else
					this.notifications.alertBoxValue("error", "You Can Only Upload A Maximum Of 5 Files");
			}
		}
		else {
			self.fileData = undefined;
			self.fileName = undefined;
		}
	}

    /*
	*  @desc   :method to initiate upload process
	*  @author :dipin
	*/
	uploadProcess(file, i) {
		let self = this;
		let reader = new FileReader();
		reader.readAsDataURL(file);
		reader.onload = () => {
			self.fileData[i].file_data = reader.result;
		};
	}

    /*
	*  @desc   :delete files from the upload list
	*  @author :dipin
	*/
	deleteFile(value) {
		this.fileData.splice(value, 1);
		if (this.fileData.length == 0) {
			this.fileData = undefined;
		}
	}

	/*
	*  @desc   :method to back to stable form
	*  @author :dipin
	*/
	setDefault() {
		this.dateArray = [];
		this.empDetails = {
			id: "",
			name: this.userData.first_name + ' ' + this.userData.last_name,
			code: this.userData.employee_id
		};
		this.empIdSearch = '';
		this.confirmBox = false;
		this.leaveSelected = [];
		this.leaveDaySelected = [];
		this.leaveDaySelected.push([0]);
		this.config = "Are You Sure You Want To Cancel?";
		this.dateArray.push({
			"change_end_date": true,
			"start_date": null,
			"end_date": null,
			"application_type": 0,
			"type": null,
			"start_date_status": false,
			"start_invalid": false,
			"end_invalid": false,
			"end_date_status": false,
			"prior_stat_start": false,
			"prior_stat_end": false,
			"count": 0,
			"submitted": false
		});
	}

	/*
	*  @desc   :method to update list by api call
	*  @author :dipin
   */
	downloadFile(selected) {
		if (this.editStatus) {
			this.loaderService.display(true);
			this.dataService.attachemntDownload(this.fileData[selected].file_id, this.editId, res => {
				if (res.status != "success") {
					this.loaderService.display(false);
				}
				else {
					let binary_string: any = window.atob(res.data);
					let types;
					if (this.fileData[selected].type == "png" || this.fileData[selected].type == "jpg" || this.fileData[selected].type == "jpeg") {
						types = 'image/png';
					}
					else if (this.fileData[selected].type == "pdf") {
						types = 'application/pdf';
					}
					else {
						types = "application/octet-stream";
					}
					let len: any = binary_string.length;
					let bytes: any = new Uint8Array(len);
					for (var i = 0; i < len; i++) {
						bytes[i] = binary_string.charCodeAt(i);
					}
					let file: any = new Blob([bytes.buffer], { type: types });
					FileSaver.saveAs(file, this.fileData[selected].fileName);
					this.loaderService.display(false);
				}
			})
		}
	}

	/*
	*  @desc   :select employee name from dropdown listed only for admin
	*  @author :dipin
	*/
	userSelected(event) {
		if (event.selected)
			if (event.selected[0]) {
				this.loaderService.display(true);
				this.currentPage = 1;
				this.listId = event.selected[0].id;
				if (this.listId != "All")
					this.dataService.getLeaveTypes(event.selected[0].id, res => {
						if (res.message == "No data found") {
							this.loaderService.display(false);
							this.lopListCount = undefined;
							this.dispListLeave = [];
							this.tableData = [];
						}
						else {
							this.dispListLeave = res.data;
							this.lopListCount = res.lopCount;
							 this.getData(this.currentPage);
						}
					})
				else {
					this.getData(this.currentPage);
				this.lopListCount = undefined;
				this.dispListLeave = [];
				}
			}
			else {
				this.listId = undefined;
				this.lopListCount = undefined;
				this.dispListLeave = [];
				this.tableData = [];
			}
	}

	/*
   *  @desc   :download attachment form leave list
   *  @author :dipin
   */
	attachmentDownloadCommon(id, leaveId, i, j, value) {
		var tempI = i;
		var tempJ = j;
		this.loaderService.display(true);
		this.dataService.attachemntDownload(id, leaveId, res => {
			if (res.status != "success") {
				this.loaderService.display(false);
			}
			else {
				let binary_string: any = window.atob(res.data);
				let types;
				if (value == false)
					if (this.tableData[tempI].file_details[tempJ].file_type == "png" || this.tableData[tempI].file_details[tempJ].file_type == "jpg" || this.tableData[tempI].file_details[tempJ].file_type == "jpeg") {
						types = 'image/png';
					}
					else if (this.tableData[tempI].file_details[tempJ].file_type == "pdf") {
						types = 'application/pdf';
					}
					else {
						types = "application/octet-stream";
					}
				else {
					types = "application/zip";
				}
				let len: any = binary_string.length;
				let bytes: any = new Uint8Array(len);
				for (var i = 0; i < len; i++) {
					bytes[i] = binary_string.charCodeAt(i);
				}
				let file: any = new Blob([bytes.buffer], { type: types });
				if (value == false)
					FileSaver.saveAs(file, this.tableData[tempI].file_details[tempJ].file_name);
				else
					FileSaver.saveAs(file, "document " + this.timeZone.getCurrentDate().toDateString());
				this.loaderService.display(false);
			}
		})
	}

	/*
 *  @desc   :show previous messages using api call
 *  @author :dipin
 */
	showMessage(index, id) {
		for (let i = 0; i < this.tableData.length; i++) {
			if (index == i) {
				this.tableData[i].messageStatus = !this.tableData[i].messageStatus;
				if (this.tableData[i].messageStatus) {
					this.messageData = [];
					this.responceLoad = true;
					this.tableData[index].chatLoad = true;
					this.dataService.showMessage(id, res => {
						if (res.status == "OK") {
							let self = this;
							this.messageData = res.data;
							for (var i = 0; i < this.messageData.length; i++) {
								let diff = Math.abs((moment.utc(this.messageData[i].send_time).toDate().getTime() - moment.utc().toDate().getTime()) / 1000);
			                    diff = Math.abs(diff);
								if (Number(diff) >= 300) {
									this.messageData[i].deleteIcon = false;
								}
								else {
									this.messageData[i].deleteIcon = true;
								}
							}
							this.tableData[index].chatLoad = false;
							this.responceLoad = false;
							setTimeout(function() {
								$("#top-chat").mCustomScrollbar("scrollTo", "bottom");
								if (document.getElementById("chatBox")) {
									if (self.selectedChat == id) {
              						   document.getElementById("chatBox").innerHTML = self.chatMessage;
									}
									else {
										self.selectedChat = id;
										self.chatMessage = '';
									}
                                   document.getElementById("chatBox").focus();
								}
							});
						}
						else {
							this.tableData[index].chatLoad = false;
							this.responceLoad = false;
						}
					})
				}
			}
			else {
				this.tableData[i].messageStatus = false;
			}
		}
	}

	/*
	*  @desc   :method send messages to the server with sender's id
	*  @author :dipin
	*/
	sendMessage(index, id) {
		if (this.chatMessage != '' && this.chatMessage.trim() != '') {
			this.entryBlock = true;
			let obj = {
				"user_id": this.userData.user_id,
				"leave_id": id,
				"message": this.chatMessage.trim()
			};
			document.getElementById("chatBox").innerHTML = '';
			setTimeout(function() {
				document.getElementById("chatBox").focus();
			});
			this.messageData.push({
				'id': '',
				"first_name": this.userData.first_name,
				"last_name": this.userData.last_name,
				"message": this.chatMessage.trim(),
				"photo": this.userData.photo,
				"send_time": moment.utc().toDate().getTime(),
				"user_id": this.userData.user_id,
				'status' : 1
			});
			this.chatMessage = '';
			this.messageData[this.messageData.length - 1].sent = true;
			setTimeout(function() {
				$("#top-chat").mCustomScrollbar("scrollTo", "bottom");
			});
			this.dataService.addMessage(obj, res => {
				if (res.status == "Success") {
					this.messageData[this.messageData.length - 1].sent = false;
					this.messageData[this.messageData.length - 1].id = res.id;
					this.messageData[this.messageData.length - 1].deleteIcon = true;
					this.entryBlock = false;
				}
				else {
					this.notifications.alertBoxValue("error", res.message);
					this.entryBlock = false;
					this.messageData.pop();
					this.messageData[this.messageData.length - 1].sent = false;
					this.messageData[this.messageData.length - 1].deleteIcon = false;
				}
			})
		}
	}

    /*
	*  @desc   :method to close all the popup of chat message while hovet on messages
	*  @author :dipin
	*/
	closeAllPopup() {
		for (let i = 0; i < this.tableData.length; i++) {
			this.tableData[i].messageStatus = false;
		}
		this.chatConfirm = false;
	}

	exportLeaveBalance() {
		this.loaderService.display(true);
		this.dataService.exportLeaveBalance(this.listId, res => {
			if (res && res.data) {
				let binary_string: any = window.atob(res.data);
				let len: any = binary_string.length;
				let bytes: any = new Uint8Array(len);
				for (var i = 0; i < len; i++) {
					bytes[i] = binary_string.charCodeAt(i);
				}

				let file: any = new Blob([bytes.buffer], { type: "application/vnd.ms-excel" });
				let filename: any = 'Leave Balance Report ' + this.timeZone.getCurrentDate().toDateString() + '.xlsx';
				FileSaver.saveAs(file, filename);
				this.loaderService.display(false);
			}
			else {
				this.notifications.alertBoxValue("error", res.message);
				this.loaderService.display(false);
			}
		})
	}

	/*
  *  @desc   :method to display selected type of list
  *  @author :dipin
  */
	deleteMessage() {
		this.messageData[this.selectChat].sent = true;
		this.dataService.deleteChat(this.userData.user_id, this.messageData[this.selectChat].id, res => {
			if (res.status == "Success") {
				for (let i = 0; i < this.messageData.length; i++) {
					if (this.messageData[i].id == res.message_id) {
						this.messageData[i].sent = false;
						this.messageData[i].delete = true;
					}
				}
			}
			else {
				this.notifications.alertBoxValue("error", res.message);
				this.messageData[this.selectChat].sent = false;
				this.messageData[this.selectChat].delete = false;
			}
		})
	}

	/*
	*  @desc   :method to display selected type of list
	*  @author :dipin
	*/
	formatDateForChat(date) {
		var strTime = date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds();
		return date.getFullYear() + "-" + Number(date.getMonth() + 1) + "-" + date.getDate() + "  " + strTime;
	}

	setMessageIcon() {
		if (this.messageData)
			if (this.messageData.length) {
				for (var i = 0; i < this.messageData.length; i++) {
					let diff = Math.abs((moment.utc(this.messageData[i].send_time).toDate().getTime() - moment.utc().toDate().getTime()) / 1000);
			            diff = Math.abs(diff);
					if (Number(diff) >= 300) {
						this.messageData[i].deleteIcon = false;
					}
					else {
						this.messageData[i].deleteIcon = true;
					}
				}
			}
	}

	/*
   *  @desc   :method for pagination
   *  @author :dipin
   */
	getpage(event) {
		if (event > 10 || this.recordsPerPage != 10) {
			this.recordsPerPage = event;
			this.currentPage = 1;
			this.getData(this.currentPage);
		}
	}
}
