import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExceptionalCalenderComponent } from './exceptional-calender.component';

describe('ExceptionalCalenderComponent', () => {
  let component: ExceptionalCalenderComponent;
  let fixture: ComponentFixture<ExceptionalCalenderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExceptionalCalenderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExceptionalCalenderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
