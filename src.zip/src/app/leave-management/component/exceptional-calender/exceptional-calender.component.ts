import { Component, OnInit } from '@angular/core';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'

import { ExceptionalDetailsService } from '../../services/exceptional-details.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

@Component({
  selector: 'app-exceptional-calender',
  templateUrl: './exceptional-calender.component.html',
  styleUrls: ['./exceptional-calender.component.css']
})
export class ExceptionalCalenderComponent implements OnInit {

    tableData     : any = [];
	editConfig    : any;
	config        : any;
	sort          : any;
	addStatus     : boolean = false;
	editStatus    : boolean = false;
	checkAll      : boolean = false;
	forDay        : boolean = false;
	forWorkDay    : boolean = false;
	multiDelete   : boolean = false;
	forEtitle     : boolean = false;
	filterStatus  : boolean = false;
	confirmBox    : boolean;
	totalSelected :     any = 0;
	currentPage   : number  = 1;
    recordsPerPage: number  = 10;
    totalRecords  : number;
    setIndex      : any;
    advanceFilterData : any;
    setStack      : any;

	constructor(private apiService    : ExceptionalDetailsService,
		        private notifications : NotificationService,
		        private loaderService : LoaderActionsService,
		        private timeZone      : TimezoneDetailsService) { }

	ngOnInit() {
		this.confirmBox  = false;
		this.config = "Are You Sure You Want To Delete?";
		if (localStorage.getItem("itemsperpage")) {
			this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			this.recordsPerPage = 10;
		}
		this.getData(this.currentPage);
	}

    /*
	*  @desc   :method to update list by api call
  	*  @author :dipin
	*/
	getData(page){
	this.loaderService.display(true);
	  this.currentPage = page;
      this.apiService.getCalanderDetails(this.currentPage,this.recordsPerPage,this.sort,this.advanceFilterData,response => {
			if (response.status == "OK") {
				if(response.data){
                 this.tableData = response.data;
                 for(var i = 0 ; i < this.tableData.length;i++){
                   this.tableData[i].vStatus = false;
                   this.tableData[i].listAppl = [];
                 }
                 for (var i = 0; i < this.tableData.length; i++) {
							for (var j = 0; j < this.tableData[i].applicable_for.length; j++) {
								for (var k = 0; k < this.tableData[i].applicable_for[j].list.length; k++) {
									if(this.tableData[i].applicable_for[j].list[k] != "")
										this.tableData[i].listAppl.push(this.tableData[i].applicable_for[j].list[k]);
								}
							}
						}
                 this.loaderService.display(false);
				}
				else{
				  this.tableData = [];
				  this.loaderService.display(false);
				}

				this.totalRecords = response.count;
				for (var i = 0; i < this.tableData.length; i++) {
					this.tableData[i].checked = false;
				}
				this.checkSelected();
			}
			else {
				this.tableData = [];
			}
		})
	}

	setFalse(index){
     for(var i = 0 ; i < this.tableData.length;i++){
           if(index == i ){
             this.tableData[i].vStatus = !this.tableData[i].vStatus;
           }
           else
            this.tableData[i].vStatus = false;
      }
	}

    /*
	*  @desc   :toogle display of popup based on the add button click
  	*  @author :dipin
	*/
	setAdd() {
	  this.addStatus  = !this.addStatus;
	  this.editStatus = false;
	}

	 /*
	*  @desc   :show or hide edit-form for selected index
  	*  @author :dipin
	*/
	showEdit(index){
      this.addStatus  = true;
      this.editStatus = true;
      this.editConfig = this.tableData[index];
	}

     /*
	*  @desc   :select all the rows listed in the table
  	*  @author :dipin
	*/
	selectAll(value){
		for(var i = 0 ; i < this.tableData.length;i++){
			this.tableData[i].checked = value;
		}
		this.checkSelected();
	}

     /*
	*  @desc   :select row using the index of the table
  	*  @author :dipin
	*/
	selectTableValue(index){
	   this.tableData[index].checked = !this.tableData[index].checked;
	   this.checkSelected();
	}

     /*
	*  @desc   :method for apply sorting using api and update the table list
  	*  @author :dipin
	*/
	applySort(value){
		this.loaderService.display(true);
		let type = 0;
		if (value == 'ed')
			if (this.forDay == true) {
				type = 1;
				this.forDay = false;
			}
			else {
				type = 0;
				this.forDay = true;
			}

		if (value == 'cd')
			if (this.forWorkDay == true) {
				type = 1;
				this.forWorkDay = false;
			}
			else {
				type = 0;
				this.forWorkDay = true;
			}

        if (value == 'title')
			if (this.forEtitle == true) {
				type = 1;
				this.forEtitle = false;
			}
			else {
				type = 0;
				this.forEtitle = true;
			}
      this.sort  = {department : value,type:type};
	  this.apiService.sortCalenderDetails({department : value,type:type},this.currentPage,this.advanceFilterData,response=>{
                  if(response.status == "OK"){
                    this.tableData = response.data;
                    for (var i = 0; i < this.tableData.length; i++) {
						this.tableData[i].vStatus = false;
						this.tableData[i].listAppl = [];
					}
						for (var i = 0; i < this.tableData.length; i++) {
							for (var j = 0; j < this.tableData[i].applicable_for.length; j++) {
								for (var k = 0; k < this.tableData[i].applicable_for[j].list.length; k++) {
									if(this.tableData[i].applicable_for[j].list[k] != "")
										this.tableData[i].listAppl.push(this.tableData[i].applicable_for[j].list[k]);
								}
							}
						}
                    this.loaderService.display(false);
                  }
                  else{
                  	this.notifications.alertBoxValue("error", response.message);
                    this.tableData = [];
                    this.loaderService.display(false);
                  }
          })
	}

     /*
	*  @desc   :method to check all the rows in the list are selected or not
  	*  @author :dipin
	*/
	checkSelected(){
	let selected = 0;
      for(var j = 0 ; j < this.tableData.length;j++){
          if(this.tableData[j].checked){
          	this.checkAll = true;
          }
          else{
          	this.checkAll = false;
          	break;
          }
	   }
	   for(var j = 0 ; j < this.tableData.length;j++){
          if(this.tableData[j].checked){
          	selected = selected + 1;
          }
	   }
	   this.totalSelected = selected;
	}

	/*
    author : dipin
    desc   : send Filter Data
    params :
    */
	filterData(event) {
	  if (event || this.advanceFilterData) {
		this.advanceFilterData = event;
		this.currentPage = 1;
		this.getData(this.currentPage);
	  }
	  else{
	  	this.advanceFilterData = undefined;
	  }
	}

	 /*
	*  @desc   :method to delete element from the list
  	*  @author :dipin
	*/
	deleteSelected(index){
		this.loaderService.display(true);
		this.apiService.deleteCalenderDetails(this.tableData[index].id,response=>{
                  if(response.status == "OK"){
                  	this.currentPage = 1;
                    this.getData(this.currentPage);
                    this.loaderService.display(false);
                   this.notifications.alertBoxValue("success", "Exceptional Working Day Deleted Successfully");
                  }
                  else{
                  	this.loaderService.display(false);
                    this.notifications.alertBoxValue("error", response.message);
                  }
          })
	}

	 /*
	*  @desc   :method to delete multipile selected element from the list
  	*  @author :dipin
	*/
	deleteMultiSelected() {
		this.loaderService.display(true);
		let temp = [];
		for (var i = 0; i < this.tableData.length; i++) {
			if (this.tableData[i].checked) {
				temp.push(this.tableData[i].id);
			}
		}
		this.apiService.deleteMultipleCalender({ "id": temp }, response => {
			if (response.status == "OK") {
				this.currentPage = 1;
				this.getData(this.currentPage);
				this.loaderService.display(false);
				this.notifications.alertBoxValue("success", "Exceptional Working Day Deleted Successfully");
			}
			else {
				this.loaderService.display(false);
				this.notifications.alertBoxValue("error", response.message);
			}
		})
	}

    /*
	*  @desc   :method to update list after popup confirmation
  	*  @author :dipin
	*/
	updateList(event){
		if(event){
		 this.getData(this.currentPage);
		}
	}

     /*
	*  @desc   :method to handle popup confirmation
  	*  @author :dipin
	*/
	getPopupConfirm(event){
		this.confirmBox = false;
		if(event == true){
		  if(this.multiDelete == true)
            this.deleteMultiSelected();
          else
          	this.deleteSelected(this.setIndex);
		}
	}

  /*
  *  @desc   :method for pagination
  *  @author :dipin
  */
	getpage(event) {
		if (event > 10 || this.recordsPerPage != 10) {
			this.recordsPerPage = event;
			this.currentPage = 1;
			this.getData(this.currentPage);
		}
	}
}
