import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

import { CalenderSettingsService } from '../../services/calender-settings.service';
import { CalenderListService } from '../../services/calender-list.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

@Component({
  selector: 'hris-calender-list',
  templateUrl: './calender-list.component.html',
  styleUrls: ['./calender-list.component.css']
})
export class CalenderListComponent implements OnInit {
    tableData      : any = [];
	editConfig     : any;
	config         : any;
	sort           : any;
	advanceFilterData : any;
	filterStatus   : boolean = false;
	addStatus      : boolean = false;
	editStatus     : boolean = false;
	checkAll       : boolean = false;
	multiDelete    : boolean = false;
	forWeek        : boolean = false;
	confirmBox     : boolean;
	currentPage    : number  = 1;
    recordsPerPage : number  = 10;
    totalRecords   : number;
	totalSelected  : any = 0;
	setIndex       : any;
    setStack       : any;

	constructor(private apiService    : CalenderListService,
		        private router        : Router,
		        private setApi        : CalenderSettingsService,
		        private notifications : NotificationService,
		        private loaderService : LoaderActionsService,
		        private timezone       : TimezoneDetailsService) { }

	ngOnInit() {
		this.loaderService.display(false);
		this.confirmBox  = false;
		this.config = "Are You Sure You Want To Delete?";
		if (localStorage.getItem("itemsperpage")) {
			this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			this.recordsPerPage = 10;
		}
		this.getData(this.currentPage);
	}

    /*
	*  @desc   :method to update list with api call
  	*  @author :dipin
	*/
	getData(page){
		this.currentPage = page;
		this.loaderService.display(true);
		this.apiService.getCalanderDetails(this.currentPage,this.recordsPerPage,this.sort,this.advanceFilterData,response => {
			if (response.status == "OK") {
				if (response.data) {
					this.tableData = response.data;
					for (var i = 0; i < this.tableData.length; i++) {
						this.tableData[i].vStatus = false;
						this.tableData[i].listAppl = [];
					}
						for (var i = 0; i < this.tableData.length; i++) {
							for (var j = 0; j < this.tableData[i].applicable_for.length; j++) {
								for (var k = 0; k < this.tableData[i].applicable_for[j].list.length; k++) {
									if(this.tableData[i].applicable_for[j].list[k] != "")
										this.tableData[i].listAppl.push(this.tableData[i].applicable_for[j].list[k]);
								}
							}
						}
				}

				else
				  this.tableData = [];

				this.totalRecords = response.count;
				for (var i = 0; i < this.tableData.length; i++) {
					this.tableData[i].checked = false;
				}
				this.checkSelected();
				 this.loaderService.display(false);
			}
			else {
				this.tableData = [];
				 this.loaderService.display(false);
			}
		})
	}

	setFalse(index){
     for(var i = 0 ; i < this.tableData.length;i++){
           if(index == i ){
             this.tableData[i].vStatus = !this.tableData[i].vStatus;
           }
           else
            this.tableData[i].vStatus = false;
      }
	}

    /*
	*  @desc   :toogle display of popup based on the add button click
  	*  @author :dipin
	*/
	setAdd(value) {
	  this.addStatus  = !this.addStatus;
	  this.editStatus = false;
	}

	 /*
	*  @desc   :show or hide edit-form for selected index
  	*  @author :dipin
	*/
	showEdit(index) {
		this.setApi.statusService = true;
		this.setApi.selectedService = [];
		this.setApi.selectedService.push(this.tableData[index]);
		this.router.navigate(['/modules/leave/calender-settings']);
	}

     /*
	*  @desc   :select all the rows listed in the table
  	*  @author :dipin
	*/
	selectAll(value){
		for(var i = 0 ; i < this.tableData.length;i++){
			this.tableData[i].checked = value;
		}
		this.checkSelected();
	}

	/*
author : dipin
desc   : send Filter Data
params :
*/
	filterData(event) {
	  if (event || this.advanceFilterData) {
		this.advanceFilterData = event;
		this.currentPage = 1;
		this.getData(this.currentPage);
	  }
	  else{
	  	this.advanceFilterData = undefined;
	  }
	}

     /*
	*  @desc   :select row using the index of the table
  	*  @author :dipin
	*/
	selectTableValue(index){
	   this.tableData[index].checked = !this.tableData[index].checked;
	   this.checkSelected();
	}

     /*
	*  @desc   :method for apply sorting using api and update the table list
  	*  @author :dipin
	*/
	applySort(value){
      let type = 0;
      if(this.forWeek == true){
        type = 1;
        this.forWeek = false;
      }
      else{
        type = 0;
        this.forWeek = true;
      }
      this.sort = {department : value,type:type};
	  this.loaderService.display(true);
	  this.apiService.sortCalenderDetails({department : value,type:type},this.currentPage,this.advanceFilterData,response=>{
                  if(response.status == "OK"){
                    this.tableData = response.data;
                    for (var i = 0; i < this.tableData.length; i++) {
						this.tableData[i].vStatus = false;
						this.tableData[i].listAppl = [];
					}
						for (var i = 0; i < this.tableData.length; i++) {
							for (var j = 0; j < this.tableData[i].applicable_for.length; j++) {
								for (var k = 0; k < this.tableData[i].applicable_for[j].list.length; k++) {
									 if(this.tableData[i].applicable_for[j].list[k] != "")
										this.tableData[i].listAppl.push(this.tableData[i].applicable_for[j].list[k]);
								}
							}
						}
                     this.loaderService.display(false);
                  }
                  else{
                    this.tableData = [];
                     this.loaderService.display(false);
                  }
          })
	}

     /*
	*  @desc   :method to check all the rows in the list are selected or not
  	*  @author :dipin
	*/
	checkSelected(){
	let selected = 0;
      for(var j = 0 ; j < this.tableData.length;j++){
          if(this.tableData[j].checked){
          	this.checkAll = true;
          }
          else{
          	this.checkAll = false;
          	break;
          }
	   }
	   for(var j = 0 ; j < this.tableData.length;j++){
          if(this.tableData[j].checked){
          	selected = selected + 1;
          }
	   }
	   this.totalSelected = selected;
	}

	 /*
	*  @desc   :method to delete element from the list
  	*  @author :dipin
	*/
	deleteSelected(index){
		 this.loaderService.display(true);
		this.apiService.deleteCalenderDetails(this.tableData[index].id,response=>{
                  if(response.status == "OK"){
                  	this.currentPage = 1;
                   this.getData(this.currentPage);
                    this.notifications.alertBoxValue("success", "Calendar Settings Deleted Successfully");
                     this.loaderService.display(false);
                  }
                  else{
                   this.notifications.alertBoxValue("error", response.message);
                    this.loaderService.display(false);
                  }
          })
	}

	 /*
	*  @desc   :method to delete multipile selected element from the list
  	*  @author :dipin
	*/
	deleteMultiSelected() {
		 this.loaderService.display(true);
		let temp = [];
		for (var i = 0; i < this.tableData.length; i++) {
			if (this.tableData[i].checked) {
				temp.push(this.tableData[i].id);
			}
		}
		this.apiService.deleteMultipleCalender({ "id": temp }, response => {
			if (response.status == "OK") {
				this.currentPage = 1;
				this.getData(this.currentPage);
				this.notifications.alertBoxValue("success", "Calendar Settings Deleted Successfully");
				 this.loaderService.display(false);
			}
			else {
				this.notifications.alertBoxValue("error", response.message);
				 this.loaderService.display(false);
			}
		})
	}
     /*
	*  @desc   :method to handle popup confirmation
  	*  @author :dipin
	*/
	getPopupConfirm(event){
		this.confirmBox = false;
		if(event == true){
		  if(this.multiDelete == true)
            this.deleteMultiSelected();
          else
          	this.deleteSelected(this.setIndex);
		}
	}

   /*
  *  @desc   :method for pagination
  *  @author :dipin
  */
	getpage(event) {
		if (event > 10 || this.recordsPerPage != 10) {
			this.recordsPerPage = event;
			this.currentPage = 1;
			this.getData(this.currentPage);
		}
	}

}
