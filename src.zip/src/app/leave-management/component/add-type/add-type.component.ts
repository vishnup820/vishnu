/*
*  @desc   :component for add leave type
*  @author :dipin
*/
import { Component, OnInit,Input,Output,EventEmitter,OnChanges,SimpleChanges } from '@angular/core';
import { FormGroup,FormControl, Validators,FormBuilder } from '@angular/forms';
import { Router  , ActivatedRoute } from '@angular/router';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import {apiList}  from '../../../shared/constants/apilist';
import { LeavetypeDetailsService } from './../../services/leave-type/leavetype-details.service';
import { CookieDataService } from 'src/app/shared/services/cookie-data/cookie-data.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-add-type',
  templateUrl: './add-type.component.html',
  styleUrls: ['../../../../assets/content/css/add-leave.css']
})
export class AddTypeComponent implements OnInit {
  periodList      : any = [];
  clubbList       : any = [];
  roundList       : any = [];
  balanceList     : any = [];
  statusList      : any = [];
  activeList      : any = [];
  onList          : any = [];
  periodSelected  : any;
  documentDays    : any;
  selectedPeriodValue : any;
  activeObject    : any;
  roundMulti      : any;
  uCurrent        : any;
  onSelected      : any;
  roundSelected   : any;
  clubSelected    : any;
  balanceSelected : any;
  statusSelected  : any = [];
  leaveSubmitted  : any;
  leaveBalanceValue : any ="";
  includeHoliday  : boolean = false;
  documentStatus  : boolean = false;
  maximumNumber   : any;
  submitted       : boolean = false;
  setApplicable   : boolean = false;
  includeWeekend  : boolean = false;
  sayClose        : boolean = false;
  excludeHolidays : any;
  newJoineeLeave  : any;
  newJoineeAfter  : any;
  rollOverCount   : any;
  yearSelected    : any = [];
  monthSelected   : any = [];
  leaveCountSelect: any = [];
  clubData        : any = [];
  activeSelected  : any = [0];
  leaveAppSelect  : any;
  selectedData    : any;
  carryMax        : any;
  startDate       : any;
  endDate         : any;
  maximumDays     : any;
  allEmployeeData : any;
  selectedId      : any;
  dataArray  : any = [];
  predefinedId   : any     = [];

  excludeStatus      : boolean = false;
  countSelected      : boolean = false;
  leaveSubmittedStat : boolean = false;
  maximumNumberStat  : boolean = false;
  halfdayStatus      : boolean = false;
  clubbingStat       : boolean = false;
  allowBeyondLimit   : boolean = false;
  markBeyondLimit    : boolean = false;
  enableRollOver     : boolean = false;
  enableRoundOff     : boolean = true;
  forExpStatus       : boolean = false;
  forAllEmStatus     : boolean = true;
  statusService      : boolean = false;
  minDate            : any;
  maxDate            : any;
  userData           : any

  addForm     : FormGroup;
  codeField   : FormControl;
  titleField  : FormControl;
  periodField : FormControl;
  onField     : FormControl;
  constructor(private routeStatus : Router,private route : ActivatedRoute,
    private apiService     : LeavetypeDetailsService,
    private notifications  : NotificationService,
    private loaderService  : LoaderActionsService,
    private timezone       : TimezoneDetailsService,
    private cookieService  : CookieService) { }

  ngOnInit() {
    if (this.route.snapshot.params['id']) {
      this.statusService = true;
      this.selectedId = this.route.snapshot.params['id'];
    }
    else {
      this.statusService = false; this.selectedId = null;
    }
    if (this.cookieService.get("user-data")) {
      this.userData = JSON.parse(this.cookieService.get("user-data"));

      this.minDate = this.timezone.toLocal(this.userData.start_date);
      this.maxDate = this.timezone.toLocal(this.userData.end_date);
    }
    this.createFormControls();
    this.createForm();
    this.apiService.getCalanderDetails(0, 0, null, null, null, response => {
      if (response.status == "OK") {
        if (response.data) {
          if(this.statusService == false){
            for (var i = 0; i < response.data.length; i++) {
              this.clubbList.push({ "id": response.data[i].id, "name": response.data[i].name });
            }
          }
          else {
            for (var i = 0; i < response.data.length; i++) {
              if(this.selectedId != response.data[i].id)
              this.clubbList.push({ "id": response.data[i].id, "name": response.data[i].name });
            }
          }
        }
        this.getData();
      }
      else {
        this.notifications.alertBoxValue("error", response.message);
      }
    })

    this.uCurrent = apiList.leaveManagement.leaveType + "/";
    this.roundList = [{ meta_key: "L", meta_value: "Lowest" }, { meta_key: "N", meta_value: "Nearest" }];
    this.statusList = [[{ meta_value: "For new joinee" }, { meta_value: "After" }]];
    this.activeList = [{ meta_key: 1, meta_value: "Active" }, { meta_key: 2, meta_value: "Inactive" }];
    this.dataArray.push({
      "experience_term": "For new joinee",
      "year": "",
      "month": "",
      "leave_count": "",
      "submitted":false
    });
    this.statusSelected.push([0]);
    this.predefinedId = [{
      id: 1, name: "location"
    },
    { id: 2, name: "user" },
    { id: 3, name: "group" },
    { id: 4, name: "department" },
    { id: 5, name: "designation" }
    ]

  }

  /*
  *  @desc   :method to update list with api call
    *  @author :dipin
  */
  getData() {
    this.loaderService.display(true);
    this.apiService.getAddLeaveData(response => {
      if (response.status == "OK") {
        if (response.data) {
          this.periodList = [];
          this.onList = [];
          this.balanceList = [];

          for (var i = 0; i < response.data.length; i++) {
            if (response.data[i].meta_key == "entitlement_period")
              this.periodList.push(response.data[i]);
            if (response.data[i].meta_key == "entitlement_on")
              this.onList.push(response.data[i]);
            if (response.data[i].meta_key == "leave_balance_calculate_on")
              this.balanceList.push(response.data[i]);
          }
          for(let m= 0;m<this.balanceList.length;m++){
            this.balanceSelected = this.matchingIndex( this.balanceList,'Start date of application', "meta_value");
          }

          if (this.statusService) {
            this.apiService.getEditData(this.selectedId, response => {
              if (response.status == "OK") {
                let tempBasic = response.data.basic_info;
                let tempClub = response.data.clubbingLeaves;
                let tempEntitlement = response.data.entitlementDetail;

                this.addForm.patchValue({
                  codeField: tempBasic.code,
                  titleField: tempBasic.name,
                });

                if (tempBasic.entitlement_for == 'E') {
                  this.forExpStatus = true;
                  this.forAllEmStatus = false;
                  this.dataArray = tempEntitlement;
                  for (var i = 0; i < this.dataArray.length; i++) {
                    if (this.dataArray[i].experience_term == "For new joinee") {
                      this.statusList[i] = [{ meta_value: "For new joinee" },
                                  { meta_value: "After" }];
                      this.statusSelected[i] = [0];
                    }
                    else {
                      this.statusList[i] = [{ meta_value: "After" }]
                      this.statusSelected[i] = [0];
                    }
                  }
                    }
                else {
                  this.forExpStatus = false;
                  this.forAllEmStatus = true;

                  if(tempEntitlement.length > 0)
                   this.allEmployeeData = tempEntitlement[0].leave_count;
                  else{
                   this.allEmployeeData = "";
                  }
                }
                 this.clubSelected = [];
                for (var i = 0; i < tempClub.length; i++) {
                  for (var j = 0; j < this.clubbList.length; j++) {
                    if (tempClub[i].club_leave_type_id == this.clubbList[j].id) {
                      this.clubSelected.push(j);
                    }
                  }
                }
                 this.roundSelected = [];
                          if (tempBasic.round_off == "L") {
                            this.roundSelected = [0];
                          }
                          else if(tempBasic.round_off == "N"){
                            this.roundSelected = [1];
                          }
                this.enableRoundOff = (tempBasic.round_off == "N" || tempBasic.round_off == "L")?true:false;
                this.includeHoliday = (tempBasic.include_holidays == 1) ? true : false;
                this.includeWeekend = (tempBasic.include_weekends == 1) ? true : false;
                this.activeSelected = (tempBasic.status == "1") ? [0] : [1];
                this.excludeStatus = (tempBasic.override_days_request == "" || tempBasic.override_days_request == null) ? false : true;
                this.excludeHolidays = (this.excludeStatus == true) ? tempBasic.override_days_request : "";
                this.allowBeyondLimit = (tempBasic.allow_beyond_limit == "1") ? true : false;
                this.markBeyondLimit = (tempBasic.beyond_limit_unpaid == "1") ? true : false;
                this.startDate = (tempBasic.expiry_start_date)?this.formatDateForPicker(tempBasic.expiry_start_date):undefined;
                this.endDate = (tempBasic.expiry_end_date)?this.formatDateForPicker(tempBasic.expiry_end_date):undefined;
                this.halfdayStatus = (tempBasic.halfday_provision == 1) ? true : false;
                this.maximumNumberStat = (tempBasic.max_consecutive_leaves == "" || tempBasic.max_consecutive_leaves == null) ? false : true;
                this.maximumDays = (this.maximumNumberStat == true) ? tempBasic.max_consecutive_leaves : "";
                this.newJoineeAfter = tempBasic.restrict_leave_balance_on;
                this.newJoineeLeave = tempBasic.restrict_leave_count;
                this.leaveSubmittedStat = (tempBasic.prior_request_days == "" || tempBasic.prior_request_days == null) ? false : true;
                this.leaveAppSelect = (this.leaveSubmittedStat == true) ? tempBasic.prior_request_days : "";
                this.enableRollOver = (tempBasic.allow_carry_forward == "0") ? false : true;
                this.carryMax = (this.enableRollOver == true) ? tempBasic.max_of_carryforward : "";
                this.clubbingStat = (tempBasic.clubbing_policy == "0") ? false : true;
                this.documentStatus = (tempBasic.document_mandatory == "1")?true:false;
                this.documentDays = (this.documentStatus == true)?tempBasic.document_submission_days:"";
                for (var i = 0; i < this.periodList.length; i++) {
                  if (tempBasic.entitlement_period == this.periodList[i].id) {
                    this.periodSelected = [i];
                  }
                }
                for (var i = 0; i < this.onList.length; i++) {
                  if (tempBasic.entitlement_on == this.onList[i].id) {
                    this.onSelected = [i];
                  }
                }
                for (var i = 0; i < this.balanceList.length; i++) {
                  if (tempBasic.leave_balance_calculate_on == this.balanceList[i].id) {
                    this.balanceSelected = [i];
                  }
                }
               this.loaderService.display(false);
              }
              else {
                this.notifications.alertBoxValue("error", response.message);
                this.loaderService.display(false);
              }
            })
          }
          else {
             this.loaderService.display(false);
          }
        }
        else
          this.loaderService.display(false);
      }
      else {
        this.loaderService.display(false);
      }
    })
  }
  /*
  * @desc :method for matching index of two values
  * @auth : Nilena
  */
 matchingIndex(srcArray, compareValue, key) {
  for (var x in srcArray) {
    if (srcArray[x][key] == compareValue) {
      return x;
    }
  }
  return null;
}

  /*
  *  @desc   :Create and define form controls of createNew form
  *  @author :dipin
  */
  createFormControls() {
    this.codeField   = new FormControl('', [this.noWhitespaceValidator]);
    this.titleField  = new FormControl('', [Validators.required,this.noWhitespaceValidator]);
    this.periodField = new FormControl('', [Validators.required]);
    this.onField     = new FormControl('', [Validators.required]);
  }

  /*
*  @desc   :create form itemForm and addForm
*  @author :dipin
*/
  createForm() {
    this.addForm = new FormGroup({
      codeField  : this.codeField,
      titleField : this.titleField,
      onField    : this.onField,
      periodField: this.periodField
    });
  }

  selectedPeriod(event) {
    if (event.selected.length){
      this.addForm.patchValue({
        periodField: event.selected[0].id
      });
      this.selectedPeriodValue = event.selected[0].meta_value;
    }
    else{
       this.addForm.patchValue({
        periodField: ""
      });
     this.selectedPeriodValue = "";
    }
  }
  selectedOnList(event) {
    if (event.selected.length)
      this.addForm.patchValue({
        onField: event.selected[0].id
      })
    else
      this.addForm.patchValue({
        onField: ""
      });
  }
  selectedActiveList(event){
   if (event.selected.length)
      this.activeObject = event.selected[0].meta_key;
   else
      this.activeObject = "";
  }

  selectedRoundList(event) {
   if (event.selected.length)
      this.roundMulti = event.selected[0].meta_key;
   else
      this.roundMulti = "";
  }

  selectedClubList(event) {
    this.clubData = [];
    if (event.selected.length)
      for(var i = 0 ; i < event.selected.length;i++){
        this.clubData.push({club_leave_type_id:event.selected[i].id})
      }
    else
      this.clubData = [];
  }

  selectedBalanceList(event) {
    if (event.selected.length)
      this.leaveBalanceValue = event.selected[0].id;
    else
      this.leaveBalanceValue = "";
  }

  selectedStatusList($event) {

  }

  /*
	*  @desc   :method to go back from the currrent page to history
  	*  @author :dipin
	*/
  back() {
    this.apiService.statusService = false;
    window.history.back();
  }

   /*
    author : dipin
    desc   : validation for white space in form
    params :
  */
  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }

  addNewForm(i) {
    let stat = false;
    for(var k = 0; k < this.dataArray.length;k++){
     if(this.dataArray[k].experience_term != "" && this.dataArray[k].experience_term == "For new joinee"){
       stat = true;
       break;
     }
     else
       stat = false;
    }

    i = this.dataArray.length - 1;
    this.dataArray[this.dataArray.length - 1].submitted = true;
    if (this.dataArray[i].experience_term != "" && this.dataArray[i].experience_term != "For new joinee")
      if (this.dataArray[i].year != "") {
        if (this.dataArray[i].month != "") {
          if (this.dataArray[i].leave_count != "") {
            this.dataArray.push({
              experience_term: "After",
              year: "",
              month: "",
              leave_count: "",
              submitted:false
            });
            if(!stat)
              this.statusList.push([{ meta_value: "For new joinee" },
                                  { meta_value: "After" }
                                  ]);
           else
              this.statusList.push([{ meta_value: "After" }]);
            this.statusSelected.push([0]);
          }
        }
      }
   if(this.dataArray[i].experience_term != "" && this.dataArray[i].experience_term == "For new joinee"){
          if (this.dataArray[i].leave_count != "") {
            this.dataArray.push({
              experience_term: "After",
              year: "",
              month: "",
              leave_count: "",
              submitted:false
            });
            this.statusList.push([{ meta_value: "After" }]);
            this.statusSelected.push([0]);
          }
    }
  }

  setCheckbox(value){
    if(value == 1){
      this.includeHoliday = !this.includeHoliday;
    }
    if(value == 2){
      this.includeWeekend = !this.includeWeekend;
    }
    if(value == 3){
      this.excludeStatus = !this.excludeStatus;
      this.excludeHolidays = "";
    }
    if(value == 4){
      this.clubbingStat = !this.clubbingStat;
      this.clubSelected = [];
    }
    if(value == 5){
      this.clubbingStat = !this.clubbingStat;
    }
    if(value == 6){
      this.clubbingStat = !this.clubbingStat;
    }
    if(value == 7){
       this.allowBeyondLimit = !this.allowBeyondLimit;
    }
    if(value == 8){
       this.markBeyondLimit = !this.markBeyondLimit;
    }
    if(value == 9){
       this.halfdayStatus = !this.halfdayStatus;
    }
    if(value == 10){
       this.leaveSubmittedStat = !this.leaveSubmittedStat;
       this.leaveAppSelect = "";
    }
    if(value == 11){
       this.enableRoundOff = !this.enableRoundOff;
       this.roundSelected = "";
    }
    if(value == 12){
       this.maximumNumberStat = !this.maximumNumberStat;
       this.maximumDays = "";
    }
    if(value == 13){
       this.enableRollOver = !this.enableRollOver;
       this.carryMax = "";
    }
    if(value == 'forAll'){
       this.forAllEmStatus = true;
       this.forExpStatus = false;
    }
    if(value == 'forExperience'){
      this.forExpStatus = true;
      this.forAllEmStatus = false;
    }
    if(value == 'document'){
       this.documentStatus = !this.documentStatus;
       this.documentDays = "";
    }
  }

  deleteForm(index) {
    this.dataArray.splice(index, 1);
    this.statusSelected.splice(index, 1);
  }

  toFrom(index,event) {
    if (event.selected.length){
      this.dataArray[index].experience_term = event.selected[0].meta_value;
    }
    else
      this.dataArray[index].experience_term = "";
  }

  checkForNew(){
    for(var i = 0;i < this.dataArray.length;i++){
      if(this.dataArray[i].experience_term == "For new joinee"){
         this.countSelected = true;
         break;
      }
      else
        this.countSelected = false;
    }
  }

  /*
  *  @desc   : validating submited data send t the server using api call
  *  @author : dipin
  */
  submitForm() {
    this.submitted = true;
    let outputData = [];
    let nonOutData = [];
    if (this.selectedData) {
      for (var i = 0; i < this.selectedData.applicable.length; i++) {
        for (var j = 0; j < this.predefinedId.length; j++) {
          if (this.predefinedId[j].name == this.selectedData.applicable[i].name) {
            if (this.selectedData.applicable[i].selectedAll == true) {
              outputData.push({ category: this.predefinedId[j].id, reference_id: 0 });
            }
            else {
              for (var k = 0; k < this.selectedData.applicable[i].list.length; k++) {
                if (this.selectedData.applicable[i].list[k].is_selected == 1) {
                  outputData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.applicable[i].list[k].id });
                }
              }
            }
          }
        }
      }

      for (var i = 0; i < this.selectedData.notApplicable.length; i++) {
        for (var j = 0; j < this.predefinedId.length; j++) {
          if (this.predefinedId[j].name == this.selectedData.notApplicable[i].name) {
            if (this.selectedData.notApplicable[i].selectedAll == true) {
              nonOutData.push({ category: this.predefinedId[j].id, reference_id: 0 });
            }
            else {
              for (var k = 0; k < this.selectedData.notApplicable[i].list.length; k++) {
                if (this.selectedData.notApplicable[i].list[k].is_selected == 1) {
                  nonOutData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.notApplicable[i].list[k].id });
                }
              }
            }
          }
        }
      }
    }
    let setStatus = false;
    if (this.forExpStatus == true) {
      for (var i = 0; i < this.dataArray.length; i++) {
        if (this.dataArray[i].experience_term == "After") {
          if (this.dataArray[i].year == "" || this.dataArray[i].leave_count == "" || this.dataArray[i].month == "") {
            setStatus = false;
            break;
          }
          else
            setStatus = true;
        }
        else if (this.dataArray[i].experience_term == "For new joinee") {
          if (this.dataArray[i].leave_count == "") {
            setStatus = false;
            break;
          }
          else
            setStatus = true;
        }
      }
    }
    if (this.addForm.invalid || outputData.length == 0 || (this.forAllEmStatus && (this.allEmployeeData == '' || this.allEmployeeData == undefined)) ||
      (this.excludeStatus && (this.excludeHolidays == '' || this.excludeHolidays == undefined)) || (this.leaveSubmittedStat && (this.leaveAppSelect == '' || this.leaveAppSelect == undefined)) ||
      (this.enableRoundOff && (this.roundMulti == '' || this.roundMulti == undefined)) || (this.maximumNumberStat && (this.maximumDays == '' || this.maximumDays == undefined)) ||
      (this.enableRollOver && (this.carryMax == '' || this.carryMax == undefined)) || (this.forExpStatus == true && (setStatus != true)) || (this.clubbingStat == true && this.clubData.length == 0) || (this.enableRoundOff == true && (this.roundMulti == '' || this.roundMulti == undefined)) ||
      (this.documentStatus && (this.documentDays == '' || this.documentDays == undefined)) ) {
      if (outputData.length == 0 && this.addForm.valid) {
        this.setApplicable = true;
        this.notifications.alertBoxValue("error", "Select Options For Applicable For");
        document.getElementById("applicable").focus();
        document.getElementById("applicable").scrollIntoView(false);
      }
      else{
        this.setApplicable = false;
      }
      if (!this.titleField.valid) {
        document.getElementById("title").focus();
      }
      else if (!this.codeField.valid) {
        document.getElementById("code").focus();
      }
      else if (outputData.length == 0) {
        document.getElementById("applicable").focus();
        document.getElementById("applicable").scrollIntoView(false);
      }
      else if (!this.periodField.valid) {
        document.getElementById("period").focus();
        document.getElementById("period").scrollIntoView(false);
      }
      else if (!this.onField.valid) {
        document.getElementById("multiSelectCustom2").focus();
        document.getElementById("on").scrollIntoView(false);
      }
      else if (this.forAllEmStatus && (this.allEmployeeData == '' || this.allEmployeeData == undefined)) {
        document.getElementById("titleR").focus();
      }
      else if (this.enableRoundOff && (this.roundMulti == '' || this.roundMulti == undefined)) {
        document.getElementById("round-off").focus();
        document.getElementById("round-off").scrollIntoView(false);
      }
      return;
    }
    else {
      let dayFirst  = this.timezone.toLocal(this.startDate);
      let daySecond = this.timezone.toLocal(this.endDate);
      let dates = this.timezone.getCurrentDate();
      if (dayFirst > daySecond) {
        this.notifications.alertBoxValue("error", "Invalid Expiry Dates");
      }
      else {
        this.loaderService.display(true);
        this.setApplicable = false;

        for(var i = 0 ; i < this.dataArray.length;i++){
          delete this.dataArray[i]['submitted'];
        }

        let tempObj = {
          "basicInfo": {
            "name": this.titleField.value.trim(),
            "code": this.codeField.value.trim(),
            "entitlement_period": this.periodField.value,
            "entitlement_on": this.onField.value,
            "entitlement_for": (this.forAllEmStatus) ? 'A' : 'E',
            "include_holidays": (this.includeHoliday) ? 1 : 0,
            "include_weekends": (this.includeWeekend) ? 1 : 0,
            "override_days_request": (this.excludeStatus) ? this.excludeHolidays : null,
            "halfday_provision": (this.halfdayStatus) ? 1 : 0,
            "max_consecutive_leaves": (this.maximumNumberStat) ? this.maximumDays : null,
            "prior_request_days": (this.leaveSubmittedStat) ? this.leaveAppSelect : null,
            "document_mandatory": (this.documentStatus == true) ? 1 : 0,
            "document_submission_days": (this.documentStatus == true) ? this.documentDays : null,
            "round_off": (this.enableRoundOff == true)?this.roundMulti:null,
            "restrict_leave_balance_on": (this.newJoineeAfter == "")?null:this.newJoineeAfter,
            "restrict_leave_count": (this.newJoineeLeave == "")?null:this.newJoineeLeave,
            "clubbing_policy": (this.clubbingStat) ? 1 : 0,
            "leave_balance_calculate_on": this.leaveBalanceValue,
            "allow_beyond_limit": (this.allowBeyondLimit) ? 1 : 0,
            "beyond_limit_unpaid": (this.markBeyondLimit) ? 1 : 0,
            "allow_carry_forward": (this.enableRollOver) ? 1 : 0,
            "max_of_carryforward": (this.enableRollOver) ? this.carryMax : null,
            "expiry_start_date": ( this.startDate != "Invalid Date")?this.formatForApi(this.startDate):"",
            "expiry_end_date": ( this.endDate != "Invalid Date")?this.formatForApi(this.endDate):"",
            "status": this.activeObject
          },
          "applicableFor": outputData,
          "not_applicable_for" : nonOutData,
          "entitlementDetail": (!this.forAllEmStatus) ? this.dataArray : [{ leave_count: this.allEmployeeData }],
          "clubbingLeaves": this.clubData
        }
        if (this.statusService) {
          this.apiService.updateCalenderDetails(tempObj, this.selectedId, response => {
            if (response.status == "Success") {
              this.addForm.reset();
              this.routeStatus.navigate(['/modules/leave/leave-type']);
              setTimeout(() => {
                this.loaderService.display(false);
                this.notifications.alertBoxValue("success", response.message);
              }, 600);
            }
            else {
              this.submitted = false;
              this.notifications.alertBoxValue("error", response.message);
                this.loaderService.display(false);
            }
          })
        }
        else {
          this.apiService.addCalenderDetails(tempObj, response => {
            if (response.status == "Success") {
              this.addForm.reset();
              this.routeStatus.navigate(['/modules/leave/leave-type']);
              setTimeout(() => {
                this.loaderService.display(false);
                this.notifications.alertBoxValue("success", response.message);
              }, 600);
            }
            else {
              this.notifications.alertBoxValue("error", response.message);
              this.submitted = false;
              this.loaderService.display(false);
            }
          })
        }
      }
    }
  }

  formatDate(date) {
    if (date) {
     var d = this.timezone.toLocal(date);
      var curr_date = d.getDate();
      var curr_month = d.getMonth() + 1;
      var curr_year = d.getFullYear();
      var date_format = curr_year + "-" + curr_month + "-" + curr_date;
      return date_format;
    }
  }

   /*
 *  @desc   : method deal with conversion of date format
 *  @author : dipin
 */
  formatDateForPicker(inputDate) {
    return this.timezone.toLocal(inputDate);
  }

 /*
 *  @desc   : date set for api format
 *  @author : dipin
 */
   formatForApi(inputDate) {
    var date = this.timezone.toLocal(inputDate);
    if(date)
    if (!isNaN(date.getTime())) {
      if ((Number(date.getMonth()) + 1) < 10) {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
      else {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
    }
    else
      return undefined;
  }

 /*
 *  @desc   : check value of the box
 *  @author : dipin
 */
  checkSum(event,value){
    if(Number(value+event.key) > 31){
      event.preventDefault();
    }
  }

  sayCloseAll($event){
    this.sayClose = true;
  }

   /*
  *  @desc   : check value of the monthbox
  *  @author : dipin
  */
  checkSumMonth(event,value){
    if(Number(value+event.key) > 11){
      event.preventDefault();
    }
  }

}
