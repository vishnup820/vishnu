/*
*  @desc   :component for display regularization list and approve
*  @author :dipin
*/
import { Component, OnInit } from '@angular/core';
import { RegularisationApprovalService } from '../../services/regularisation-approval/regularisation-approval.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { CookieService } from 'ngx-cookie-service';
import { PendingListService } from '../../../shared/services/pending-list/pending-list.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { HostListener } from '@angular/core';

declare var require: any;
var moment = require('moment');

@Component({
  selector: 'app-regularisation-approval',
  templateUrl: './regularisation-approval.component.html',
  styleUrls: ['./regularisation-approval.component.css']
})
export class RegularisationApprovalComponent implements OnInit {

  advanceFilterData     : any;
  searchValue           : any;
  approvalDetails       : any;
  approveId             : any;
  config                : any;
  configDelete          : any;
  role                  : any;
  messageData           : any;
  selectChat            : any;
  selectedChat          : any;
  userData              : any;
  selectedList          : any;
  appliedDate           : any;
  
  // approveRejectData     : any;

  rejectPopUp           : boolean = false;
  searchTextBox         : boolean = false;
  entryBlock            : boolean = false;
  chatConfirm           : boolean = false;
  cancelBox             : boolean = false;
  responceLoad          : boolean = true;
  currentPage           : number = 1;
  recordsPerPage        : number = 10;
  totalRecords          : number;
  compensatoryDatesId   : number;
  userId                : number;

  rejectStatus          : boolean = false;
  nodata                : boolean = false;
  confirmBox            : boolean = false;
  filterStatus          : boolean = false;
  cancelButtonId        : any;
  chatMessage           : any = "";
  cancelPopUp           : boolean = false;
  singlecancel          : boolean = false;
  imgErr                : any =[];

  constructor(
  	private regularisationApprovalService   : RegularisationApprovalService,
  	private loaderActionsService            : LoaderActionsService,
  	private notificationService             : NotificationService,
    private cookies                         : CookieService,
    private timeZone                        : TimezoneDetailsService,
    private PendingListService              : PendingListService) { }

  ngOnInit() {
    this.loaderActionsService.display(true);
  	this.config = "Are You Sure You Want To Approve?";
    this.configDelete = "Are You Sure You Want To Cancel?";
    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    if (this.cookies.get("user-data"))
      this.userData = JSON.parse(this.cookies.get("user-data"));
  	this.getDetails(this.currentPage);
  }

 

  //prevent console edit

//   @HostListener('document:keydown', ['$event'])
//   keydown(e: KeyboardEvent) {
//       console.log("Key Up! " + e.key);
//       console.log(e)
//       if(e.key=='F12'){
//         this.disabledEvent(e);
//       }
//       if (e.ctrlKey && e.shiftKey && e.keyCode == 73) {
//         this.disabledEvent(e);
//     }
//     // "J" key
//     if (e.ctrlKey && e.shiftKey && e.keyCode == 74) {
//         this.disabledEvent(e);
//     }
//     if (e.ctrlKey && e.shiftKey && e.keyCode == 67) {
//       this.disabledEvent(e);
//   }
//   if(e.ctrlKey && e.shiftKey){
//     this.disabledEvent(e);
//   }
    
      
//   }

//   @HostListener('document:contextmenu', ['$event'])
//   onDocumentRightClick(event) {
//     console.log(event);
//     event.preventDefault()
   
//   }

//  disabledEvent(e) {
//     if (e.stopPropagation) {
//         e.stopPropagation();
//     } else if (window.event) {
//         window.event.cancelBubble = true;
//     }
//     e.preventDefault();
//     return false;
// }



  updateList(){
    this.PendingListService.getPendingList(response => {
      if (response) {
            let pendata = response;
          let aclData=  JSON.parse(localStorage.getItem("acl"));
          if(aclData.acl.length>0){
            for(let i=0; i<aclData.acl.length;i++){
              if(aclData.acl[i].name=='Approvals'){
                aclData.acl[i].acl.pending=pendata.total_pending;
                for(let j=0;j<aclData.acl[i].child.length; j++){
                    if(aclData.acl[i].child[j].name=='Regularization Approval'){
                      aclData.acl[i].child[j].acl.pending=pendata.regularisation[0].pending;
                    }
                  }
              }
            }
          }
          localStorage.setItem('acl',JSON.stringify(aclData))
          this.PendingListService.setAclData(aclData);

        }
    })
  }


  /*
  *  @desc   : get approval details
  *  @author : arunjohnson
 */
  getDetails(page) {
    this.loaderActionsService.display(true);
    this.role = JSON.parse(this.cookies.get('user-data')).role_id;
  	this.currentPage = page;
  	let userId : number;
  	userId = 1;
  	this.regularisationApprovalService.getDetails(this.currentPage,this.recordsPerPage,this.searchValue,this.advanceFilterData,userId,res=>{
  		if (res.status == "OK" && res.data && res.data.length) {
        	this.totalRecords         = res.count;
          this.approvalDetails      = res.data;
        
        if (this.approvalDetails && this.approvalDetails.length) {
          let tempArray = [];
          for (let i = 0; i < this.approvalDetails.length; i++) {
            this.approvalDetails[i].basic.messageStatus = false;
            this.approvalDetails[i].basic.chatLoad = false;
            this.approvalDetails[i].basic.display = false;
            let secondHand = [];
            for (var j = 0; j < this.approvalDetails[i].basic.detail.length; j++) {
              secondHand.push({ date: this.approvalDetails[i].basic.detail[j].applied_date, status: this.approvalDetails[i].basic.detail[j].status });
            }
            tempArray.push(secondHand);
          }
          let checkDate = this.timeZone.getCurrentDate();
          for (var i = 0; i < tempArray.length; i++) {
            for (var j = 0; j < tempArray[i].length; j++) {
              if (moment(checkDate).isBefore(moment(moment(tempArray[i][j].date).add('days', 1)))) {
                this.approvalDetails[i].basic.display = true;
                break;
              }
              else {
                this.approvalDetails[i].basic.display = false;
              }
            }
          }
        }
          this.loaderActionsService.display(false);
        }
        else {
        this.approvalDetails  = [];
        this.nodata           = true;
        this.loaderActionsService.display(false);
      }
  	})
  }

  /*
   author : Arun Johnson
   desc   : Search  when enter key is pressed
  */
  search(value) {
   if (value.trim() != '' || (this.searchValue != '' && this.searchValue)) {
    this.searchValue = value;
    this.currentPage = 1;
    this.getDetails(this.currentPage);
   }
  }

  /*
	*  @desc   : commpensatory single date details
	*  @author : arunjohnson
  */
  singleDateDetails(data,comp_request_details_id,id) {
  	this.compensatoryDatesId = comp_request_details_id;
  	this.userId              = id;
  	this.rejectPopUp         = true;
  }

  /*
	*  @desc   : commpensatory single date cancel details
	*  @author : ashiq
  */
  singleDateCancel(data,comp_request_details_id,id,appliedDate){
    this.compensatoryDatesId = comp_request_details_id;
    this.userId              = id;
    this.appliedDate         = appliedDate
    this.singlecancel         = true;
  }

  singleCancelConfirm(event) {
    this.singlecancel = false;
    if (event.status == true) {
      this.loaderActionsService.display(true);
      this.regularisationApprovalService.singlecCancelData(this.compensatoryDatesId, this.appliedDate, event.value, res => {
        if (res.status == "OK") {
          this.updateList();
          this.notificationService.alertBoxValue("success", res.data.message);
          this.getDetails(this.currentPage);
        } else {
          this.updateList();
          this.getDetails(this.currentPage);
          this.notificationService.alertBoxValue("error", res.message);
          this.loaderActionsService.display(false);
        }
      })
    }

  }


 /*
	*  @desc   : regularisation reject
	*  @author : arunjohnson
 */
  dateDelete(event) {
	  if (this.rejectStatus) {
        this.rejectPopUp = false;
        this.loaderActionsService.display(true);
      this.regularisationApprovalService.singleDateDelete(event.value, this.compensatoryDatesId, this.userId, res => {
        if(res.status == "OK") {
          this.updateList();
          this.notificationService.alertBoxValue("success",res.data.message);
          this.getDetails(this.currentPage);
        } else {
          this.notificationService.alertBoxValue("error",res.message);
          this.rejectPopUp = false;
          this.updateList();
          this.getDetails(this.currentPage);
          this.loaderActionsService.display(false);
        }
		  })
	  } else {
	  	this.loaderActionsService.display(true);
      this.rejectPopUp = false;
	  	this.regularisationApprovalService.rejectData(event.value, this.userId,  res => {
        if(res.status == "OK") {
          this.updateList();
          this.notificationService.alertBoxValue("success",res.message);
          this.rejectPopUp = false;
          this.getDetails(this.currentPage);
        } else {
          this.notificationService.alertBoxValue("error",res.message);
          this.rejectPopUp = false;
          this.updateList();
          this.getDetails(this.currentPage);
          this.loaderActionsService.display(false);
        }
		})
	  }
  }


  /*
	*  @desc   : regularisation approve by hr
	*  @author : arunjohnson
  */
  approveCompensatory(event) {
    this.confirmBox = false;
    if (event.status == true) {
      this.loaderActionsService.display(true);
      this.regularisationApprovalService.approve(this.approveId,event.value, res => {
        if (res.status == "OK") {
          this.updateList();
          this.notificationService.alertBoxValue("success", res.message);
          this.getDetails(this.currentPage);
        } else {
          this.updateList();
          this.getDetails(this.currentPage);
          this.notificationService.alertBoxValue("error", res.message);
          this.loaderActionsService.display(false);
        }
      })
    }
  }


  getCancelConfirm(event) {
    this.cancelBox = false;
    if (event.status == true) {
      this.loaderActionsService.display(true);
      this.regularisationApprovalService.cancelData(this.userId,event.value, res => {
        if (res.status == "OK") {
          this.updateList();
          this.notificationService.alertBoxValue("success", res.message);
          this.getDetails(this.currentPage);
        } else {
          this.updateList();
          this.notificationService.alertBoxValue("error", res.message);
          this.getDetails(this.currentPage);
        }
      })
    }

  }

  /*
   author : Arun Johnson
   desc   : send Filter Data
   params :
  */
  filterData(data) {
   if (data || this.advanceFilterData) {
    this.advanceFilterData  = data;
    this.currentPage        = 1;
    this.getDetails(this.currentPage);
    }
    else{
      this.advanceFilterData = undefined;
    }
   }

  /*
   author : Arun Johnson
   desc   : add class based on index
  */
  getClassByValue(index) {
    return this.regularisationApprovalService.getClassByValue(index);
  }

  setFocus() {
    window.setTimeout(function() {
      document.getElementById('searchField').focus();
    }, 1);
  }

    /*
  *  @desc   :method for pagination
  *  @author :dipin
  */
  getpage(event) {
    if (event > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      this.getDetails(this.currentPage);
    }
  }

    /*
  *  @desc   :show previous messages using api call
  *  @author :dipin
  */
  showMessage(index, id) {
    for (let i = 0; i < this.approvalDetails.length; i++) {
      if (index == i) {
        this.approvalDetails[i].basic.messageStatus = !this.approvalDetails[i].basic.messageStatus;
        if (this.approvalDetails[i].basic.messageStatus) {
          this.messageData = [];
          this.responceLoad = true;
          this.approvalDetails[index].basic.chatLoad = true;
          this.regularisationApprovalService.showMessage(id, res => {
            if (res.status == "OK") {
              let self = this;
              this.messageData = res.data;
              for (var i = 0; i < this.messageData.length; i++) {
                let diff = Math.abs((moment.utc(this.messageData[i].send_time).toDate().getTime() - moment.utc().toDate().getTime()) / 1000);
                          diff = Math.abs(diff);
                if (Number(diff) >= 300) {
                  this.messageData[i].deleteIcon = false;
                }
                else {
                  this.messageData[i].deleteIcon = true;
                }
              }
              this.approvalDetails[index].basic.chatLoad = false;
              this.responceLoad = false;
              setTimeout(function() {
                $("#top-chat").mCustomScrollbar("scrollTo", "bottom");
                if (document.getElementById("chatBox")) {
                  if (self.selectedChat == id) {
                      document.getElementById("chatBox").innerHTML = self.chatMessage;
                  }
                  else {
                    self.selectedChat = id;
                    self.chatMessage = '';
                  }
                      document.getElementById("chatBox").focus();
                }
              });
            }
            else {
              this.approvalDetails[index].basic.chatLoad = false;
              this.responceLoad = false;
            }
          })
        }
      }
      else {
        this.approvalDetails[i].basic.messageStatus = false;
      }
    }
  }

  /*
  *  @desc   :method send messages to the server with sender's id
  *  @author :dipin
  */
  sendMessage(index, id) {
    if (this.chatMessage != '' && this.chatMessage.trim() != '') {
      this.entryBlock = true;
      let obj = {
        "user_id": this.userData.user_id,
        "regularization_id": id,
        "message": this.chatMessage.trim()
      };
      document.getElementById("chatBox").innerHTML = '';
      setTimeout(function() {
        document.getElementById("chatBox").focus();
      });
      this.messageData.push({
        'id': '',
        "first_name": this.userData.first_name,
        "last_name": this.userData.last_name,
        "message": this.chatMessage.trim(),
        "photo": this.userData.photo,
        "send_time": moment.utc().toDate().getTime(),
        "user_id": this.userData.user_id,
        'status' : 1
      });
      this.chatMessage = '';
      this.messageData[this.messageData.length - 1].sent = true;
      setTimeout(function() {
        $("#top-chat").mCustomScrollbar("scrollTo", "bottom");
      });
      this.regularisationApprovalService.addMessage(obj, res => {
        if (res.status == "Success") {
          this.messageData[this.messageData.length - 1].sent = false;
          this.messageData[this.messageData.length - 1].id = res.id;
          this.messageData[this.messageData.length - 1].deleteIcon = true;
          this.entryBlock = false;
        }
        else {
          this.notificationService.alertBoxValue("error", res.message);
          this.entryBlock = false;
          this.messageData.pop();
          this.messageData[this.messageData.length - 1].sent = false;
          this.messageData[this.messageData.length - 1].deleteIcon = false;
        }
      })
    }
  }

  /*
  *  @desc   :method to close all the popup of chat message while hovet on messages
  *  @author :dipin
  */
  closeAllPopup() {
    this.chatConfirm = false;
    for (let i = 0; i < this.approvalDetails.length; i++) {
      this.approvalDetails[i].basic.messageStatus = false;
    }
  }

  /*
   *  @desc   :method to display selected type of list
   *  @author :dipin
   */
  deleteMessage() {
    this.messageData[this.selectChat].sent = true;
    this.regularisationApprovalService.deleteChat(this.userData.user_id, this.messageData[this.selectChat].id, res => {
      if (res.status == "Success") {
        for (let i = 0; i < this.messageData.length; i++) {
          if (this.messageData[i].id == res.message_id) {
            this.messageData[i].sent = false;
            this.messageData[i].delete = true;
          }
        }
      }
      else {
        this.notificationService.alertBoxValue("error", res.message);
        this.messageData[this.selectChat].sent = false;
        this.messageData[this.selectChat].delete = false;
      }
    })
  }




  /*
  *  @desc   :method to display selected type of list
  *  @author :dipin
  */
  formatDate(date) {
    var strTime = date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds();
    return date.getFullYear() + "-" + Number(date.getMonth() + 1) + "-" + date.getDate() + "  " + strTime;
  }

  setMessageIcon() {
    if (this.messageData)
      if (this.messageData.length) {
        for (var i = 0; i < this.messageData.length; i++) {
            let diff = Math.abs((moment.utc(this.messageData[i].send_time).toDate().getTime() - moment.utc().toDate().getTime()) / 1000);
            diff = Math.abs(diff);
          if (Number(diff) >= 300) {
            this.messageData[i].deleteIcon = false;
          }
          else {
            this.messageData[i].deleteIcon = true;
          }
        }
      }
  }
}
