import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegularisationApprovalComponent } from './regularisation-approval.component';

describe('RegularisationApprovalComponent', () => {
  let component: RegularisationApprovalComponent;
  let fixture: ComponentFixture<RegularisationApprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegularisationApprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegularisationApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
