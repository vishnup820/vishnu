import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { PayperiodService } from '../../services/payperiod-service/payperiod.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { NotificationService } from '../../../shared/services/notifications/notification.service';

@Component({
  selector: 'app-pay-period-settings',
  templateUrl: './pay-period-settings.component.html',
  styleUrls: ['../../../../assets/content/css/pay-period.css','../../../../assets/content/css/shifts.css']
})
export class PayPeriodSettingsComponent implements OnInit {

  payperiodToggle       : boolean = false;
  apiObject             : any = {}
  currentPage       		: number = 1;
  recordsPerPage    		: number = 10;
  totalRecords      		: number;
  payperiodData 			  : any = [];
  searchTextBox				  : boolean = false;
  searchD 					    : any;
  lazyLoad              : boolean = false;
  searchKeyword         : any;
  @ViewChild('foc') inputEl : ElementRef;
  statusData            : any =  [
                {status: 'Active', value: 1},
                {status: 'Inactive', value: 2}
              ];
  statusChecked         : any = [];
  filterStatus          : boolean = false;
  statusSelected        : any = [];
  status                : number = 0
  showConfirmBox        : boolean = false;
  deletedItem           : any;

  payPeriodName         : any;
  payPeriodCycle        : any = "Monthly";
  payPeriodStatus            : any =  [
                        {status: 'Active', value: 1},
                        {status: 'Inactive', value: 2}
              ];
  submit                : boolean = false;
  payPeriodStatusChecked       : any = [0];
  selectedData          : any = [];
  submitted             : boolean = false;

  predefinedId          : any = [];

  endOfCycle            : any = [];
  payPeriodCycleChecked : any = [23];
  selectedCycle         : any;
  startPeriod           : any;
  endVal                : any;
  lockStatus            : any;
  dayEndCycle           : any;
  overrideActivity      : boolean = false; 
  overStatus            : any;
  overrideStat          : boolean = false;
  paydayChecked         : any =   [0]
  paydayItem            : any;
  cycleId               : any;
  overridedDays         : any;
  editActive            : boolean = false;
  lockstatus            : boolean = false;
  overridestat          : boolean = false;
  lockStat              : boolean = false;
  filterActive          : boolean = false;
  changedStatus         : any;
  valid                 : boolean = false;
  valid2                : boolean = false;
  lockActivity          : boolean = false;
  labelHeader           : any;
  id                    : any;
  res                   : any =[];
  editStatus            : boolean = false;






  constructor(private payperiodService : PayperiodService,
              private loaderActionsService : LoaderActionsService,
              private notificationService : NotificationService) { }
  ngOnInit() {
    this.predefinedId = [{
      id: 1, name: "location"
    },
    { id: 2, name: "user" },
    { id: 3, name: "group" },
    { id: 4, name: "department" },
    { id: 5, name: "designation" }
    ]
  	if(localStorage.getItem("itemsperpage")){
      	this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else{
      	this.recordsPerPage = 10;
    }
  	this.apiObject = {
      "page": this.currentPage,
      "page_limit": this.recordsPerPage,
    }
    for(var i=0;i<=28;i++){
      this.endOfCycle[i] =  {"cycleVal":this.addSufix(i+1,29),"val":i+1}
    }
  	this.listAllPayperiods();
  }

  addSufix(i,lastday) {
    var j = i % 10,
        k = i % 100;
    if(i==lastday){
      return "Last Day"
    }
    if (j == 1 && k != 11 && i != lastday) {
        return i + "st";
    }
    if (j == 2 && k != 12 && i != lastday) {
        return i + "nd";
    }
    if (j == 3 && k != 13 && i != lastday) {
        return i + "rd";
    }
    return i + "th";
}

  togglePayperiod(){
    this.labelHeader =  "Add";
    this.res=[];
    this.cancelAdd();
  	this.payperiodToggle = true;
  }

  listAllPayperiods(){
    this.loaderActionsService.display(true);
  	this.payperiodService.getAllPayperiod(this.apiObject,(response)=>{
      if(response){
        this.payperiodData = response.data;
        this.totalRecords  =     Number(response.count);
        this.currentPage   =     this.apiObject.page;
  	  }else{
        this.payperiodData = [];
      }
    this.loaderActionsService.display(false);
    })
  }
  /*
	author : vinod.k
	desc   : search to list items
	params :
	*/
    searchList(keyword) {
      if(this.searchKeyword || this.searchD.trim() != ''){  
      	this.searchKeyword = keyword;
      	this.apiObject.keyword = this.searchKeyword ? this.searchKeyword : '';
      	this.apiObject.page = 1;
      	this.listAllPayperiods();
       }
    }

    inputfocus(){
    	setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
    }

     getpage(eve){
      if(eve>10 || this.recordsPerPage != 10){
          this.recordsPerPage = eve;
          this.apiObject['page_limit'] = eve;
          this.apiObject['page'] = 1;
          this.currentPage = 1;
          this.listAllPayperiods();
      }
    }

    pageChangeEvent(page) {
      this.apiObject.page = page;
      this.currentPage    = page;
      this.listAllPayperiods();
    }

    statusFilterEvent(event){
      this.statusSelected = event;
    }
    showFilter(){
       // this.cancelShift();
     }

    filterApply(){
    let statusFil  = this.statusSelected && this.statusSelected.selected && this.statusSelected.selected[0] && this.statusSelected.selected[0].status ? this.statusSelected.selected[0].status : 0;
    let secondLoader = this.checkFilterStatus(statusFil);
    if (secondLoader) {
      this.filterActive = true;
      if(this.statusSelected){
        if (this.statusSelected.selected.length) {
          if(this.statusSelected.selected[0].status == "Active"){
            this.apiObject['st'] = "1";
            this.filterActive = true;
            this.apiObject['page'] = 1;
          }else if(this.statusSelected.selected[0].status == "Inactive"){
            this.apiObject['st'] = "2";
            this.apiObject['page'] = 1;
          }
        }
        else {
          this.filterActive = false;
          this.apiObject['st'] = 1;
        }
      }
      this.listAllPayperiods();
    }
    else {
      this.filterActive = false;
      this.apiObject['st']   = null;
    }
    }

    checkFilterStatus(stat){
    let ret = true;
    if (stat == 0 && (this.status == stat)){
      ret = false;
    }
    this.status = stat;
    return ret;
  }

  filterCancel() {
    if (this.checkFilterCanCancel()) {
      this.apiObject['st']  = null;
      this.statusChecked      = [];
      this.apiObject['page'] = 1;
      this.listAllPayperiods();
    }
    this.filterActive = false;
  }

  checkFilterCanCancel() {
      let ret = true;
    if (this.status == 0) {
      return false;
    }
    return true;
  }

  deletepayperiod(id){
    this.deletedItem = id
    this.showConfirmBox = true;
  }
  confirmPopup(ev){
    if(ev == true) {
        this.loaderActionsService.display(true);
        this.payperiodService.deletePayperiod(this.deletedItem, (response) => {
            if (response.status == "OK") {
              this.notificationService.alertBoxValue("success", response.message);
              this.apiObject.page = 1;
              // this.apiObject['sftstat'] = "1";
              this.listAllPayperiods();
            }
            else {
              this.loaderActionsService.display(false);
              this.notificationService.alertBoxValue("error", response.message);
            }
        })
        this.showConfirmBox = false;
      }
      else{
        this.showConfirmBox = false;
      }    
  }

  addNewpayperiod(){
    this.loaderActionsService.display(true);
    this.submitted = true;
     let dayStatus  = false; 
     let outputData = [];
     let nonOutData = [];
     this.lockstatus = false;
     this.overridestat = false;
     let applicable = false;
    if(this.payPeriodName == "" || this.payPeriodName == null || !this.payPeriodName.replace(/\s/g, '').length){
      this.submit = true;
      let appNameScrollPos = document.getElementById("pay-period");
      appNameScrollPos.focus();
    }
    else{
      this.submit = false;
    }
    if (this.selectedData) {
      for (var i = 0; i < this.selectedData.applicable.length; i++) {
        for (var j = 0; j < this.predefinedId.length; j++) {
          if (this.predefinedId[j].name == this.selectedData.applicable[i].name) {
            if (this.selectedData.applicable[i].selectedAll == true) {
              outputData.push({ category: this.predefinedId[j].id, reference_id: 0 });
            }
            else {
              for (var k = 0; k < this.selectedData.applicable[i].list.length; k++) {
                if (this.selectedData.applicable[i].list[k].is_selected == 1) {
                  outputData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.applicable[i].list[k].id });
                }
              }
            }
          }
        }
      }

      for (var i = 0; i < this.selectedData.notApplicable.length; i++) {
        for (var j = 0; j < this.predefinedId.length; j++) {
          if (this.predefinedId[j].name == this.selectedData.notApplicable[i].name) {
            if (this.selectedData.notApplicable[i].selectedAll == true) {
              nonOutData.push({ category: this.predefinedId[j].id, reference_id: 0 });
            }
            else {
              for (var k = 0; k < this.selectedData.notApplicable[i].list.length; k++) {
                if (this.selectedData.notApplicable[i].list[k].is_selected == 1) {
                  nonOutData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.notApplicable[i].list[k].id });
                }
              }
            }
          }
        }
      }
    }
    if(!outputData.length){
      applicable = true;
    }else{
      applicable = false;
    }
    if(this.overridedDays != null && this.overStatus=="enable"){
      this.valid2 = /^(0?[1-9]|[1][0-9]|[2][0-8])?$/.test(this.overridedDays);
    }else{
      this.valid2 = true;
    }
    if((this.overridedDays == "" || this.overridedDays == null || !this.overridedDays.replace(/\s/g, '').length || !this.valid2) && this.overStatus=="enable"){
      this.overridestat = true;
      // let appNameScrollPos = document.getElementById("pay-period");
      // appNameScrollPos.focus();
    }
    else{
      this.overridestat = false;
    }
    // if((this.overridedDays == this.dayEndCycle) && (this.overridedDays != null && this.dayEndCycle != null) && (this.lockStatus=="enable" && this.overStatus=="enable")){
    //   dayStatus = true;
    //   this.notificationService.alertBoxValue("warning","Payment cannot be initiated");
    // }else{
    //   dayStatus = false;
    // }
    // if(this.paydayItem <= (this.overridedDays || this.dayEndCycle)){
    //   dayStatus = true;
    //   this.notificationService.alertBoxValue("warning","Payment cannot be initiated");
    // }else{
    //   dayStatus = false;
    // }
    if((Number(this.dayEndCycle) > Number(this.overridedDays)) && (this.lockStatus=="enable" && this.overStatus=="enable")){
      dayStatus = true;
      this.notificationService.alertBoxValue("warning","Lock activities should not be greater than Override locking date");
    }else{
      dayStatus = false;
    }
    if(this.dayEndCycle != null && this.lockStatus=="enable"){
      this.valid = /^(0?[1-9]|[1][0-9]|[2][0-8])?$/.test(this.dayEndCycle);
    }else{
      this.valid = true;
    }
    if((this.dayEndCycle == "" || this.dayEndCycle == null || !this.dayEndCycle.replace(/\s/g, '').length || !this.valid) && this.lockStatus=="enable"){
      this.lockstatus = true;
      // let appNameScrollPos = document.getElementById("pay-period");
      // appNameScrollPos.focus();
    }
    else{
      this.lockstatus = false;
    }
    
      let finalObj =  {
              "title"     : this.payPeriodName,
              "cycle" : this.payPeriodCycle,
              "end_of_cycle": this.cycleId,
              "activity_locking":(this.dayEndCycle)?this.dayEndCycle:null,
              "override_days": (this.overridedDays)?this.overridedDays:null,
              "pay_day": this.paydayItem,
              "status": this.changedStatus,
              "applicable_for": outputData,
              "not_applicable_for" : nonOutData       
          }
    if(!this.submit && !applicable && !this.overridestat && !this.lockstatus && !dayStatus){
      this.payperiodService.submitPayPeriodMaster((this.id)?this.id:null,this.labelHeader,finalObj,(response)=>{
        if(response.status == "Success"){
          this.notificationService.alertBoxValue("success", response.message);
          // this.totalRecords  =     Number(response.count);
          // this.currentPage   =     this.apiObject.page;
          this.payperiodToggle = false;
          this.editActive=false;
          this.res=[];
          this.cancelAdd();
          this.apiObject['page'] = 1;
          this.listAllPayperiods();
        }else{
          this.notificationService.alertBoxValue("warning", response.message);
          // this.payperiodData = [];
        }
      })
    }
    this.loaderActionsService.display(false);
  }

  cancelAdd(){
    this.payPeriodName = null;
    this.payPeriodStatusChecked = [0]
    // this.selectedData         = [];
    this.payPeriodCycleChecked = [23]
    this.dayEndCycle          = null;
    this.overridedDays        = null;
    this.paydayChecked        = [0]
    this.submitted            = false;
    this.lockActivity         = false;
    this.overrideActivity     = false;
    this.lockStat             = false;
    this.overrideStat         = false;
    this.submit               = false;
    this.editStatus           = false;
    this.overridestat         = false;
    this.lockstatus           = false;
    this.lockStatus           ="disable"
    this.overStatus           ="disable"
    // this.changedStatus   = 1;
  }

  payPeriodNameChange(nameModel){
    if(nameModel == '' || nameModel == '' || !nameModel.replace(/\s/g, '').length){
         this.submit = true;
       }else{
         this.submit = false;
       }  
  }

  statusFilterChange(event){
    if(event && event.selected.length){
       this.changedStatus = event.selected[0].value;
   }
  }

  cycleFilterChange(event){
    if(event && event.selected.length){
       this.cycleId =  event.selected[0].val
      this.selectedCycle = event.selected[0].cycleVal;
      this.payrollSet(event,this.selectedCycle)
    }
  }
  // lastday(y,m){
  //   return  new Date(y, m +1, 0).getDate();
  // }
  payrollSet(e,cycleval){
    // this.startPeriod = cycleval;
    if(e.selected[0].cycleVal == "1st"){
      this.endVal = cycleval; 
      this.startPeriod = "2nd";
      // this.endVal = this.endOfCycle[this.endOfCycle.length-1].cycleVal;
    }else if(e.selected[0].cycleVal == "Last Day"){
      // this.endVal = this.endOfCycle[0].cycleVal;
      this.startPeriod = "1st"
      this.endVal = "Last Day";
    }
    else if(e.selected[0].val == 28){
       this.startPeriod = "29th"
       this.endVal = "28th";
    }
    else{
      for(var i=0;i<this.endOfCycle.length;i++){
      if(e.selected[0].val == this.endOfCycle[i].val){
        // this.endVal = this.endOfCycle[i-1].cycleVal;
        i = i+1;
        this.startPeriod = this.endOfCycle[i].cycleVal;
        this.endVal = cycleval
      }
    }
    }
  }

  isLockactivity(modelstatus){
    this.lockStatus = modelstatus;
    if(modelstatus == "enable"){
      this.lockStat = true;
      this.dayEndCycle = null;
    }else{
      this.lockStat = false;
      this.dayEndCycle = null;
      this.lockstatus = false;
    }
  }

  isOverrideActivity(overrideStatus){
    this.overStatus = overrideStatus;
     if(overrideStatus == "enable"){
      this.overrideStat = true;
      this.overridedDays = null;
    }else{
      this.overrideStat = false;
      this.overridedDays = null;
      this.overridestat = false;
    }
  }

  payDayFilterChange(changeevent){
    if(changeevent && changeevent.selected.length)
      this.paydayItem  = changeevent.selected[0].val
    }

  Cancelpayperiod(){
    this.payperiodToggle = false;
    this.editActive=false;
    this.cancelAdd();
  }

  dayEndChange(lockmodel){
    this.valid = /^(0?[1-9]|[1][0-9]|[2][0-8])?$/.test(lockmodel);
    if((lockmodel == '' || lockmodel == '' || !lockmodel.replace(/\s/g, '').length || !this.valid) && this.lockStatus=="enable"){
         this.lockstatus = true;
       }else{
         this.lockstatus = false;
       }
  }
  overEndChange(overridemodel){
    this.valid2 = /^(0?[1-9]|[1][0-9]|[2][0-8])?$/.test(overridemodel);
    if((overridemodel == '' || overridemodel == '' || !overridemodel.replace(/\s/g, '').length || !this.valid2) && this.overStatus=="enable"){
         this.overridestat = true;
       }else{
         this.overridestat = false;
       }  
  }

    /*
	 * @desc :method for matching index of two values
	 * @auth : Ashiq
	 */
	matchingIndex(srcArray, compareValue, key) {
		for (var x in srcArray) {
			if (srcArray[x][key] == compareValue) {
				return x;
			}
    }
  }
	

  editForm(data){
  this.id = data.id; 
  this.labelHeader = "Edit"
  this.payperiodToggle=true;
  this.editActive=true;
  this.editStatus=true;
  this.lazyLoad=true;
  this.payperiodService.getAllEditedDatas((this.id)?this.id:null,(response)=>{
    if(response){
        this.res = response.data;
        this.payPeriodName = this.res.title
         this.payPeriodCycle  = this.res.cycle;
         this.changedStatus=this.res.status;
         this.selectedCycle=this.res.end_of_cycle;
         this.lazyLoad=false;
         this.payPeriodCycleChecked =[this.endOfCycle.findIndex(x => x.val == this.res.end_of_cycle)];
         if(this.res.status == "1"){
          this.payPeriodStatusChecked = [0]
         }else{
          this.payPeriodStatusChecked = [1]
         }
         if( this.res.activity_locking !== null && this.res.activity_locking !== ''){
             this.lockStat=true;
             this.lockActivity=true;
             this.lockStatus   ="enable"
             
             this.dayEndCycle=this.res.activity_locking;
            }else{
              this.lockStat=false;
                this.lockStatus   ="disable"
              this.lockActivity=false;
            }
            if( this.res.override_days !== null && this.res.override_days !== ''){
              this.overrideStat=true;
              this.overrideActivity=true;
              this.overStatus="enable"
              this.overridedDays=this.res.override_days;
             }else{
                this.overrideStat=false;
                this.overStatus="disable"
                this.overrideActivity=false;
              }
            this.paydayItem = this.res.pay_day;
            this.paydayChecked =[this.endOfCycle.findIndex(x => x.val == this.res.pay_day)];
           
        }})
      }
      getStatus(st){
        if(st == '1'){
          return 'Active'
        }else if(st == '2'){
          return 'Inactive'
        }else{
          return 'Delete'
        }
      }


}

