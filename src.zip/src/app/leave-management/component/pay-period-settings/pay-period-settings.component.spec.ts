import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayPeriodSettingsComponent } from './pay-period-settings.component';

describe('PayPeriodSettingsComponent', () => {
  let component: PayPeriodSettingsComponent;
  let fixture: ComponentFixture<PayPeriodSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayPeriodSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayPeriodSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
