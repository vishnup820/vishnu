import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeRegularisationComponent } from './employee-regularisation.component';

describe('EmployeeRegularisationComponent', () => {
  let component: EmployeeRegularisationComponent;
  let fixture: ComponentFixture<EmployeeRegularisationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeRegularisationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeRegularisationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
