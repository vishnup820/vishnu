import { Component, OnInit, Renderer, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { RegularisationApprovalService } from '../../services/regularisation-approval/regularisation-approval.service';

import { EmployeeRegularisationService } from '../../services/employee-regularisation/employee-regularisation.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
declare var require: any;
var moment = require('moment');
@Component({
	selector: 'app-employee-regularisation',
	templateUrl: './employee-regularisation.component.html',
	styleUrls: ['../../../../assets/content/css/employee_regularisation.css']
})
export class EmployeeRegularisationComponent implements OnInit, OnDestroy {

	currentPage: number = 1;
	recordsPerPage: number = 10;
	rollId: number;
	totalRecords: number;
	deleteIndex: number;

	config: string;

	formerror: boolean = false;
	lazyLoad: boolean = false;
	addEditTab: boolean = false;
	addEditStatus: boolean = false;
	searchTextBox: boolean = false;
	confirmBox: boolean = false;
	dateerror: boolean = false;
	filterTextBox: boolean = false;
	filterStatus: boolean = false;
	isDuplicate: boolean;

	maxDate: Date = new Date();
	minDate: Date = new Date('1900');

	listenFunc: any;
	reason: any;
	editdata: any;
	empList: any = [];
	empSearch: any;
	empDetails: any;
	employeeList: any;
	empCode: any;
	empId: any;
	searchValue: any;
	advanceFilterData: any;
	empIdSearch: any;
	type: any = [{ "id": 1, "name": "Full Day" }, { "id": 2, "name": "Half day(1st Half)" }, { "id": 3, "name": "Half day(2nd Half)" }];
	attendance: any = [{ "id": 1, "name": "Present" }, { "id": 2, "name": "Absent" }];
	//dayTime                   : any = [{"id" : 1, "name" : "Full Day"},{"id" : 2, "name" : "Half day(First Half)"},{"id" : 3, "name" : "Half day(Seacond Half)"}];
	dateArray: any = [];

	// form1                     : FormGroup;
	// empSearch                 : FormControl;
	userType: boolean = false;
	empEditId: any;
	userData: any;
	payPeriod: any;
	payExtraPeriod: any;
	userlocId: any;
	userzone: any;
	userid: any;
	localref: string = '';
	fileToUpload: File = null;

	approvalDetails: any;
	approveId: any;
	configDelete: any;
	role: any;
	messageData: any;
	selectChat: any;
	selectedChat: any;
	selectedList: any;
	fullData: any = [];
	// approveRejectData     : any;

	entryBlock: boolean = false;
	chatConfirm: boolean = false;
	responceLoad: boolean = true;
	compensatoryDatesId: number;
	userId: number;

	rejectStatus: boolean = false;
	nodata: boolean = false;
	cancelButtonId: any;
	chatMessage: any = "";
	cancelPopUp: boolean = false;

	constructor(
		private employeeRegularisationService: EmployeeRegularisationService,
		private notificationService: NotificationService,
		private loaderActionsService: LoaderActionsService,
		private renderer: Renderer,
		private cookies: CookieService,
		private chRef: ChangeDetectorRef,
		private timeZone: TimezoneDetailsService,
		private regularisationApprovalService: RegularisationApprovalService) { }

	ngOnInit() {
		this.userData = JSON.parse(this.cookies.get("user-data"));
		this.userzone = this.userData.time_zone;
		this.userlocId = this.userData.location_id;
		let endDate = this.timeZone.getCurrentDate();
		this.maxDate = new Date(endDate.setDate(endDate.getDate() - 1));
		// this.maxDate = this.timeZone.getCurrentDate();
		this.userid = this.userData.user_id;
		let self = this;
		if (localStorage.getItem("itemsperpage")) {
			this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			this.recordsPerPage = 10;
		}
		this.rollId = JSON.parse(this.cookies.get('user-data')).role_id;
		this.loaderActionsService.display(true);
		// this.empId  = (JSON.parse(this.cookies.get('user-data')).username).toUpperCase()+"("+JSON.parse(this.cookies.get('user-data')).employee_id+")";
		this.empId = (JSON.parse(this.cookies.get('user-data')).first_name) + " " +
			(JSON.parse(this.cookies.get('user-data')).last_name) + " (" + (JSON.parse(this.cookies.get('user-data')).employee_id) + ")";
		this.config = "Are You Sure You Want To Delete?";
		if (this.rollId == 4 || this.rollId == 2) {
			this.getEmpDetails();
			this.empIdSearch = this.empId;
		}
		this.chRef.detectChanges();
		// this.getEmployeeList(this.currentPage);
	}

	ngOnDestroy() {
		this.listenFunc;
	}

	/*
	 author : Arun Johnson
	 desc   : get employee List
	*/
	getEmployeeList(page) {
		this.currentPage = page;
		this.loaderActionsService.display(true);
		this.employeeRegularisationService.getEmployeeList(this.currentPage, this.recordsPerPage, this.searchValue, this.advanceFilterData, res => {
			if (res.status == "OK" && res.data && res.data.length) {
				this.employeeList = res.data;
				this.totalRecords = res.count;
				if (this.employeeList && this.employeeList.length) {
					let tempArray = [];
					for (let i = 0; i < this.employeeList.length; i++) {
						this.employeeList[i].basic.messageStatus = false;
						this.employeeList[i].basic.chatLoad = false;
						this.employeeList[i].basic.display = false;
						let secondHand = [];
						for (var j = 0; j < this.employeeList[i].basic.detail.length; j++) {
							secondHand.push({ date: this.employeeList[i].basic.detail[j].applied_date, status: this.employeeList[i].basic.detail[j].status });
						}
						tempArray.push(secondHand);
					}
					let checkDate = this.timeZone.getCurrentDate();
					for (var i = 0; i < tempArray.length; i++) {
						for (var j = 0; j < tempArray[i].length; j++) {
							if (moment(checkDate).isBefore(moment(moment(tempArray[i][j].date).add('days', 1)))) {
								this.employeeList[i].basic.display = true;
								break;
							}
							else {
								this.employeeList[i].basic.display = false;
							}
						}
					}
				}
				this.loaderActionsService.display(false);
			}
			else {
				this.employeeList = [];
				this.loaderActionsService.display(false);
			}
		})
	}

	/*
	   author : Arun Johnson
	   desc   : send Filter Data
	   params :
	  */
	filterData(event) {
		if (event || this.advanceFilterData) {
			this.advanceFilterData = event;
			this.currentPage = 1;
			this.getEmployeeList(this.currentPage);
		}
		else
			this.advanceFilterData = undefined;
	}
	/*
	 author : Arun Johnson
	 desc   : Search  when enter key is pressed
	*/
	search(value) {
		this.searchValue = value;
		this.currentPage = 1;
		this.getEmployeeList(this.currentPage);
	}

	/*
	 author : Arun Johnson
	 desc   : create new form for seperate for edit and add
	*/
	addNewForm() {
		this.dateerror = false;
		for (let i = 0; i < this.dateArray.length; i++) {
			if (!this.dateArray[i].start_date) {
				this.dateerror = true;
			}
			if (this.dateArray[i].start_date_status) {
				this.dateerror = true;
			}
			if (!this.dateArray[i].type_value || this.dateArray[i].type_value.length == 0) {
				this.dateerror = true;
			}
			if (!this.dateArray[i].type_Attendance || this.dateArray[i].type_Attendance.length == 0) {
				this.dateerror = true;
			}
		}
		if (!this.dateerror) {
			this.dateArray.push({
				"start_date": null,
				"application_type": [0],
				"type_value": 0,
				"application_attendance": [0],
				"type_Attendance": 0,
				"start_date_status": false
			});
		}
	}

	/*
	 author : Arun Johnson
	 desc   : get emp details
	*/
	getEmpList(list) {
		this.empDetails = list;
		this.searchTextBox = false;
		this.empEditId = list.code;
		this.userid = list.user_id;
		this.userlocId = list.location_id;
		this.userzone = list.timezone;
		this.empIdSearch = list.first_name + " " + list.last_name + " (" + list.code + ")";
		if (this.empEditId != this.userData.employee_id) {
			this.userType = false;
		}
		else {
			this.userType = true;
		}
		this.empSearch = null;
		this.checkWithPayperiod();
		let endDate = this.getCurrentDate(list.timezone);
		this.maxDate = new Date(endDate.setDate(endDate.getDate() - 1));
	}

	/*
	 author : Arun Johnson
	 desc   : new Add Form
	*/
	dateForm() {
		this.dateArray = [];
		this.reason = null;
		this.userType = true;
		// this.empIdSearch = null;
		this.empIdSearch = this.empId;
		this.empSearch = null;
		this.empCode = null;
		this.dateArray = [];
		this.dateArray.push({
			"start_date": null,
			"application_type": [0],
			"type_value": 0,
			"application_attendance": [0],
			"type_Attendance": 0,
			"start_date_status": false
		});
		this.lazyLoad = true;
		this.checkWithPayperiod();
	}
	getlastday(y, m) {
		return new Date(y, m, 0).getDate();
	}
	/*
  author : vinod
  desc   : get emp details  from api
 */

	checkWithPayperiod() {
		let last = false
		let val = false;
		this.employeeRegularisationService.getValidations(this.userid, (this.userlocId) ? this.userlocId : null, (this.userzone) ? this.userzone : null, res => {
			if (res.message == "No data found") {
				this.lazyLoad = false;
			}
			else {
				this.payPeriod = (res && res.data) ? res.data.payPeriodDay : undefined;
				this.payExtraPeriod = (res && res.data && res.data.overRideDay) ? Number(res.data.overRideDay) : undefined;
				let date = this.timeZone.getCurrentDate()

				let tempDate = moment(this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth() + 1) + "-" + Number(this.payPeriod)), 'MM-DD-YYYY HH:mm').add(this.payExtraPeriod + 1, 'days');
				let nextCycleStart = tempDate.toDate()
				let nextMonthStart = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth() + 1) + "-" + (Number(this.payPeriod) + 1))
				let tempPay = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth()) + "-" + (Number(this.payPeriod) + 1))

				// let tempDate = moment(this.timeZone.toLocal(date.getFullYear() + "-"+ Number(date.getMonth() + 1) + "-" + Number(this.payPeriod)), 'MM-DD-YYYY HH:mm').add(this.payExtraPeriod + 1, 'days');+
				// let y = tempDate.toDate()
				// let t = this.timeZone.toLocal(date.getFullYear() + "-" +Number(date.getMonth() + 1) + "-" + (Number(this.payPeriod)+1))
				if (this.payPeriod == "29") {
					last = true;
					this.payPeriod = this.getlastday(date.getFullYear(), (date.getMonth()))
				}
				let tempDate2 = moment(this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth()) + "-" + Number(this.payPeriod)), 'MM-DD-YYYY HH:mm').add(this.payExtraPeriod, 'days');
				if (!this.userType) {
					if (this.userData.role_id == 2 || this.userData.role_id == 4) {
						if (date.getDate() >= Number(this.payPeriod)) {
							if (Date.parse(tempDate.toDate()) >= Date.parse(moment(this.timeZone.getCurrentDate(), 'MM-DD-YYYY HH:mm').toDate())) {
								this.minDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth()) + "-" + (Number(this.payPeriod) + 1));
							}
							else {
								if (last) {
									this.minDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth()) + "-" + (Number(this.payPeriod) + 1));
								}

								else {
									this.minDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth() + 1) + "-" + (Number(this.payPeriod) + 1));
								}
							}
						}
						else {
							if ((nextCycleStart != undefined) || (nextCycleStart! = null) || (nextCycleStart != "Invalid Date")) {
								let currentDay = new Date(date.getFullYear(), date.getMonth(), date.getDate())
								let lastdaywithExtapayprd = new Date(tempDate2.toDate().getFullYear(), tempDate2.toDate().getMonth(), tempDate2.toDate().getDate())
								if (Number(nextCycleStart.getMonth()) > Number(nextMonthStart.getMonth()) && (currentDay <= lastdaywithExtapayprd)) {
									val = true;
								}
								else if (Number(nextCycleStart.getMonth()) == 0 && Number(nextMonthStart.getMonth()) == 11 && (currentDay <= lastdaywithExtapayprd)) {
									val = true;
								}
							}
							if (val) {
								if (last) {
									this.minDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth()) + "-" + 1);
								}
								else {
									this.minDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth() - 1) + "-" + (Number(this.payPeriod) + 1));
								}
							} else {
								let currentDay = new Date(date.getFullYear(), date.getMonth(), date.getDate())
								let lastdaywithExtapayprd = new Date(tempDate2.toDate().getFullYear(), tempDate2.toDate().getMonth(), tempDate2.toDate().getDate())
								if (currentDay <= lastdaywithExtapayprd) {
									this.minDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth() - 1) + "-" + (Number(this.payPeriod) + 1));

									// this.startDate = this.timeZone.toLocal(date.getFullYear()+"-"+ Number(date.getMonth()) + "-" + (Number(this.payPeriod)+1));
									// this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
								} else {
									this.minDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth()) + "-" + (Number(this.payPeriod) + 1));
									// this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
								}
							}
						}
					}
					else {
						if (date.getDate() > Number(this.payPeriod)) {
							this.minDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth() + 1) + "-" + (Number(this.payPeriod) + 1));
						}
						else {
							this.minDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth()) + "-" + (Number(this.payPeriod) + 1));
						}
					}
				}
				else {
					if (!last) {

						if (date.getDate() >= tempPay.getDate()) {
							this.minDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth() + 1) + "-" + (Number(this.payPeriod) + 1));
						}
						else {
							this.minDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth()) + "-" + (Number(this.payPeriod) + 1));
						}
					}
					else {
						this.minDate = this.timeZone.toLocal(date.getFullYear() + "-" + Number(date.getMonth()) + "-" + (Number(this.payPeriod) + 1))
					}
					// this.minDate  = this.timeZone.toLocal(res.data.financialYear.start_date);
					// this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
					// this.minDate = this.timeZone.getCurrentDate();
				}
				this.lazyLoad = false;
			}
		})
	}

	getEmpDetails() {
		this.lazyLoad = true;
		this.employeeRegularisationService.getEmpDetails(res => {
			if (res.message == "No data found") {
				this.empList = [];
				this.lazyLoad = false;
			}
			else {
				this.empList = res.data;
				this.lazyLoad = false;
			}
		})
	}

	/*
	 author : Arun Johnson
	 desc   : confirm popup
	*/
	confirmPopup() {
		this.confirmBox = false;
		this.deleteindividualPeople();
	}

	/*
	 author : Arun Johnson
	 desc   : delete the people
	 params : index of check box
	*/
	deleteindividualPeople() {
		let selectedPeople: any = this.employeeList[this.deleteIndex];
		this.loaderActionsService.display(true);
		this.employeeRegularisationService.deletePeople(selectedPeople, res => {
			if (res.status == "Success") {
				this.notificationService.alertBoxValue("success", res.msg.message);
				this.getEmployeeList(1);
			} else {
				this.loaderActionsService.display(false);
				this.notificationService.alertBoxValue("error", res.msg.message);
			}
		});
	}

	/*
	 author : Arun Johnson
	 desc   : from date from date picker
	*/
	startDate(index, date, event) {
		this.dateerror = false;
		this.addEditTab = true;
		this.dateArray[index]['start_date'] = date;
		this.dateArray[index]['start_date_status'] = false;
		// for (let i = 0; i < this.dateArray.length; i++) {
		// 	if (i != index && this.employeeRegularisationService.formateDate(date) == this.employeeRegularisationService.formateDate(this.dateArray[i].start_date) && date) {
		// 		this.dateArray[index]['start_date_status'] = true;
		// 	}
		// }
	}

	/*
	 author : Arun Johnson
	 desc   : delete form
	*/
	deleteForm(index) {
		this.dateArray.splice(index, 1);
	}

	/*
	 author : Arun Johnson
	 desc   : type multiselect set data
	*/
	typeEvent(event, index) {
		event.selected.length !== 0 ? this.dateArray[index]['type_value'] = event.selected[0].id : this.dateArray[index]['type_value'] = [];

	}

	/*
	 author : Arun Johnson
	 desc   : attendance multiselect set data
	*/
	attendanceEvent(event, index) {
		event.selected.length !== 0 ? this.dateArray[index]['type_Attendance'] = event.selected[0].id : this.dateArray[index]['type_Attendance'] = [];

	}


	/*
	author : Arun Johnson
	desc   : edit Form
	params : index of check box
   */
	editForm(data, event) {
		this.searchTextBox = false;
		this.addEditStatus = false;
		this.editdata = data;
		this.userType = true;
		this.addEditTab = true;
		this.lazyLoad = true;
		this.employeeRegularisationService.regularizationIdDetails(data.basic.id, res => {
			this.lazyLoad = false;
			if (res.status == "OK") {
				this.dateArray = [];
				this.empCode = data.basic.id;
				this.reason = data.basic.reason_for_request;
				let dateArray = res.data[0].basic.detail;
				this.empIdSearch = res.data[0].basic.user_name + "(" + res.data[0].basic.code + ")";
				for (let i = 0; i < (dateArray && dateArray.length); i++) {
					let typeIndex;
					let attendanceIndex;
					dateArray[i].application_type == "Full Day" ? typeIndex = 0 : dateArray[i].application_type == "1st Half" ? typeIndex = 1 : dateArray[i].application_type == "2nd Half" ? typeIndex = 2 : typeIndex = 0;
					dateArray[i].application_attendance == "Present" ? attendanceIndex = 0 : dateArray[i].application_attendance == "Absence" ? attendanceIndex = 1 : attendanceIndex = 0;

					if (dateArray[i].applied_date_status != "Rejected") {
						this.dateArray.push({
							"start_date": this.timeZone.toLocal(dateArray[i].applied_date),
							"application_type": [typeIndex],
							"type_value": 0,
							"start_date_status": false,
							"application_attendance": [attendanceIndex],
							"type_Attendance": 0
						})
					}
					if (this.dateArray.length == 0) {
						this.dateArray.push({
							"start_date": null,
							"application_type": [0],
							"type_value": 0,
							"application_attendance": [0],
							"type_Attendance": 0,
							"start_date_status": false
						});
					}
				}
			}
		})
	}

	/*
	author : Arun Johnson
	desc   : delet form
   */
	submitForm() {
		let fullday = [];
		let halfday = [];
		for (let i = 0; i < this.dateArray.length; i++) {
			let dateFormated = this.employeeRegularisationService.formateDate(this.dateArray[i].start_date);
			this.dateArray[i].checkValue = dateFormated + this.dateArray[i].type_value + this.dateArray[i].type_Attendance;

			if (this.dateArray[i].type_value == 1) {
				fullday.push({ 'date': dateFormated, 'type': this.dateArray[i].type_value, 'attendance': this.dateArray[i].type_Attendance })
			} else {
				halfday.push({ 'date': dateFormated, 'type': this.dateArray[i].type_value, 'attendance': this.dateArray[i].type_Attendance })
			}
			// this.fullData.push({'date': dateFormated,'type': this.dateArray[i].type_value,'attendance': this.dateArray[i].type_Attendance})
		}
		var valueArr = (this.dateArray.map(function (item) { return item.checkValue }));
		this.isDuplicate = valueArr.some(function (item, idx) {
			return valueArr.indexOf(item) != idx
		});

		if (!this.isDuplicate) {
			if (fullday.length > 0) {
				for (let i = 0; i < fullday.length; i++) {
					if (halfday.length > 0) {
						for (let j = 0; j < halfday.length; j++) {
							if (fullday[i].date == halfday[j].date) {
								this.isDuplicate = true;
							}
						}
					}
				}
			}
		}

		this.formerror = false;
		this.dateerror = false;
		if (!this.empIdSearch && this.rollId != 1) {
			this.formerror = true;
		}
		for (let i = 0; i < this.dateArray.length; i++) {
			if (!this.dateArray[i].start_date) {
				this.dateerror = true;
			}
			// if (this.dateArray[i].start_date_status) {
			// 	this.dateerror = true;
			// }
			if (!this.dateArray[i].type_value || this.dateArray[i].type_value.length == 0) {
				this.dateerror = true;
			}
			if (!this.dateArray[i].type_Attendance || this.dateArray[i].type_Attendance.length == 0) {
				this.dateerror = true;
			}
		}
		if (!this.reason || this.reason.trim() == "") {
			this.reason = null;
			this.formerror = true;
		}


		if (!this.isDuplicate) {

			if (!this.addEditStatus && !this.formerror && !this.dateerror) {
				this.lazyLoad = true;
				this.employeeRegularisationService.editRegularisation(this.editdata, this.dateArray, this.reason.trim(), this.empCode, res => {
					this.lazyLoad = false;
					if (res.status == "OK") {
						this.formerror = false;
						this.addEditTab = false;
						this.notificationService.alertBoxValue("success", res.message);
						this.getEmployeeList(this.currentPage);
					} else if (res.status == "fail") {
						this.addEditTab = false;
						this.getEmployeeList(this.currentPage);
						this.notificationService.alertBoxValue("error", res.message.toString());
					}
					// else {
					// 	this.notificationService.alertBoxValue("error", res.message);
					// }
				})
			} else if (!this.formerror && !this.dateerror) {
				this.lazyLoad = true;
				this.employeeRegularisationService.addRegularisation(this.empDetails, this.dateArray, this.reason.trim(), res => {
					this.lazyLoad = false;
					if (res.status == "OK") {
						this.formerror = false;
						this.addEditTab = false;
						this.notificationService.alertBoxValue("success", res.message);
						this.getEmployeeList(this.currentPage);
						// }
					} else if (res.status == "fail") {
						this.addEditTab = false;
						this.getEmployeeList(this.currentPage);
						this.notificationService.alertBoxValue("error", res.message.toString());
					}
				})
			}

		} else {
			if (this.empDetails || this.reason) {
				this.notificationService.alertBoxValue("error", "You have already selected the same type for the same date(s)");
			}
		}





	}

	/*
*  @desc   :method for pagination
*  @author :dipin
*/
	getpage(event) {
		if (event > 10 || this.recordsPerPage != 10) {
			this.recordsPerPage = event;
			this.currentPage = 1;
			this.getEmployeeList(this.currentPage);
		}
	}

	getCurrentDate(input) {
		let userData = JSON.parse(this.cookies.get("user-data"));
		if (userData.apply_datetime_conversion == '1') {
			let value = moment().tz(input).format('Z');
			value = this.timeStringToFloat(value);
			value = value.replace(":", '.');
			return this.calcTime(value)
		}
		else {
			return new Date();
		}
	}

	timeStringToFloat(time) {
		var hoursMinutes = time.split(/[.:]/);
		var hours = parseInt(hoursMinutes[0], 10);
		var minutes = hoursMinutes[1] ? parseInt(hoursMinutes[1], 10) : 0;
		return (hours + minutes / 60).toString();
	}

	calcTime(offset, value?) {
		let d, utc, nd;
		if (value) {
			d = moment.utc(value).toDate();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
		else {
			d = new Date();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
	}

	/*
*  @desc   :show previous messages using api call
*  @author :dipin
*/
	showMessage(index, id) {
		for (let i = 0; i < this.employeeList.length; i++) {
			if (index == i) {
				this.employeeList[i].basic.messageStatus = !this.employeeList[i].basic.messageStatus;
				if (this.employeeList[i].basic.messageStatus) {
					this.messageData = [];
					this.responceLoad = true;
					this.employeeList[index].basic.chatLoad = true;
					this.employeeRegularisationService.showMessage(id, res => {
						if (res.status == "OK") {
							let self = this;
							this.messageData = res.data;
							for (var i = 0; i < this.messageData.length; i++) {
								let diff = Math.abs((moment.utc(this.messageData[i].send_time).toDate().getTime() - moment.utc().toDate().getTime()) / 1000);
								diff = Math.abs(diff);
								if (Number(diff) >= 300) {
									this.messageData[i].deleteIcon = false;
								}
								else {
									this.messageData[i].deleteIcon = true;
								}
							}
							this.employeeList[index].basic.chatLoad = false;
							this.responceLoad = false;
							setTimeout(function () {
								$("#top-chat").mCustomScrollbar("scrollTo", "bottom");
								if (document.getElementById("chatBox")) {
									if (self.selectedChat == id) {
										document.getElementById("chatBox").innerHTML = self.chatMessage;
									}
									else {
										self.selectedChat = id;
										self.chatMessage = '';
									}
									document.getElementById("chatBox").focus();
								}
							});
						}
						else {
							this.employeeList[index].basic.chatLoad = false;
							this.responceLoad = false;
						}
					})
				}
			}
			else {
				this.employeeList[i].basic.messageStatus = false;
			}
		}
	}

	/*
	*  @desc   :method send messages to the server with sender's id
	*  @author :dipin
	*/
	sendMessage(index, id) {
		if (this.chatMessage != '' && this.chatMessage.trim() != '') {
			this.entryBlock = true;
			let obj = {
				"user_id": this.userData.user_id,
				"regularization_id": id,
				"message": this.chatMessage.trim()
			};
			document.getElementById("chatBox").innerHTML = '';
			setTimeout(function () {
				document.getElementById("chatBox").focus();
			});
			this.messageData.push({
				'id': '',
				"first_name": this.userData.first_name,
				"last_name": this.userData.last_name,
				"message": this.chatMessage.trim(),
				"photo": this.userData.photo,
				"send_time": moment.utc().toDate().getTime(),
				"user_id": this.userData.user_id,
				'status': 1
			});
			this.chatMessage = '';
			this.messageData[this.messageData.length - 1].sent = true;
			setTimeout(function () {
				$("#top-chat").mCustomScrollbar("scrollTo", "bottom");
			});
			this.employeeRegularisationService.addMessage(obj, res => {
				if (res.status == "Success") {
					this.messageData[this.messageData.length - 1].sent = false;
					this.messageData[this.messageData.length - 1].id = res.id;
					this.messageData[this.messageData.length - 1].deleteIcon = true;
					this.entryBlock = false;
				}
				else {
					this.notificationService.alertBoxValue("error", res.message);
					this.entryBlock = false;
					this.messageData.pop();
					this.messageData[this.messageData.length - 1].sent = false;
					this.messageData[this.messageData.length - 1].deleteIcon = false;
				}
			})
		}
	}

	/*
	*  @desc   :method to close all the popup of chat message while hovet on messages
	*  @author :dipin
	*/
	closeAllPopup() {
		this.chatConfirm = false;
		for (let i = 0; i < this.approvalDetails.length; i++) {
			this.approvalDetails[i].messageStatus = false;
		}
	}

	/*
	 *  @desc   :method to display selected type of list
	 *  @author :dipin
	 */
	deleteMessage() {
		this.messageData[this.selectChat].sent = true;
		this.employeeRegularisationService.deleteChat(this.userData.user_id, this.messageData[this.selectChat].id, res => {
			if (res.status == "Success") {
				for (let i = 0; i < this.messageData.length; i++) {
					if (this.messageData[i].id == res.message_id) {
						this.messageData[i].sent = false;
						this.messageData[i].delete = true;
					}
				}
			}
			else {
				this.notificationService.alertBoxValue("error", res.message);
				this.messageData[this.selectChat].sent = false;
				this.messageData[this.selectChat].delete = false;
			}
		})
	}

	/*
	*  @desc   :method to display selected type of list
	*  @author :dipin
	*/
	formatDate(date) {
		var strTime = date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds();
		return date.getFullYear() + "-" + Number(date.getMonth() + 1) + "-" + date.getDate() + "  " + strTime;
	}

	setMessageIcon() {
		if (this.messageData)
			if (this.messageData.length) {
				for (var i = 0; i < this.messageData.length; i++) {
					let diff = Math.abs((moment.utc(this.messageData[i].send_time).toDate().getTime() - moment.utc().toDate().getTime()) / 1000);
					diff = Math.abs(diff);
					if (Number(diff) >= 300) {
						this.messageData[i].deleteIcon = false;
					}
					else {
						this.messageData[i].deleteIcon = true;
					}
				}
			}
	}

    /*
   author : dipin
   desc   : add class based on index
  */
	getClassByValue(index) {
		return this.regularisationApprovalService.getClassByValue(index);
	}
}
