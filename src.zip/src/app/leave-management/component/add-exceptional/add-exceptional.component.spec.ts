import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddExceptionalComponent } from './add-exceptional.component';

describe('AddExceptionalComponent', () => {
  let component: AddExceptionalComponent;
  let fixture: ComponentFixture<AddExceptionalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddExceptionalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddExceptionalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
