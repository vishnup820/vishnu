/*
*  @desc   :component for add holiday popup
*  @author :dipin
*/
import { Component, OnInit,Input,Output,EventEmitter,OnChanges,SimpleChanges,ViewChild,
         AfterViewInit} from '@angular/core';
import { FormGroup,FormControl, Validators,FormBuilder } from '@angular/forms';
import { MalihuScrollbarService } from 'ngx-malihu-scrollbar';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { ExceptionalDetailsService } from '../../services/exceptional-details.service';
import {apiList}  from '../../../shared/constants/apilist';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { BsDatepickerDirective } from 'ngx-bootstrap/datepicker';
import { CookieService } from 'ngx-cookie-service';
declare var require: any;
var moment = require('moment');
@Component({
  selector: 'hris-exceptional',
  templateUrl: './add-exceptional.component.html',
  styleUrls: ['./add-exceptional.component.css']
})
export class AddExceptionalComponent implements OnInit {

  @Input()  addStatus  : boolean;
  @Input()  editStatus : boolean;
  @Input()  editConfig : any;
  @Output() valueChange = new EventEmitter();
  @Output() successPro  = new EventEmitter();
  @ViewChild(BsDatepickerDirective) datepicker: BsDatepickerDirective;

  addForm     : FormGroup;
  yearField   : FormControl;
  titleField  : FormControl;
  dateFieldF  : FormControl;
  dateFieldT  : FormControl;
  reason      : FormControl;

  submitted      : boolean = false;
  setApplicable  : boolean = false;
  lazyLoad       : boolean = false;
  confirmClear   : boolean = false;
  yearList       : any     = [];
  yearSelected   : any     = [];
  selectedYear   : any;
  firstDate      : any;
  startDate      : any;
  endDate        : any;
  options        : any;
  secondDate     : any;
  selectedData   : any;
  uCurrent       : any;
  userData       : any;
  dateStatus     : boolean = false;
  predefinedId   : any = [];
  exceptionalDay  : any;
  holidayDay      : any;
  minDate        : Date = new Date('1900');
  maxDate        : Date = new Date('2500');

  constructor(private apiService: ExceptionalDetailsService,
    private notifications: NotificationService,
    private mScrollbarService: MalihuScrollbarService,
    private cookieService    : CookieService,
    private timezone       : TimezoneDetailsService){
}

  ngOnInit() {
  
    let date = this.timezone.getCurrentDate();
    let self = this;
    this.options = {
      axis: 'y',
      theme: 'minimal-dark',
      autoHideScrollbar: false,
      advanced: {
        autoScrollOnFocus: 'false'
      },
      callbacks: {
        whileScrolling: function() {
          if(self.datepicker.isOpen)
              self.datepicker.hide();
        }
      }
    };
    this.userData = JSON.parse(this.cookieService.get("user-data"));
    this.predefinedId = [{
      id: 1, name: "location"
    },
    { id: 2, name: "user" },
    { id: 3, name: "group" },
    { id: 4, name: "department" },
    { id: 5, name: "designation" }
    ]
    this.createFormControls();
    this.createForm();
    this.addForm.reset();
    this.uCurrent = apiList.leaveManagement.editExceptional;
  }

  ngOnChanges(changes: SimpleChanges) {
    let date = this.timezone.getCurrentDate()
    window.scrollTo(0, 0);
    this.lazyLoad = true;
    if (this.editStatus) {
      this.uCurrent = apiList.leaveManagement.editExceptional;
      this.apiService.listCalenderYear(response => {
        if (response.status == "OK") {
          this.yearList = response.data;
        
        for (var i = 0; i < this.yearList.length; i++) {
          if (this.editConfig.financial_year_id == this.yearList[i].id) {
            this.minDate = this.timezone.toLocal(this.yearList[i].start_date);
            this.maxDate = this.timezone.toLocal(this.yearList[i].end_date);
            this.yearSelected = [i];
          
          
            break;
           }
           
        }
        localStorage.setItem('fyValue', this.editConfig.financial_year_id);
          this.lazyLoad = false;
        }
        else {
          this.yearList = [];
          this.lazyLoad = false;
        }
      })
      this.addForm.patchValue({
        yearField: this.editConfig.year,
        titleField: this.editConfig.title,
        dateFieldF: this.timezone.toLocal(this.editConfig.exception_date),
        dateFieldT: this.timezone.toLocal(this.editConfig.compensatory_date),
        reason: this.editConfig.reason
      });
      // this.yearSelected = (this.editConfig.year == date.getFullYear()) ? [1] : [0];
    }
    else
      if (this.addForm) {
        this.addForm.reset();
        this.apiService.listCalenderYear(response => {
          if (response.status == "OK") {
            this.yearList = response.data;
            // this.yearSelected = [0];
            if(this.yearList.length>0){
              for(let i=0;i<this.yearList.length;i++){
                if(this.yearList[i].start_date==this.userData.finActive_start && this.yearList[i].end_date==this.userData.finActive_end ){
                  this.yearSelected=[i];
                  localStorage.setItem('fyValue',this.yearList[i].id);
                }
              }
            }
            this.minDate = this.timezone.toLocal(this.yearList[0].start_date);
            this.maxDate = this.timezone.toLocal(this.yearList[0].end_date);
            this.lazyLoad = false;
          }
          else {
            this.yearList = [];
            this.lazyLoad = false;
          }
        })
        this.submitted = false;
      }
  }

  /*
  *  @desc   :Create and define form controls of createNew form
  *  @author :dipin
  */
  createFormControls() {
    this.yearField  = new FormControl('', [Validators.required]);
    this.titleField = new FormControl('', [Validators.required,this.noWhitespaceValidator]);
    this.dateFieldF = new FormControl('');
    this.dateFieldT = new FormControl('');
    this.reason     = new FormControl('');
  }

   /*
    author : dipin
    desc   : validation for white space in form
    params :
  */
  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }

  /*
*  @desc   :create form itemForm and addForm
*  @author :dipin
*/
  createForm() {
    this.addForm = new FormGroup({
      yearField  : this.yearField,
      titleField : this.titleField,
      dateFieldF : this.dateFieldF,
      dateFieldT : this.dateFieldT,
      reason     : this.reason
    });
  }

  /*
  *  @desc   :hide popup and emit false value for parent component
  *  @author :dipin
  */
  cancelPopup() {
    this.addStatus = false;
    this.addForm.reset();
    this.valueChange.emit(false);
  }

  /*
  *  @desc   : validating submited data send t the server using api call
  *  @author : dipin
  */
  addHoliday() {
    let outputData = [];
    let nonOutData = [];
    let exception_date= this.formatForApi(this.dateFieldF.value);
    let compensatory= this.formatForApi(this.dateFieldT.value);
        if(exception_date==compensatory){
        this.dateStatus = true;
        this.notifications.alertBoxValue("error", " Exceptional Working Date and Exceptional Holiday Date Cannot Be Same!");
      }
      else{
        this.dateStatus = false;
      }
    this.submitted = true;
    if (this.selectedData) {
      for (var i = 0; i < this.selectedData.applicable.length; i++) {
        for (var j = 0; j < this.predefinedId.length; j++) {
          if (this.predefinedId[j].name == this.selectedData.applicable[i].name) {
            if (this.selectedData.applicable[i].selectedAll == true) {
              outputData.push({ category: this.predefinedId[j].id, reference_id: 0 });
            }
            else {
              for (var k = 0; k < this.selectedData.applicable[i].list.length; k++) {
                if (this.selectedData.applicable[i].list[k].is_selected == 1) {
                  outputData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.applicable[i].list[k].id });
                }
              }
            }
          }
        }
      }

      for (var i = 0; i < this.selectedData.notApplicable.length; i++) {
        for (var j = 0; j < this.predefinedId.length; j++) {
          if (this.predefinedId[j].name == this.selectedData.notApplicable[i].name) {
            if (this.selectedData.notApplicable[i].selectedAll == true) {
              nonOutData.push({ category: this.predefinedId[j].id, reference_id: 0 });
            }
            else {
              for (var k = 0; k < this.selectedData.notApplicable[i].list.length; k++) {
                if (this.selectedData.notApplicable[i].list[k].is_selected == 1) {
                  nonOutData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.notApplicable[i].list[k].id });
                }
              }
            }
          }
        }
      }
    }
    this.addForm.controls['dateFieldF'].setErrors(null);
    this.addForm.controls['dateFieldT'].setErrors(null);
    this.addForm.updateValueAndValidity();
    if (this.addForm.invalid || outputData.length == 0 || this.dateStatus || this.dateFieldF.value==null && this.dateFieldT.value==null ) {
      if(outputData.length == 0 && this.addForm.valid){
        this.setApplicable = true;
        this.notifications.alertBoxValue("error", "Select Options For Applicable For");
      }
      if( this.dateFieldF.value==null &&  this.dateFieldT.value==null){
        if (this.dateFieldF.value==null) {
          document.getElementById("date-of-joing").focus();
          this.mScrollbarService.scrollTo("top",document.getElementById("date-of-joing"),{scrollInertia:0});
        }
        else if (this.dateFieldT.value==null) {
          document.getElementById("date-of-joingT").focus();
          this.mScrollbarService.scrollTo("top",document.getElementById("date-of-joingT"),{scrollInertia:0});
        }
      }
    if (!this.titleField.valid) {
      this.mScrollbarService.scrollTo("top",document.getElementById("last-name"),{scrollInertia:0});
      document.getElementById("last-name").focus();
    }
    else if (!this.reason.valid) {
      document.getElementById("description").focus();
    }
    // else if (!this.dateFieldF.valid) {
    //   document.getElementById("date-of-joing").focus();
    //   this.mScrollbarService.scrollTo("top",document.getElementById("date-of-joing"),{scrollInertia:0});
    // }
    // else if (!this.dateFieldT.valid) {
    //   document.getElementById("date-of-joingT").focus();
    //   this.mScrollbarService.scrollTo("top",document.getElementById("date-of-joingT"),{scrollInertia:0});
    // }
      return;
    }
    else {
      this.lazyLoad = true;
      this.setApplicable = false;
      let temp = {
        calendar_id: this.selectedYear.id,
        title: this.titleField.value.trim(),
        exception_date: this.formatForApi(this.dateFieldF.value),
        compensatory_date: this.formatForApi(this.dateFieldT.value),
        reason: this.reason.value,
        financial_year_id: this.selectedYear.id,
        applicable_for: outputData,
        not_applicable_for : nonOutData
      }


      if (this.editStatus) {
        this.apiService.updateCalenderDetails(temp, this.editConfig.id, response => {
          if (response.status == "OK") {
            this.notifications.alertBoxValue("success", "Exceptional Working Day Updated Successfully");
            setTimeout(() => {
              this.cancelPopup();
              this.lazyLoad = false;
              this.successPro.emit(true);
            }, 600);
          }
          else {
            this.notifications.alertBoxValue("error", response.message);
            this.lazyLoad = false;
            this.successPro.emit(false);
          }
        })
      }
      else {
        this.apiService.addCalenderDetails(temp, response => {
          if (response.status == "OK") {
            this.notifications.alertBoxValue("success", "Exceptional Working Day Added Successfully");
            setTimeout(() => {
              this.cancelPopup();
              this.lazyLoad = false;
              this.successPro.emit(true);
            }, 600);
          }
          else {
            this.notifications.alertBoxValue("error", response.message);
            this.lazyLoad = false;
            this.successPro.emit(false);
          }
        })
      }
    }
  }

  /*
  *  @desc   : method deal with year field single selection
  *  @author : dipin
  */
  selectedDataYear(event) {
    this.selectedYear = event.selected[0];
    if (event.selected.length){
       this.addForm.patchValue({
        yearField: event.selected[0].year_title
      });
      let sameYearCheck;
       for(var i = 0 ; i < this.yearList.length;i++){
         if(event.selected[0].year_title == this.yearList[i].year_title){
            this.minDate = this.timezone.toLocal(this.yearList[i].start_date);
            this.maxDate = this.timezone.toLocal(this.yearList[i].end_date);
            sameYearCheck=i;

            break;
         }
       }
        let  checkFyValue;
       if (localStorage.getItem('fyValue')) {
        checkFyValue = Number(localStorage.getItem('fyValue'));
      }
      if(checkFyValue!= event.selected[0].id){
        this.confirmClear=true
      }else{
        this.confirmClear=false
      }
       if(this.confirmClear ){
        this.addForm.patchValue({
          dateFieldF: null,
          dateFieldT: null
        });

       }
      
   
    }
    else
      this.addForm.patchValue({
        yearField: null
      })
  }

  /*
 *  @desc   : method deal with year field single selection
 *  @author : dipin
 */
  selectedStatusList(event) {
    if (event.selected.length)
      this.addForm.patchValue({
        statusField: event.selected[0].value
      })
    else
      this.addForm.patchValue({
        statusField: null
      })
  }

  /*
 *  @desc   : method deal with conversion of date format
 *  @author : dipin
 */
  formatDate(inputDate) {
    var date = this.timezone.toLocal(inputDate);
    if (!isNaN(date.getTime())) {
      if ((Number(date.getMonth()) + 1) < 10) {
        if (Number(date.getDate() < 10)) {
          return "0" + date.getDate() + "-0" + (Number(date.getMonth()) + 1) +"-"+ date.getFullYear();
        }
        else {
         return date.getDate() + "-0" + (Number(date.getMonth()) + 1) +"-"+ date.getFullYear();
        }
      }
      else {
        if (Number(date.getDate() < 10)) {
         return date.getDate() +"-"+ (Number(date.getMonth()) + 1) +"-"+ date.getFullYear();
        }
        else {
          return  date.getDate() +"-"+ (Number(date.getMonth()) + 1) +"-"+ date.getFullYear();
        }
      }
    }
  }

  formatForApi(inputDate) {
    var date = this.timezone.toLocal(inputDate);
    if(date)
    if (!isNaN(date.getTime())) {
      if ((Number(date.getMonth()) + 1) < 10) {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
      else {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
    }
    else
      return undefined;
  }

  checkDay(event,value){
    if(event!=null){
      let selectedDate=event;
      let  date=new Date(selectedDate).getDate();
      let month=new Date(selectedDate).getMonth();
      let year=new Date(selectedDate).getFullYear();
      let fulldate = date +'/'+ month +'/'+ year;
      if(value == 0){
       this.firstDate = event;
       this.exceptionalDay=fulldate;
      }
      else{
       this.secondDate = event;
       this.holidayDay=fulldate;
      }
    
      //   if(this.exceptionalDay==this.holidayDay){
      //   this.dateStatus = true;
      //   this.notifications.alertBoxValue("error", "Dates Cannot Be Same!");
      // }
      // else{
      //   this.dateStatus = false;
      // }

    }
   
  }
}
