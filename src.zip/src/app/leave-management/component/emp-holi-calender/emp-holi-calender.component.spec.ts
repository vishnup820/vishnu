import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpHoliCalenderComponent } from './emp-holi-calender.component';

describe('EmpHoliCalenderComponent', () => {
  let component: EmpHoliCalenderComponent;
  let fixture: ComponentFixture<EmpHoliCalenderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmpHoliCalenderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpHoliCalenderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
