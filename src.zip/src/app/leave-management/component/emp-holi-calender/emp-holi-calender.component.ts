/*
*  @desc   :component for display holiday calender for employee
*  @author :hashid
*/
import { Component, OnInit } from '@angular/core';

import { CookieService } from 'ngx-cookie-service';
import { EmpHoliCalenderService } from '../../services/emp-holi-calender.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

@Component({
  selector: 'app-emp-holi-calender',
  templateUrl: './emp-holi-calender.component.html',
  styleUrls: ['./emp-holi-calender.component.css']
})
export class EmpHoliCalenderComponent implements OnInit {
	tableData     : any     = [];
	totalSelected : any     = 0;
	currentPage   : number  = 1;
 	recordsPerPage: number  = 10;
  totalRecords  : number;
  applySort     : any;
  editStatus    : boolean;
  addStatus     : boolean;
  editConfig    : any;
  updateList    : any;
  filterSort    : any     = {};
  queryObject   : any     = {};

	yearList      : any;
	yearSelected  :any ;
	usedata       :any ;
	typeSelected  :any = []
	typeChecked   :any = []
  filterActive  : boolean = false;
  filterStatus  : boolean = false;
  constructor(
  	private apiService    : EmpHoliCalenderService,
    private loaderService : LoaderActionsService,
	private timeZone      :TimezoneDetailsService,
	private cookieService: CookieService
  ) { }

  ngOnInit() {
		this.loaderService.display(true);

		if(this.cookieService.get("user-data")){
			this.usedata =	JSON.parse(this.cookieService.get("user-data"));
		 }
		 
    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
	}
	

    this.apiService.listCalenderYear(response => {
			if (response.status == "OK") {
				this.yearList = response.data;
				let currentYear=this.timeZone.getCurrentDate().getFullYear();
				if(this.yearList.length>0){
					for(let i=0;i<this.yearList.length;i++){
						if(	this.yearList[i].year==currentYear){
						 this.typeChecked=[i];
						 this.yearSelected=this.yearList[i].year;
						}
					}
				}
				this.getData(this.currentPage);

			}
		})
  	// this.getData(this.currentPage);
  }

 /*
	*  @desc   :method to update list by api call
  	*  @author :hashid
	*/
 getData(page){
		this.loaderService.display(true);
		this.currentPage = page;
      this.apiService.getEmploHoliDetails(this.currentPage,this.recordsPerPage,this.yearSelected, this.usedata.user_id,response => {
			if (response.status == "OK") {
				if(response.data){
                 this.tableData = response.data;
				}
				else
				  this.tableData = [];

				this.totalRecords = response.count;
				this.loaderService.display(false);
			}
			else {
				this.tableData = [];
				this.loaderService.display(false);
			}
		})
  }
  	/*
    author : Nilena Alexander
     desc   : status event of singleselect
     params :  event selected data
   */
  financialyearList(event) {
    if (event.selectedIndex.length != 0) {
      this.typeChecked = event.selectedIndex;
    }
    else {
      this.typeChecked = [];
    }
    this.typeSelected = event;
  }
 	/*
	*  @desc   :method to get seleced financial year
  	*  @author :nilena
	*/
	selectedDataYear(event){
		if (event.selectedIndex.length != 0) {
			this.typeChecked = event.selectedIndex;
			this.yearSelected = event.selected[0].year

		  }
		  else {
			this.typeChecked = [];
		  }
		  this.typeSelected = event;
	}
	/*
	*  @desc   :method to apply filter
  	*  @author :nilena
	*/
	filterApply(){
		let statusFil = this.typeSelected && this.typeSelected.selected && this.typeSelected.selected[0] && this.typeSelected.selected[0].year ? this.typeSelected.selected[0].year : 0;
		let loader = this.apiService.checkFilterStatus(
			statusFil
		  );
		  if (loader) {
			this.filterActive = true;
			if (this.yearList) {
			  if (this.typeSelected.selected.length) {
				if (this.typeSelected.selected[0].year) {
					this.yearSelected = this.typeSelected.selected[0].year
				} 
			  }
			  else {
				this.yearSelected = null;
			  }
			  this.currentPage = 1;
			  this.getData(this.currentPage);
			}
		  }
		  else {
			this.currentPage = 1;
			this.filterActive = false;
			this.yearSelected = null;
			this.typeChecked = null
		}
	}
	 /*
   * @ desc    : method for filter cancel
   * @ author  : Nilena Alexander
   */
	filterCancel() {
		if (this.apiService.checkFilterCanCancel()) {
			this.yearSelected = null;
			this.typeChecked = null;
			this.currentPage = 1;

			let currentYear = this.timeZone.getCurrentDate().getFullYear();
			if (this.yearList.length > 0) {
				for (let i = 0; i < this.yearList.length; i++) {
					if (this.yearList[i].year == currentYear) {
						setTimeout(() => { this.typeChecked = [i]; }, 100)
						
						this.yearSelected = this.yearList[i].year;
					}
				}
			}
			this.getData(this.currentPage);

		}

		let currentYear = this.timeZone.getCurrentDate().getFullYear();
		if (this.yearList.length > 0) {
			for (let i = 0; i < this.yearList.length; i++) {
				if (this.yearList[i].year == currentYear) {
					this.typeChecked = [i];
					this.yearSelected = this.yearList[i].year;
				}
			}
		}
		this.filterActive = false;
		this.yearSelected = null;
		this.apiService.clearFilterStatus();
		// this.typeChecked = null;
	}


	sortFilter(label) {
    let currentSortStatus = this.filterSort[label]?this.filterSort[label].rev: true;
    this.filterSort = {};
    this.filterSort[label] = {rev:!currentSortStatus}
    this.filterSort["label"] = label;
    this.queryObject.sort = (this.filterSort[label].rev == true)?`${'&sort=-'}${label}`:`${'&sort='}${label}`
    this.dataSort();
  }

  dataSort(){
  		let self = this;
      this.apiService.getSortValue(this.currentPage,this.recordsPerPage,this.queryObject, this.yearSelected, this.usedata.user_id,function(res){
        if(res) {
        self.tableData = res.data;
        } else {
          self.tableData = [];
        }
    });
  }

  /*
  *  @desc   :method for pagination
  *  @author :vinod
  */
  getpage(event) {
    if (event > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      this.getData(this.currentPage);
    }
  }
}










