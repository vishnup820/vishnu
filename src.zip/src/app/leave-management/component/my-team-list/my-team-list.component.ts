/*
*  @desc   :component for display teamlist fo corresponding user and manage
*  @author :dipin
*/
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MyTeamListService } from '../../services/team-list/my-team-list.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-my-team-list',
  templateUrl: './my-team-list.component.html',
  styleUrls: ['./my-team-list.component.css']
})
export class MyTeamListComponent implements OnInit {

  currentPage       : number = 1;
  recordsPerPage    : number = 10;
  advanceFilterData : any;
  searchValue       : any;
  searchD           : any;
  filterSort        : any = {};
  queryObject       : any = {};
  nodata            : boolean = false;
  dummyPeopleData   : any = [];
  totalRecords      : any;
  searchTextBox     : boolean = false;
  filterStatus      : boolean = false;
  usedata           : any;
  filterActive      : boolean = false;
  heading           : any;
  @ViewChild('foc') inputEl: ElementRef;

  constructor(
    private myTeamListService: MyTeamListService,
    private loaderActionsService: LoaderActionsService,
    private cookieService: CookieService) { }

  ngOnInit() {
    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    this.getPeople(this.currentPage);
  }

  /*
  *  @desc   :list team members
  *  @author :dipin
  */
  getPeople(cPage) {
    if (this.cookieService.get("user-data")) {
      this.usedata = JSON.parse(this.cookieService.get("user-data"));
      if (this.usedata.role_id == 3 || this.usedata.role_id == 4) {
        this.heading = "My Team List"
      }
      else if (this.usedata.role_id == 2) {
        this.heading = "My Team List"
      }
      else {
        this.heading = "Employee List"
      }
    }
    this.currentPage = cPage;
    this.loaderActionsService.display(true);
    this.myTeamListService.getPeople(this.currentPage, this.recordsPerPage, this.advanceFilterData, this.searchValue, this.queryObject, res => {
      if (res.status == "OK" && res.data && res.data.length) {
        this.totalRecords = res.count;
        this.dummyPeopleData = res.data;
        this.nodata = false;
      }
      else {
        this.dummyPeopleData = [];
        this.nodata = true;
      }
      this.loaderActionsService.display(false);
    })
  }

  /*
  *  @desc   :search team members
  *  @author :dipin
  */
  search(searchKey) {
    if (this.searchValue || this.searchD.trim() != '') {
      this.searchValue = searchKey;
      this.currentPage = 1;
      this.getPeople(this.currentPage);
    }
  }

  /*
  *  @desc   :filter team members
  *  @author :dipin
  */
  filterData(event) {
    if(event||this.advanceFilterData ){
      this.currentPage = 1;
      this.advanceFilterData = event;
      if (this.advanceFilterData) {
        if ((this.advanceFilterData.department && this.advanceFilterData.department.selected.length) || (this.advanceFilterData.designation && this.advanceFilterData.designation.selected.length) || (this.advanceFilterData.location && this.advanceFilterData.location.selected.length) || (this.advanceFilterData.role && this.advanceFilterData.role.selected.length)) {
          this.filterActive = true;
        }
        else {
          this.filterActive = false;
        }
      } else {
        this.filterActive = false;
      }
      this.getPeople(this.currentPage);
    }
    else{
    event= undefined;
    }
    
  }

  /*
  *  @desc   :sort team members
  *  @author :dipin
  */
  sortDepartment(sortfield) {
    let currentSortStatus = this.filterSort[sortfield] ? this.filterSort[sortfield].rev : true;
    this.filterSort = {};
    this.filterSort[sortfield] = { rev: !currentSortStatus }
    this.filterSort["label"] = sortfield;
    this.queryObject.sort = `${this.filterSort[sortfield].rev ? '-' : ''}${sortfield}`;
    this.getPeople(this.currentPage);
  }

  /*
  *  @desc   :method to focus search
  *  @author :dipin
  */
  inputfocus() {
    setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
  }

  /*
  *  @desc   :method for pagination
  *  @author :dipin
  */
  getpage(event) {
    if (event > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      this.getPeople(this.currentPage);
    }
  }

}
