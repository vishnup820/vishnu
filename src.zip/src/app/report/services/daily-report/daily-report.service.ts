import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList }  from '../../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class DailyReportService {
  apiBaseUrl  : string;
  date:any;

  constructor(private http: HttpClient) {
  	this.apiBaseUrl = globalVariables.apiBaseUrl;
   }

    /*
 	 author : vinod.k
 	 desc   : get initial report
    */
  get_dailyreport(date,loc,dep,call_back){
        this.date = this.formateDate(date);
		let url: string = this.apiBaseUrl + apiList.report.details;
		let promise: any = new Promise((resolve, reject) => {
			let sDepPart = (dep != null)?"&dep_id="+dep:"";
			this.http.get(url + "?dte="+this.date+"&loc_id="+loc+sDepPart)
				.toPromise()
				.then(res => {
					call_back(res);
				})
		})
  }
  /*
 	 author : vinod.k
 	 desc   : change date date
    */
	formateDate(date) {
		if (date) {
			var curr_date = date.getDate();
			var curr_month = date.getMonth() + 1; //Months are zero based
			var curr_year = date.getFullYear();
			return (curr_year + "-" + curr_month + "-" + curr_date)
		}
	}

     /*
 	 author : vinod.k
 	 desc   : load report based on location and department
    */
	loadReportsForselected(obj,call_back){
	    this.date = this.formateDate(obj.date_selected);
	    let urlparam = this.generatequeryString(obj);
		let url: string = this.apiBaseUrl + apiList.report.details+"?dte="+this.date;
		url = url + urlparam;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					call_back(res);
				})
		})
	}

	/*
 	 author : vinod.k
 	 desc   : genarate url query parameter
    */
	generatequeryString(obj){
		let urlstring = `${obj.loc?'&loc_id='+obj.loc:''}${obj.dep?'&dep_id='+obj.dep:''}`
		return urlstring;
	}

	getLocations(cb) {
      let url: string =  this.apiBaseUrl + apiList.location.details;
      let promise: any = new Promise((resolve, reject) => {
        this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
       })
     })
    }
}
