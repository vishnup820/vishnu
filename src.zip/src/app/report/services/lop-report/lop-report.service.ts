import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList }  from '../../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class LopReportService {
  apiBaseUrl  : string;
  sortData:any;
  // date:any;
  searchItem:any;
  constructor(private http: HttpClient) { this.apiBaseUrl = globalVariables.apiBaseUrl}

 /*
 	 author : vinod.k
 	 desc   : get Lop report details
    */
  get_dailyLopreport(dates,fdates,loc,call_back){
		let url: string = this.apiBaseUrl + apiList.report.lopReport;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "?loc="+loc+"&frmDate="+dates+"&toDate="+fdates)
				.toPromise()
				.then(res => {
					call_back(res);
				})
		})
  }

  /*
 	 author : vinod.k
 	 desc   : get Lop report details based on pagination
    */
	getLopReport(dates,fdates,page, per_page,loc,sort, cb) {
		let url: string = this.apiBaseUrl + apiList.report.lopReport;
		let sortData = this.getExactQuery(sort);
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "?loc="+loc +"&offset=" + page + "&perpage=" + per_page+"&frmDate="+dates+"&toDate="+fdates + sortData)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

    /*
 	 author : vinod.k
 	 desc   : get Lop report on search
    */
	getLopSearchReport(dates,fdates,month,searchVal,id,cb){
		let url: string = this.apiBaseUrl + apiList.report.lopReport;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "?mnth="+ month +"&loc="+id + "&keyword=" + searchVal+"&frmDate="+dates+"&toDate="+fdates)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

    /*
 	 author : vinod.k
 	 desc   : get Lop report based on sort
    */
	getEmployeeSort(frdate,todate,qobj,id,cb){
		this.sortData = this.getExactQuery(qobj);
		let url: string = this.apiBaseUrl + apiList.report.lopReport;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "?frmDate="+ frdate + "&toDate="+ todate + "&loc="+ id + this.sortData)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	/*
 	 author : vinod.k
 	 desc   : get the query based on sort
    */
	getExactQuery(qobj){
		let query = `${qobj.sort?'&sort=' + qobj.sort: ''}`
		return query;
	}

	exportExcelData(dates,fdates,searchKey,id,cb){
		if(searchKey != null){
			this.searchItem = "/1" + "?loc="+id+"&keyword=" + searchKey;
		}
		else{
			this.searchItem = "/1" + "?loc="+ id;
		}
		let url: string = this.apiBaseUrl + apiList.report.excelReport + this.searchItem + "&frmDate="+dates+"&toDate="+fdates;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	getClassByValue(index) {
        switch (index % 10) {
            case 0: return "default-avatar islamic-green";
            case 1: return "default-avatar limerick";
            case 2: return "default-avatar chilean-fire";
            case 3: return "default-avatar persian-pink";
            case 4: return "default-avatar deep-magenta";
            case 5: return "default-avatar gigas";
            case 6: return "default-avatar endeavour";
            case 7: return "default-avatar dodger-blue";
            case 8: return "default-avatar jordy-blue";
            case 9: return "default-avatar Light-sea-green";
            case 10: return "emp-profileimage";
        }
    }

    getLocations(cb) {
      let url: string =  this.apiBaseUrl + apiList.people.master;
      let promise: any = new Promise((resolve, reject) => {
        this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
       })
     })
    }

    getCurrentFinancialYear(loc,cb){
		 	let url:string;
		 	url = this.apiBaseUrl + apiList.report.finYear+"/"+loc+"/lop";
 		    let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
		 	})
		})
	}
}
