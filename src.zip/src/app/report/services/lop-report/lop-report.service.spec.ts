import { TestBed } from '@angular/core/testing';

import { LopReportService } from './lop-report.service';

describe('LopReportService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LopReportService = TestBed.get(LopReportService);
    expect(service).toBeTruthy();
  });
});
