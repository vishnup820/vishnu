import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList }  from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root'
})
export class StatusReportService {
 apiBaseUrl  : string;
 date:any;
 usedata:any;
 currDate : any;
 searchItem:any;
 savedStartDate:any;
 savedEndDate:any;
 savedMonth:any;
 savedMonthIndex:any;
 savedYearIndex:any
  constructor(private http: HttpClient,private cookieService: CookieService) {
   this.apiBaseUrl = globalVariables.apiBaseUrl
}

 getStatusReport(month, id, cb){
 	if(this.cookieService.get("user-data")){
  	    this.usedata =	JSON.parse(this.cookieService.get("user-data"));
  	}
 	let url:string;
 	if(this.usedata.role_id == 4){
 		url = `${this.apiBaseUrl}${apiList.report.roleStatus}/${this.usedata.user_id}/attendance-status-report`
 	}
    else{
    	url = this.apiBaseUrl + apiList.report.statusReport;
    }
      this.date = month;
      //stat=1 for resighned people inactive
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "?month="+ this.date +"&fid="+id)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
 }

 getSearchReport(month,searchVal,id,cb){
 	let url:string;
 	if(this.usedata.role_id ==4){
 		url = `${this.apiBaseUrl}${apiList.report.roleStatus}/${this.usedata.user_id}/attendance-status-report`
 	}
    else{
    	url = this.apiBaseUrl + apiList.report.statusReport;
    }
		// let url: string = this.apiBaseUrl + apiList.report.statusReport;
		let fullYear = month;
 		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "?month="+ fullYear + "&keyword=" + searchVal +"&fid="+id)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}
	loadReportsForselected(month,obj,cb){
    let url:string;
 	if(this.usedata.role_id ==4){
 		url = `${this.apiBaseUrl}${apiList.report.roleStatus}/${this.usedata.user_id}/attendance-status-report`
 	}
    else{
    	url = this.apiBaseUrl + apiList.report.statusReport;
    }
	    let urlparam = this.generatequeryString(obj);
	    let fulldate = month;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "?month="+ fulldate + urlparam)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	generatequeryString(obj){
		let urlstring = `${obj.loc?'&loc_id='+obj.loc:''}${obj.dep?'&dep_id='+obj.dep:''}`
		return urlstring;
	}

	loadStatusOnscroll(page,perpage,month,id,cb){
	let url:string;
 	if(this.usedata.role_id == 4){
 		url = `${this.apiBaseUrl}${apiList.report.roleStatus}/${this.usedata.user_id}/attendance-status-report`
 	}
    else{
    	url = this.apiBaseUrl + apiList.report.statusReport;
    }
		let fullYear = month;
 		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "?month="+ fullYear + "&page=" + page + "&limit=" + perpage +"&fid="+id)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	getCurrentFinancialYear(cb){
		 	let url:string;
		 	url = this.apiBaseUrl + apiList.report.finYear;
 		    let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
		 	})
		})
	}

	getIndex(dateObj){
	  this.currDate = new Date();
	  let k = this.currDate.getMonth();
	  switch (k) {
	  	case 0:
	  	return 9;
	  		break;
	  	case 1:
	  	return 10;
	  		break;
	  	case 2:
	  	return 11;
	  		break;
	  	case 3:
	  	return 0;
	  		break;
	  	case 4:
	  	return 1;
	  		break;
	  	case 5:
	  	return 2;
	  		break;
	  	case 6:
	  	return 3;
	  		break;
	  	case 7:
	  	return 4;
	  		break;
	  	case 8:
	  	return 5;
	  		break;
	  	case 9:
	  	return 6;
	  		break;
	  	case 10:
	  	return 7;
	  		break;
	  	case 11:
	  	return 8;
	  		break;
	  	default:
	  		// code...
	  		break;
	  }
	}

	exportExcelData(keyword,month,yearid,cb){
		if(keyword != null && keyword !=""){
			this.searchItem = "?month=" + month  + "&keyword=" + keyword;
		}
		else{
			this.searchItem = "?month=" + month;
		}
		 	let url:string;
		 	url = this.apiBaseUrl + apiList.report.statusReportExport + this.searchItem + "&fid="+yearid;
 		    let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
		 	})
		})
	}
}
