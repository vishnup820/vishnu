import { TestBed } from '@angular/core/testing';

import { LatecomingService } from './latecoming.service';

describe('LatecomingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LatecomingService = TestBed.get(LatecomingService);
    expect(service).toBeTruthy();
  });
});
