import { Component, OnInit , ElementRef,ViewChild,ChangeDetectorRef } from '@angular/core';
// import { LopReportService } from '../services/lop-report/lop-report.service';
import { LatecomingService } from '../services/late-coming/latecoming.service';
import {PlatformLocation } from '@angular/common';
import { globalVariables } from '../../shared/constants/globals';
import { LoaderActionsService } from '../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';
import * as FileSaver from 'file-saver';
import { StatusReportService } from '../services/status-report/status-report.service';
import { TimezoneDetailsService } from '../../shared/services/timezone-details/timezone-details.service';
declare var require: any;
var moment = require('moment');

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs';
import { first } from 'rxjs/operators';
import { merge } from 'rxjs/observable/merge';

@Component({
  selector: 'app-late-coming-report',
  templateUrl: './late-coming-report.component.html',
  styleUrls: ['../../../assets/content/css/lop-report.css']
})
export class LateComingReportComponent implements OnInit {

  monthArray            : any=[];
  status                : number=0;
  date                  : any;
  lop_details           : any=[];
  tooltipArray          : any = [];
  searchValue           : any ="";
  searchTextBox         : boolean = false;
  totalRecords      : number;
  currentPage       : number = 1;
  recordsPerPage    : number = 10;
  nodata                : boolean        = false;
  moveToTop         : boolean = false;
  month                 : any;
  selectedIEvent        : any;
  searchKey             : any;
  selectedItems         : any = [];
  locationSelected      : any = [];
  searchD               : any;
  filterSort            : any = {};
  queryObject           : any = {};
  apiBaseUrl            : any;
  imagePath             : any;
  locationList          : any;
  currentZone           : any;
  currentId             : any;
  currentDate           : any;
  downloadUrl           : any;
  fileURL               : any;
  finMonths             : any;
  eData                 : boolean = false;
  @ViewChild('foc') inputEl:ElementRef;
  @ViewChild('a') a: any;
  sdate                 : any;
  fdate                 : any;

  showAdvanceFilter     : boolean = false;
  filterActive          : boolean = false;
  disablePayperiod      : boolean = false;
  finYearstatus         : number = 0;
  dateRangeValue        : any = [];
  max                   : Date;
  locEvent              : any = [];
  locationerror         : boolean = false;
  daterangeError        : boolean = false;
  payperiodrangeError   : boolean = false;
  statusInit            : number = 0;
  ind                   : any;
  loaderPayperiod       : boolean = false;
  userData                         : any
  minDate                          : any;

  constructor(private LatecomingService: LatecomingService,
              private platformLocation: PlatformLocation,
              private el: ElementRef,
              private loaderActionsService: LoaderActionsService,
              private cookieService: CookieService,
              private statusReportService: StatusReportService,
              private timeZone: TimezoneDetailsService,
              private changeRef: ChangeDetectorRef) 
              {
               this.apiBaseUrl = globalVariables.apiBaseUrl;
              }

  ngOnInit() {

    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    if (this.cookieService.get("user-data")) {
      this.userData = JSON.parse(this.cookieService.get("user-data"));
      this.minDate= new Date(this.userData.financialMin_date);
    }
 
    this.queryObject['page'] = this.currentPage;
    this.queryObject['limit'] = this.recordsPerPage;

    this.max = this.timeZone.getCurrentDate();
    let date = new Date(); 
    let value = [];
    this.dateRangeValue = [new Date(date.getFullYear(), date.getMonth(), 1),this.timeZone.getCurrentDate()]
    this.sdate = this.formatForApi(this.dateRangeValue[0]);
    this.fdate = this.formatForApi(this.dateRangeValue[1]);
    let self = this;
    this.loaderActionsService.display(true);
      this.LatecomingService.getLocations(response => {
        if (response.status == 'OK') {
          self.locationList = response.data;
          let x = []
          let userData = JSON.parse(this.cookieService.get("user-data"));
          for (let i = 0; i < self.locationList.location.length; i++) {
            this.locationSelected.push(i);
            x.push(self.locationList.location[i].id)
          }
           this.currentId = x +'';
          this.lopOnCurrentDate();
        }
        else {
          self.loaderActionsService.display(false);
          self.locationList = [];
        }
      });
    }


    /*
    author : vinod.k
    desc   : get the initial data based on current month
    */
  lopOnCurrentDate() {
    this.loaderActionsService.display(true);
    this.eData = false;
    
    this.LatecomingService.get_dailyLopreport(this.queryObject, this.searchKey?this.searchKey:null ,(this.sdate)?this.sdate:null,(this.fdate)?this.fdate:null, this.currentId, res => {
      this.eData = true;
      if (res) {
        this.lop_details = res.data;
        if (res.data.length > 0) {
          this.currentPage = this.queryObject.page;
          this.totalRecords = res.count;
          let  morngingDAte=[];
          let morngingTime=[];
          let evengDate=[];
          let evengTime=[];
          let morningdata  =[]
          let eveningdata=[];
          let lateComingMorningTime =[];
          let earlyGoingTime =[];
          let evengdata={}

          for(let i=0;i< this.lop_details.length;i++){
           
            if(this.lop_details[i].gracetime_morning_time!=null){
                var latecomingArray = this.lop_details[i].gracetime_morning_time;
                   for( let j=0;j<latecomingArray.length; j++){
                    var splitarray= latecomingArray[j].split(" ");
                     var date1 = splitarray[0];
                     var time1= splitarray[1];
                     morningdata.push({date:date1 , time:time1})
                   }
                   this.lop_details[i].morningData = morningdata;
                   morningdata = [];
              }

                if(this.lop_details[i].gracetime_evening_time!=null){
                  var latecomingArray = this.lop_details[i].gracetime_evening_time;
                  for( let j=0;j<latecomingArray.length; j++){
                   var splitarray= latecomingArray[j].split(" ");
                    var date1 = splitarray[0];
                    var time1= splitarray[1];
                    eveningdata.push({date:date1 , time:time1})
                  }
                  this.lop_details[i].eveningdata = eveningdata;
                  eveningdata = [];
                  }

                  if(this.lop_details[i].late_coming_morning_time!=null){
                    var latecomingArray = this.lop_details[i].late_coming_morning_time;
                    for( let j=0;j<latecomingArray.length; j++){
                     var splitarray= latecomingArray[j].split(" ");
                      var date1 = splitarray[0];
                      var time1= splitarray[1];
                      lateComingMorningTime.push({date:date1 , time:time1})
                    }
                    this.lop_details[i].lateComingMorningTime = lateComingMorningTime;
                    lateComingMorningTime = [];
                    }

                    if(this.lop_details[i].early_going_time!=null){
                      var latecomingArray = this.lop_details[i].early_going_time;
                      for( let j=0;j<latecomingArray.length; j++){
                       var splitarray= latecomingArray[j].split(" ");
                        var date1 = splitarray[0];
                        var time1= splitarray[1];
                        earlyGoingTime.push({date:date1 , time:time1})
                      }
                      this.lop_details[i].earlyGoingTime = earlyGoingTime
                      earlyGoingTime = [];
                      }
                    }
                    this.nodata = false;
        }
        else {
          this.lop_details = [];
          this.nodata = true;
        }
      }
      this.statusInit = 1;
      this.loaderActionsService.display(false);
    })
  }

  /*
    author : vinod.k  
    desc   : month chabge event trigger
    */
  selectedMonth(event) {
    if(!this.disablePayperiod){
       this.ind = event.selectedIndex[0] + 1;
       this.payperiodrangeError = false;
       this.sdate = (event && event.selected.length)?event.selected[0].frmDate:null;
       this.fdate = (event && event.selected.length)?event.selected[0].toDate:null;
    }
  }

  /*
    author : vinod.k
    desc   : format date
    */
  convertDate(date) {
    var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "June",
      "July", "Aug", "Sep", "Oct", "Nov", "Dec"];
    if (date != 0) {
      var curr_month = monthNames[date.getMonth()];
      var curr_date = date.getDate();
      var curr_year = date.getFullYear();
      var curr_day = days[date.getDay()];
      return (curr_date + "th" + " " + curr_month + " " + curr_year + " " + curr_day)
    }
  }

  inputfocus() {
    setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
  }
   /**
* @ desc   : TO implement pagination
* @ author  : Nilena Alexander
*/
pageChangeEvent(page) {
  this.queryObject.page = page;
  this.currentPage = 1;
  this.lopOnCurrentDate();
}
/*
 * @ desc   : TO implement pagination
 * @ author  : Nilena Alexander
 */
getpage(eve) {
  if (eve > 10 || this.recordsPerPage != 10) {
    this.recordsPerPage = eve;
    this.queryObject['limit'] = eve;
    this.queryObject['page'] = 1;
    this.currentPage = 1;
    this.lopOnCurrentDate();
  }
}
  // /*
  //   author : vinod.k
  //   desc   : get report based on pagination
  //   */
  // getReport(event) {
    
  //   this.loaderActionsService.display(true);
  //   this.currentPage = event;
  //   this.LatecomingService.getLopReport(this.sdate,this.fdate, this.currentPage, this.recordsPerPage, this.currentId,this.queryObject, res => {
  //     if (res.status == "OK" && res.data.length) {
  //       this.totalRecords = res.count;
  //       this.lop_details = res.data;
  //       this.nodata = false;
  //     }
  //     else {
  //       this.lop_details = [];
  //       this.nodata = true;
  //     }
  //     this.loaderActionsService.display(false);
  //   })
  // }

  /*
    author : vinod.k
    desc   : get report based on search value
    */
  search(value) {
    if (this.searchValue || this.searchD.trim() != '') {
      this.searchValue = value;
      this.currentPage = 1;
      this.getSearchResult(this.searchValue);
    }
  }

  /*
    author : vinod.k
    desc   : get report based on search value (api call)
    */
  getSearchResult(event) {
    this.loaderActionsService.display(true);
    this.searchKey = event;
    if(this.searchKey==""){
      this.searchKey=null;
    }
    this.LatecomingService.getLopSearchReport(this.sdate,this.fdate,this.month, this.searchKey, this.currentId, res => {
      if (res.status == "OK" && res.data.length) {
        this.totalRecords = res.count;
        this.lop_details = res.data;
        let  morngingDAte=[];
        let morngingTime=[];
        let evengDate=[];
        let evengTime=[];
        let morningdata  =[]
        let eveningdata=[];
        let lateComingMorningTime =[];
        let earlyGoingTime =[];
        let evengdata={}
        if(res.data.length>0){

         
          for(let i=0;i< this.lop_details.length;i++){
           
            if(this.lop_details[i].gracetime_morning_time!=null){
                var latecomingArray = this.lop_details[i].gracetime_morning_time;
                   for( let j=0;j<latecomingArray.length; j++){
                    var splitarray= latecomingArray[j].split(" ");
                     var date1 = splitarray[0];
                     var time1= splitarray[1];
                     morningdata.push({date:date1 , time:time1})
                   }
                   this.lop_details[i].morningData = morningdata;
                   morningdata = [];
              }

                if(this.lop_details[i].gracetime_evening_time!=null){
                  var latecomingArray = this.lop_details[i].gracetime_evening_time;
                  for( let j=0;j<latecomingArray.length; j++){
                   var splitarray= latecomingArray[j].split(" ");
                    var date1 = splitarray[0];
                    var time1= splitarray[1];
                    eveningdata.push({date:date1 , time:time1})
                  }
                  this.lop_details[i].eveningdata = eveningdata;
                  eveningdata = [];
                  }

                  if(this.lop_details[i].late_coming_morning_time!=null){
                    var latecomingArray = this.lop_details[i].late_coming_morning_time;
                    for( let j=0;j<latecomingArray.length; j++){
                     var splitarray= latecomingArray[j].split(" ");
                      var date1 = splitarray[0];
                      var time1= splitarray[1];
                      lateComingMorningTime.push({date:date1 , time:time1})
                    }
                    this.lop_details[i].lateComingMorningTime = lateComingMorningTime;
                    lateComingMorningTime = [];
                    }

                    if(this.lop_details[i].early_going_time!=null){
                      var latecomingArray = this.lop_details[i].early_going_time;
                      for( let j=0;j<latecomingArray.length; j++){
                       var splitarray= latecomingArray[j].split(" ");
                        var date1 = splitarray[0];
                        var time1= splitarray[1];
                        earlyGoingTime.push({date:date1 , time:time1})
                      }
                      this.lop_details[i].earlyGoingTime = earlyGoingTime
                      earlyGoingTime = [];
                      }
                    }
                  }
                  this.nodata = false;
      }
      else {
        this.lop_details = [];
        this.nodata = true;
      }
      this.loaderActionsService.display(false);
    })
  }

  /*
   author : vinod.k
   desc   : get report based on sort value
   */
  sortDepartment(label) {
    let currentSortStatus = this.filterSort[label] ? this.filterSort[label].rev : true;
    this.filterSort = {};
    this.filterSort[label] = { rev: !currentSortStatus }
    this.filterSort["label"] = label;
    this.queryObject.sort = (this.filterSort[label].rev == true) ? `${'asc&sortField='}${label}` : `${'desc&sortField='}${label}`
    this.loadEmployee();
  }

  /*
  author : vinod.k
  desc   : get report based on sort value (api call)
  */
  loadEmployee() {
    let self = this;
    this.LatecomingService.getEmployeeSort(this.sdate,this.fdate, this.queryObject, this.currentId, function(res) {
      if (res) {
        self.lop_details = res.data;
        self.totalRecords = res.count;
        self.nodata = false;
      } else {
        self.lop_details = [];
        self.nodata = true;
      }
    });
  }

  /*
  author : vinod.k
  desc   : lop report download as excel
  */
  exportExcel() {
    this.loaderActionsService.display(true);
    this.LatecomingService.exportExcelData((this.sdate)?this.sdate:null,(this.fdate)?this.fdate:null, (this.searchKey) ? this.searchKey : null, this.currentId, res => {
      if (res && res.data) {
        let binary_string: any = window.atob(res.data);
        let len: any = binary_string.length;
        let bytes: any = new Uint8Array(len);
        for (var i = 0; i < len; i++) {
          bytes[i] = binary_string.charCodeAt(i);
        }
        let file: any = new Blob([bytes.buffer], { type: "application/vnd.ms-excel" });
        let filename: any = 'LopReport.xlsx';
        FileSaver.saveAs(file, filename);
      }
    })
    this.loaderActionsService.display(false);
  }

  getClassByValue(index) {
    return this.LatecomingService.getClassByValue(index);
  }

  // getpage(event) {
  //   if (event > 10 || this.recordsPerPage != 10) {
  //     this.recordsPerPage = event;
  //     this.currentPage = 1;
  //     this.getReport(this.currentPage);
  //   }
  // }

  getCurrentDate(input) {
    let userData = JSON.parse(this.cookieService.get("user-data"));
    if (userData.apply_datetime_conversion == '1') {
      let value = moment().tz(input).format('Z');
      value = this.timeStringToFloat(value);
      value = value.replace(":", '.');
      return this.calcTime(value)
    }
    else {
      return new Date();
    }
  }

  timeStringToFloat(time) {
    var hoursMinutes = time.split(/[.:]/);
    var hours = parseInt(hoursMinutes[0], 10);
    var minutes = hoursMinutes[1] ? parseInt(hoursMinutes[1], 10) : 0;
    return (hours + minutes / 60).toString();
  }

  calcTime(offset, value?) {
    let d, utc, nd;
    if (value) {
      d = moment.utc(value).toDate();
      utc = d.getTime() + (d.getTimezoneOffset() * 60000);
      nd = new Date(utc + (3600000 * offset));
      return nd
    }
    else {
      d = new Date();
      utc = d.getTime() + (d.getTimezoneOffset() * 60000);
      nd = new Date(utc + (3600000 * offset));
      return nd
    }
  }

  setLocation(event) {

    // this.loaderActionsService.display(true);
    let self = this;
    // && (this.selectedIEvent != event.selected[0])
    if (event.selected.length) {
      if(event.selected.length>1){
        self.disablePayperiod = true;
        this.selectedItems = [];
        this.changeRef.detectChanges();
      }else{
        self.loaderPayperiod = true;
        // self.dateRangeValue = [];
        self.disablePayperiod = false;
        // this.sdate = null;
        // this.fdate = null;
        this.changeRef.detectChanges();
      }
      let userData = JSON.parse(this.cookieService.get("user-data"));
      if(self.locationList && self.disablePayperiod){
        let x = [];
        // this.locationSelected = [];
        for (let i = 0; i < self.locationList.location.length; i++) {
            for(var j=0;j<event.selected.length;j++){
              if (self.locationList.location[i].id == event.selected[j].id) {
                x.push(self.locationList.location[i].id);
          }}
        }
            this.currentId = x +'';
      }
      if(this.finYearstatus == 1 && !this.disablePayperiod){
        this.currentZone = event.selected[0].timezone;
        this.currentId = event.selected[0].id +'';
        this.currentDate = this.getCurrentDate(event.selected[0].timezone);
        this.date = this.currentDate;
        this.month = this.date.getMonth() + 1;
        // this.LatecomingService.getCurrentFinancialYear((this.currentId)?this.currentId:null,res => {
        //   this.finMonths     = res.data.months;
        //   this.selectedItems = [this.getIndex(this.finMonths,res.data.endcycle)];
        // })
      }
      if(this.finYearstatus == 0 && !this.disablePayperiod){
        this.currentZone = event.selected[0].timezone;
        this.currentId = event.selected[0].id + '';
        this.currentDate = this.getCurrentDate(event.selected[0].timezone);
        this.date = this.currentDate;
        this.month = this.date.getMonth() + 1;
        // this.LatecomingService.getCurrentFinancialYear((this.currentId)?this.currentId:null,res => {
        //   this.finMonths     = res.data.months;
        //   this.selectedItems = [this.getIndex(this.finMonths,res.data.endcycle)];
        // })
        this.finYearstatus = 1;
      }
    }
    else {
      this.selectedItems = [];
      this.loaderPayperiod = false;
      this.selectedIEvent = undefined;
      this.locEvent       = undefined;
    }
      this.locEvent = event.selected

  }

  getlastday(y,m){
    return  new Date(y, m, 0).getDate();                      
  }

  getIndex(dateObj,endcycle) {
    let last = false;
    let tempDate;
    let currDate = this.getCurrentDate(this.currentZone);
    let date = this.timeZone.getCurrentDate()
    let k = currDate.getMonth();
    if(endcycle == "29"){
      last  = true;
        endcycle = this.getlastday(currDate.getFullYear(),(currDate.getMonth()))
    }
    if ((currDate.getDate() > Number(endcycle)) && !last) {
      tempDate = moment(this.timeZone.toLocal(date.getFullYear() + "-"+ Number(date.getMonth()+1) + "-" + Number(endcycle)), 'MM-DD-YYYY HH:mm');
    }else if((currDate.getDate() < Number(endcycle)) && !last){
      tempDate = moment(this.timeZone.toLocal(date.getFullYear() + "-"+ Number(date.getMonth()) + "-" + Number(endcycle)), 'MM-DD-YYYY HH:mm');
    }else if((currDate.getDate() == Number(endcycle)) && !last){
      tempDate = moment(this.timeZone.toLocal(date.getFullYear() + "-"+ Number(date.getMonth()) + "-" + Number(endcycle)), 'MM-DD-YYYY HH:mm');
    }
    else{
      tempDate = moment(this.timeZone.toLocal(date.getFullYear() + "-"+ Number(date.getMonth()) + "-" + 1), 'MM-DD-YYYY HH:mm');
    }
    for(var i =0;i<dateObj.length;i++){
       let  h = this.formatForApi(tempDate.toDate());
       if(moment(h).isBetween(moment(dateObj[i].frmDate).subtract(1,'d'), moment(dateObj[i].toDate).add(1,'d'))){
            this.loaderPayperiod = false;
            return i+1;
       } 
    }
  }

  /*
  *  @desc   : make date to the format 'dd-mm-yyyy'
  *  @author : nilena
  */
  formatForApi(inputDate) {
    var date = this.timeZone.toLocal(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
      }
      else
        return undefined;
  }

  dateRangeChange(date){
      if(this.disablePayperiod && date){
        this.daterangeError = false;
        // this.dateRangeValue = this.rangeFormat(date);
        this.sdate = this.formatForApi(this.dateRangeValue[0]);
        this.fdate = this.formatForApi(this.dateRangeValue[1]);
      }    
  }
  rangeFormat(value){
                    if(value.length){
                        // this.selectedItems = [];
                        // this.changeRef.detectChanges();
                        const range = value.map(d => moment(d).format('DD-MM-YYYY'));
                        return range[0] + ' - ' + range[1];
                    }
                    else{
                        return null;
                    }
                }


  filterApply(){
    if(this.locEvent.length){
      this.locationerror = false;
      if(this.locEvent.length>1 && !this.dateRangeValue.length){
        this.daterangeError = true;
        this.filterActive = true;
        this.disablePayperiod = true;
        this.selectedItems = [];
        this.showAdvanceFilter = true;
        this.payperiodrangeError = false;
      }else if(this.locEvent.length==1 && !this.selectedItems){
        this.showAdvanceFilter = true;
        this.daterangeError = false
        this.disablePayperiod = false;
        this.filterActive = true;
        this.payperiodrangeError = true
      }else{
        this.showAdvanceFilter = false;
        if(this.locEvent.length==1){
          this.selectedItems[0] = this.ind;
        }
        if(this.searchValue){
          this.searchKey=this.searchValue;
        }
        this.currentPage = 1;
        this.queryObject.page=1
        this.lopOnCurrentDate();
      }
    }
    else{
      this.currentPage = 1;
      this.queryObject.page=1
      this.showAdvanceFilter = true;
      this.locationerror = true;
      this.filterActive =false;

    }
  }

  filterCancel(){
    var self = this;
    let date = new Date(); 
    this.loaderPayperiod = false;
    this.dateRangeValue = [new Date(date.getFullYear(), date.getMonth(), 1),this.timeZone.getCurrentDate()]
    this.sdate = this.formatForApi(this.dateRangeValue[0]);
    this.fdate = this.formatForApi(this.dateRangeValue[1]);
    this.LatecomingService.getLocations(response => {
        if (response.status == 'OK') {
          self.locationList = response.data;
          let x = []
          let userData = JSON.parse(this.cookieService.get("user-data"));
          for (let i = 0; i < self.locationList.location.length; i++) {
              this.locationSelected.push(i);
               x.push(self.locationList.location[i].id)
           }
           this.currentId = x +'';
           if(!this.searchValue){
            this.searchKey=null;
           }
           this.queryObject.page=1;
           
           this.lopOnCurrentDate();
        }
        else {
          self.loaderActionsService.display(false);
          self.locationList = [];
        }
      });
  }
  topPositionData(event,z){
		let yPosition = event.clientY;
	 let innerheight  = window.innerHeight;
	 if(((innerheight)/2) < yPosition && (z>3)){
		this.moveToTop = true;
	}
	else{
	 this.moveToTop = false;
	}
	}
}
