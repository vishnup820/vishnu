import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LateComingReportComponent } from './late-coming-report.component';

describe('LateComingReportComponent', () => {
  let component: LateComingReportComponent;
  let fixture: ComponentFixture<LateComingReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LateComingReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LateComingReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
