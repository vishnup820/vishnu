import { NgModule,ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GlobalErrorHandlerService } from '../global-error-handler.service';
import { DailyReportComponent } from './daily-report/daily-report.component';
import { RouterModule } from '@angular/router';
import {  HTTP_INTERCEPTORS } from '@angular/common/http';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { SharedModule } from '../shared/shared.module';
import { DailyReportService } from './services/daily-report/daily-report.service';
import { LopReportService } from './services/lop-report/lop-report.service';
import { LopReportComponent } from './lop-report/lop-report.component';
import { StatusReportComponent } from './status-report/status-report.component';
import { RoleGuardService } from '../shared/services/role-guard/role-guard.service';
import { MalihuScrollbarModule } from 'ngx-malihu-scrollbar';
import { MalihuScrollbarService } from 'ngx-malihu-scrollbar';
import {NgXDonutChartModule} from 'ngx-donutchart';
import { FormsModule } from '@angular/forms';
import { LateComingReportComponent } from './late-coming-report/late-coming-report.component';

@NgModule({
  declarations: [
  DailyReportComponent,
  LopReportComponent,
  StatusReportComponent,
  LateComingReportComponent,
  ],
  imports: [
    FormsModule,
    CommonModule,
    RouterModule,
    SharedModule,
    NgXDonutChartModule,
    BsDatepickerModule.forRoot(),
    MalihuScrollbarModule.forRoot(),
    RouterModule.forChild([
      {
        path       : 'daily-report',
        canActivate : [RoleGuardService],
        component  :  DailyReportComponent,
      },
      {
        path       : 'lop-report',
        canActivate : [RoleGuardService],
        component  :  LopReportComponent,
      },
      {
        path       : 'status-report',
        canActivate : [RoleGuardService],
        component  :  StatusReportComponent,
      },
      {
        path       : 'latecoming',
         canActivate : [RoleGuardService],
        component  :  LateComingReportComponent,
      }
      ])
  ],
  providers:[DailyReportService,LopReportService,MalihuScrollbarService,
    {
      provide  : ErrorHandler,
      useClass : GlobalErrorHandlerService,
    }
]
})
export class ReportModule { }
