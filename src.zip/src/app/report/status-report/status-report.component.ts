import { Component, OnInit , HostListener,ElementRef,EventEmitter,ViewChild,Renderer2,ChangeDetectorRef} from '@angular/core';
import { StatusReportService } from '../services/status-report/status-report.service';
import { MalihuScrollbarService } from 'ngx-malihu-scrollbar';
import { LoaderActionsService } from '../../shared/services/loader/loader-actions.service'
import * as FileSaver from 'file-saver';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-status-report',
  templateUrl: './status-report.component.html',
  styleUrls: ['../../../assets/content/css/status-report.css']
})
export class StatusReportComponent implements OnInit{

  constructor(
    private statusReportService : StatusReportService,
    private el                  : ElementRef,
    private mScrollbarService   : MalihuScrollbarService,
    private loaderActionsService:LoaderActionsService,
    private renderer: Renderer2,
    private changeDetectorRef:ChangeDetectorRef,
    private cookieService: CookieService
     ) { }
 searchD              :any;
  monthObj            : any   = [];
  selectedMonth       : any   = [];
  selectedYear        : any   = [];
  yearObj             : any   = [];
  date                : any;
  monthSelected       : any;
  yearSelected        : any;
  statusMonth         : number = 0;
  statusYear          : number = 0;
  showDate            : any;
  totalnumbers        : any     =[];
  totalDays           : any;
  myValue             : any;
  dayCollection       : any     =[];
  dataCollection      : any;
  dataCollection2     : any;
  listData            : any;
  Currentclass        : any;
  listDataStatus      : any;
  searchValue         : any;
  showAdvancedFilter  : boolean;
  searchTextBox       : boolean = false;
  searchKey           : any;
  queryObject         : any     = {};
  nodata              : boolean;
  selectedItems       : any     = {loc:'',
                                  dep:'',
                                  date_selected:''
                                  };
  leaveCountPerDay  : any = [];
  totalleave        : any;
  leavetype         : any;
  originalObj       : any;
  page              : number  = 1
  perPage           : number = 50;
  b                 : any;
  scrollbarOptions  : any;
  wrapeerWith       : any;
  wrapeerWithBody   : any;
  firstVal          : any;
  secondVal         : any;
  searchVal         : boolean = false;
  searchkeyVal      : any="";
  tablewidth        : boolean = false;
  finMonths         : any;
  statusVar         : boolean = false;
  eData             : boolean =false;
  showfooter        : boolean;
  lazyloader        : boolean = false;
  selected          : any;
  container         : any;
  usedata           : any;
  statusChecked      : any =[]; 
  financialYEarList  : any  = [];
  finMonthData       :any;
  filterActive       : boolean = false;
  filterStatus       : boolean = false;
  selectedfilterYear  : any;
  fulldata            :any;
  currentFinancialYear:any;
  yearId              :any;
  dates :any = []
  selectedFilterMonth : any
  @ViewChild('tbody') tbody: any;
  @ViewChild('thead') thead: any;
  @ViewChild('foc') inputEl:ElementRef;

  ngOnInit() {
    if(this.cookieService.get("user-data")){
        this.usedata =  JSON.parse(this.cookieService.get("user-data"));
    }
    this.usedata.role_id == 4
    this.loaderActionsService.display(true);
    this.date = new Date();
    this.statusReportService.getCurrentFinancialYear(res => {
      this.eData = true;
      this.fulldata = res.data;
      this.finMonths = res.data.year_months;
      this.currentFinancialYear = res.data.active_year;
      // this.selectedMonth = [this.statusReportService.getIndex(this.finMonths)];



      if (this.finMonths.length > 0) {
        for (let i = 0; i < this.finMonths.length; i++) {
          if (this.finMonths[i].start_date == this.currentFinancialYear.fin_startdate && this.finMonths[i].end_date == this.currentFinancialYear.fin_enddate) {
            this.statusChecked = [i];
            this.statusReportService.savedStartDate = this.finMonths[i].start_date;
            this.statusReportService.savedEndDate = this.finMonths[i].end_date;
            this.finMonthData = this.finMonths[i].months;
            let currentday = new Date();
            let currentMonth = currentday.getMonth() + 1;
            for (let i = 0; i < this.finMonthData.length; i++) {

              let dummydate = this.finMonthData[i].month_start_date.split('-');
              let correctDate = dummydate[1] + '-' + dummydate[0] + '-' + dummydate[2];

              let eachdate = new Date(correctDate);
              let eachMonth = eachdate.getMonth() + 1;
              if (currentMonth == eachMonth) {
                    this.selectedMonth =[i];
                    this.statusReportService.savedMonthIndex=i;
                  this.monthSelected = this.finMonthData[i].month_start_date;
                  this.statusReportService.savedMonth = this.monthSelected;
              
               
              }
            }
            // this.monthSelected = this.finMonths[i].months[this.selectedMonth].month_start_date;
           
            this.filterActive = true;
           break;
          
          }
          else {
            this.statusChecked = [0];
            this.finMonthData = this.finMonths[0].months;
            this.selectedMonth = [0];
            this.monthSelected = this.finMonths[0].months[0].month_start_date;

            this.statusReportService.savedMonthIndex=0;
            this.statusReportService.savedMonth = this.finMonths[0].months[0].month_start_date;

          }
        

        }
      }
      setTimeout( ()=>{
        this.filterApply()
      },1000)

    
      // setTimeout( ()=>{
      //   this.generateDays()
      // },500)
       

    })






    this.dayCollection={
      0:"S", 
      1:"M",
      2:"T",
      3:"W",
      4:"T",
      5:"F",
      6:"S"
    }
    this.monthObj.push({month:"January",id:0},
      {month:"February",id:1},
      {month:"March",id:2},
      {month:"April",id:3},
      {month:"May",id:4},
      {month:"June",id:5},
      {month:"July",id:6},
      {month:"August",id:7},
      {month:"September",id:8},
      {month:"October",id:9},
      {month:"November",id:10},
      {month:"December",id:11})
    let self = this;
    this.scrollbarOptions = {
       axis: 'y', 
       scrollInertia: 0,
       mouseWheelPixels: 160,
       theme: 'minimal-dark',
             callbacks: {
         onTotalScroll: function() {
           self.lazyloader = true;
           self.changeDetectorRef.detectChanges();
            self.page = self.page+1;
            if(!self.statusVar){
              // setTimeout(()=>{
              self.statusReportService.loadStatusOnscroll(self.page,self.perPage,self.monthSelected,self.yearId, res=>{
              // self.lazyLoadService.loadNext(true);
              if(res.data.records.length !=0){  
                // if(res.data.records.length ==0){
                //   // self.lazyLoadService.loadNext(false);
                // }
                self.bindConcatData(res);
              }
              else{
                // self.statusVar = true;
                self.lazyloader = false;
                self.changeDetectorRef.detectChanges();
              }
            })
          }
          // },1000)
        }
      }
    }
  }


  getallData(){
      // this.b = document.getElementById('multiselect1');
      // this.b = document.getElementById('scrolltop');
      // this.b.scrollTop = 244;
      // this.b.scrollHeight = 200;
       // this.b.scrollTop = this.b.scrollHeight - this.b.clientHeight;
  }
  bindConcatData(res){
    let self = this;
    self.lazyloader = true;
    this.changeDetectorRef.detectChanges();
    setTimeout(()=>{
      this.dataCollection = this.dataCollection.concat(this.processData(res.data.records));
      this.lazyloader = false;
      this.changeDetectorRef.detectChanges();
    },1000)
  }
  /*
    author : nilena
    desc   : filterselection for financial year
    */
  financialYearData(event) {
   
    // this.finMonths = event.selected[0].months
    if (event && event.selected[0]) {
      this.yearId =event.selected[0].id;
  
      this.finMonthData=event.selected[0].months;
      this.statusReportService.savedStartDate=event.selected[0].start_date;
      this.statusReportService.savedEndDate=event.selected[0].end_date;

      let monthdates=event.selected[0].months;
      let datearray=[];
      for(let i=0; i<monthdates.length;i++){
        let  dummydate = monthdates[i].month_start_date.split('-');
        let correctDate= dummydate[1] + '-'+ dummydate[0]+'-'+ dummydate[2];
        datearray.push(new Date(correctDate))
      }
      var minDate=new Date(Math.min.apply(null,datearray));
 

       var dateValue = minDate.getDate();
       if(dateValue<10){
         let alterDate ='0';
           var dateValuess = alterDate + dateValue;
         }
        
       let monthValue = minDate.getMonth() + 1; 
       if(monthValue<10){
        let alterMonth ='0';
        var  monthValuess= alterMonth + monthValue;
       }
       var yearValue = minDate.getFullYear();
 
    let  dateStr = (dateValue<10?dateValuess:dateValue) + "-" +(monthValue < 10?monthValuess:monthValue)  + "-" + yearValue;

   for(let i=0;i<monthdates.length; i++){
     if(monthdates[i].month_start_date==dateStr){
      this.selectedMonth=[i];
     }
   }

   if(this.currentFinancialYear.fin_startdate== event.selected[0].start_date &&  this.currentFinancialYear.fin_enddate== event.selected[0].end_date){
    // this.statusChecked = [this.statusReportService.savedYearIndex] ;
    this.monthSelected =  this.statusReportService.savedMonth;
    this.selectedMonth =  [this.statusReportService.savedMonthIndex];
  }




    }



  } 
   /*
    author : nilena
    desc   : filterselection
    */
  filterApply(){
    if(this.statusMonth == 1){
      this.generateDays();
    }
    this.statusMonth = 1;
  }
   
/*
    author : nilena
    desc   : filterto cancel ffilter
    */
  filterCancel() {
    // for(let i =0;i<this.finMonths.length;i++){
    // if(this.usedata.end_date == this.finMonths[i].end_date && this.usedata.start_date == this.finMonths[i].start_date ){ 
    // this.statusChecked = [i]
    // this.finMonths = this.financialYEarList.data[i].months
    // this.filterActive = true;
    // this.filterApply()





    // if ( this.currentFinancialYear.fin_startdate != this.statusReportService.savedStartDate
    //   && this.currentFinancialYear.fin_enddate != this.statusReportService.savedEndDate || this.statusReportService.savedMonth != this.monthSelected) {

      // this.statusReportService.getCurrentFinancialYear(res => {
      //   this.eData = true;
      //   this.fulldata = res.data;
      //   this.finMonths = res.data.year_months;
      //   this.selectedMonth = [this.statusReportService.getIndex(this.finMonths)];
      //   this.monthSelected = this.finMonths[this.selectedMonth].value;

      //   if (this.finMonths.length > 0) {
      //     for (let i = 0; i < this.finMonths.length; i++) {
      //       if (this.finMonths[i].start_date == this.currentFinancialYear.fin_startdate && this.finMonths[i].end_date == this.currentFinancialYear.fin_enddate) {
      //         this.statusChecked = [i];
      //         this.finMonthData = this.finMonths[i].months;
      //         this.monthSelected = this.finMonths[i].months[this.selectedMonth].month_start_date;
      //         this.filterActive = true;
      //         this.filterApply()
      //         break;
      //       }
      //       else{ 
      //         this.statusChecked=[0];
      //         this.finMonthData = this.finMonths[0].months;
      //         this.monthSelected=this.finMonths[0].months[0].month_start_date;
      //       }
      //     }
      //   }
        
     

      // })

    // }

    this.loaderActionsService.display(true);
    this.statusReportService.getCurrentFinancialYear(res => {
      this.eData = true;
      this.fulldata = res.data;
      this.finMonths = res.data.year_months;
      this.currentFinancialYear = res.data.active_year;
      // this.selectedMonth = [this.statusReportService.getIndex(this.finMonths)];



      if (this.finMonths.length > 0) {
        for (let i = 0; i < this.finMonths.length; i++) {
          if (this.finMonths[i].start_date == this.currentFinancialYear.fin_startdate && this.finMonths[i].end_date == this.currentFinancialYear.fin_enddate) {
            this.statusChecked = [i];
            this.statusReportService.savedStartDate = this.finMonths[i].start_date;
            this.statusReportService.savedEndDate = this.finMonths[i].end_date;
            this.finMonthData = this.finMonths[i].months;
            let currentday = new Date();
            let currentMonth = currentday.getMonth() + 1;
            for (let i = 0; i < this.finMonthData.length; i++) {

              let dummydate = this.finMonthData[i].month_start_date.split('-');
              let correctDate = dummydate[1] + '-' + dummydate[0] + '-' + dummydate[2];

              let eachdate = new Date(correctDate);
              let eachMonth = eachdate.getMonth() + 1;
              if (currentMonth == eachMonth) {
                this.selectedMonth = [i];
                this.monthSelected = this.finMonthData[i].month_start_date;
                this.statusReportService.savedMonth = this.monthSelected;


              }
            }
            // this.monthSelected = this.finMonths[i].months[this.selectedMonth].month_start_date;

            this.filterActive = true;
            // this.filterApply()

            break;

          } else {
            this.statusChecked = [0];
            this.finMonthData = this.finMonths[0].months;
            this.monthSelected = this.finMonths[0].months[0].month_start_date;

          }

        }

      }

      // this.filterApply()

      setTimeout( ()=>{
        this.generateDays()
      },500)
    
  

    })







  }
  /*
    author : vinod.k
    desc   : selection of month from dropdown
    */
  selectedMonthEvent(event){
    if(this.statusMonth == 1){
      this.monthSelected = event.selected[0].month_start_date;
    }
    this.statusMonth = 1;
  }
  
  /*
    author : vinod.k
    desc   : selection of year from dropdown
    */
  // selectedYearEvent(event){
  //   if(this.statusYear == 1){
  //     if(!event.selected && !event.selected[0].year){
  //       this.yearSelected = this.date.getFullYear()
  //     }
  //     else{
  //       this.yearSelected = event.selected[0].year;
  //     }
  //     this.generateDays();
  //   }
  //   this.statusYear = 1;
  // }
  
  /*
    author : vinod.k
    desc   : genarate total leave each day
    */
  generateLeaveClass(arrObj){
    if(arrObj >= 0 &&  arrObj < 1){
      return "range-one";
    }
    if(arrObj == 1){
      return "range-one";  
    }
    if(arrObj > 1 && arrObj < 2){
      return "range-one";  
    }
    if(arrObj == 2){
      return "range-two";  
    }
    if(arrObj > 2 && arrObj < 3){
      return "range-two";  
    }
    if(arrObj == 3 ){
      return "range-three";
    }
    if(arrObj >3 && arrObj < 4){
      return "range-three";
    }
    if(arrObj >= 4){
      return "range-four";
    } 
  }
  

  inputfocus(){
          setTimeout(() => {this.inputEl.nativeElement.focus();},100)   
    }
  /*
    author : vinod.k
    desc   : add class for the status of leave count
    */
  checkDailyStatus(totalleavecount){
    for(var i=0;i<totalleavecount.length;i++){
      totalleavecount[i].class = this.generateLeaveClass(totalleavecount[i].leaves) 
    }
    return totalleavecount  
  }
  
  /*
    author : vinod.k
    desc   : genarate table for different users status
    */
  generateDays() {
    this.loaderActionsService.display(true);
    if(this.monthSelected == "" && this.monthSelected == "NaN") {
      this.loaderActionsService.display(false);
      // select both dropdown
    }
    else {
      this.dates = []
      this.leaveCountPerDay = [];
      this.statusReportService.getStatusReport(this.monthSelected, this.yearId, res=>{
      if(res.data.records && res.data.records.length){
        this.dataCollection   = this.processData(res.data.records)
        this.leaveCountPerDay = res.data.monthly_leaves
        this.totalleave       =  this.checkDailyStatus(this.leaveCountPerDay)
        this.checkAllvalues(this.totalleave)
        let d = this.monthSelected.split("-");
        this.showDate         =  this.monthObj[d[1]-1].month +" " + d[2];
        this.totalDays        = new Date(d[2],d[1],0).getDate();
        this.totalnumbers     = Array(this.totalDays).fill(this.totalDays).map((x,i)=>i+1);
        for(let i =0;i<this.totalnumbers.length;i++){
           this.dates[i] = ( this.geteveryDay(this.totalnumbers[i])) 
        }

        this.nodata           = false;
      }
      else{
        this.dataCollection  = [];
        this.nodata          = true;
      }
          setTimeout(()=>{
            this.loaderActionsService.display(false);
          },10) 
      })
    }
  }

  /*
    author : vinod.k
    desc   : show/hide footer
    */
  checkAllvalues(totalleave){
      // let flag1 = false;
      // for(let item of totalleave){
      //   if(item["leaves"]!=0){
      //     flag1=true;
      //     break;
      //   }
      //   else{
            //flag1 = false;
      // }
      // }
    let val
    let arrNames = [];
        Object.keys(totalleave).forEach(function(key) {
        val  = totalleave[key]["leaves"];
         arrNames.push(val);
        });
    let flag = 0;
    for(var i = 0; i < arrNames.length; ++i) {
      if(arrNames[i] !== 0) {
      flag = 1;
      break;
    }
  } 
  if(flag) {
      this.showfooter = true;
  } else {
      this.showfooter = false;  
    }
  }
  /*
    author : vinod.k
    desc   : genarate different class for different users status
    */
  genrateClass(first, second) {
    this.firstVal   = first;
    this.secondVal  = second;
    // if(first == null){
    //   first = 0
    // }
    // if(second == null){
    //   second = 0;
    // }
    if(first==0 && second == 0){
      return 'working-day';
    }
    if(first==0 && second == 6){
      return 'inform-leave-afternoon-future';
    }
    if(first==1 && second ==1){
      return "attendance-marked";
    }
    if(first==1 && second == 2){
      return "leave-taken-afternoon";
      // return "leave-taken-beforenoon";
    }
    if(first==1 && second == 3){
     return "on-duty-beforenoon-present"
      // return "un-informed-leave-beforenoon";
    }
    if(first==1 && second == 6){
      return "leave-applied-afternoon";
      // return "infome-leave-afternoon";
    }
    if(first==2 && second == 1){
     return "leave-taken-beforenoon"
      // return "leave-taken-afternoon";
    }
    if(first==2 && second == 2){
      // return "attendance-marked";
      return "leave-taken"
    }
    if(first==2 && second == 3){
      return "on-duty-un-informed-leave-beforenoon"
      // return "on-duty-beforenoon-present";
    }
    if(first==2 && second == 6){
      return "unformed-leave-beforenoon-inform-leave-afternoon";
      // return "leave-applied-afternoon";
    }
    if(first==3 && second == 1){
      return "on-duty-afternoon-present";
      // return "un-informed-leave-afternoon";
    }
    if(first==3 && second == 2){
      return "on-duty-un-informed-leave-afternoon";
      // return "on-duty-afternoon-present";
    }
    if(first==3 && second == 3){
      return "on-duty";
    }
    if(first==3 && second == 6){
      return "on-duty-leave-applied-afternoon";
    }
    if(first==6 && second == 0){
      return "inform-leave-beforenoon-future";
    }
    if(first==3 && second == 0){
     return "on-duty-second-future"
      // return "un-informed-leave-beforenoon";
    }
    if(first==0 && second == 3){
     return "on-duty-first-future"
      // return "un-informed-leave-beforenoon";
    }
    if(first==6 && second == 1){
      return "leave-applied-beforenoon";
      // return "infome-leave-beforenoon";
    }
    if(first==6 && second == 2){
      return "inform-leave-beforenoon-unformed-leave-afternoon";
      // return "leave-applied-beforenoon";
    }
    if(first==6 && second == 3){
      return "on-duty-leave-applied-beforenoon";
    }
    if(first==6 && second == 6){
      return "leave-applied";
    }
    if(first==4 && second == 4){
      return "weekend-holiday";
    }
    if(first==5 && second == 5){
      return "calendar-holidays";
    }
  }
  
   /*
    author : vinod.k
    desc   : process our total users array
    */
  processData(data){
    for(var i = 0;i<data.length;i++){
      for(var j = 0;j<data[i].list.length;j++){
        data[i].list[j].class = this.genrateClass((data[i].list[j] && data[i].list[j].first_half_attendance)?data[i].list[j].first_half_attendance:0,(data[i].list[j] && data[i].list[j].second_half_attendance)?data[i].list[j].second_half_attendance:0)

      }
    }
    return data;
  }
 
 /*
    author : vinod.k
    desc   : weekend checking
    */
 //  getDayClass(dayValue){
 //  this.myValue = new Date(this.yearSelected, this.monthSelected, dayValue);
 //  if(this.dayCollection[this.myValue.getDay()] == 'S'){
 //         return "weekend-holiday";
 //   }
 // }
  
  /*
    author : vinod.k
    desc   : get every day of a month
    */
  geteveryDay(dayValue){
    if(this.monthSelected){
    let d = this.monthSelected.split("-");
    this.myValue = new Date(d[2],d[1]-1,dayValue);
    // let dates
      return this.dayCollection[this.myValue.getDay()];
    }
  }
  
  /*
    author : vinod.k
    desc   : search a user based on id and name
    */
  search(value) {
    if(   this.searchkeyVal || this.searchD.trim ()!='' ){
      this.tablewidth = true;
      this.loaderActionsService.display(true);
      this.searchkeyVal = value;
      if(value === '' || value === null){
        if(this.tbody && this.thead){
          // this.renderer.removeClass(this.tbody.nativeElement,'tbody-search')
          // this.renderer.removeClass(this.thead.nativeElement,'thead-search')
          this.tbody.nativeElement.className="";
          this.thead.nativeElement.className="";
        }
       }
        else{
          if(this.tbody && this.thead){
            this.tbody.nativeElement.className="";
            this.thead.nativeElement.className="";
            this.renderer.addClass(this.tbody.nativeElement,'tbody-search')
            this.renderer.addClass(this.thead.nativeElement,'thead-search')
          }
          
        }
    
        this.searchValue = value;
        this.getSearchResult(this.searchValue);
    }
   
  }
  
  /*
    author : vinod.k
    desc   : return the search result
    */
  getSearchResult(event){

    this.searchVal = true;
    this.leaveCountPerDay = [];
    this.searchKey = event;
    this.statusReportService.getSearchReport(this.monthSelected,this.searchKey, this.yearId,res =>{
    if(res && res.data.records.length > 0) {
      this.dataCollection  = this.processData(res.data.records);
      this.leaveCountPerDay = res.data.monthly_leaves
      this.totalleave       =  this.checkDailyStatus(this.leaveCountPerDay)
      this.checkAllvalues(this.totalleave)
      this.nodata           = false;
    }
    else {
      this.dataCollection  = [];
      this.nodata          = true;
      }
      setTimeout(()=>{
        this.loaderActionsService.display(false);
      },10)
    })
  }

  /*
    author : vinod.k
    desc   : add style dynamically for tfoot and tbody
    */
  setMyStyles(value){
    // this.tbody.mCustomScrollbar("update");
    if(value == "a"){
      this.wrapeerWith = document.getElementById('table-wrapper').offsetWidth;
      // if(this.wrapeerWith == 1026){
      //   this.wrapeerWith = 1043;
      // }
    }
    // if(value == "b"){
    //   this.wrapeerWith = document.getElementById('table-wrapper').offsetWidth;
    // }
    // if(value == "c" && (this.searchkeyVal != null || this.searchkeyVal != "")){
    //   this.wrapeerWith = 1057;
    // }
    // setTimeout(()=>{
    let styles = {
      'width': `${this.wrapeerWith}px`  
    };
      return styles
  // },100)
  }

   /*
    author : vinod.k
    desc   : load status report based on location and department
    */
  advanceFilter(filterd_data){
     if((filterd_data.location == null || filterd_data.location.selected.length == 0) && (filterd_data.department == null || filterd_data.department.selected.length ==0)){
       if(this.tbody && this.thead){
        this.tbody.nativeElement.className = "";
        this.thead.nativeElement.className = "";
      }
    }
    else{
      if(this.tbody && this.thead){
          this.tbody.nativeElement.className="";
          this.thead.nativeElement.className="";
          this.renderer.addClass(this.tbody.nativeElement,'tbody-search')
          this.renderer.addClass(this.thead.nativeElement,'thead-search')
        }
    }
    if(filterd_data.location && filterd_data.location.selected.length>0){
      this.selectedItems.loc = filterd_data.location.selected[0].id  
    }
    else{
      this.selectedItems.loc = '';
    }
    if(filterd_data.department && filterd_data.department.selected.length>0){
      this.selectedItems.dep = filterd_data.department.selected[0].id  
    }
    else{
      this.selectedItems.dep = '';
    }
    // this.selectedItems.date_selected = this.date_today;
    let selectedObj = this.selectedItems;
    this.loadReportsForselected(selectedObj);
  }
  
  /*
    author : vinod.k
    desc   : load report for selected data on filter
    */
  loadReportsForselected(selectedObj){
   this.loaderActionsService.display(true);
    this.statusReportService.loadReportsForselected(this.monthSelected,selectedObj,res=>{
      if(res.data.records.length > 0){
          this.dataCollection = this.processData(res.data.records);
          this.leaveCountPerDay = res.data.monthlyleaves
          this.totalleave       =  this.checkDailyStatus(this.leaveCountPerDay);
          this.checkAllvalues(this.totalleave)
          this.nodata         = false;
        }
        else{
        this.dataCollection  = [];
        this.nodata          = true;
      }
       this.loaderActionsService.display(false);
      })    
  }
  
  exportExcel(){

      this.loaderActionsService.display(true);
      this.changeDetectorRef.detectChanges();

      this.statusReportService.exportExcelData(this.searchkeyVal,this.monthSelected, this.yearId, res =>{ 
       if(res && res.data){
        let binary_string:any =  window.atob(res.data);
       let len:any = binary_string.length;
       let bytes:any = new Uint8Array( len );
      for (var i = 0; i < len; i++){
        bytes[i] = binary_string.charCodeAt(i);
      }
        let file:any = new Blob([bytes.buffer], {type:"application/vnd.ms-excel"});
          let filename:any = 'statusReport.xlsx';
          FileSaver.saveAs(file, filename);
      this.loaderActionsService.display(false);
        }
       })
   }
   tableScrollTop(){
     $("#scrollToptable").mCustomScrollbar("update");
     $("#scrollToptable").mCustomScrollbar("scrollTo", "top");
     this.page=1;
}
}

