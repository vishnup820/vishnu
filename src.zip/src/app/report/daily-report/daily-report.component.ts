import { Component, OnInit } from '@angular/core';
import { DailyReportService } from '../services/daily-report/daily-report.service';
import { NgXDonutChartSlice } from 'ngx-donutchart/ngx-donutchart.type';
import { LoaderActionsService } from '../../shared/services/loader/loader-actions.service'
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from './../../shared/services/timezone-details/timezone-details.service';
import { FilterService } from './../../shared/services/filter/filter.service';
import { ConstantServicesService } from './../../shared/services/constant/constant-services.service';

declare var require: any;
var moment = require('moment');

@Component({
  selector: 'app-daily-report',
  templateUrl: './daily-report.component.html',
  styleUrls: ['./daily-report.component.css']
})
export class DailyReportComponent implements OnInit {

  date_today: any;
  total_users: string;
  report_details: any;
  status: number = 0;
  selectedItems: any = {
	loc: '',
	dep: '',
	date_selected: ''
  };
  toatalUsers: string;
  flag: boolean = false;
  markedStatus: any;
  selectedData : any = [];
  showAdvancedFilter: boolean;
  data: any = {};
  selectZone : any;
  filterActive :boolean = false;
  nodata:boolean = false;
  dateMax : Date = new Date();
  // minDate : Date = new Date("2015");
  advanceFilterData  :any;
  slices: NgXDonutChartSlice[];
  fullLocation :any = [];
  selectedLoc  : any = [];
  initailfilter:number = 0;
  currentlength : any;
	prevlength:any;
	minDate:any;
	userData:any;
  constructor(
	private dailyReportService: DailyReportService,
	private loaderActionsService: LoaderActionsService,
	private router            : Router,
	private cookieService : CookieService,
	private timeZone : TimezoneDetailsService,
	private filterService : FilterService,
	private constData     : ConstantServicesService) { }

	ngOnInit() {
		this.dateMax = this.timeZone.getCurrentDate();
		this.date_today = this.timeZone.getCurrentDate();
		this.selectZone = JSON.parse(this.cookieService.get("user-data")).time_zone;
		if (this.cookieService.get("user-data")) {
			this.userData = JSON.parse(this.cookieService.get("user-data"));
			this.minDate= new Date(this.userData.financialMin_date);
		}

		// this.selectedData = [{
		// 	id       : JSON.parse(this.cookieService.get("user-data")).location_id,
		// 	name     : JSON.parse(this.cookieService.get("user-data")).location,
		// 	timezone : this.selectZone
		// }];
		// localStorage.setItem('currentLoc',JSON.stringify({'id':this.selectedData[0].id,'zone':this.selectedData[0].timezone}));
		

		// this.filterService.filterVar['reortLoc'] = this.selectedData;
		this.loadInitalReport();
	}

  /*
	* author : vinod.k
	* desc   : load report initalli
  */
  loadInitalReport() {
  			// setTimeout( ()=>{
  		this.loaderActionsService.display(true);
  		this.filterService.location.subscribe((val: any) => {
			// this.showLoader = val;
			// this.filterService.loc
  			this.selectedData =  JSON.parse(JSON.stringify(val));
  	 if(this.selectedData.length>0){
  	 		this.fullLocation = [];
  			this.fullLocation = val;
			this.filterService.filterarray = this.selectedData;
  				let loc_id: any = [];
  				let loc;
			    this.selectedData.map((value) => {
			    	loc_id.push(value.id)
			    });
				loc = loc_id+'';
				// this.selectedData[0].id
	this.loaderActionsService.display(true);
	this.dailyReportService.get_dailyreport(this.date_today,loc,(this.selectedItems.dep)?this.selectedItems.dep:null,res => {
	  if (res && res.marked == "completed" ) {
		this.markedStatus = res.marked;
		this.report_details = res.data;
		if (this.report_details.present == 0 && this.report_details.leave == 0 && this.report_details.absent == 0 && this.report_details.holidays == 0 && this.report_details.wekends == 0 && this.report_details.onduty == 0 && this.report_details.peopleCount != 0) {
		  this.slices = [{ color: '#D3D3D3', value: (this.report_details.peopleCount / 100) * this.report_details.peopleCount }]
		  this.total_users = (this.report_details.peopleCount).toString();
		}
		else if (this.report_details.peopleCount == 0) {
		  this.total_users = (0).toString();
		  this.slices = [{ color: '#D3D3D3', value: (200 / 100) * 200 }]
		}
		else {
		  this.total_users = (this.report_details.peopleCount).toString();
		  this.slices = [
			{ color: '#4ab2f4', value: (this.report_details.present ? (this.report_details.present / 100) * this.report_details.peopleCount : 0) },
			{ color: '#e16767', value: (this.report_details.absent ? (this.report_details.absent / 100) * this.report_details.peopleCount : 0) },
			{ color: '#ff8143', value: (this.report_details.leave ? (this.report_details.leave / 100) * this.report_details.peopleCount : 0) },
			{ color: '#4274e1', value: (this.report_details.holidays ? (this.report_details.holidays / 100) * this.report_details.peopleCount : 0) },
			{ color: '#db873c', value: (this.report_details.wekends ? (this.report_details.wekends / 100) * this.report_details.peopleCount : 0) },
			// { color: '#66d078', value: (this.report_details.unPaidLeaves ? (this.report_details.unPaidLeaves / 100) * this.report_details.peopleCount : 0) },
			{ color: '#ff6afd', value: (this.report_details.onduty ? (this.report_details.onduty / 100) * this.report_details.peopleCount : 0) }]
		}
		this.nodata = false;
		this.loaderActionsService.display(false);
	  }
	  if(Object.keys(res.data).length === 0 && res.marked == null){
	  	this.nodata = true;
	  	this.loaderActionsService.display(false);
	  }
	  if (res && (res.marked == "in progress" || res.marked == null || res.marked == "pending")) {
		this.report_details = res.data;
		this.markedStatus = res.marked;
		if (this.report_details.present == 0 && this.report_details.leave == 0 && this.report_details.absent == 0 && this.report_details.holidays == 0 && this.report_details.wekends == 0 && this.report_details.onduty == 0 && this.report_details.peopleCount != 0) {
		  this.slices = [{ color: '#D3D3D3', value: (this.report_details.peopleCount / 100) * this.report_details.peopleCount }]
		  this.total_users = (this.report_details.peopleCount).toString();
		}
		else if (this.report_details.peopleCount == 0) {
		  this.total_users = (0).toString();
		  this.slices = [{ color: '#D3D3D3', value: (200 / 100) * 200 }]
		}
		else {
		  this.total_users = (this.report_details.peopleCount).toString();
		  this.slices = [{ color: '#4ab2f4', value: (this.report_details.present ? (this.report_details.present / 100) * this.report_details.peopleCount : 0) },
		  { color: '#e16767', value: (this.report_details.absent ? (this.report_details.absent / 100) * this.report_details.peopleCount : 0) },
		  { color: '#ff8143', value: (this.report_details.leave ? (this.report_details.leave / 100) * this.report_details.peopleCount : 0) },
		  { color: '#4274e1', value: (this.report_details.holidays ? (this.report_details.holidays / 100) * this.report_details.peopleCount : 0) },
		  { color: '#db873c', value: (this.report_details.wekends ? (this.report_details.wekends / 100) * this.report_details.peopleCount : 0) },
		  // { color: '#66d078', value: (this.report_details.unPaidLeaves ? (this.report_details.unPaidLeaves / 100) * this.report_details.peopleCount : 0) },
		  { color: '#ff6afd', value: (this.report_details.onduty ? (this.report_details.onduty / 100) * this.report_details.peopleCount : 0) }]
		}
		this.nodata = false;
		this.loaderActionsService.display(false);
	  }
	})
	}
});
// },2000)
  }

  /*
	author : vinod.k
	desc   : load report based on date change
   */
  onValueChange(event) {
	if (this.status == 1) {
	  this.loaderActionsService.display(true);
	  let loc_id: any = [];
	  // this.selectedData = [];	
  		let loc;
		 this.selectedData.map((value) => {
			loc_id.push(value.id)
		 });
	    loc = loc_id+'';
	  this.slices = [];
	  this.date_today = event;
	  this.dailyReportService.get_dailyreport(this.date_today,loc,(this.selectedItems.dep)?this.selectedItems.dep:null,res => {
		if (res && res.marked == "completed") {
		  this.markedStatus = res.marked;
		  this.report_details = res.data;
		  if (this.report_details.present == 0 && this.report_details.leave == 0 && this.report_details.absent == 0 && this.report_details.holidays == 0 && this.report_details.wekends == 0 && this.report_details.onduty == 0 && this.report_details.peopleCount != 0) {
			this.slices = [{ color: '#D3D3D3', value: (this.report_details.peopleCount / 100) * this.report_details.peopleCount }]
			this.total_users = (this.report_details.peopleCount).toString();
		  }
		  else if (this.report_details.peopleCount == 0) {
			this.total_users = (0).toString();
			this.slices = [{ color: '#D3D3D3', value: (200 / 100) * 200 }]
		  }
		  else {
			this.total_users = (this.report_details.peopleCount).toString();
			this.slices = [{ color: '#4ab2f4', value: (this.report_details.present ? (this.report_details.present / 100) * this.report_details.peopleCount : 0) },
			{ color: '#e16767', value: (this.report_details.absent ? (this.report_details.absent / 100) * this.report_details.peopleCount : 0) },
			{ color: '#ff8143', value: (this.report_details.leave ? (this.report_details.leave / 100) * this.report_details.peopleCount : 0) },
			{ color: '#4274e1', value: (this.report_details.holidays ? (this.report_details.holidays / 100) * this.report_details.peopleCount : 0) },
			{ color: '#db873c', value: (this.report_details.wekends ? (this.report_details.wekends / 100) * this.report_details.peopleCount : 0) },
			// { color: '#66d078', value: (this.report_details.unPaidLeaves ? (this.report_details.unPaidLeaves / 100) * this.report_details.peopleCount : 0) },
			{ color: '#ff6afd', value: (this.report_details.onduty ? (this.report_details.onduty / 100) * this.report_details.peopleCount : 0) }]
		  }
		  this.nodata = false;
		  this.loaderActionsService.display(false);
		}
		if(Object.keys(res.data).length === 0 && res.marked == null){
	  	this.nodata = true;
	  	this.loaderActionsService.display(false);
	  }
		if (res && (res.marked == "in progress" || res.marked == null || res.marked == "pending")) {
		  this.report_details = res.data;
		  this.markedStatus = res.marked;
		  if (this.report_details.present == 0 && this.report_details.leave == 0 && this.report_details.absent == 0 && this.report_details.holidays == 0 && this.report_details.wekends == 0 && this.report_details.onduty == 0 && this.report_details.peopleCount != 0) {
			this.slices = [{ color: '#D3D3D3', value: (this.report_details.peopleCount / 100) * this.report_details.peopleCount }]
			this.total_users = (this.report_details.peopleCount).toString();
		  }
		  else if (this.report_details.peopleCount == 0) {
			this.total_users = (0).toString();
			this.slices = [{ color: '#D3D3D3', value: (200 / 100) * 200 }]
		  }
		  else {
			this.total_users = (this.report_details.peopleCount).toString();
			this.slices = [{ color: '#4ab2f4', value: (this.report_details.present ? (this.report_details.present / 100) * this.report_details.peopleCount : 0) },
			{ color: '#e16767', value: (this.report_details.absent ? (this.report_details.absent / 100) * this.report_details.peopleCount : 0) },
			{ color: '#ff8143', value: (this.report_details.leave ? (this.report_details.leave / 100) * this.report_details.peopleCount : 0) },
			{ color: '#4274e1', value: (this.report_details.holidays ? (this.report_details.holidays / 100) * this.report_details.peopleCount : 0) },
			{ color: '#db873c', value: (this.report_details.wekends ? (this.report_details.wekends / 100) * this.report_details.peopleCount : 0) },
			// { color: '#66d078', value: (this.report_details.unPaidLeaves ? (this.report_details.unPaidLeaves / 100) * this.report_details.peopleCount : 0) },
			{ color: '#ff6afd', value: (this.report_details.onduty ? (this.report_details.onduty / 100) * this.report_details.peopleCount : 0) }]
		  }
		  this.nodata = false;
		  this.loaderActionsService.display(false);
		}
	  })
	}
	this.status = 1;
  }
  /*
	  author : vinod.k
	  desc   : load report based on location and department
	 */
	advanceFilter(filterd_data) {
		// this.status = 0;
		// || this.advanceFilterData
		if(filterd_data) {
			let filteredDummy = [];
			this.fullLocation.map((item, index) => {
				if(filteredDummy.indexOf(item) == -1)
					filteredDummy.push(item)
				})
			// this.currentlength = filterd_data.reportValue.selected.length
			// if((this.currentlength == this.prevlength) &&  (filterd_data && !filterd_data.department.selected.length  && filterd_data.reportValue && filterd_data.reportValue.selected.length) && filterd_data.reportValue.selected.length == filteredDummy.length){
			// 	this.showAdvancedFilter = false;
			// }
			// else{
			// this.selectedData = [];
				this.initailfilter = 1;
				this.advanceFilterData = filterd_data;
				if(filterd_data && filterd_data.reportValue && filterd_data.reportValue.selected.length > 0) {
					this.selectedLoc = this.advanceFilterData.reportValue.selected;
			    	let loc_id: any = [];
			    	filterd_data.reportValue.selected.map((value) => {
			    		loc_id.push(value.id)
			    	});
					this.selectedItems.loc = loc_id+'';
					let aestTime = [];
					let aestTime2 = [];
					for(var i=0;i<filterd_data.reportValue.selected.length;i++){
						aestTime.push(new Date().toLocaleString("en-US", {timeZone:filterd_data.reportValue.selected[i].timezone}));
	    				aestTime2.push({"date" : new Date(aestTime[i]), "zone":filterd_data.reportValue.selected[i].timezone});
					}
					let sorted = [];
					let v;
					for(var i=0;i<aestTime2.length;i++){
		  				v = aestTime2.sort(function(a,b){
          					return (a.date) - (b.date);
          				});
					}
					this.selectZone = v[0].zone 
					this.selectedData = [];
					// filterd_data.reportValue.selected[0].timezone;
					for(var i=0;i<filterd_data.reportValue.selected.length;i++){
						this.selectedData.push(filterd_data.reportValue.selected[i]);
					}
					this.date_today = this.getCurrentDate(v[0].zone);
					this.dateMax = this.getCurrentDate(v[0].zone);
					// this.prevlength = filterd_data.reportValue.selected.length
				}
				else {
					this.selectedData = [{
						id: JSON.parse(this.cookieService.get("user-data")).location_id,
						name: JSON.parse(this.cookieService.get("user-data")).location,
						timezone: this.selectZone
					}];
					// this.selectedItems.loc = this.selectedData.id;
					let loc_id: any = [];
			    	this.selectedData.map((value) => {
			    		loc_id.push(value.id)
			    	});
					this.selectedItems.loc = loc_id+'';
					// this.filterService.filterVar['reortLoc'] = this.selectedData;
					this.filterService.filterarray = this.selectedData;
					this.selectZone = JSON.parse(this.cookieService.get("user-data")).time_zone;
					this.date_today = this.timeZone.getCurrentDate();
					this.dateMax = this.timeZone.getCurrentDate();
				}
			if (filterd_data && filterd_data.department && filterd_data.department.selected.length > 0) {
				this.selectedItems.dep = filterd_data.department.selected[0].id
			}
			else {
				this.selectedItems.dep = "";
			}
				this.selectedItems.date_selected = this.date_today;
				let selectedObj = this.selectedItems;
				if ((filterd_data && filterd_data.reportValue && filterd_data.reportValue.selected.length > 0) || (filterd_data && filterd_data.department && filterd_data.department.selected.length > 0)) {
					this.filterActive = true;
				}
				else {
					this.filterActive = false;
				}
				this.loadReportsForselected(selectedObj);
			// }
		}
		else {
			let dummy = [];
			let filteredDummy = [];
			this.fullLocation.map((item, index) => {
				if(filteredDummy.indexOf(item) == -1)
					filteredDummy.push(item)
			})
			if(this.initailfilter == 0 || (this.selectedItems.dep == "" && this.selectedLoc.length) && this.selectedLoc.length == filteredDummy.length){
				filterd_data = undefined;
			    this.selectedItems.dep = "";
				this.showAdvancedFilter = false;
				// this.filterService.location.next(filteredDummy);
				// let dummy = [];
				// this.fullLocation.map((item, index) => {
				// if(dummy.indexOf(item) == -1)
				// 	dummy.push(item)
				// })
				// this.selectedData = dummy;
				// this.selectedLoc  = dummy;
				// this.filterService.filterarray = this.selectedData;
			}
			else{
				filterd_data = undefined;
				this.selectedItems.dep = "";
				// this.selectedData = [{
				// 	id: JSON.parse(this.cookieService.get("user-data")).location_id,
				// 	name: JSON.parse(this.cookieService.get("user-data")).location,
				// 	timezone: this.selectZone
				// }];
				// this.selectedData = this.fullLocation;
				this.fullLocation.map((item, index) => {
					if(dummy.indexOf(item) == -1)
						dummy.push(item)
				})
				this.selectedData = dummy;
				// this.selectedLoc  = dummy;
				this.filterService.filterarray = this.selectedData;
				this.filterService.location.next(dummy);
				// this.filterService.filterVar['reortLoc'] = this.selectedData;
		  	}
		}
	}

  /*
   author : vinod.k
   desc   : api for loading report based on location and department
  */
  loadReportsForselected(selectedObj) {
  	this.loaderActionsService.display(true);
	this.slices = [];
	this.dailyReportService.loadReportsForselected(selectedObj, res => {
	  if (res && res.marked == "completed") {
		// this.loaderActionsService.display(true);
		this.markedStatus = res.marked;
		this.report_details = res.data;
		if (this.report_details.present == 0  && this.report_details.leave == 0 && this.report_details.absent == 0 && this.report_details.holidays == 0 && this.report_details.wekends == 0 && this.report_details.onduty == 0 && this.report_details.peopleCount != 0) {
		  this.slices = [{ color: '#D3D3D3', value: (this.report_details.peopleCount / 100) * this.report_details.peopleCount }]
		  this.total_users = (this.report_details.peopleCount).toString();
		}
		else if (this.report_details.peopleCount == 0) {
		  this.total_users = (0).toString();
		  this.slices = [{ color: '#D3D3D3', value: (200 / 100) * 200 }]
		}
		else {
		  this.total_users = (this.report_details.peopleCount).toString();
		  this.slices = [{ color: '#4ab2f4', value: (this.report_details.present ? (this.report_details.present / 100) * this.report_details.peopleCount : 0) },
		  { color: '#e16767', value: (this.report_details.absent ? (this.report_details.absent / 100) * this.report_details.peopleCount : 0) },
		  { color: '#ff8143', value: (this.report_details.leave ? (this.report_details.leave / 100) * this.report_details.peopleCount : 0) },
		  { color: '#4274e1', value: (this.report_details.holidays ? (this.report_details.holidays / 100) * this.report_details.peopleCount : 0) },
		  { color: '#db873c', value: (this.report_details.wekends ? (this.report_details.wekends / 100) * this.report_details.peopleCount : 0) },
		  // { color: '#66d078', value: (this.report_details.unPaidLeaves ? (this.report_details.unPaidLeaves / 100) * this.report_details.peopleCount : 0) },
		  { color: '#ff6afd', value: (this.report_details.onduty ? (this.report_details.onduty / 100) * this.report_details.peopleCount : 0) }]
		}
		this.nodata = false;
		this.loaderActionsService.display(false);
	  }
	  if(Object.keys(res.data).length === 0 && res.marked == null){
	  	this.nodata = true;
	  	this.loaderActionsService.display(false);
	  }
	  if (res && (res.marked == "in progress" || res.marked == null || res.marked == "pending")) {
		this.loaderActionsService.display(true);
		this.markedStatus = res.marked;
		this.report_details = res.data;
		if (this.report_details.present == 0 && this.report_details.leave == 0 && this.report_details.absent == 0 && this.report_details.holidays == 0 && this.report_details.wekends == 0 && this.report_details.onduty == 0 && this.report_details.peopleCount != 0) {
		  this.slices = [{ color: '#D3D3D3', value: (this.report_details.peopleCount / 100) * this.report_details.peopleCount }]
		  this.total_users = (this.report_details.peopleCount).toString();
		}
		else if (this.report_details.peopleCount == 0) {
		  this.total_users = (0).toString();
		  this.slices = [{ color: '#D3D3D3', value: (200 / 100) * 200 }]
		}
		else {
		  this.total_users = (this.report_details.peopleCount).toString();
		  this.slices = [{ color: '#4ab2f4', value: (this.report_details.present ? (this.report_details.present / 100) * this.report_details.peopleCount : 0) },
		  { color: '#e16767', value: (this.report_details.absent ? (this.report_details.absent / 100) * this.report_details.peopleCount : 0) },
		  { color: '#ff8143', value: (this.report_details.leave ? (this.report_details.leave / 100) * this.report_details.peopleCount : 0) },
		  { color: '#4274e1', value: (this.report_details.holidays ? (this.report_details.holidays / 100) * this.report_details.peopleCount : 0) },
		  { color: '#db873c', value: (this.report_details.wekends ? (this.report_details.wekends / 100) * this.report_details.peopleCount : 0) },
		  // { color: '#66d078', value: (this.report_details.unPaidLeaves ? (this.report_details.unPaidLeaves / 100) * this.report_details.peopleCount : 0) },
		  { color: '#ff6afd', value: (this.report_details.onduty ? (this.report_details.onduty / 100) * this.report_details.peopleCount : 0) }]
		}
		this.nodata = false;
		this.loaderActionsService.display(false);
	  }
	})
  }

  gotoemployeepage(){
  	// localStorage.setItem('currentLoc',JSON.stringify({'id':this.selectedData.id,'zone':this.selectedData.timezone}));
  	localStorage.setItem('userDetails',JSON.stringify({location :{selected : this.selectedData}}));
  	this.router.navigate(['/modules/employee/details']);
  }

  gotoMarkattendence(){
		let today = `${this.date_today.getFullYear()}-${this.date_today.getMonth()+1}-${this.date_today.getDate()}`
		// localStorage.setItem('currentLoc',JSON.stringify({'id':this.selectedData.id,'zone':this.selectedData.timezone}));
		this.router.navigate(['modules/attendance/marking/'+today]);
		//comended
		// this.router.navigate(['modules/attendance/marking/'+today],{ queryParams: { order: 'popular' } });
		localStorage.setItem('currentLocid',JSON.stringify({'id':this.selectedItems.loc}))
  }

  	getCurrentDate(input) {
		let userData = JSON.parse(this.cookieService.get("user-data"));
		if (userData.apply_datetime_conversion == '1') {
			let value = moment().tz(input).format('Z');
			value = this.timeStringToFloat(value);
			value = value.replace(":", '.');
			return this.calcTime(value)
		}
		else {
			return new Date();
		}
	}

	timeStringToFloat(time) {
		var hoursMinutes = time.split(/[.:]/);
		var hours = parseInt(hoursMinutes[0], 10);
		var minutes = hoursMinutes[1] ? parseInt(hoursMinutes[1], 10) : 0;
		return (hours + minutes / 60).toString();
	}

	calcTime(offset, value?) {
		let d, utc, nd;
		if (value) {
			d = moment.utc(value).toDate();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
		else {
			d = new Date();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
	}
}

