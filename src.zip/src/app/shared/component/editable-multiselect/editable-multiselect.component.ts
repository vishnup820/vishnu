/*
 author : dipin
 desc   : component for editable multiselect
*/
import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef, OnChanges, SimpleChanges } from '@angular/core';
import { FormsModule, FormControl, Validators } from '@angular/forms';
import { Subscription, Subject, of } from 'rxjs';
import { debounceTime , distinctUntilChanged, map , mergeMap, delay } from 'rxjs/operators';
import { globalVariables } from '../../../shared/constants/globals';

@Component({
  selector: 'hris-editable-multiselect',
  templateUrl: './editable-multiselect.component.html',
  styleUrls: ['../../../../assets/content/css/multiselect.css']
})
export class EditableMultiselectComponent implements OnInit {

	@Input('data')        data 	      : any = [];
	@Input('keyName')     keyValue 	  : any;
	@Input('placeholder') placeholder : any;
	@Input('selectData')  selectData  : any = [];
	@Input('id')          id          : any;
	@Output() selectedData = new EventEmitter();

	enableDropDown  : boolean = false;
	selectedValues  : any;
	searchWord      : any     = '';
	selectedList    : any     = [];
	key             : string  = 'label';
	type            : any;
	textField       : any;
	count           : number = 0;

	public keyUp = new Subject<KeyboardEvent>();
	private subscription: Subscription;

	constructor(private change : ChangeDetectorRef) {
		this.subscription = this.keyUp.pipe(
			map(event => event && event.target['value']),
			debounceTime(500),
			distinctUntilChanged(),
		).subscribe((val) => { this.search(val) });
	}

	ngOnInit() {
		this.count = globalVariables.componentCount + 1;
	}

	ngOnChanges(changes: SimpleChanges) {
		if (this.data && this.data.length > 0 && (typeof this.data[0] == 'string' || typeof this.data[0] == 'number')) {
			this.type = 1;
		}
		else if (this.data && this.data.length > 0 && typeof this.data[0] == 'object') {
			this.type = 2;
		}
		if (this.type == 1) {
			let tempArray = [];
			for (let i = 0; i < this.data.length; i++) {
				tempArray.push({ id: (i + 1), label: this.data[i], fsChecked: false });
			}
			this.data = tempArray;
		}
		else if (this.type == 2) {
			let tempArray = [];
			for (let i = 0; i < this.data.length; i++) {
				tempArray.push({ id: (i + 1), label: this.data[i][this.keyValue], fsChecked: false, originalData: this.data[i] });
			}
			this.data = tempArray;
		}
		if (this.data && this.selectData) {
			// console.log(this.data)
			this.selectedList = [];
			stage1: for (var i = 0; i < this.data.length; i++) {
				stage2: for (var j = 0; j < this.selectData.length; j++) {
					if(!this.data[i].label)
						if(this.data[i].originalData.email){
                          this.data[i].label = this.data[i].originalData.email;
						}
						// else if(this.data[i].originalData.id){
						// 	this.data[i].id = this.data[i].originalData.id;
						//   }
						else{
						  this.data[i].label = this.data[i].originalData.label;;
						}
					if (this.selectData[j] == this.data[i].label) {
						this.selectedList.push(this.data[i]);
						this.selectedList = Object.values(this.selectedList.reduce((acc,cur)=>Object.assign(acc,{[cur.label]:cur}),{}));
						this.data[i].fsChecked = true;
						break stage2;
					}
				}
			}

           let tempArray = [];
           for(var i = 0;i < this.selectedList.length;i++){
             tempArray.push(this.selectedList[i].label);
           }
            if(this.selectData)
			 for(var i = 0 ; i < this.selectData.length;i++){
               if(!tempArray.includes(this.selectData[i])){
                  			this.selectedList.push({
				fsChecked: true,id: Number(this.data[i].id)+1,label: this.selectData[i],originalData:
					{
						email: this.selectData[i]
					}
			});
               }
			 }
			this.selectedData.emit(this.selectedList);
		}
    }

    /*
    author : dipin
    desc   : methods to implement operations on select data from the list
    */
	select(data) {
		if (data.fsChecked) {
			let index = this.selectedList.findIndex(x => x.id == data.id);
			this.selectedList.splice(index, 1);
			data.fsChecked = false;
		} else {
			data.fsChecked = true;
			this.selectedList.push(data);
		}

		if (this.type == 1) {
			let tempArray = [];
			for (let i = 0; i < this.selectedList.length; i++) {
				tempArray.push(this.selectedList[i].label);
			}
			this.selectedData.emit(tempArray);
		} else if (this.type == 2) {
			let tempArray = [];
			for (let i = 0; i < this.selectedList.length; i++) {
				tempArray.push(this.selectedList[i].originalData);
			}
		}
		this.textField = "";
		this.keyUp.next();
		this.enableDropDown = false;
		document.getElementById(this.id).focus();
	}

    /*
    author : dipin
    desc   : list the matching records based on keyword
    */
	search(x) {
		if (x && x.trim() != '') {
			this.enableDropDown = true;
			this.searchWord = x.trim();
		} else {
			this.enableDropDown = false;
			this.searchWord = '';
		}
	}

   /*
    author : dipin
    desc   : remove records from the selected list
   */
	remove(data) {
		let index = this.selectedList.findIndex(x => x.id == data.id);
		this.selectedList.splice(index, 1);
		let dataIndex = this.data.findIndex(x => x.id == data.id);

		if(this.data[dataIndex])
		 this.data[dataIndex].fsChecked = false;
	}

    /*
    author : dipin
    desc   :
   */
	onKeyDown(event) {
		var key = event.keyCode || event.charCode;
		if ((key == 8 || key == 46) && this.textField.trim() == '') {
			if (this.selectedList.length) {
				let id = this.selectedList.pop().id;
				this.selectedData.emit(this.selectedList);
				let dataIndex = this.data.findIndex(x => x.id == id);

				if(this.data[dataIndex])
				  this.data[dataIndex].fsChecked = false;
			}
		}	
		if(event.code == 'Tab' || event.code == 'Comma'){
          this.clickOutSide(true);
		}
	}

    /*
    author : dipin
    desc   :
    */
	clickOutSide(event) {
		let groupEmail;
		this.enableDropDown = false;
		if(this.textField)
		 groupEmail = this.textField.split(',');

		if(groupEmail){
			groupEmail = this.removeDuplicates(groupEmail);
			for(let i = 0 ; i < groupEmail.length;i++){
              this.checkEmail(groupEmail[i].trim());
			}
		}
		else {
         this.checkEmail(this.textField);
		}
		this.textField = "";
		this.selectedData.emit(this.selectedList);
		this.keyUp.next();
	}

	focusText() {
      document.getElementById(this.id).focus();
      this.enableDropDown = true;
	}

	checkEmail(value) {
		var email_exp = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
		if (email_exp.test(value)) {
			this.selectedList.push({
				fsChecked: true,id: Number(this.data[this.data.length - 1].id)+1,label: value,originalData:
					{
						email: value
					}
			});
			this.textField = "";
			this.data.push({
				fsChecked: true,id: Number(this.data[this.data.length - 1].id)+1,label: value,originalData:
					{
						email: value
					}
			});
		}
	}

    removeDuplicates(arr) {
		let unique_array = []
		for (let i = 0; i < arr.length; i++) {
			if (unique_array.indexOf(arr[i]) == -1) {
				unique_array.push(arr[i])
			}
		}
		return unique_array
	}
}
