import {
  Component,
  OnInit ,
  Input ,
  Output,
  EventEmitter,
  SimpleChanges,
  OnChanges,
  AfterViewInit,
  ChangeDetectorRef
} from '@angular/core';
  declare var require: any;
  var moment = require('moment');
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

@Component({
  selector    : 'app-calendar',
  templateUrl : './calendar.component.html',
  styleUrls   : ['./calendar.component.css']
})

export class CalendarComponent implements OnInit , OnChanges{
  @Input()   maxDate : Date;
  @Input()   minDate : Date;
  @Input()   setDate : any;
  @Output() changeDate = new EventEmitter();

  startDate  : any;
  editDate   : any;
  errorStatus: boolean = false;
  isOpen     : boolean = false;
  newDate    : any;

  constructor(private chRef : ChangeDetectorRef,private timeZone : TimezoneDetailsService) { }

  ngOnInit() {

  }

  ngOnChanges(changes: SimpleChanges) {
    let self = this;
    if (self.setDate) {
      self.startDate = this.timeZone.toLocal(self.setDate);
    }
    else{
      self.startDate = "";
      self.editDate  = "";
    }
  }

  changeDateFormat(event) {
    if(event){
      this.editDate = this.formatForApi(event);
      this.changeDate.emit({date:this.editDate,status:true});
    }
  }

  /*
  *  @desc   : date set for api format
  *  @author : dipin
  */
  formatForApi(inputDate) {
    var date = this.timeZone.toLocal(inputDate);
    if (!isNaN(date.getTime())) {
      if ((Number(date.getMonth()) + 1) < 10) {
        if (Number(date.getDate() < 10)) {
          return "0" + date.getDate() + "-" + "0" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
        }
        else {
          return date.getDate() + "-" + "0" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
        }
      }
      else {
        if (Number(date.getDate() < 10)) {
          return "0" + date.getDate() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
        }
        else {
          return date.getDate() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
        }
      }
    }
  }

  /*
  *  @desc   : accepting entered date format
  *  @author : dipin
  */
  enterDate() {
    this.changeDate.emit({ date: this.editDate, status: false });
    if (this.editDate.length < 7){
      this.newDate = undefined;
      this.editDate = this.editDate.replace(/[^0-9]/g, "");
      this.addSlash();
    }
    if (this.editDate.length == 10 && this.isValidDate(this.editDate)) {
      let tempDate = this.editDate.split('-');
      this.isOpen = false;
      if (moment(tempDate[0] + "-" + tempDate[1] + "-" + tempDate[2],'DD-MM-YYYY HH:mm').isValid() && moment(tempDate[0] + "-" + tempDate[1] + "-" + tempDate[2],'DD-MM-YYYY HH:mm').isBetween(this.minDate, this.maxDate)) {
        let date = tempDate[0]+"-"+tempDate[1]+"-"+tempDate[2];
        this.startDate = moment(tempDate[0] + "-" + tempDate[1] + "-" + tempDate[2],'DD-MM-YYYY HH:mm').format('DD-MM-YYYY HH:mm');
        this.errorStatus = false;
        this.changeDate.emit({ date: this.editDate, status: true });
      }
      else {
        this.errorStatus = true;
        this.changeDate.emit({ date: this.editDate, status: false });
      }
    }
    else{
      this.errorStatus = true;
      this.changeDate.emit({ date: this.editDate, status: false });
    }
  }

  isValidDate(s) {
    var bits = s.split('-');
    var d = new Date(bits[2], bits[1] - 1, bits[0]);
    return d && (d.getMonth() + 1) == bits[1];
  }

    /*
  *  @desc   : set date format
  *  @author : dipin
  */
  addSlash() {
    if (this.editDate.charAt(1) && this.editDate.charAt(2) != '-') {
      if (this.editDate.charAt(2) == '/') {
        this.editDate = this.editDate.replace("/", "-");
      }
      else if (this.editDate.charAt(2) == ' ') {
         this.editDate = this.editDate.replace(" ", "-");
      }
      else
        this.editDate = this.editDate.slice(0, 2) + '-' + this.editDate.slice(2);
    }
    if (this.editDate.charAt(4) && this.editDate.charAt(5) != '-') {
      if (this.editDate.charAt(5) == '/') {
         this.editDate = this.editDate.replace("/", "-");
      }
      else if (this.editDate.charAt(5) == ' ') {
         this.editDate = this.editDate.replace(" ", "-");
      }
      else
        this.editDate = this.editDate.slice(0, 5) + '-' + this.editDate.slice(5);
    }
  }

      /*
  *  @desc   : set date format on paste event
  *  @author : dipin
  */
  onPasteDate(value) {
    if (value.clipboardData.getData('text/plain') == this.newDate) {
      value.preventDefault();
      this.newDate = undefined;
    }
    else {
      this.newDate = value.clipboardData.getData('text/plain');
      if (value.clipboardData.getData('text/plain').length >= 8) {
        this.editDate = value.clipboardData.getData('text/plain');
        this.editDate = this.editDate.replace(/[^0-9]/g, "");
        this.addSlash();
      }
    }
  }

  /*
  *  @desc   : check date is valid or not ,on blur event
  *  @author : dipin
  */
  blurDate() {
    if (this.editDate) {
      let tempDate = this.editDate.split('-');
      this.isOpen = false;
      if (tempDate.length < 3 || tempDate[0] == "" || tempDate[1] == "" || tempDate[2] == "" || !this.isValidDate(this.editDate)) {
        this.errorStatus = true;
        this.newDate = undefined;
        this.changeDate.emit({ date: this.editDate, status: false });
      }
      else {
        if (moment(tempDate[0] + "-" + tempDate[1] + "-" + tempDate[2],'DD-MM-YYYY HH:mm').isValid() && moment(tempDate[0] + "-" + tempDate[1] + "-" + tempDate[2],'DD-MM-YYYY HH:mm').isBetween(this.minDate, this.maxDate)) {
          this.startDate = moment(tempDate[0] + "-" + tempDate[1] + "-" + tempDate[2],'DD-MM-YYYY HH:mm').format('DD-MM-YYYY HH:mm');
          this.errorStatus = false;
          this.changeDate.emit({ date: this.editDate, status: true });
        }
        else {
          this.errorStatus = true;
          this.newDate = undefined;
          this.changeDate.emit({ date: this.editDate, status: false });
        }
      }
    }
  }

}





