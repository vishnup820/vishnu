import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicableForComponent } from './applicable-for.component';

describe('ApplicableForComponent', () => {
  let component: ApplicableForComponent;
  let fixture: ComponentFixture<ApplicableForComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplicableForComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicableForComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
