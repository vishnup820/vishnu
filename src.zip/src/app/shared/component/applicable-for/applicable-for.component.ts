/*
*  @desc   :component for handling applicable-for form
*  @author :dipin
*/
import { Component, OnInit,Output,EventEmitter,Input,Renderer,SimpleChanges} from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { FormGroup,FormControl, Validators,FormBuilder } from '@angular/forms';
import { ApplyService } from '../../services/apply-for/apply.service';
import { ConstantServicesService } from '../../services/constant/constant-services.service';

@Component({
	selector: 'hris-applicable',
	templateUrl: './applicable-for.component.html',
	styleUrls: ['./applicable-for.component.css']
})
export class ApplicableForComponent implements OnInit {
	@Input()  editConfig         : any;
	@Input()  applicableDisable  : boolean;
	@Input()  submitted          : boolean;
	@Input()  sayClose           : boolean;
	@Input()  explodeApplicable  : boolean;
	@Input()  exclude            : boolean;
	@Input()  hideTag		 	 : boolean;
	@Input()  hideLabel          : boolean;
	@Input()  showUser           : boolean;
	@Input()  userLocationGroup  : boolean;
	@Input()  showData           : any;
	@Input()  locationOnly       : boolean;
	@Input()  removenotApplicable:boolean;
	@Input() userOnly            : boolean ;

	@Output() selectedData     = new EventEmitter();
	displayApplicable            : boolean = true;
	applicableStatus             : boolean = true;
	lazy              			 : boolean = false;
	showuserOnly                 : boolean = false;
	tempList          			 : any     = [];
	sidebarData       			 : any     = [];
	rSidebarData      			 : any     = [];
	statusListSidebar 			 : any     = [];
	statusNonSidebar  			 : any     = [];
	selectedApplicable			 : any = [];
	selectedIndex     			 : any;
	listenFunc        			 : any
	setLength         			 : any;
	searchApplicableText 	     : any;
	selectedNonIndex  			 : any;
	searchText        			 : any;
	hide 					 	 : boolean;
	hideText                     : boolean;
	results           			 : Object;
    searchTerm                  = new Subject<string>();

	constructor(private searchService : ApplyService,
		        private renderer      : Renderer,
		        private apiService    : ConstantServicesService) {
	}

	ngOnInit() {
		if (this.hideTag == true) {
			this.hide = true;
		}
		if (this.hideLabel == true) {
			this.hideText = true;
		}
		if (this.editConfig.editStatus) {
			this.lazy = true;
			this.displayApplicable = true;
			this.searchService.id = this.editConfig.id;
			this.searchService.url = this.editConfig.url;
			if (this.showData) {
				if(this.showData.applicable_for)
				  this.sidebarData = this.showData.applicable_for.reverse();
				else
				  this.sidebarData = this.showData.applicable_for;

				if(this.showData.not_applicable_for)
                  this.rSidebarData = this.showData.not_applicable_for.reverse();
			    else
				  this.rSidebarData = this.showData.not_applicable_for;

				if(this.sidebarData && this.rSidebarData)
				for(let i = 0 ; i < this.sidebarData.length;i++){
                  if (this.sidebarData[i].name == "user") {
					   for(let j = 0 ; j < this.sidebarData[i].list.length;j++){

					   	  if(!this.sidebarData[i].list[j].name.includes('(') && !this.sidebarData[i].list[j].name.includes(')')){
					   	  	this.sidebarData[i].list[j].name  = this.sidebarData[i].list[j].name +" (ID"+this.sidebarData[i].list[j].code+")";
					   	  }
					   	 if(!this.rSidebarData[i].list[j].name.includes('(') && !this.rSidebarData[i].list[j].name.includes(')')){
					   	  this.rSidebarData[i].list[j].name = this.rSidebarData[i].list[j].name +" (ID"+this.rSidebarData[i].list[j].code+")";
					   	}
					   }
				   }
				}
				if (this.sidebarData && this.rSidebarData) {
					if (this.exclude == true) {
						let temp = [];
						for (var i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[i].name == "location" || this.sidebarData[i].name == "group") {
								temp.push(this.sidebarData[i]);
							}
						}
						this.sidebarData = temp.reverse();
					}
					else if (this.showUser) {
						let temp = [];
						for (var i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[i].name == "user" || this.sidebarData[i].name == "group") {
								temp.push(this.sidebarData[i]);
							}
						}
						this.sidebarData = temp.reverse();
					}
					else if (this.locationOnly) {
						let temp = [];
						for (var i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[i].name == "location") {
								temp.push(this.sidebarData[i]);
							}
						}
						this.sidebarData = temp.reverse();
					}
					else if (this.userLocationGroup) {
						let temp = [];
						for (var i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[i].name == "location" || this.sidebarData[i].name == "group" || this.sidebarData[i].name == "user") {
								temp.push(this.sidebarData[i]);
							}
						}
						this.sidebarData = temp.reverse();
					}
					this.selectedIndex = 0;
					this.selectedNonIndex = 0;
					if (this.sidebarData || this.rSidebarData) {
						for (var i = 0; i < this.sidebarData.length; i++) {
							this.sidebarData[i].status = false;
							this.sidebarData[i].selectedAll = false;
							this.sidebarData[i].listAppl = [];
						}
						for (var i = 0; i < this.sidebarData.length; i++) {
							this.rSidebarData[i].status = false;
							this.rSidebarData[i].selectedAll = false;
							this.rSidebarData[i].listAppl = [];
						}

                        for(let i = 0; i < this.sidebarData.length;i++){
                          this.sidebarData[i].status = false;
                        }
                        for(let i = 0; i < this.rSidebarData.length;i++){
                          this.rSidebarData[i].status = false;
                        }
						this.sidebarData[0].status = true;
						this.rSidebarData[0].status = true;
						for (var i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[i].all == true) {
								this.selectedAllSub(i, true);
							}
							else {
								this.checkSelected(i, true);
								this.setStatusList(true);
							}
						}
						for (var i = 0; i < this.rSidebarData.length; i++) {
							if (this.rSidebarData[i].all == true) {
								this.selectedAllSub(i, false);
							}
							else {
								this.checkSelected(i, false);
								this.setStatusList(false);
							}
						}
						this.searchService.currentUrl = this.sidebarData[0].link;
						this.checkSelected(0, false);
						this.setStatusList(false);
						this.tempList = [];
						for (var i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[i].all != "1")
								for (var j = 0; j < this.sidebarData[i].list.length; j++) {
									if (this.sidebarData[i].list[j].is_selected == "1" && this.sidebarData[i].list[j] != "")
										this.tempList.push(this.sidebarData[i].list[j].name);
								}
							else
								this.tempList.push("All " + this.sidebarData[i].name);
						}
					}
					this.selectedData.emit({ "applicable": this.sidebarData, "notApplicable": this.rSidebarData });
					this.lazy = false;
				}
			}
			else
				this.searchService.getDetailsEdit(response => {
					if (response.status == "OK") {
						this.sidebarData = JSON.parse(JSON.stringify(response.data.applicable_for)).reverse();
						this.rSidebarData = JSON.parse(JSON.stringify(response.data.not_applicable_for)).reverse();
						let cStatus = false;
						if(this.sidebarData && this.rSidebarData)
						for (let i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[0].name == "user") {
						     cStatus = true;
					        }
					        else {
						     cStatus = false;
					        }
							if (this.sidebarData[i].name == "user") {
								for (let j = 0; j < this.sidebarData[i].list.length; j++) {
									this.sidebarData[i].list[j].name = this.sidebarData[i].list[j].name + " (ID" + this.sidebarData[i].list[j].code + ")";
									this.rSidebarData[i].list[j].name = this.rSidebarData[i].list[j].name + " (ID" + this.rSidebarData[i].list[j].code + ")";
								}
							}
						}
						if (this.exclude == true) {
							let temp = [];
							for (var i = 0; i < this.sidebarData.length; i++) {
								if (this.sidebarData[i].name == "location" || this.sidebarData[i].name == "group") {
									temp.push(this.sidebarData[i]);
								}
							}
							if (!cStatus)
						    this.sidebarData = temp.reverse();
					        else
						    this.sidebarData = temp;
						}
						else if (this.showUser) {
							let temp = [];
							for (var i = 0; i < this.sidebarData.length; i++) {
								if (this.sidebarData[i].name == "user" || this.sidebarData[i].name == "group") {
									temp.push(this.sidebarData[i]);
								}
							}
							if (!cStatus)
						    this.sidebarData = temp.reverse();
					        else
						    this.sidebarData = temp;
						}
						else if (this.locationOnly) {
						let temp = [];
						for (var i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[i].name == "location") {
								temp.push(this.sidebarData[i]);
							}
						}
						if (!cStatus)
						this.sidebarData = temp.reverse();
					    else
						this.sidebarData = temp;
					    }
					    else if (this.userLocationGroup) {
						let temp = [];
						for (var i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[i].name == "location" || this.sidebarData[i].name == "group" || this.sidebarData[i].name == "user") {
								temp.push(this.sidebarData[i]);
							}
						}
						if (!cStatus)
						this.sidebarData = temp.reverse();
					    else
						this.sidebarData = temp;
					    }
						this.selectedIndex = 0;
						this.selectedNonIndex = 0;
						if (this.sidebarData || this.rSidebarData) {
							for (var i = 0; i < this.sidebarData.length; i++) {
								this.sidebarData[i].status = false;
								this.sidebarData[i].selectedAll = false;
								this.sidebarData[i].listAppl = [];
							}
							for (var i = 0; i < this.sidebarData.length; i++) {
								this.rSidebarData[i].status = false;
								this.rSidebarData[i].selectedAll = false;
								this.rSidebarData[i].listAppl = [];
							}

							this.sidebarData[0].status = true;
							this.rSidebarData[0].status = true;
							for (var i = 0; i < this.sidebarData.length; i++) {
								if (this.sidebarData[i].all == true) {
									this.selectedAllSub(i, true);
								}
								else {
									this.checkSelected(i, true);
									this.setStatusList(true);
								}
							}
							for (var i = 0; i < this.rSidebarData.length; i++) {
								if (this.rSidebarData[i].all == true) {
									this.selectedAllSub(i, false);
								}
								else {
									this.checkSelected(i, false);
									this.setStatusList(false);
								}
							}
							this.searchService.currentUrl = this.sidebarData[0].link;
							this.checkSelected(0, false);
							this.setStatusList(false);
							this.tempList = [];
							for (var i = 0; i < this.sidebarData.length; i++) {
								if (this.sidebarData[i].all != "1")
									for (var j = 0; j < this.sidebarData[i].list.length; j++) {
										if (this.sidebarData[i].list[j].is_selected == "1" && this.sidebarData[i].list[j] != "")
											this.tempList.push(this.sidebarData[i].list[j].name);
									}
								else
									this.tempList.push("All " + this.sidebarData[i].name);
							}
						}
						this.selectedData.emit({ "applicable": this.sidebarData, "notApplicable": this.rSidebarData });
						this.lazy = false;
					}
					else {
						this.sidebarData = [];
						this.selectedData.emit({ "applicable": this.sidebarData, "notApplicable": this.rSidebarData });
						this.lazy = false;
					}
				})
		}
		else {
			this.lazy = true;
			this.searchService.getDetails(this.exclude, response => {
				if (response.status == "OK") {
					this.sidebarData = JSON.parse(JSON.stringify(response.data)).reverse();
					this.rSidebarData = JSON.parse(JSON.stringify(response.data)).reverse();
					let cStatus = false;
					if(this.sidebarData && this.rSidebarData)
					for (let i = 0; i < this.sidebarData.length; i++) {
						if (this.sidebarData[0].name == "user") {
						  cStatus = true;
					    }
					    else {
						  cStatus = false;
					    }
						if (this.sidebarData[i].name == "user") {
							for (let j = 0; j < this.sidebarData[i].list.length; j++) {
								this.sidebarData[i].list[j].name = this.sidebarData[i].list[j].name + " (ID " + this.sidebarData[i].list[j].code + ")";
								this.rSidebarData[i].list[j].name = this.rSidebarData[i].list[j].name + " (ID " + this.rSidebarData[i].list[j].code + ")";
							}
						}
					}
					this.selectedIndex = 0;
					this.selectedNonIndex = 0;

					if (this.exclude == true) {
						let temp = [];
						for (var i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[i].name == "location" || this.sidebarData[i].name == "group") {
								temp.push(this.sidebarData[i]);
							}
						}
						if (!cStatus)
						this.sidebarData = temp.reverse();
					    else
						this.sidebarData = temp;
					}
					else if (this.showUser) {
						let temp = [];
						for (var i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[i].name == "user" || this.sidebarData[i].name == "group") {
								temp.push(this.sidebarData[i]);
							}
						}
						if (!cStatus)
						this.sidebarData = temp.reverse();
					    else
						this.sidebarData = temp;
					}
					else if (this.locationOnly) {
						let temp = [];
						for (var i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[i].name == "location") {
								temp.push(this.sidebarData[i]);
							}
						}
						if (!cStatus)
						this.sidebarData = temp.reverse();
					    else
						this.sidebarData = temp;
					}
					else if (this.userLocationGroup) {
						let temp = [];
						for (var i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[i].name == "location" || this.sidebarData[i].name == "group" || this.sidebarData[i].name == "user") {
								temp.push(this.sidebarData[i]);
							}
						}
						if (!cStatus)
						this.sidebarData = temp.reverse();
					    else
						this.sidebarData = temp;
					}

					for (var i = 0; i < this.sidebarData.length; i++) {
						this.sidebarData[i].status = false;
						this.sidebarData[i].selectedAll = false;
					}
					for (var i = 0; i < this.sidebarData.length; i++) {
						this.rSidebarData[i].status = false;
						this.rSidebarData[i].selectedAll = false;
					}
					this.sidebarData[0].status = true;
					this.rSidebarData[0].status = true;
					this.tempList = [];
					this.searchService.currentUrl = this.sidebarData[0].link;
					this.setStatusList(true);
					this.selectedData.emit({ "applicable": this.sidebarData, "notApplicable": this.rSidebarData });
					this.lazy = false;
				}
				else {
					this.sidebarData = [];
					this.selectedData.emit({ "applicable": this.sidebarData, "notApplicable": this.rSidebarData });
					this.lazy = false;
				}
			})
		}
	}

		ngOnChanges(changes: SimpleChanges) {
		if (this.showData && !this.submitted) {
			if(this.showData.applicable_for != null){
              this.sidebarData = this.showData.applicable_for.reverse();
			}
			else{
              this.sidebarData = this.showData.applicable_for;
			}

			if(this.showData.not_applicable_for != null){
              this.rSidebarData = this.showData.not_applicable_for.reverse();
			}
			else{
			  this.rSidebarData = this.showData.not_applicable_for;
			}

			if (this.sidebarData && this.rSidebarData) {
				let cStatus = false;
				for (let i = 0; i < this.sidebarData.length; i++) {
					if (this.sidebarData[0].name == "user") {
						cStatus = true;
					}
					else {
						cStatus = false;
					}
					// if (this.sidebarData[i].name == "user") {
					// 	for (let j = 0; j < this.sidebarData[i].list.length; j++) {
					// 		this.sidebarData[i].list[j].name = this.sidebarData[i].list[j].name + " (ID " + this.sidebarData[i].list[j].code + ")";
					// 		this.rSidebarData[i].list[j].name = this.rSidebarData[i].list[j].name + " (ID " + this.rSidebarData[i].list[j].code + ")";
					// 	}
					// }
					for(let i = 0 ; i < this.sidebarData.length;i++){
                  if (this.sidebarData[i].name == "user") {
					   for(let j = 0 ; j < this.sidebarData[i].list.length;j++){

					   	  if(!this.sidebarData[i].list[j].name.includes('(') && !this.sidebarData[i].list[j].name.includes(')')){
					   	  	this.sidebarData[i].list[j].name  = this.sidebarData[i].list[j].name +" (ID"+this.sidebarData[i].list[j].code+")";
					   	  }
					   	 if(!this.rSidebarData[i].list[j].name.includes('(') && !this.rSidebarData[i].list[j].name.includes(')')){
					   	  this.rSidebarData[i].list[j].name = this.rSidebarData[i].list[j].name +" (ID"+this.rSidebarData[i].list[j].code+")";
					   	}
					   }
				   }
				}
				}
				if (this.exclude == true) {
					let temp = [];
					for (var i = 0; i < this.sidebarData.length; i++) {
						if (this.sidebarData[i].name == "location" || this.sidebarData[i].name == "group") {
							temp.push(this.sidebarData[i]);
						}
					}
					if (!cStatus)
						this.sidebarData = temp.reverse();
					else
						this.sidebarData = temp;
				}
				else if (this.showUser) {
					let temp = [];
					for (var i = 0; i < this.sidebarData.length; i++) {
						if (this.sidebarData[i].name == "user" || this.sidebarData[i].name == "group") {
							temp.push(this.sidebarData[i]);
						}
					}
					if (!cStatus)
						this.sidebarData = temp.reverse();
					else
						this.sidebarData = temp;
				}
				else if (this.locationOnly) {
					let temp = [];
					for (var i = 0; i < this.sidebarData.length; i++) {
						if (this.sidebarData[i].name == "location") {
							temp.push(this.sidebarData[i]);
						}
					}
					if (!cStatus)
						this.sidebarData = temp.reverse();
					else
						this.sidebarData = temp;
				}
				else if (this.userLocationGroup) {
						let temp = [];
						for (var i = 0; i < this.sidebarData.length; i++) {
							if (this.sidebarData[i].name == "location" || this.sidebarData[i].name == "group" || this.sidebarData[i].name == "user") {
								temp.push(this.sidebarData[i]);
							}
						}
						if (!cStatus)
						this.sidebarData = temp.reverse();
					    else
						this.sidebarData = temp;
			    }
				this.selectedIndex = 0;
				this.selectedNonIndex = 0;
				if (this.sidebarData || this.rSidebarData) {
					for (var i = 0; i < this.sidebarData.length; i++) {
						this.sidebarData[i].status = false;
						this.sidebarData[i].selectedAll = false;
						this.sidebarData[i].listAppl = [];
					}
					for (var i = 0; i < this.sidebarData.length; i++) {
						this.rSidebarData[i].status = false;
						this.rSidebarData[i].selectedAll = false;
						this.rSidebarData[i].listAppl = [];
					}

					this.sidebarData[0].status = true;
					this.rSidebarData[0].status = true;
					for (var i = 0; i < this.sidebarData.length; i++) {
						if (this.sidebarData[i].all == true) {
							this.selectedAllSub(i, true);
						}
						else {
							this.checkSelected(i, true);
							this.setStatusList(true);
						}
					}
					for (var i = 0; i < this.rSidebarData.length; i++) {
						if (this.rSidebarData[i].all == true) {
							this.selectedAllSub(i, false);
						}
						else {
							this.checkSelected(i, false);
							this.setStatusList(false);
						}
					}
					this.searchService.currentUrl = this.sidebarData[0].link;
					this.checkSelected(0, false);
					this.setStatusList(false);
					this.tempList = [];
					for (var i = 0; i < this.sidebarData.length; i++) {
						if (this.sidebarData[i].all != "1")
							for (var j = 0; j < this.sidebarData[i].list.length; j++) {
								if (this.sidebarData[i].list[j].is_selected == "1" && this.sidebarData[i].list[j] != "")
									this.tempList.push(this.sidebarData[i].list[j].name);
							}
						else
							this.tempList.push("All " + this.sidebarData[i].name);
					}
				}
				this.selectedData.emit({ "applicable": this.sidebarData, "notApplicable": this.rSidebarData });
				this.lazy = false;
			}
		}
	}

	closeAll() {
       this.apiService.popupStatus(!this.displayApplicable);
	}

	setUrlSearch(value){
      if(value == true){
        this.searchService.currentUrl = this.sidebarData[0].link;
      }
      else{
        this.searchService.currentUrl = this.rSidebarData[0].link;
      }
	}

    /*
    *  @desc   :component for handling applicable-for form
    *  @author :dipin
    */
	setStatusList(value) {
		if (value == true) {
			this.statusListSidebar = [];
			if (this.sidebarData)
				for (var i = 0; i < this.sidebarData.length; i++) {
					let countStatus = false;
					for (var j = 0; j < this.sidebarData[i].list.length; j++) {
						if (this.sidebarData[i].list[j].is_selected == 1) {
							countStatus = true;
							break;
						}
					}
					this.statusListSidebar.push(countStatus);
				}
		}
		else {
			this.statusNonSidebar = [];
			if (this.rSidebarData)
				for (var i = 0; i < this.rSidebarData.length; i++) {
					let countStatus = false;
					for (var j = 0; j < this.rSidebarData[i].list.length; j++) {
						if (this.rSidebarData[i].list[j].is_selected == 1) {
							countStatus = true;
							break;
						}
					}
					this.statusNonSidebar.push(countStatus);
				}

		}
	}

    /*
    *  @desc   :method for dealing sidebarmenu selection
    *  @author :dipin
    */
	setSidebarMainmenu(index, value) {
		if (value == true) {
			this.sidebarData[index].status = true;
			this.selectedIndex = index;
			this.searchService.currentUrl = (this.sidebarData[index].link);
			for (var i = 0; i < this.sidebarData.length; i++) {
				if (i != index) {
					this.sidebarData[i].status = false;
				}
			}
			this.selectedData.emit({"applicable":this.sidebarData,"notApplicable":this.rSidebarData});
		}
		else {
            this.rSidebarData[index].status = true;
			this.selectedNonIndex = index;
			this.searchService.currentUrl = (this.rSidebarData[index].link);
			for (var i = 0; i < this.rSidebarData.length; i++) {
				if (i != index) {
					this.rSidebarData[i].status = false;
				}
			}
			this.selectedData.emit({"applicable":this.sidebarData,"notApplicable":this.rSidebarData});
		}
	}

    /*
     *  @desc   :
     *  @author :dipin
     */
	subValueCheck(i,value,id) {
		if (value == true) {
			for (var l = 0; l < this.sidebarData[i].list.length; l++) {
				if (this.sidebarData[i].list[l].id == id) {
					if (this.sidebarData[i].list[l].is_selected == 0) {
						this.sidebarData[i].list[l].is_selected = 1;
					}
					else
						this.sidebarData[i].list[l].is_selected = 0;
				}
			}
			this.setStatusList(value);
			this.checkSelected(i, value);
			this.selectedData.emit({ "applicable": this.sidebarData, "notApplicable": this.rSidebarData });
		}
		else {
            for (var l = 0; l < this.rSidebarData[i].list.length; l++) {
				if (this.rSidebarData[i].list[l].id == id) {
					if (this.rSidebarData[i].list[l].is_selected == 0) {
						this.rSidebarData[i].list[l].is_selected = 1;
					}
					else
						this.rSidebarData[i].list[l].is_selected = 0;
				}
			}
			this.setStatusList(value);
			this.checkSelected(i, value);
			this.selectedData.emit({"applicable":this.sidebarData,"notApplicable":this.rSidebarData});
		}
	}

    /*
     *  @desc   :remove all selection in click
     *  @author :dipin
     */
	removeAllSelect(i, value) {
		if (value == true) {
			for (var j = 0; j < this.sidebarData[i].list.length; j++) {
				this.sidebarData[i].list[j].is_selected = 0;
			}
			this.sidebarData[i].selectedAll = false;
			this.sidebarData[i].all = 0;
			this.setStatusList(value);
			this.selectedData.emit({"applicable":this.sidebarData,"notApplicable":this.rSidebarData});
		}
		else {
            for (var j = 0; j < this.rSidebarData[i].list.length; j++) {
				this.rSidebarData[i].list[j].is_selected = 0;
			}
			this.rSidebarData[i].selectedAll = false;
			this.rSidebarData[i].all = 0;
			this.setStatusList(value);
			this.selectedData.emit({"applicable":this.sidebarData,"notApplicable":this.rSidebarData});
		}
	}

    /*
     *  @desc   :select all function for button click
     *  @author :dipin
     */
	selectedAllSub(i, value) {
		if (value == true) {
			for (var j = 0; j < this.sidebarData[i].list.length; j++) {
				if (this.sidebarData[i].selectedAll)
					this.sidebarData[i].list[j].is_selected = 0;
				else
					this.sidebarData[i].list[j].is_selected = 1;
			}
			this.sidebarData[i].selectedAll = !this.sidebarData[i].selectedAll;
			this.setStatusList(value);
			this.searchApplicableText = "";
			this.selectedData.emit({"applicable":this.sidebarData,"notApplicable":this.rSidebarData});
		}
		else {
			this.searchText = "";
           for (var j = 0; j < this.rSidebarData[i].list.length; j++) {
				if (this.rSidebarData[i].selectedAll)
					this.rSidebarData[i].list[j].is_selected = 0;
				else
					this.rSidebarData[i].list[j].is_selected = 1;
			}
			this.rSidebarData[i].selectedAll = !this.rSidebarData[i].selectedAll;
			this.setStatusList(value);
			this.selectedData.emit({"applicable":this.sidebarData,"notApplicable":this.rSidebarData});
		}
	}

    /*
     *  @desc   :check the count of selection in listed value
     *  @author :dipin
     */
	checkSelected(i, value) {
		if (value == true) {
			for (var j = 0; j < this.sidebarData[i].list.length; j++) {
				if (this.sidebarData[i].list[j].is_selected == 1) {
					this.sidebarData[i].selectedAll = true;
				}
				else {
					this.sidebarData[i].selectedAll = false;
					break;
				}
			}
		}
		else {
			for (var j = 0; j < this.rSidebarData[i].list.length; j++) {
				if (this.rSidebarData[i].list[j].is_selected == 1) {
					this.rSidebarData[i].selectedAll = true;
				}
				else {
					this.rSidebarData[i].selectedAll = false;
					break;
				}
			}
		}
	}

	setData() {
		this.tempList = [];
		for (var i = 0; i < this.sidebarData.length; i++) {
			if(this.sidebarData[i].all != "1")
			for (var j = 0; j < this.sidebarData[i].list.length; j++) {
				if (this.sidebarData[i].list[j].is_selected == "1" && this.sidebarData[i].list[j] != "")
					this.tempList.push(this.sidebarData[i].list[j].name);
			}
            else
            	this.tempList.push("All "+this.sidebarData[i].name);
		}
	}
}
