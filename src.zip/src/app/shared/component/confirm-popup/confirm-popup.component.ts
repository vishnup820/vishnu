import { Component, OnInit, EventEmitter, Output,Input} from '@angular/core';

@Component({
  selector: 'hris-confirm-popup',
  templateUrl: './confirm-popup.component.html',
  styleUrls: ['../../../../assets/content/css/toast-and-confirmation.css']
})
export class ConfirmPopupComponent implements OnInit {
     confirmStatus		:	boolean;
	@Output() 	status 	:	EventEmitter<any> 		= 	new EventEmitter();
	@Output() noStatus	:	EventEmitter<any> 		= 	new EventEmitter();
	@Input() 	config 	:	any;
	@Input()  type      : any;

	constructor() {
	}

	ngOnInit() {
		this.confirmStatus  =  true;
  	}

  	/*
  	*  @desc   :close button to close the popup window
  	*  @author :dipin
 	 */
 	closePopup(){
		this.confirmStatus = false;
		this.noStatus.emit(false);
  	}

  	/*
  	*  @desc   :user confirmation of popupbox confirmation and emit value
  	*  @author :dipin
  	*/
  	confirmation(value:string){
		if(value=='no'){
			this.confirmStatus 	=	false;
			this.noStatus.emit(false);
		}
		else{
	  		this.confirmStatus 	= 	false;
	  		this.status.emit(true);
		}
   	}

}
