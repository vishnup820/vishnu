/*
*  @desc   :alertbox component for notifications
*  @author :dipin
*/
import { Component, OnInit, Input } from '@angular/core';

import { NotificationService } from '../../services/notifications/notification.service';

@Component({
	selector: 'hris-alertbox',
	templateUrl: './alertbox.component.html',
	styleUrls: ['../../../../assets/content/css/toast-and-confirmation.css']
})
export class AlertboxComponent implements OnInit {

	alertValue: any;

	constructor(private notificationService: NotificationService) {
		this.alertValue = notificationService.alertBox;
	}

	ngOnInit() { }

	/*
	*  @desc   :close button function for alert boxes
	*  @author :dipin
	*/
	closeAlert(value: string) {
		switch (value) {
			case "error":
				this.notificationService.alertBox.error.status = false;
				break;
			case "warning":
				this.notificationService.alertBox.warning.status = false;
				break;
			case "info":
				this.notificationService.alertBox.info.status = false;
				break;
			case "success":
				this.notificationService.alertBox.success.status = false;
				break;
			default:
				break;
		}
		this.alertValue = this.notificationService.alertBox;
	}
}
