import { Component, OnInit, EventEmitter, Output,Input } from '@angular/core';

@Component({
  selector: 'hris-cancel-popup',
  templateUrl: './cancel-popup.component.html',
  styleUrls: ['./cancel-popup.component.css']
})
export class CancelPopupComponent implements OnInit {


    reason              :   any = "";

    confirmStatus		:	boolean;
    formerror           :   boolean = false;

	@Output() 	status 	:	EventEmitter<any> 		= 	new EventEmitter();
	@Output() noStatus	:	EventEmitter<any> 		= 	new EventEmitter();

	constructor() {
	}

	ngOnInit() {
		this.confirmStatus  =  true;
  	}

  	/*
  	*  @desc   :close button to close the popup window
  	*  @author :dipin
 	 */
 	closePopup(){
		this.confirmStatus = false;
		let reason         = this.reason;
		this.noStatus.emit(false);
  	}

  	/*
  	*  @desc   :user confirmation of popupbox confirmation and emit value
  	*  @author :dipin
  	*/
  	confirmation(value:string){
		if(value=='no'){
			let reason = this.reason;
			this.confirmStatus 	=	false;
			this.noStatus.emit(false);
		}
		else{
			let reason = this.reason;
	  		this.confirmStatus 	= 	false;
	  		if(this.reason && this.reason.trim() != "") {
	  			this.status.emit({"status":true,"value": reason});
	  		} else {
	  			this.formerror = true;
	  			this.reason    = this.reason.trim();
	  		}
		}
   	}
}
