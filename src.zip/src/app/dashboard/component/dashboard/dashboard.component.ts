/*
*  @desc   :component for display dashboard
*  @author :dipin
*/
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(
  	private cookieService       : CookieService,
  	private router              : Router,) { }

  ngOnInit() {
  	if(this.cookieService.get('session')){
            let url : string = JSON.parse(this.cookieService.get('user-data')).landing_url;
            this.router.navigateByUrl("/"+url);
    }
  }

}
