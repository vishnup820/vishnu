import { NgModule,ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { GlobalErrorHandlerService } from '../global-error-handler.service';

import { SharedModule } from '../shared/shared.module';

import { DashboardComponent } from './component/dashboard/dashboard.component';

const routes: Routes = [
	{path: '', component: DashboardComponent, pathMatch: 'full'}
];

@NgModule({
  declarations: [DashboardComponent],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(routes)
  ] ,
  providers: [
    {
      provide  : ErrorHandler,
      useClass : GlobalErrorHandlerService,
    }
  ],
})
export class DashboardModule { }
