import { NgModule,ErrorHandler} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';

import { LoginComponent } from './component/login/login.component';
import { GlobalErrorHandlerService } from '../global-error-handler.service';

import { LoginService }  from '../auth/services/login/login.service';
import { LoginGuardService }  from '../auth/services/login-guard/login-guard.service';
import { ForgotPasswordComponent } from './component/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './component/reset-password/reset-password.component';

@NgModule({
  declarations: [LoginComponent, ForgotPasswordComponent, ResetPasswordComponent],
  providers   : [
   LoginService,
   CookieService,
   {
    provide  : ErrorHandler,
    useClass : GlobalErrorHandlerService,
   }
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forChild([
		    {
        	path        : 'login',
        	component   : LoginComponent
        },
                {
          path        : 'forgot-password',
          canActivate : [LoginGuardService],
          component   : ForgotPasswordComponent
        },
        {
          path        : 'reset-password/:id',
          component   : ResetPasswordComponent
        },
        {
          path        : 'reset-password',
          component   : ResetPasswordComponent
        }
    ])
  ],
})
export class AuthModule { }
