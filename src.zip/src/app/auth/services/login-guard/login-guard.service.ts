import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild , Router} from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
// import { LoaderActionsService } from '../loader/loader-actions.service';
@Injectable({
  providedIn: 'root'
})
export class LoginGuardService implements CanActivate{

  constructor(	private cookieService : CookieService,
  	            private router        : Router) { }

	canActivate() {
		let currentDomain = window.location.origin.split('/'), temp;
		currentDomain[2] = currentDomain[2].replace(':4200', '');//for local only
		if (this.cookieService.get(currentDomain[2] + "Client") && JSON.parse(this.cookieService.get(currentDomain[2] + "Client")).auth_type == "internal") {
			return true;
		}
		else {
			this.router.navigate(['login']);
			return false;
		}
	}
}
