import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/toPromise';

import { apiList } from '../../../shared/constants/apilist';
import { globalVariables } from '../../../shared/constants/globals';

@Injectable()

export class LoginService {
    apiBaseUrl : string;
    constValue : boolean = false;

    constructor(private http: HttpClient) {
        this.apiBaseUrl = globalVariables.apiBaseUrl;
    }

    /*
    *  @desc   :authentication api call
    *  @author :vinod
    *  @params :user name & password
    */
    login(user,cb):void{
        let url: string = this.apiBaseUrl + apiList.auth.login;
        this.http.post(url,user)
        .toPromise()
        .then(res=>{
            cb(res);
        });
    }

     /*
    *  @desc   :authentication detail based on domain
    *  @author :vinod
    *  @params :user name & password
    */
    getDomain(domain,cb):void{
        let url: string = this.apiBaseUrl + apiList.auth.entityInfo+"?domain="+domain;
        this.http.get(url)
        .toPromise()
        .then(res=>{
            cb(res);
            //console.log(res);
        });
    }
}
