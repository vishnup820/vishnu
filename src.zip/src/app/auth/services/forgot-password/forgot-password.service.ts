import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/toPromise';

import { apiList } from '../../../shared/constants/apilist';
import { globalVariables } from '../../../shared/constants/globals';

@Injectable({
  providedIn: 'root'
})
export class ForgotPasswordService {
    apiBaseUrl: string;

    constructor(private http: HttpClient) {
        this.apiBaseUrl = globalVariables.apiBaseUrl;
    }

    /*
    *  @desc   : submiting email id to the server for verification code
    *  @author : dipin dinesh
    */
    forgotPassword(user,cb):void{
        let url: string = this.apiBaseUrl + apiList.auth.sendMail;
        this.http.post(url,{"search" : user})
        .toPromise()
        .then(res=>{
            cb(res);
        });
    }

    /*
    *  @desc   : submiting email id to the server for verification code
    *  @author : dipin dinesh
    */
    resetPassword(obj,cb):void{
        let url: string = this.apiBaseUrl + apiList.auth.resetPassword;
        this.http.put(url,obj)
        .toPromise()
        .then(res=>{
            cb(res);
        });
    }
}
