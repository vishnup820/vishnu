import { Component, OnInit,ElementRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ForgotPasswordService } from '../../services/forgot-password/forgot-password.service';
import { CookieService } from 'ngx-cookie-service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { LoginService } from '../../services/login/login.service';
import { CookieDataService } from '../../../shared/services/cookie-data/cookie-data.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['../../../../assets/content/css/login.css']
})
export class ResetPasswordComponent implements OnInit {

	resetPassword       : FormGroup;
	newPassword         : FormControl;
	rePass              : FormControl;
	formError           : boolean = false;
	passwordMatchStatus : boolean = false;
	lazyLoad            : boolean = false;
	usernameStatus      : boolean = false;
	newpassStatus       : boolean = false;
	showError           : boolean = false;
	confirmpassStatus   : boolean = false;
	loginApiStatus      : boolean = false;
	validationError     : boolean = false;
	noValue             : boolean = false;
	reInputPass         : any;
	newInputPass        : any;
	successMessage      : any;
	errorMessage        : any;
	code                : any;
	entityInfo          : any;
	errorMsg            :string="";

	constructor(private cookieService: CookieService,
		private cookies : CookieDataService,
		private router         : Router,
		private dataService    : ForgotPasswordService,
        private routerActivated: ActivatedRoute,
        private loginService   : LoginService) { }

	ngOnInit() {
		let href = this.router.url.split("/");
		let currentDomain = window.location.origin.split('/');
		currentDomain[2] = currentDomain[2].replace(':4200','');//for local only
		if (this.cookieService.get(currentDomain[2] + "Client")) {
			this.entityInfo = JSON.parse(this.cookieService.get(currentDomain[2] + "Client"));
		}
		else {
			this.lazyLoad = true;
			let self = this;
			this.loginService.getDomain(currentDomain[2], response => {
				if (response.status == "OK") {
					this.entityInfo = response.data;
					this.cookies.setClient(response.data, currentDomain[2]);
				    self.lazyLoad = false;
				}
			})
		}

		if (href.length >= 3) {
			this.code = href[href.length - 1];
			this.showError = false;
			this.createFormControls();
			this.createForm();
		}
		else {
			this.code = "";
			this.showError = true;
			this.errorMessage = "Looks like it is an invalid verification code or something went wrong";
		}
	}

	/*
	* @dec     : Reset Password
	* @author  : dipin
	*/
	createFormControls(): void {
		this.newPassword = new FormControl('', [
			Validators.required, Validators.minLength(8),
			Validators.maxLength(50),
			Validators.pattern("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,54})")
		]);
		this.rePass = new FormControl('', [Validators.required]);
	}

	/*
	* @dec     : Reset Password
	* @author  : dipin
	*/
	createForm(): void {
		this.resetPassword = new FormGroup({
			newPassword: this.newPassword,
			rePass: this.rePass
		});
	}

	/*
	* @dec     : Reset Password
	* @author  : dipin
	*/
	checkMatchPassword() {
		if (this.newInputPass == this.reInputPass) {
			this.passwordMatchStatus = false;
		}
		else {
			this.passwordMatchStatus = true;
		}
	}

	/*
	* @dec     : Reset Password
	* @author  : dipin
	*/
	onFormSubmit() {
		if (this.newPassword.value==undefined||this.newPassword.value=='') {
			this.newpassStatus = true;
		}
		else {
			this.newpassStatus = false;
		}
		if (!this.rePass.valid) {
			this.confirmpassStatus = true;
		}
		else {
			this.confirmpassStatus = false;
		}

		if (this.validationError==false && this.newPassword.value && this.passwordMatchStatus == false && this.rePass.value) {
			if (this.newInputPass == this.reInputPass) {
				this.loginApiStatus = true;
				this.passwordMatchStatus = false;
				let temp = {
					"verification_code": decodeURIComponent(this.code),
					"password": this.newInputPass,
					"confirm_password": this.reInputPass
				}
				this.dataService.resetPassword(temp, res => {
					if (res.status == "OK") {
						this.errorMessage = undefined;
						this.successMessage = res.message;
						this.showError = true;
						this.loginService.constValue = true;
						this.router.navigate(['/login']);
					}
					else {
						this.loginApiStatus = false;
						this.showError = true;
						this.loginService.constValue = false;
						this.successMessage = undefined;
						this.errorMessage = res.message;
					}
				})
			}
		}
		else {
			this.passwordMatchStatus = true;
		}
	}

	/*
	* @dec     : validating passsword using error message
	* @author  : ashiq
	*/

	onSelection() {
		let checkval = this.newPassword.value ? (this.newPassword.value).toString() : '';
		var patt1 = /[a-z]/g;
		var patt2 = /[A-Z]/g;
		var patt3 = /[@!#$%^&*()<>?{}]/g;
		var patt4 = /[a-z][A-Z][@!#$%^&*()<>?{}]{8,54}/g;
		if (checkval.trim().length == 0) {
			this.noValue = true;
		} else {
			this.noValue = false;
		}
		if (checkval.trim().length > 1) {

			if (checkval.match(patt1) == null) {
				this.validationError = true;
				this.errorMsg = "must have one lower case letter";
			} else if (checkval.match(patt2) == null) {
				this.validationError = true;
				this.errorMsg = "must have one upper case letter";
			} else if (checkval.match(patt3) == null) {
				this.errorMsg = "must have one special character";
				this.validationError = true;
			} else if (checkval.trim().length < 8) {
				this.errorMsg = "must have min length 8  ";
				this.validationError = true;
			} else if (checkval.trim().length > 54) {
				this.validationError = true;
				this.errorMsg = "must have max length of 54 ";
			} else {
				this.validationError = false;
			}

		} else {
			this.validationError = false;
		}
	}




}
