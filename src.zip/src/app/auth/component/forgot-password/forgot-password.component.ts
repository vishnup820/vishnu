import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { ForgotPasswordService } from '../../services/forgot-password/forgot-password.service';
import { CookieService } from 'ngx-cookie-service';
import { LoginService } from '../../services/login/login.service';
import { CookieDataService } from '../../../shared/services/cookie-data/cookie-data.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['../../../../assets/content/css/login.css']
})
export class ForgotPasswordComponent implements OnInit {

  emailId    : FormControl;
  forgotForm : FormGroup;
  message    : any;
  successMessage : any;
  errorMessage   : any;
  successMsg : boolean = false;
  errorMsg   : boolean = false;
  lazyLoad   : boolean = false;
  loginApiStatus : boolean = false;
  entityInfo : any;
  formError  : boolean;
  constructor(
    private router                 : Router,
    private loaderService          : LoaderActionsService,
    private forgotPasswordService  : ForgotPasswordService,
    private cookieService          : CookieService,
    private loginService           : LoginService,
    private cookies                : CookieDataService
    ) { }

  ngOnInit() {
    let currentDomain = window.location.origin.split('/');
    if (this.cookieService.get(currentDomain[2] + "Client")) {
      this.entityInfo = JSON.parse(this.cookieService.get(currentDomain[2] + "Client"));
    }
    else {
      this.lazyLoad = true;
      let self = this;
      currentDomain[2] = currentDomain[2].replace(':4200','');//for local only
      this.loginService.getDomain(currentDomain[2], response => {
        if (response.status == "OK") {
          this.entityInfo = response.data;
          this.cookies.setClient(response.data, currentDomain[2]);
          self.lazyLoad = false;
        }
      })
    }
  	this.createFormControls();
    this.createForm();
    this.formError =  false;
  }

    /*
    *  @desc   : method to create form controls
    *  @author : dipin
    */
    createFormControls () : void {
  	    // let email = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$";
  	    this.emailId     =   new FormControl('', [Validators.required]);
    }

    /*
    *  @desc   : method to create form using specified form controls
    *  @author : dipin
    */
    createForm() : void {
  	    this.forgotForm = new FormGroup({
  		    emailId : this.emailId
  	    })
    }

    /*
    *  @desc   : method to pass formdata to server through api call
    *  @author : dipin
    */
    onSubmit() {
  	    if(!this.emailId.valid){
            this.formError = true;
        }
        else {
            this.loginApiStatus = true;
    	      this.forgotPasswordService.forgotPassword(this.emailId.value,response => {
                if(response.status != "FAIL"){
                    this.successMessage = response.message;
                    this.errorMessage   = undefined;
                    this.loginApiStatus = false;
                }
                else{
                    this.successMessage = undefined;
                    this.errorMessage   = response.message;
                    this.loginApiStatus = false;
                }
    	    })
        }
    }

    back(){
      window.history.back();
      let currentDomain = window.location.origin.split('/');
      this.cookieService.delete(currentDomain[2] + "Client");
    }

}
