import { Component, OnInit , ViewChild,ElementRef  } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

import { CookieDataService } from '../../../shared/services/cookie-data/cookie-data.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { LoginService } from '../../services/login/login.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['../../../../assets/content/css/login.css']
})
export class LoginComponent implements OnInit {


    loginForm      :  FormGroup;
    userName       :  FormControl;
    password       :  FormControl;

    errorMessage   : any;

    loginApiStatus   : boolean = false;
 	formError        : boolean = false;
    errorMessageStat : boolean = false;
    showLogin        : boolean = false;
    displayReset     : boolean = false;
    lazyLoader       : boolean = false;
    showpassword      : boolean = false;
    mailroute        : any;
    detailData       : any;
    newpath          : any;
    @ViewChild('foc') inputEl:ElementRef;

  	constructor(
        private loginService        : LoginService,
        private router              : Router,
        private loaderService       : LoaderActionsService,
        private cookieDataService   : CookieDataService,
        private notificationService : NotificationService,
        private cookieService       : CookieService
    ){ }

    ngOnInit() {
        this.createFormControls();
        this.createForm();
        this.lazyLoader = true;
        let currentUrl = window.location.origin.split('/');

        if(this.loginService.constValue == true){
          this.displayReset = true;
          this.loginService.constValue = false;
        }
        else{
          this.displayReset = false;
          this.loginService.constValue = false;
        }
        currentUrl[2] = currentUrl[2].replace(':4201','');//for local only
        this.loginService.getDomain(currentUrl[2], response => {
            if (response.status == "OK") {
                let self = this;
                this.detailData = response.data;
                if (this.detailData.auth_type == "internal") {
                    this.showLogin = true;
                    this.lazyLoader = false;
                }
                else {
                    this.showLogin = false;
                    this.lazyLoader = false;
                }
                this.cookieDataService.setClient(response.data, currentUrl[2]);
            }
            if (this.cookieService.get('session')) {
                let url: string = JSON.parse(this.cookieService.get('user-data')).landing_url;
                this.router.navigateByUrl("/" + url);
            }
        })
    }

  	createFormControls() : void{
  		let useName       =   "^[a-zA-Z0-9._@]+$";
  		this.userName     =   new FormControl('', [Validators.required,this.noWhitespaceValidator,Validators.pattern(useName)]);
		this.password     =   new FormControl('', [Validators.required,this.noWhitespaceValidator]);
    }

    createForm() : void{
    	this.loginForm = new FormGroup({
    		userName : this.userName,
    		password : this.password
    	})
    }

    /*
    *  @desc   : White space Validator
    *  @author : Arun Johnson
    */
    noWhitespaceValidator(control: FormControl) {
        let isWhitespace = (control.value || '').trim().length === 0;
           let isValid = !isWhitespace;
        return isValid ? null : { 'whitespace': true }
    }

    /*
    *  @desc   : login form submission
    *  @author : Arun Johnson
    */
    onSubmit() {
        if(!this.loginForm.valid){
            this.formError=true;
        }
        else{
            let currentUrl = window.location.origin.split('/');
            currentUrl[2]  = currentUrl[2].replace(':4201','');//for local only
            this.loginApiStatus = true;
            this.loaderService.display(true);
            this.formError = false;
            let loginParams = {
                "username"    : this.loginForm.value.userName,
                "client"      : "HRISWEB",
                "domain"      :  currentUrl[2],
                "password"    : this.loginForm.value.password
            };
            this.loginService.login(loginParams,response =>{
                if(response.status== "OK"){
                    this.cookieDataService.saveCookieOnLogin(response);
                    if(response.data.landing_url) {
                        if(this.cookieService.get('mailrouter')) {
                            let routestatus = false;
                            this.newpath =  JSON.parse(this.cookieService.get('mailrouter')).mailroute;
                            for(var i=0;i<response.data.acl.length;i++){
                                for(var j=0;j<response.data.acl[i].child.length;j++){
                                    if(response.data.acl[i].child[j].route == this.newpath){
                                        routestatus = true;
                                        this.cookieService.delete("mailrouter");
                                    }
                                }
                            }
                            if(routestatus){
                                this.router.navigate([this.newpath]);
                            } else {
                                this.cookieService.delete("mailrouter");
                                this.router.navigate([response.data.landing_url]);
                            }
                        }
                        else{
                            this.router.navigate([response.data.landing_url]);
                        }
                    }else {
                        this.router.navigate(['/modules/organization/department']);
                        this.loginApiStatus = false;
                    }
                }
                else{
                    this.loginApiStatus = false;
                    this.errorMessage   = response.message;
                    this.errorMessageStat      = true;
                    let self = this;
                    setTimeout(()=>{
                        // self.errorMessage = null;
                        self.errorMessageStat    = false;
                    },3000)

                	// this.notificationService.alertBoxValue("error",response.message);
                    this.loaderService.display(false);
                }

            })
        }
    }

    showHidePassword(){
        this.showpassword=!this.showpassword;
        if(this.inputEl.nativeElement.type === 'password'){
            this.inputEl.nativeElement.type = 'text';
        }
        else
        {
            this.inputEl.nativeElement.type = 'password';
        }
    
    }
}
