import { BrowserModule, } from '@angular/platform-browser';
import { NgModule,ErrorHandler } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CookieService } from 'ngx-cookie-service';
import { AuthModule } from './auth/auth.module';
import { SharedModule } from './shared/shared.module'
import { AppRoutingModule } from './app-routing.module';
import { LoaderComponent } from './shared/component/loader/loader.component';
import { LoaderActionsService } from './shared/services/loader/loader-actions.service';
import { AppComponent } from './app.component';
import { GlobalErrorHandlerService } from './global-error-handler.service';
import { MainInterceptorService } from './main-interceptor.service';
import { ModulesComponent } from './modules/modules.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Firebaseconfig } from '../firebaseconfig';
import { AngularFireMessagingModule } from '@angular/fire/messaging';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFireModule } from '@angular/fire';
// import { MentionModule } from 'angular-mentions';

@NgModule({
  declarations: [
    AppComponent,
    LoaderComponent,
    ModulesComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AuthModule,
    SharedModule,
    AppRoutingModule,
    // MentionModule,
    BrowserAnimationsModule,
    AngularFireDatabaseModule,
    AngularFireAuthModule,
    AngularFireMessagingModule,
    AngularFireModule.initializeApp(Firebaseconfig.config),

  ],
  providers: [
  CookieService,
  LoaderActionsService,
    {
      provide  : HTTP_INTERCEPTORS,
      useClass : MainInterceptorService,
      multi    : true,
    },
    {
      provide  : ErrorHandler,
      useClass : GlobalErrorHandlerService,
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
