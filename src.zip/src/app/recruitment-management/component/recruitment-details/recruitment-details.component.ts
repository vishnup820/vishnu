/*
*  @desc   :component for display manager leave and approve
*  @author :dipin
*/
import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { Router,NavigationEnd,ActivatedRoute} from '@angular/router';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';

import { RecruitmentDetailsService } from '../../services/recruitment-details/recruitment-api/recruitment-details.service';
declare var require: any;
var moment = require('moment');

@Component({
  selector: 'app-recruitment-details',
  templateUrl: './recruitment-details.component.html',
  styleUrls: ['../../../../assets/content/css/recruitment.css']
})
export class RecruitmentDetailsComponent implements OnInit {
  
  tableData         : any;
  htmlContent       : any;
  emailData         : any;
  startDate         : any;
  endDate           : any;
  selectedDate      : any;
  idValue           : any;
  config            : any;
  selectedEmailData : any;
  assignNote        : any;
  previousUrl       : any;
  titleInput        : any = '';
  selectedEmail     : any = [];
  filterValue       : any = [];
  id                : any;
  userData          : any;
  subValue          : any;
  formerror         : boolean;
  showStatus        : boolean;
  confirmBox        : boolean;
  showApproval      : boolean = false;
  showOpen          : boolean = false;
  showList          : boolean = false;
  reqAssign         : boolean = false;
  showDiv           : boolean = false;
  toolTip           : boolean = false;
  setTrigger        : boolean = true;
  constructor(private apiService: RecruitmentDetailsService,
    private notifications: NotificationService,
    private loaderService: LoaderActionsService,
    private cookieService: CookieService,
    private router : Router,
    private activeRoute : ActivatedRoute,
    private timeZone: TimezoneDetailsService,
    private cd: ChangeDetectorRef,
    public aclVerif : AclVerificationService) {
    router.events
      .filter(event => event instanceof NavigationEnd)
      .subscribe(e => {
        // if(e.url){
        //  this.previousUrl = e.url;
        // }
      });
  }

  ngOnInit() {
    this.loaderService.display(true);
    if(this.cookieService.get("user-data")){
      this.userData = JSON.parse(this.cookieService.get("user-data"));
      this.id = this.activeRoute.snapshot.params['id'];
      this.checkUrl();
      this.startDate = this.timeZone.getCurrentDate();
      this.confirmBox = false;
      this.config = "Are You Sure You Want To Cancel?";
      this.apiService.getList(this.id,this.showApproval,this.showList,this.showOpen, response => {
        this.loaderService.display(true);
        if (response.status == "OK") {
            this.tableData  = response.data;
            this.idValue    = this.tableData.details.status_slug;
            this.getPeopleData();
        }
        else {
          this.tableData = [];
          this.loaderService.display(false);
        }
      });
    }
  }

  openWindow(){
    window.open(this.tableData.details.file_data);
  }

  /*
   *  @desc   :method to update list by api call
   *  @author :dipin
   */
  getData(id) {
    this.loaderService.display(true);
    this.apiService.getList(id,this.showApproval,this.showList,this.showOpen, response => {
      if (response.status == "OK") {
          this.tableData  = response.data;
          this.idValue    = this.tableData.details.status_slug;
          if (this.showList) {
              if (this.tableData.details.requested_by == this.userData.user_id) {
                if (this.tableData.details.status_slug == "Cancelled" || this.tableData.details.status_slug == 'Rejected' || this.tableData.details.status_slug == "Approved") {
                  this.tableData.details.showEdit   = false;
                }
                else if (this.tableData.details.status_slug == 'Created' || this.tableData.details.status_slug == 'Pending' || this.tableData.details.status_slug == 'Overdue') {
                  this.tableData.details.showEdit = true;
                }
              }
              else if(       
                this.aclVerif.checkAclDummy('recruitment-post') &&
                this.aclVerif.checkAclDummy('recruitment-assign') &&
                this.aclVerif.checkAclDummy('schedule-interview') &&
                this.aclVerif.checkAclDummy('candidate-register') && 
                this.aclVerif.checkAclDummy('interviewer') &&
                !this.aclVerif.checkAclDummy('master-management') &&
                !this.aclVerif.checkAclDummy('recuirment-approval')){
                if (this.tableData.details.status_slug == "Processing" || this.tableData.details.status_slug == 'In Progress') {
                  this.tableData.details.showEdit   = false;
                }
                else if (this.tableData.details.status_slug == 'On Hold' || this.tableData.details.status_slug == 'Created' || this.tableData.details.status_slug == 'Approved' || this.tableData.details.status_slug == 'Overdue') {
                  this.tableData.details.showEdit = true;
                }
              }
          }
          else if (this.showApproval) {
              if (this.tableData.details.status_slug == "Processing" || this.tableData.details.status_slug == 'In Progress') {
                this.tableData.details.showEdit = false;
              }
              else if (this.tableData.details.status_slug == 'Pending' || this.tableData.details.status_slug == 'Overdue'
                || this.tableData.details.status_slug == 'On Hold') {
                this.tableData.details.showEdit = true;
              }
          }
          else{
              if (this.tableData.details.status_slug == "Posted") {
                this.tableData.details.showEdit   = false;
              }
              else if (this.tableData.details.status_slug == 'New' || this.tableData.details.status_slug == 'Overdue') {
                this.tableData.details.showEdit   = true;
              }
              else if (this.tableData.details.status_slug == 'On Hold') {
                this.tableData.details.showEdit   = true;
              }
              else if (this.tableData.details.status_slug == 'In Progress') {
                this.tableData.details.showEdit   = false;
              }
          }
        this.loaderService.display(false);
      }
      else {
        this.tableData = [];
        this.loaderService.display(false);
      }
    })
  }
  
  	/*
   *  @desc   :method to handle popup confirmation
	   *  @author :dipin
   */
	getPopupConfirm(event) {
    let status;
    this.confirmBox = false;
		if (event == true) {
      status = this.apiService.checkStatus(this.config,this.subValue);
      this.loaderService.display(true);
      this.apiService.changeStatus(this.id,status,this.showApproval,this.showList,this.showOpen,response => {
        if (response.status == "OK") {
          this.notifications.alertBoxValue("success", response.message);
          this.getData(this.id);
        }
        else {
          this.notifications.alertBoxValue("error", response.message);
          this.getData(this.id);
        }
      })
		}
  }
  
  getPeopleData() {
    this.getMasterListPeople();
  }

  assignList(){
    this.formerror=false;
    this.reqAssign = !this.reqAssign;
    this.titleInput = '';
    this.getMasterListPeople();
  }

  getMasterListPeople(){
    this.apiService.assignList(this.id,response => {
      if (response.status == "OK") {
        this.loaderService.display(false);
        if (response.selected_recruitment_team) {
         if(response.selected_recruitment_team && response.selected_recruitment_team.length){
            for(let i = 0;i < response.selected_recruitment_team.length;i++){
               this.selectedEmail.push(response.selected_recruitment_team[i].user_name);
            }
         }
        }
        if(response.full_recruitment_team){
          this.emailData = response.full_recruitment_team;
        }
        this.selectedDate = response.target_date;
        this.titleInput   = response.notes; 
      }
    })
  }

  back(){
    window.history.back();
  }

  checkUrl(){
    let url;
    (localStorage.getItem("recruitUrl"))?url= localStorage.getItem("recruitUrl"):'';
    if(url.match('/modules/recruitment/requirement-approval')){
      this.showApproval = true;
      this.showList     = false;
      this.showOpen     = false;
      this.filterValue  = [];
    }
    else if(url.match('/modules/recruitment/requirement-list')){
      this.showApproval = false;
      this.showList     = true;
      this.showOpen     = false;
      this.filterValue  = [];
    }
    else{
      this.showApproval = false;
      this.showList     = false;
      this.showOpen     = true;
      this.filterValue  = [{id:11,name:'Closed'},{id:9,name:'On Hold'},{id:8,name:"Posted"},
      {id:6,name:"In Progress"},{id:10,name:"Overdue"},{id:4,name:"Cancelled"}];
    }
  }

  toFrom() {

  }

  /*
*  @desc   :method to add random classes bsed on index
*  @author :dipin
*/
  getClassByValue(index) {
    switch (index % 10) {
      case 0: return "default-avatar islamic-green";
      case 1: return "default-avatar limerick";
      case 2: return "default-avatar chilean-fire";
      case 3: return "default-avatar persian-pink";
      case 4: return "default-avatar deep-magenta";
      case 5: return "default-avatar gigas";
      case 6: return "default-avatar endeavour";
      case 7: return "default-avatar dodger-blue";
      case 8: return "default-avatar jordy-blue";
      case 9: return "default-avatar Light-sea-green";
      case 10: return "emp-profileimage";
    }
  }

  submitAssign() {
    this.formerror = true;
    if ((!this.titleInput || this.titleInput.trim() == '') || (!this.selectedEmailData || this.selectedEmailData.length == 0) || (!this.selectedEmailData || this.selectedEmailData.length == 0) || !this.selectedDate) {
      return;
    }
    else {
      this.formerror = false;
      this.loaderService.display(true);
      let temp = [];
      for(let i = 0 ; i < this.selectedEmailData.length;i++){
        temp.push({"user_id":this.selectedEmailData[i].originalData.people_id});
      }
      let obj = {
        "users"          : temp,
        "requirement_id" : this.id,
        "target_date"    : this.apiService.formatForApi(this.selectedDate),
        "notes"          : this.assignNote
      }
      this.apiService.assign(obj, response => {
        if (response.status == "OK") {
          this.notifications.alertBoxValue("success", response.message);
          this.apiService.assignList(this.id,response => {
            if (response.status == "OK") {
              this.reqAssign = false;
              this.titleInput = '';
              this.selectedEmail = [];
              if (response.selected_recruitment_team) {
               if(response.selected_recruitment_team && response.selected_recruitment_team.length){
                  for(let i = 0;i < response.selected_recruitment_team.length;i++){
                     this.selectedEmail.push(response.selected_recruitment_team[i].user_name);
                  }
               }
              }
              if(response.full_recruitment_team){
                this.emailData = response.full_recruitment_team;
              }
              this.selectedDate = response.target_date;
              this.titleInput   = response.notes; 
              this.getData(this.id);
              this.setTrigger = false;
              this.cd.detectChanges();
              this.setTrigger = true;
            }
          })
        }
        else {
          this.loaderService.display(false);
          this.reqAssign = false;
          this.titleInput = '';
          this.notifications.alertBoxValue("error", response.message);
        }
      })
    }
  }

  edit(id){
    if( this.tableData.details.status_slug != 'Cancelled' && 
        this.tableData.details.status_slug != 'Rejected'  && 
        this.tableData.details.status_slug != 'Approved')
      this.router.navigate(['/modules/recruitment/requirement-edit/'+id]);
  }
}
