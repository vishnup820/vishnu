import { Component, OnInit, OnDestroy} from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';

import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { ChangeEvent } from '@ckeditor/ckeditor5-angular/ckeditor.component';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonFilesService } from '../../services/common/common-files.service';
import { AddRequirementService } from '../../services/add-requirement/add-requirement.service';


@Component({
  selector: 'app-requirement-add',
  templateUrl: './requirement-add.component.html',
  styleUrls: ['../../../../assets/content/css/recruitment.css','../../../../assets/content/css/recruitmentChat.css']
})
export class RequirementAddComponent implements OnInit ,OnDestroy{

  public Editor          = ClassicEditor;
  public Editor1         = ClassicEditor;
  public Editor2         = ClassicEditor;
  public selectedJobDesc    = ''  
  public selectedGoodtoHave = ''  
  public selectedMustHave   = ''   
  newRequirement         : number;
  totalPosition          : number;
  replacement            : number;
  selectedJobType        : any = [];
  jobTypeItem            : any = [];
  jobType                : any;

  workExpItem            : any = [];
  selectedWorkExp        : any = [];
  workExp                : any;

  selectedJobTitle       : any = [];
  JobTitleItem           : any = [];
  jobTitle               : any;

  selectedEmploymentType : any = [];
  employmentTypeItem     : any = [];
  employmentType         : any; 

  industryItem           : any = [];
  selectedIndustry       : any = [];
  industry               : any;

  selectedLocation       : any = [];
  locationItem           : any = [];
  location               : any;
  newLocation            : any;
  minDate                : any; 
  maxdate                : any;
  targetDate             : any;
  userData               : any;
  requestedOn            : any;
  selectedAddress        : any;
 
  requestedBy            : any;
  comments               : any;
  managerRole            : any;
  adminRole              : any;
  type        		       : any;
  fileName            	 : any;
  fileData    	         : any;
  budget                 : any;
  editDetail             : any;
  config                 : any;
  selectedQual           : any;
  skillSelected          : any;
  selectedSkill          : any;
  qualificationData      : any;
  qualificationItem      : any = [];
  skillsetItem           : any = [];
  editId                 : number;
  requestedById          : number
  editStatus             : boolean = false;
  enableAddress          : boolean = false;
  expandDiv              : boolean = false;
  submitted              : boolean = false;
  jobTitleErr            : boolean = false;
  positionsErr           : boolean = false;
  workExpErr             : boolean = false;
  locationErr            : boolean = false;
  addressErr             : boolean = false;
  skilledErr             : boolean = false;
  confirmBox             : boolean = false;
  constructor(   
    private cookieService              : CookieService,
    private timezoneDetailsService     : TimezoneDetailsService,
    private NotificationService        : NotificationService,
    private loader                     : LoaderActionsService,
    private router                     : Router,
    private activatedRoute             : ActivatedRoute,
    private AclVerificationService     : AclVerificationService,
    private CommonFilesService         : CommonFilesService,
    private AddRequirementService      : AddRequirementService) { }

  ngOnInit() {
    this.loader.display(true)
    if (this.cookieService.get("user-data")) {
      this.userData      = JSON.parse(this.cookieService.get("user-data"));

      this.minDate       = this.timezoneDetailsService.toLocal(this.userData.start_date);
      this.maxdate       = this.timezoneDetailsService.toLocal(this.userData.end_date);
     
      this.adminRole     = this.AclVerificationService.checkAclDummy('allemployee-list');
      this.managerRole   = this.AclVerificationService.checkAclDummy('team-list');
    }
    this.activatedRoute.params.subscribe(params => this.editId = params.id);
    if(this.editId !=undefined) {
      this.loader.display(true)
      this.editStatus = true;
      this.editDetails();
     } else{
      this.loader.display(true)
      this.editStatus = false
      this.editId     = null
      this.addView();
     }

     this.jobTypeItem = [{ "id": 1, "name": "Full-time" },{ "id": 2, "name": "Part-time" }];
     this.selectedJobType = [0];
  }
  /**
   * @Author : Nilena Alexander  
   * @Desc   : To get masterdata
   */
  getMasterDetails(){
    this.loader.display(true)
    this.AddRequirementService.getMasterDetails(response=>{
      if(response.status=="OK"){
        this.loader.display(false)
        this.workExpItem            = response.data.work_experience;
        this.employmentTypeItem     = response.data.employement_type;
        this.locationItem           =  response.data.location;
        this.JobTitleItem           =  response.data.job_title;
        this.industryItem           =  response.data.industry;
        this.qualificationItem      = response.data.qualification
        this.skillsetItem           = response.data.skill_set
        this.selectedEmploymentType = [this.CommonFilesService.matchingIndex(this.employmentTypeItem,"Permanent","name")]
        this.selectedIndustry = [this.CommonFilesService.matchingIndex(this.industryItem,"IT","name")]
      }
    })
  }
  /**
   * @Author : Nilena Alexander  
   * @Desc   : To manage addform
   */

  addView(){
    this.loader.display(true)
    this.getMasterDetails();
    this.requestedOn   = this.timezoneDetailsService.getCurrentDate();
    this.targetDate    = this.timezoneDetailsService.getCurrentDate();
    this.requestedBy   = this.userData.first_name + " " + this.userData.last_name + "(" + this.userData.employee_id + ")";
    this.requestedById = this.userData.user_id
    this.loader.display(false)
  }
  /**
   * @Author : Nilena Alexander  
   * @Desc   : To manage ck text editor
   */


  public onChange( { editor }: ChangeEvent ) {
    this.selectedJobDesc = editor.getData();
   }
   public Change( { editor }: ChangeEvent ) {
    this.selectedMustHave = editor.getData();
   }
   public OnChanges( { editor }: ChangeEvent ) {
    this.selectedGoodtoHave = editor.getData();
   }

   /**
   * @Author : Nilena Alexander  
   * @Desc   : To add new jobtitle from dropdown
   */

  getJobTitle(event){
  
    if (event.selected.length> 0) {
      this.jobTitle = event.selected[0].id;
    }
    else 
      this.jobTitle = null;  
      if(this.jobTitleErr==true && this.submitted == true)
      this.jobTitleErr = false
  }

  /* 
   * @Author : Nilena Alexander  
   * @Desc   : To find total No of positions
   */
  getTotalPosition(req?:number,rep?:number){
    if(req == null || req ==undefined)
     req = null;
     if(rep == null || rep ==undefined)
     rep = null;
    this.totalPosition = +req + +rep;
    if(this.totalPosition == 0){
      this.totalPosition=null;
    }
    if(this.positionsErr==true && this.submitted == true)
    this.positionsErr=false;
  }

  /**
   * @Author : Nilena Alexander  
   * @Desc   : To getSelected workexp from dropdown
   */
   getWorkExperience(event){
      if (event.selected.length >0) {
        this.workExp = event.selected[0].id;
      }
      else
      this.workExp= null;
      if(this.workExpErr==true && this.submitted == true)
      this.workExpErr=false;  
    }
   
  /**
   * @Author : Nilena Alexander  
   * @Desc   : To getSelected jobType from dropdown
   */

  getJobType(event){
    if (event.selected.length> 0) 
      this.jobType = event.selected[0].id;
    else 
      this.jobType = null;
   }

   /**
   * @Author : Nilena Alexander  
   * @Desc   : To getSelected employmentType from dropdown
   */
  getEmploymentType(event){
    
    if (event.selected.length> 0) 
     this.employmentType = event.selected[0].id; 
    else 
      this.employmentType = null;
   }
   /**
   * @Author : Nilena Alexander  
   * @Desc   : To getSelected Industry from dropdown
   */
   getIndustry(event){
    if (event.selected.length> 0) 
      this.industry = event.selected[0].id;
    else 
      this.industry = null;
   }

  /**
   * @Author : Nilena Alexander  
   * @Desc   : To getSelected location from dropdown
   */
   getLocation(event){  
    if (event.selected.length> 0 && event.selected[0].id) {
      this.location          = event.selected[0].id;
      this.newLocation       = null;
      this.enableAddress     = false;
      this.selectedAddress   = event.selected[0].address;
    }else if (event.selected.length> 0 && event.selected[0].name) {
      this.newLocation       = event.selected[0].name;
      this.location          = null;
      this.enableAddress     = true;
    }else{
      this.location         = null;
      this.enableAddress    = false;
    }
    if(this.locationErr == true && this.submitted == true && event.selected[0].id){
      this.locationErr = false;
      this.addressErr  = false;
    }else  if(this.locationErr == true && this.submitted == true && event.selected[0].name){
      this.locationErr = false;
      this.addressErr  = true;
    }
    
   }

  /**
   * @Author : Nilena Alexander  
   * @Desc   : To add new location from dropdown
   */
   showAddNew(event) {
    if (event.status) {
      this.enableAddress    = true;
      this.selectedAddress  = null;
      this.locationItem.push({ name: event.value });
      this.selectedLocation = [this.locationItem.length - 1];
    } else 
      this.enableAddress    = false;
  }
 /**
   * @Author : Nilena Alexander  
   * @Desc   : To check whether some address is entered in address field
   */
  addressChceck(){
    if(this.addressErr == true && this.submitted == true && this.selectedAddress)
      this.addressErr = false;
  }
   /**
   * @Author : Nilena Alexander  
   * @Desc   : To trim space in a text area
   */
  commonTrim(value){
    if(value && value.trim()!= ''){
      return value;
    }
  }
    /*
 * @desc : component for validate space
 * @auth : nilena
   */
  changeListener($event): void {
    this.readThis($event.target)
  //  let  cb =  this.CommonFilesService.readThis(event.target )
  //  this.fileData = cb.fileData;
  //  this.fileName = cb.filename;
  //  this.type     = cb.type;
  }
   
  /*
	* @desc : component for validate space
	* @auth : dipin
  */
	readThis(inputValue: any): void {
    
		var file: File = inputValue.files[0];
		if (file != undefined) {
			this.type = inputValue.files[0].name.split('.').pop();
			var myReader: FileReader = new FileReader();
            this.fileName = file.name;
			myReader.onloadend = (e) => {
				this.fileData = myReader.result;
			}
			myReader.readAsDataURL(file);
		}
		else {
			this.fileData = undefined;
			this.fileName = "";
		}
  }
  /*
  * @desc :  method to submitForm
  * @auth : nilena
  */
  submitForm(){
    this.submitted         = true;
   if(this.jobTitle)
     this.jobTitleErr      = false;
    else{
      this.jobTitleErr     = true;
      let appNameScrollPos = document.getElementById("jobtitle");
      appNameScrollPos.scrollIntoView({ behavior: 'smooth', block: 'start' });
      document.getElementById("jobtitle").focus();
    }
    if(this.totalPosition  == null ||this.totalPosition ==undefined ||this.totalPosition ==0 ){
      this.positionsErr    = true;
      let appNameScrollPos = document.getElementById("totalposition");
      appNameScrollPos.scrollIntoView({ behavior: 'smooth', block: 'start' });
      document.getElementById("totalposition").focus();
    }
    else
      this.positionsErr    = false;
    
    if(this.workExp)
    this.workExpErr        = false;
    else {
      this.workExpErr      = true;
      let appNameScrollPos = document.getElementById("workExp");
      appNameScrollPos.scrollIntoView({ behavior: 'smooth', block: 'start' });
      document.getElementById("workExp").focus();
    }
    if(this.location || this.newLocation)
    this.locationErr     = false;
    else{
      this.locationErr     = true;
      let appNameScrollPos = document.getElementById("location");
      appNameScrollPos.scrollIntoView({ behavior: 'smooth', block: 'start' });
      document.getElementById("location").focus();
    }
     if(this.selectedAddress)
     this.addressErr     = false;
     else{
      this.addressErr     = true;
      let appNameScrollPos = document.getElementById("add_ress");
      appNameScrollPos.scrollIntoView({ behavior: 'smooth', block: 'start' });
      document.getElementById("add_ress").focus();
     }

     let tempEmail = [];
     let tempSkill = [];

     if (this.selectedQual) {
      for (let i = 0; i < this.selectedQual.length; i++) {
        tempEmail.push(this.selectedQual[i].label);
      }
    }
    if (this.skillSelected) {
      for (let i = 0; i < this.skillSelected.length; i++) {
        tempSkill.push(this.skillSelected[i].label);
      }
    }
     if(tempSkill.length)
     this.skilledErr       = false;
    else{
      this.skilledErr      = true;
      let appNameScrollPos = document.getElementById("skill");
      appNameScrollPos.scrollIntoView({ behavior: 'smooth', block: 'start' });
      document.getElementById("skill").focus();
    }

     if( !this.jobTitleErr && !this.positionsErr  && !this.workExpErr && !this.locationErr &&  !this.addressErr  && !this.skilledErr){
     this.loader.display(true)

      let arrObj={
      "job_title_id"        : this.jobTitle,
      "new_req_num"         : this.newRequirement,
      "replace_num"         : this.replacement,
      "total_position"      : this.totalPosition,
      "work_experience_id"  : this.workExp,
      "job_type"            : this.jobType,
      "employment_type_id"  : this.employmentType,
      "industry_id"         : this.industry,
      "budget"              : this.budget,
      "skill_set"           : tempSkill.toString(),
      "location_id"         : this.location,    
      "new_location"        : this.newLocation,
      "new_location_address": this.newLocation?this.selectedAddress:null,
      "job_description"     : this.selectedJobDesc,
      "must_have"           : this.selectedMustHave,
      "good_have"           : this.selectedGoodtoHave,
      "qualifications"      : tempEmail?(tempEmail.toString()):null,
      "requested_on"        : this.CommonFilesService.formatForApi(this.requestedOn),
      "target_date"         : this.CommonFilesService.formatForApi(this.targetDate),
      "requested_by"        : this.requestedById,
      "comments"            : this.comments,
      "file_data"           : this.fileData?this.fileData:null,
      "rc_requirement_file" : this.fileName?this.fileName:null
       }
       this.AddRequirementService.addRequest(arrObj, this.editId,response=>{
        if(response.status =="OK"){
          setTimeout(() => {
            this.NotificationService.alertBoxValue("success", response.message);
          },500)
          this.cancelForm();
        
        }else {
          this.NotificationService.alertBoxValue("error", response.message);
          this.loader.display(false)
        }

       })
     } 
  }
  /*
  * @desc :  to method to cancelform
  * @auth : nilena alexander
  */
 cancel(){
    this.confirmBox          = true;
    this.config = "Changes made will not be saved.Do you want to proceed?"
 }
  cancelForm(){
  
    this.selectedAddress     = null;
    this.selectedMustHave    = null;
    this.selectedGoodtoHave  = null;
    this.selectedJobDesc     = null;
    this.industry            = null;
    this.jobType             = null;
    this.jobTitle            = null;
    this.location            = null;
    this.newLocation         = null;
    this.workExp             = null;
    this.replacement         = null;
    this.newRequirement      = null;
    this.totalPosition       = null;
    this.employmentType      = null;  
    window.history.back();
  }
   /*
  * @desc :  to method to editForm
  * @auth : nilena alexander
  */
  editDetails(){
    this.loader.display(true)
    this.AddRequirementService.getEditDetails(this.editId,response=>{
      if(response.status =="OK"){
        this.loader.display(false)
        this.editDetail = response.data.details
        this.budget             = this.editDetail.budget
        this.comments           = this.editDetail.comments
        this.totalPosition      = this.editDetail.total_position
        this.newRequirement     = this.editDetail.new_req_num
        if( this.editDetail.replace_num==="0")
          this.replacement        = null
        else
        this.replacement        = this.editDetail.replace_num
        this.requestedBy        = this.editDetail.requested_by_name +"(" + this.editDetail.requested_by_code+ ")"
        this.requestedById      = this.editDetail.requested_by;
        this.requestedOn        = this.timezoneDetailsService.toLocal(this.editDetail.requested_on)
        this.targetDate         = this.timezoneDetailsService.toLocal(this.editDetail.target_date)
        this.JobTitleItem       = response.masters.job_title
        this.workExpItem        = response.masters.work_experience
        this.employmentTypeItem = response.masters.employement_type
        this.industryItem       = response.masters.industry
        this.locationItem       = response.masters.location
        this.skillsetItem       = response.masters.skill_set
        this.qualificationItem  = response.masters.qualification

      setTimeout(()=>{
      this.selectedWorkExp    = [this.CommonFilesService.matchingIndex(this.workExpItem,this.editDetail.work_experience_id,"id")]
      this.selectedJobTitle   = [this.CommonFilesService.matchingIndex(this.JobTitleItem,this.editDetail.job_title_id,"id")]
      this.selectedJobType    = [this.CommonFilesService.matchingIndex(this.jobTypeItem,this.editDetail.job_type,"id")]
      this.selectedIndustry   = [this.CommonFilesService.matchingIndex(this.industryItem,this.editDetail.industry_id,"id")]
      this.selectedEmploymentType = [this.CommonFilesService.matchingIndex(this.employmentTypeItem, this.editDetail.employment_type_id, "id")]
      },500)
        this.selectedGoodtoHave = this.editDetail.good_have
        this.selectedMustHave   = this.editDetail.must_have   
        this.selectedJobDesc    = this.editDetail.job_description
        this.fileName           = this.editDetail.rc_requirement_file ? this.editDetail.rc_requirement_file : '';
        // this.fileData           = this.editDetail.rc_requirement_file ? this.editDetail.rc_requirement_file : ''
        this.type               = this.editDetail.rc_requirement_file ? "pdf" : '';


        if (this.editDetail.skill_set)
         this.selectedSkill = this.editDetail.skill_set.split(',')
         if (this.editDetail.qualifications)
          this.qualificationData = this.editDetail.qualifications.split(',')

        let checkLoc : boolean = false;
       for (let i = 0; i < this.locationItem.length; i++) {
        if (this.locationItem[i].id ==this.editDetail.location_id ) {
          checkLoc = true;
          break;
        } else
        checkLoc = false;
      } 
       if(!checkLoc)
          this.locationItem.push({ "id": this.editDetail.location_id, "name": this.editDetail.location })      
         this.selectedLocation    = [this.CommonFilesService.matchingIndex(this.locationItem,this.editDetail.location_id,"id")]       
      }
      
    })
  }
  requrimentSkill(){
    if(this.skillSelected &&this.skillSelected.length && this.submitted)
    this.skilledErr= false;
  }
/**
 * @author:Nilena Alexander
 * @desc : to change date change
 */
  dateChange(requestedOn,targetDate){
    if (this.timezoneDetailsService.toLocal(requestedOn) >= this.timezoneDetailsService.toLocal(targetDate)) {
      this.targetDate    = this.requestedOn;
    }
  }

  ngOnDestroy(){

  }

  
}
