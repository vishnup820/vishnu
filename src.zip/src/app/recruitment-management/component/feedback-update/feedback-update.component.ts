import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { CommonFilesService } from '../../services/common/common-files.service';
import { globalVariables } from '../../constants/globals';
import { ManagerFeedbackService } from '../../services/manager-feedback/manager-feedback.service';
import { ActivatedRoute, Router } from '@angular/router';
// import { globalVariables } from '../../../shared/constants/globals';
import { MalihuScrollbarModule } from 'ngx-malihu-scrollbar'
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { Timestamp } from 'rxjs';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';



@Component({
  selector: 'app-feedback-update',
  templateUrl: './feedback-update.component.html',
  styleUrls: ['../../../../assets/content/css/recruitment.css', '../../../../assets/content/css/recruitmentChat.css']
})
export class FeedbackUpdateComponent implements OnInit {

  constants        : string
  detailId         : number
  newID            : any = []; //req_id
  StatItems        : any = [];
  selectedStat     : any = [];
  StatusId            : any;
  round               : any;
  updatedStatus       : any;
  updatedComment      : any;
  reasonForCancel     : any;
  candidateDetail     : any = [];
  interviewInfoDetail : any = []
  comment          : string;
  scheduleId       : number;
  commentErr       : boolean = false;
  statusErr        : boolean = false;
  roundErr         : boolean = false;
  submitted        : boolean = false;
  activeTab        : boolean = false;
  viewBtn          : boolean = false;
  scrollLeft       : boolean = true;
  scrollEnd        : boolean = false;
  lazyLoad         : boolean = false;
  hideArrow        : boolean = false;
  showFeedBack     : boolean ;
  
  public scrollbarOptions;

  constructor( private commonFiles   : CommonFilesService,
    private ManagerFeedbackService   : ManagerFeedbackService,
    private activatedRoute           : ActivatedRoute,
    private route                    : Router,
    private MalihuScrollbarModule    : MalihuScrollbarModule,
    private chRef                    : ChangeDetectorRef,
    private loader                   : LoaderActionsService,
    private notification             : NotificationService,
    private timeZone                 : TimezoneDetailsService ) {
    this.StatItems = globalVariables.feedBackStatus;
    
   }
  ngOnInit() {
    this.activatedRoute.params.subscribe(params => this.detailId = params.id);
    this.activatedRoute.queryParamMap.subscribe(params => {
      let req = params.get('req');
      this.newID = req
      this.feedbackDetail();
    })
    let self = this
    self.scrollbarOptions = {
      axis: 'x', scrollInertia: 0, theme: 'dark', autoHideScrollbar: false, scrollButtons: { enable: true },
      callbacks: {
        onTotalScroll: function () {
          self.scrollEnd = true;
          self.chRef.detectChanges();
        },
        whileScrolling: function (this) {
          self.scrollLeft = false;
          self.scrollEnd = false;
          self.chRef.detectChanges();
        },
        onTotalScrollBack: function () {
          self.scrollLeft = true;
          self.chRef.detectChanges();
        }
      }
    }

  }
  /*
 *@author: Nilena Alexander
 *@desc  : management of tab and corresponding api call
 */
  onChange(val) {
    for (let i = 0; i < this.interviewInfoDetail.length; i++) {
      if (val == this.interviewInfoDetail[i].id) {
        this.scheduleId = this.interviewInfoDetail[i].id;
        this.tabDetails(this.scheduleId)
        this.interviewInfoDetail[i].status = true
      } else {
        this.interviewInfoDetail[i].status = false
        // this.statusErr = false
        // this.commentErr = false
        // this.comment = null

      }
    }
  }

  openWindow(url) {
    window.open(url);
  }

  /*
  *@author: Nilena Alexander
  *@desc  : to  get details
  */

  feedbackDetail() {
    // this.newID = 5
    // this.detailId = 51
    this.loader.display(true)
    this.ManagerFeedbackService.getDetails(this.newID, this.detailId, response => {
      if (response.status == "OK") {
        if (response.data) {
          this.scheduleId = response.data.interview_info.data[0].id

          this.loader.display(false)
          this.candidateDetail = response.data.details
          if( this.candidateDetail.drop_down_name==="InterviewScheduled"){
            this.candidateDetail.new_status_name ="Interview Scheduled"
          }
          else if(this.candidateDetail.drop_down_name==="InterviewCancelled"){
            this.candidateDetail.new_status_name ="Interview Cancelled"
          }
          this.candidateDetail.candidate_name = this.candidateDetail.first_name + " " + this.candidateDetail.last_name
          this.interviewInfoDetail = response.data.interview_info.data;
          if( this.interviewInfoDetail){
            this.tabDetails(this.interviewInfoDetail[0].id);
          }
       

          this.utcConvert();
          this.dateConversion()
          if (this.interviewInfoDetail.length > 3) {
            this.hideArrow =true;
        
          }else           
           this.hideArrow =false;

          for (let i = 0; i < this.interviewInfoDetail.length; i++) {
            if (i != 0)
              this.interviewInfoDetail[i].status = false;
            else
              this.interviewInfoDetail[i].status = true;
          }
        }
        else {
          this.candidateDetail = []
          this.interviewInfoDetail = []
        }
      }
    })

  }

  /* @ desc    : date  conversionbasedon utcstarttime
   * @ author  : Nilena Alexander
   */
  dateConversion() {
    for (let i = 0; i < this.interviewInfoDetail.length; i++) {
      let tempFirst = this.timeZone.getLocalDate(this.interviewInfoDetail[i].interview_date + " " + this.interviewInfoDetail[i].start_time);
      this.interviewInfoDetail[i].interview_date = new Date(tempFirst).getFullYear() + "-" + (Number(new Date(tempFirst).getMonth()) + 1) + "-" + new Date(tempFirst).getDate();
    }
  }
  /**method forutc conversion
       * @ author  : Nilena Alexander
       */

  utcConvert() {
    for (let i = 0; i < this.interviewInfoDetail.length; i++) {
        let startTime = this.interviewInfoDetail[i].start_time;
        let endTime = this.interviewInfoDetail[i].end_time;
        let sStart = startTime.split(":");
        let eStart = endTime.split(":");
        let time1 = this.timeZone.getTimeNow(sStart[0] + ":" + sStart[1]);
        let time2 = this.timeZone.getTimeNow(eStart[0] + ":" + eStart[1]);
        let time3 = this.timeZone.timeTo12Convert(time1);
        let time4 = this.timeZone.timeTo12Convert(time2);
        this.interviewInfoDetail[i].interview_time = time3 + "-" + time4;      
    }
  }
  /*
  *@author: Nilena Alexander
  *@desc  :function to decide form hide or show
  */

  tabDetails(id) {
    this.lazyLoad = true;
          for(let i=0;i<this.interviewInfoDetail.length;i++){
            if(id == this.interviewInfoDetail[i].id){
              if(this.interviewInfoDetail[i].schedule_status==="0"){
                this.reasonForCancel = this.interviewInfoDetail[i].reason_cancel
                this.viewBtn =true;
                this.lazyLoad = false;
                this.showFeedBack = true
                this.comment = null
                this.StatusId = null
                this.selectedStat = []
           
              }else{
                this.viewBtn =false;
                if(this.interviewInfoDetail[i].interviewer_comment==null){
                  this.lazyLoad = false;
                  this.showFeedBack = true
                  this.comment = null
                  this.StatusId = null
                  this.selectedStat = []
             
                }else{
                  this.lazyLoad = false;
                  this.showFeedBack = false;
                  this.updatedComment =this.interviewInfoDetail[i].interviewer_comment
                  this.updatedStatus = this.interviewInfoDetail[i].schedule_status
                }
              }
            }
 
        }
    // this.ManagerFeedbackService.getTabDetails(this.scheduleId, response => {
    //   if (response.status == "OK") {
    //     if (response.data.length) {
      
    //     } else {
    //       this.lazyLoad = false;
    //       this.showFeedBack = true
    //       this.comment = null
    //       this.StatusId = null
    //       this.selectedStat = []
    //     }
    //   }
    // })
  }
  /*
*@author: Nilena Alexander
*@desc  : back to listing
*/

  backToListing() {
    this.route.navigate(['/modules/recruitment/requirement-list'])
  }
  /*
  *@author: Nilena Alexander
  *@desc  : to  get status fdrom dropdwn
  */
  getStatus(event) {
    if (event.selected.length > 0) {
      this.StatusId = event.selected[0].id
    }
  }
  /*
  *@author: Nilena Alexander
  *@desc  : to  trim value in comment box
  */
  commentVal(val) {
    this.comment = this.commonFiles.commonTrim(val);
  }
  /*
  *@author: Nilena Alexander
  *@desc  : to  submit form
  */
  submitForm() {
    this.submitted = true;
    if (this.comment)
      this.commentErr = false;
    else
      this.commentErr = true;
    if (this.StatusId)
      this.statusErr = false;
    else
      this.statusErr = true;

    if (!this.commentErr && !this.statusErr) {
      let arrObj = {
        "status": this.StatusId,
        "comment": this.comment,
      }
      this.ManagerFeedbackService.updateStatus(arrObj, this.scheduleId, this.newID, this.detailId, response => {
        this.lazyLoad = true;
        this.lazyLoad = true;
        if (response.status = "OK") {
          if (response.data) {
            this.showFeedBack = false;
            this.updatedComment = response.data[0].comment;
            this.updatedStatus = response.data[0].status;
            this.notification.alertBoxValue("success", response.message);
            this.feedbackDetail()
          }
        }
        else if (response.status == "fail") {
          this.showFeedBack = true;
          this.notification.alertBoxValue("error", response.message);
        }
      })
    }

  }
  /*
 *@author: Nilena Alexander
 *@desc  : to update
 */
  backtoList() {
    this.route.navigate(['modules/recruitment/interview-list'])
  }
  OnDestroy() {

  }

}
