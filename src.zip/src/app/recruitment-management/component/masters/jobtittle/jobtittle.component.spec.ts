import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JobtittleComponent } from './jobtittle.component';

describe('JobtittleComponent', () => {
  let component: JobtittleComponent;
  let fixture: ComponentFixture<JobtittleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JobtittleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JobtittleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
