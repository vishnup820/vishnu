import { Component, OnInit, ElementRef, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import { MasterService } from '../../../services/masters/master.service';

import { apiList } from '../../../../shared/constants/apilist';
import { NotificationService } from '../../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../../shared/services/loader/loader-actions.service';
@Component({
  selector: 'app-interview-round',
  templateUrl: './interview-round.component.html',
  styleUrls: ['../../../../../assets/content/css/recruitmentMasters.css']
})
export class InterviewRoundComponent implements OnInit {

  @ViewChild('jobTittleRef') jobTittleRef: ElementRef;

  masterName: FormControl;
  masterStatus: FormControl;
  masterRegisterForm: FormGroup;

  showForm: boolean = false;
  showConfirmBox: boolean = false;
  formError: boolean = false;

  queryObject: any = {};
  chosenObject: any = {};
  filterSort: any = {};

  status = [
    { value: 'Active', id: 1 },
    { value: 'Inactive', id: 2 },
  ];

  currentPage: number = 1;
  recordsPerPage: number = 10;
  totalRecords: number;

  masterData: any = [];
  deleteSingle: string;
  searchValue  :any;

  searchTextBox :boolean =false
  @ViewChild('foc') inputEl: ElementRef;
  constructor(
    private loader: LoaderActionsService,
    private notifications: NotificationService,
    private masterService: MasterService,
    private cdref: ChangeDetectorRef
  ) { }

  ngOnInit() {
    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    this.queryObject = {
      "page": this.currentPage,
      "page_limit": this.recordsPerPage,
      'sort':'stat'
    }
    this.getMasterData();
    this.createFormControls();
    this.createForm();
  }
   /*
   *  @desc   :method send messages to the server with sender's id
   *  @author :dipin
   */
	setFocus() {
		window.setTimeout(function() {
			document.getElementById('searchField').focus();
		}, 1);
	}
  search(value, set) {
		if (value.trim() != '' || (this.searchValue != '' && this.searchValue)) {
      this.searchValue =value.trim();
      this.queryObject.search =this.searchValue;
      this.queryObject.page = 1;

			this.getMasterData();
		}
  }

  /**
  * @ desc   : for validation
  * @ author  : arun johnson
  */
  createFormControls() {
    this.masterName = new FormControl('', [Validators.required, this.masterService.noWhitespaceValidator]);
    this.masterStatus = new FormControl('', [Validators.required, this.masterService.noWhitespaceValidator]);
  }

  /**
  * @ desc   : for form validation
  * @ author  :arun johnson
  */
  createForm(): void {
    this.masterRegisterForm = new FormGroup({
      masterName: this.masterName,
      masterStatus: this.masterStatus
    });
  }

  /**
  * @ desc   : get interview rounund data
  * @ author  :arun johnson
  */
  getMasterData() {
    this.loader.display(true);
    let type = 'type=interview_round';
    this.masterService.getMasterData(this.queryObject, type, response => {
      if (response) {
        this.masterData = response.data;
        this.totalRecords = response.count;
        this.currentPage = this.queryObject.page;
      } else {
        this.masterData = [];
      }
      this.loader.display(false);
    });
  }

  /**
  * @ desc   : TO close the add and edit form
  * @ author  : arun johnson
  */
  toggleForm(event) {
    this.chosenObject = null;
    this.showForm = !this.showForm;
    let element = document.getElementById('dropdownactive');
    if (this.showForm) {
      element.classList.add("mystyle");
    }
    else {
      element.classList.remove("mystyle");
    }
    this.reset();
  }

  /**
  * @ desc   : form reset
  * @ author  :
  */
  reset() {
    this.formError = false;
    this.masterRegisterForm.reset();
  }
  /**
  * @ desc   : pagination
  * @ author  :
  */
  getpage(eve) {
    if (eve > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = eve;
      this.queryObject['page_limit'] = eve;
      this.queryObject['page'] = 1;
      this.currentPage = 1;
      this.getMasterData();
    }
  }

  /**
  * @ desc   : TO implement pagination
  * @ author  : arun johnson
  */
  pageChangeEvent(page) {
    this.queryObject.page = page;
    this.getMasterData();
  }
  /**
  * @ desc   :
  * @ author  :
  */
  statusChange(event) {
    if (event.selected && event.selected.length > 0) {
      this.masterStatus.setValue(event.selected[0].id + '');
    }
  }

  /**
  * @ desc   : add form
  * @ author  : arun johnson
  */
  submitForm() {
    if (this.masterRegisterForm.invalid) {
      this.formError = true;
    } else {
      this.loader.display(true);
      let data = {
        "meta_key": "interview_round",
        "meta_value": this.masterName.value,
        'status': this.masterStatus.value
      };
      this.masterService.addMasterData(apiList.recruitment.addCommonmaster, data, response => {
        this.loader.display(false);
        if (response.status == "OK") {
          this.loader.display(false);
          this.notifications.alertBoxValue("success", response.message);
          this.toggleForm(null);
          // this.locationFormError = false;
          this.getMasterData();
        }
        else {
          this.loader.display(false);
          this.notifications.alertBoxValue("error", response.message);
        }
      });
    }
  }

  /**
* @ desc   : conformation popup
* @ author  : arun johnson
*/
  confirmPopup() {
    if (this.deleteSingle) {
      this.deleteEmployeeType(this.deleteSingle)
    }
    this.queryObject.page = 1;
    this.showConfirmBox = false;
  }

  /**
  * @ desc   :
  * @ author  : arun johnson
  */
  deleteEmployeeType(id) {
    this.loader.display(true);
    this.masterService.deleteMaster(apiList.recruitment.addCommonmaster, id, (response) => {
      if (response.status == "OK") {
        this.getMasterData();
        this.notifications.alertBoxValue("success", response.message);
        this.loader.display(false);
      }
      else {
        this.notifications.alertBoxValue("error", response.message);
        this.loader.display(false);
      }
    });
  }


  /**
  * @ desc   :  form edit
  * @ author  : arun johnson
  */
  editForm() {
    if (this.masterRegisterForm.invalid) {
      this.formError = true;
    } else {
      this.loader.display(true);
      let data = {
        "meta_key": "interview_round",
        "meta_value": this.masterName.value,
        'status': this.masterStatus.value
      };

      this.masterService.editMasterData(apiList.recruitment.addCommonmaster, data, this.chosenObject.id, response => {
        this.loader.display(false);
        if (response.status == "OK") {
          this.loader.display(false);
          this.notifications.alertBoxValue("success", response.message);
          // this.toggleForm(null);
          // this.locationFormError = false;
          this.getMasterData();
        }
        else {
          this.loader.display(false);
          this.notifications.alertBoxValue("error", response.message);
        }

      })
    }
  }

  /**
  * @ desc   :
  * @ author  : arun johnson
  */
  openEditForm(data, event, index) {
    if (!this.masterData[index].editStatus) {
      for (var i = 0; i < this.masterData.length; i++) {
        if (this.masterData[i].id === data.id) {
          data.editStatus = true;
        }
        else {
          this.masterData[i].editStatus = false;
        }
      }
      this.chosenObject = null;
      this.masterName.setValue(data.name);
      this.masterStatus.setValue(data.status);
      this.chosenObject = data;
      data.status == 1 ? this.chosenObject.selectedIndex = [0] : this.chosenObject.selectedIndex = [1];
      this.cdref.detectChanges();
      this.masterService.position(event,index);
    }
  }

  /**
  * @ desc   : To sort location
  * @ author  :
  */
 sortMasterData(label) {
    let currentSortStatus = this.filterSort[label] ? this.filterSort[label].rev : true;
    this.filterSort = {};
    this.filterSort[label] = { rev: !currentSortStatus }
    this.filterSort["label"] = label;
    this.queryObject.sort = (this.filterSort[label].rev)?label:'-'+label;
    this.getMasterData();
  }
}
