import { Component, OnInit, ChangeDetectorRef,ElementRef,ViewChild } from '@angular/core';
import { LoaderActionsService } from '../../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../../shared/services/notifications/notification.service';
import { MasterService } from '../../../services/masters/master.service';
import { apiList } from '../../../../shared/constants/apilist';

@Component({
  selector: 'app-recruitment-team',
  templateUrl: './recruitment-team.component.html',
  styleUrls: ['../../../../../assets/content/css/recruitmentMasters.css']
})
export class RecruitmentTeamComponent implements OnInit {

  dataList: any = [];
  queryObject: any = {};
  totalRecords: number;
  currentPage = 1;
  recordsPerPage = 10;
  showAdd = false;
  isServiceActive = false;
  showConfirmBox = false;
  searchKey : boolean = true;
  deleteData: any;
  updateId: any = null;
  valid = false;
  formData = {
    name: '',
    status: null,
    editStatus: null,
    editName: null
  };
  peopleLIst: any = [];
  searchValue  :any;
  masterData: any = [];

  searchTextBox :boolean =false
  @ViewChild('foc') inputEl: ElementRef;
  statusList = [];
  constructor(
    private teamService: MasterService,
    private loader: LoaderActionsService,
    private notifications: NotificationService,
    private cdref: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.initStatus();
    this.getPeople();
    if (localStorage.getItem('itemsperpage')) {
      this.recordsPerPage = Number(localStorage.getItem('itemsperpage'));
    }
    this.queryObject = {
      'page': this.currentPage,
      'page_limit': this.recordsPerPage,
      'sort': 'stat',
    };
    this.loadData();
  }
 /*
   *  @desc   :method send messages to the server with sender's id
   *  @author :dipin
   */
	setFocus() {
		window.setTimeout(function() {
			document.getElementById('searchField').focus();
		}, 1);
  }
   /**
  * @ desc   : for search 
  * @ author  :nilena Alexander
  */
 search(value, set) {
  if (value.trim() != '' || (this.searchValue != '' && this.searchValue)) {
    this.searchValue =value.trim();
    this.queryObject.search =this.searchValue;
    this.loadData();
  }
}
  getPeople() {
    this.teamService.getPeople({}, (res) => {
      if (res && res.data) {
        res.data.map((item) => {
          item.name = item.first_name + ' ' + item.last_name + ' (' + item.code + ')';
        });
        this.peopleLIst = res.data;
      } else {
        this.peopleLIst = [];
      }
    });
  }

  getPeopleData(data) {
    if (data && data.selected.length) {
      this.formData.name = data.selected[0].id;
    } else {
      this.formData.name = '';
    }
  }
  /**
* @ desc   : Fetch Data
* @ author  : Varun K N
*/
  loadData() {
    let self = this;
    self.loader.display(true);
    this.teamService.getMasterData(this.queryObject, 'type=recruitment-team', function (res) {
      self.loader.display(false);
      if (res) {
        self.dataList = res.data;
        self.totalRecords = res.count;
      } else {
        self.dataList = [];
      }
    });
  }

  /**
  * @ desc   : TO implement pagination
  * @ author  : Varun K N
  */
  pageChangeEvent(page) {
    this.queryObject.page = page;
    this.currentPage = page;
    this.loadData();
  }

  /**
  * @ desc   : TO implement pagination
  * @ author  : Varun K N
  */
  getpage(eve) {
    if (eve > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = eve;
      this.queryObject['page_limit'] = eve;
      this.queryObject['page'] = 1;
      this.currentPage = 1;
      this.loadData();
    }
  }

  /**
  * @ desc   : TO implement sort
  * @ author  : Varun K N
  */

  sort(value) {
    let type = 0;
    if(this.searchKey == true){
      type = 1;
      this.searchKey = false;
    }
    else{
      type = 0;
      this.searchKey = true;
    }

    if(type == 0){
      this.queryObject.sort = value;
    }
    else{
      this.queryObject.sort = "-"+value;
    }
    this.loadData();
  }

  initStatus() {
    this.statusList = [
      { id: 1, value: 'Active' },
      { id: 2, value: 'Inactive' }
    ];
  }

  /**
  * @ desc   : Get data from status single selector
  * @ author  : Varun K N
  */

  getStatus(data) {
    if (data.selected && data.selected.length) {
      this.formData.status = data.selected[0].id;
    } else {
      this.formData.status = null;
    }
  }
  /**
  * @ desc   : Initialize add form
  * @ author  : Varun K N
  */
  initAdd() {
    this.valid = false;
    this.formData = {
      name: '',
      status: null,
      editStatus: null,
      editName: null
    };
    this.initStatus();
  }
  /**
  * @ desc   : Add skill set submit
  * @ author  : Varun K N
  */
  submit() {
    this.valid = true;
    if (this.isServiceActive || this.formData.name.toString().trim() === '' || !this.formData.status) {
      return;
    }
    this.isServiceActive = true;
    const data = {
      people_id: this.formData.name,
      status: this.formData.status
    };
    let self = this;
    self.loader.display(true);
    this.teamService.addMasterData(apiList.recruitment.addRecruitmentTeam, data, (res) => {
      this.valid = false;
      this.isServiceActive = false;
      self.loader.display(false);
      if (res && res.status == 'OK') {
        this.notifications.alertBoxValue('success', res.message);
        this.loadData();
        this.showAdd = false;
      } else {
        this.notifications.alertBoxValue('error', res.message);
      }
    });
  }
  /**
  * @ desc   : Delete data
  * @ author  : Varun K N
  */
  deleteRecruiter() {
    let self = this;
    this.showConfirmBox = false;
    self.loader.display(true);
    this.teamService.deleteMaster(apiList.recruitment.deleteRecruiter, this.deleteData, (res) => {
      this.isServiceActive = false;
      self.loader.display(false);
      if (res && res.status == 'OK') {
        this.notifications.alertBoxValue('success', res.message);
        this.currentPage = 1;
        this.queryObject.page = 1;
        this.loadData();
      } else {
        this.notifications.alertBoxValue('error', res.message);
      }
    });
  }

  /**
  * @ desc   : Get data for update
  * @ author  : Varun K N
  */
  getRecruiterData(data, event, index) {
    this.valid = false;
    data.edit = !data.edit;
    this.formData.status = data.status;
    this.formData.editStatus = [];
    this.formData.editStatus.push(this.statusList.findIndex((item) => item.id == data.status));
    this.formData.name = data.people_id;
    this.formData.editName = [];
    this.formData.editName.push(this.peopleLIst.findIndex((item) => item.id == data.people_id));
    this.updateId = data;
    this.cdref.detectChanges();
    this.teamService.position(event, index);
  }

  /**
  * @ desc   : Update interviewer set
  * @ author  : Varun K N
  */
  update() {
    this.valid = true;
    if (this.formData.name === '' || !this.formData.status) { return; }
    const data = {
      people_id: this.formData.name,
      status: this.formData.status,
      id: this.updateId.id
    };
    let self = this;
    self.loader.display(true);
    this.teamService.editMasterData(apiList.recruitment.updateRecruiter, data, this.updateId.id, (res) => {
      this.valid = false;
      this.isServiceActive = false;
      self.loader.display(false);
      if (res && res.status == 'OK') {
        this.notifications.alertBoxValue('success', res.message);
        this.loadData();
        this.showAdd = false;
        this.updateId.edit = false;
      } else {
        this.notifications.alertBoxValue('error', res.message);
      }
    });
  }


}
