/*
*  @desc   :component for display leave type and management
*  @author :dipin
*/
import { Component, OnInit} from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';
import { CookieService } from 'ngx-cookie-service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { RecruitmentListService } from '../../services/recruitment-details/recruitment-list/recruitment-list.service';

@Component({
  selector: 'app-requirement-list',
  templateUrl: './requirement-list.component.html',
  styleUrls: ['../../../../assets/content/css/recruitment.css']
})
export class RequirementListComponent implements OnInit {
  searchTextBox : boolean = false;
  filterStatus  : boolean = false;
  confirmBox    : boolean = false;
  showApproval  : boolean = false;
  showOpen      : boolean = false;
  showList      : boolean = false;
  forId         : boolean = false;
  forDate       : boolean = false;
  forStatus     : boolean = false;
  searchValue   : any = "";
  sort          : any;
  setIndex      : any;
  tableData     : any = [];
  filterValue   : any = [];
  config        : any;
  totalRecords  : number;
  currentPage   : number  = 1;
  recordsPerPage: number  = 10;
  advanceFilterData : any;
  userData : any;

  constructor(private apiService : RecruitmentListService,
    private notifications        : NotificationService,
    private loaderService        : LoaderActionsService,
    private router               : Router,
    private cookieService        : CookieService,
    private acl                  : AclVerificationService,) { }

  ngOnInit() {
    this.confirmBox  = false;
		this.config = "Are You Sure You Want To Cancel?";
		if (localStorage.getItem("itemsperpage")) {
			this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			this.recordsPerPage = 10;
    }
    if(this.cookieService.get("user-data")){
      this.userData = JSON.parse(this.cookieService.get("user-data"));
      this.checkUrl();
      this.getData(this.currentPage);
    }
  }

   /*
	*  @desc   :method to update list by api call
  	*  @author :dipin
	*/
  getData(page) {
    this.loaderService.display(true);
    this.currentPage = page;
    let temp = [];
    this.apiService.getDetails(this.currentPage, this.recordsPerPage, this.advanceFilterData, this.searchValue, this.sort, this.showApproval, this.showList, this.showOpen, response => {
      if (response.status == "OK") {
        if (response.data) {
          this.tableData = response.data;
          if (this.showList) {
            for (let i = 0; i < this.tableData.length; i++) {
              if (this.tableData[i].requested_by == this.userData.user_id) {
                if (this.tableData[i].status_slug == "Cancelled" || this.tableData[i].status_slug == 'Rejected' || this.tableData[i].status_slug == "Approved") {
                  this.tableData[i].showEdit   = false;
                  this.tableData[i].showDelete = false;
                }
                else if (this.tableData[i].status_slug == 'Created' || this.tableData[i].status_slug == 'Pending' || this.tableData[i].status_slug == 'Overdue') {
                  this.tableData[i].showEdit = true;
                  this.tableData[i].showDelete = true;
                }
              }
              else if(this.acl.checkAclDummy('recruitment-post') &&
              this.acl.checkAclDummy('recruitment-assign') &&
              this.acl.checkAclDummy('schedule-interview') &&
              this.acl.checkAclDummy('candidate-register') && 
              this.acl.checkAclDummy('interviewer') && 
              !this.acl.checkAclDummy('master-management') &&
              !this.acl.checkAclDummy('recuirment-approval') ){
                if (this.tableData[i].status_slug == "Processing" || this.tableData[i].status_slug == 'In Progress') {
                  this.tableData[i].showEdit   = false;
                  this.tableData[i].showDelete = true;
                }
                else if (this.tableData[i].status_slug == 'On Hold' || this.tableData[i].status_slug == 'Created' || this.tableData[i].status_slug == 'Approved' || this.tableData[i].status_slug == 'Overdue') {
                  this.tableData[i].showEdit = true;
                  this.tableData[i].showDelete = true;
                }
              }
            }
          }
          else if (this.showApproval) {
            for (let i = 0; i < this.tableData.length; i++) {
              if (this.tableData[i].status_slug == "Processing" || this.tableData[i].status_slug == 'In Progress') {
                this.tableData[i].showEdit = false;
                this.tableData[i].showDelete = true;
              }
              else if (this.tableData[i].status_slug == 'Pending' || this.tableData[i].status_slug == 'Overdue'
                || this.tableData[i].status_slug == 'On Hold') {
                this.tableData[i].showEdit = true;
                this.tableData[i].showDelete = true;
              }
            }
          }
          else{
            for (let i = 0; i < this.tableData.length; i++) {
              if (this.tableData[i].status_slug == "Posted") {
                this.tableData[i].showEdit   = false;
                this.tableData[i].showDelete = true;
                this.tableData[i].showAdd    = true;
              }
              else if (this.tableData[i].status_slug == 'New' || this.tableData[i].status_slug == 'Overdue') {
                this.tableData[i].showEdit   = true;
                this.tableData[i].showDelete = true;
                this.tableData[i].showAdd    = true;
              }
              else if (this.tableData[i].status_slug == 'On Hold') {
                this.tableData[i].showEdit   = true;
                this.tableData[i].showDelete = true;
                this.tableData[i].showAdd    = false;
              }
              else if (this.tableData[i].status_slug == 'In Progress') {
                this.tableData[i].showEdit   = false;
                this.tableData[i].showDelete = true;
                this.tableData[i].showAdd    = false;
              }
            }
          }
        }
        else {
          this.tableData = [];
        }
        this.totalRecords = response.count;
        this.loaderService.display(false);
      }
      else {
        this.tableData = [];
        this.loaderService.display(false);
      }
    })
  }

  setFocus() {
    window.setTimeout(function () {
      document.getElementById('searchField').focus();
    }, 1);
  }

  checkUrl(){
    if(this.router.url.match('/recruitment/requirement-approval')){
      localStorage.setItem('recruitment', '/modules/recruitment/requirement-approval');
      this.showApproval = true;
      this.showList     = false;
      this.showOpen     = false;
      this.filterValue  = [{id:2,name:'Approved'},{id:3,name:'Rejected'},{id:4,name:'Cancelled'},{id:1,name:'Pending'}];
    }
    else if(this.router.url.match('/recruitment/requirement-list')){
      localStorage.setItem('recruitment', '/modules/recruitment/requirement-list');

      this.showApproval = false;
      this.showList     = true;
      this.showOpen     = false;
      this.filterValue  = [{id:2,name:'Approved'},{id:3,name:'Rejected'},
      {id:4,name:'Cancelled'},{id:5,name:'Processing'},{id:6,name:'In Progress'},{id:10,name:"Overdue"}];
    }
    else{
      localStorage.setItem('recruitment', '/modules/recruitment/requirement-openings');
      this.showApproval = false;
      this.showList     = false;
      this.showOpen     = true;
      this.filterValue  =[{id:7,name:'New'},{id:11,name:'Closed'},{id:9,name:'On Hold'},{id:8,name:"Posted"},
      {id:6,name:"In Progress"},{id:10,name:"Overdue"},{id:4,name:"Cancelled"}];
    }
  }

      /*
	*  @desc   :method to get responce from the confirm popup component
  	*  @author :dipin
	*/
	getPopupConfirm(event){
		this.confirmBox = false;
		if(event == true){
        this.deleteSelected(this.setIndex);
		}
  }
  
   /*
	*  @desc   :method to delete element from the list
  	*  @author :dipin
	*/
	deleteSelected(index){
		this.loaderService.display(true);
		this.apiService.deleteDetails(this.tableData[index].id,response=>{
                  if(response.status == "OK"){
                  	this.loaderService.display(false);
                  	this.currentPage = 1;
                   this.getData(this.currentPage);
                   this.notifications.alertBoxValue("success",response.message);
                  }
                  else{
                  	this.loaderService.display(false);
                   this.notifications.alertBoxValue("error", response.message);
                  }
          })
	}

  /*
 author : dipin
 desc   : Search  when enter key is pressed
*/
  search(value, set) {
    if (value.trim() != '' || (this.searchValue != '' && this.searchValue)) {
      this.searchValue = value;
      this.sort = undefined;
      this.currentPage = 1;
      this.getData(this.currentPage);
    }
  }


  /*
 author : dipin
 desc   : send Filter Data
 params :
*/
  filterData(event) {
    if (event || this.advanceFilterData) {
      this.advanceFilterData = event;
      this.currentPage = 1;
      this.getData(this.currentPage);
    }
    else
      this.advanceFilterData = undefined;
  }

  /*
  *  @desc   :method for pagination
  *  @author :dipin
  */
 getpage(event) {
  if (event > 10 || this.recordsPerPage != 10) {
    this.recordsPerPage = event;
    this.currentPage = 1;
    this.getData(this.currentPage);
  }
}

  edit(id,type){
    if(type){
      localStorage.setItem('recruitUrl',JSON.stringify(this.router.url))
      localStorage.setItem('recruitUrl',JSON.stringify(this.router.url))

      this.router.navigate(['/modules/recruitment/details/'+id]);
    }
    else
      this.router.navigate(['/modules/recruitment/requirement-edit/'+id]);
  }

     /*
	*  @desc   :method for apply sorting using api and update the table list
  	*  @author :dipin
	*/
	applySort(value){
		let type = 0;
		if(value == 'jId')
		if (this.forId == true) {
			type = 1;
			this.forId = false;
		}
		else {
			type = 0;
			this.forId = true;
		}

  if(value == 'tDate')
		if (this.forDate == true) {
			type = 1;
			this.forDate = false;
		}
		else {
			type = 0;
			this.forDate = true;
    }
    
  if(value == 'reqStat')
		if (this.forStatus == true) {
			type = 1;
			this.forStatus = false;
		}
		else {
			type = 0;
			this.forStatus = true;
		}
      this.sort = {department : value,type:type};
      this.getData(this.currentPage);
  }
  
  showCandidate(id){
    this.router.navigate(['/modules/recruitment/add-candidate'],{queryParams: { id:id }});
  }
}
