import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecruitmentCandidateListComponent } from './recruitment-candidate-list.component';

describe('RecruitmentCandidateListComponent', () => {
  let component: RecruitmentCandidateListComponent;
  let fixture: ComponentFixture<RecruitmentCandidateListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecruitmentCandidateListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecruitmentCandidateListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
