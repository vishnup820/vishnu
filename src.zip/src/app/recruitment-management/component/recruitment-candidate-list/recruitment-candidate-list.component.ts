import { Component, OnInit , ViewChild , ElementRef  } from '@angular/core';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import {CandidateListService} from  '../../services/candidate-list/candidate-list.service';
import {AddCandidateService} from  '../../services/add-candidate/add-candidate.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-recruitment-candidate-list',
  templateUrl: './recruitment-candidate-list.component.html',
  styleUrls: ['../../../../assets/content/css/recruitment.css'] 
})
export class RecruitmentCandidateListComponent implements OnInit {
 
   @ViewChild('foc') inputEl : ElementRef;
   candidateList       :   any        = [];
   currentPage         :   number     = 1;
   recordsPerPage      :   number     = 10;
   queryObject         :   any        = {};
   totalRecords        :   number;
   searchD             :   any;
   dateRangeValue      :   any;
   statusChecked       :   any;
   statusSelected      :   any;
   ExperienceChecked   :   any;
   ExperienceSelected  :   any;
   typeTitleChecked    :   any;
   titleSelected       :   any;
   advanceFilterData   :   any;
   filterStatVal       :   number;
   expStatus           :   any        = [];
   statusType          :   any        = [];
   searchValue         :   string     = "";
   searchKeyword       :   any        = "";
   searchTextBox       :   boolean    = false;
   filterActive        :   boolean    = false;
   filterStatus	       :   boolean = false;
   filterSort          :   any        = {};
   jobArray            :   any        = [];
   relExperience        :   any        = [];

  constructor(private loaderService: LoaderActionsService,
    private timeZone: TimezoneDetailsService,
    private CandidateListService: CandidateListService,
    private AddCandidateService: AddCandidateService,
    private router			          	: Router,
    ) { }

  ngOnInit() {
    this.statusType = [
      {
        "name": "New", "value": "11", "index": 0
      },
      // {
      //   "name": "Interview Sheduled", "value": "1", "index": 1
      // },
      // {
      //   "name": "Interview Cancelled", "value": "0", "index": 2
      // }, 
      {
        "name": "Rejected", "value": "4", "index": 3 
      },
      {
        "name": "Shortlisted", "value": "5", "index": 4
      },
      {
        "name": "Selected", "value": "6", "index": 5
      },
      {
        "name": "On Hold", "value": "7", "index": 6
      },
      {
        "name": "Joined", "value": "8", "index": 7
      },
      {
        "name": "Offered", "value": "9", "index": 8
      },
      {
        "name": "Withdrawn", "value": "10", "index": 9
      }
    ]

    this.expStatus = [
      {
         "experience": "0 year", value: 0
      },
      {
        "experience": "1 year", value: 1
      },
      {
         "experience": "2 year",value: 2
      }, 
      {
         "experience": "3 year", value: 3
      },
      {
         "experience": "4 year", value: 4
      },
      {
        "experience": "5 year", value: 5
      },
      {
        "experience": "6 year", value: 6
      },
      {
         "experience": "7 year", value : 7
      },
      {
         "experience": "8 year", value: 8
      },
      {
        "experience": "9 year", value: 9
      },
      {
        "experience": "10 year", value: 10
      },
      {
        "experience": "11 year", value: 11
      },
      {
        "experience": "12 year", value: 12
      },
      {
         "experience": "13 year", value: 13
      },
      {
         "experience": "14 year", value: 14
      },
      {
        "experience": "15 year", value : 15
      }
   ]
    this.queryObject['page'] = this.currentPage;
    this.queryObject['page_limit'] = this.recordsPerPage;
    // this.AddCandidateService.getRecruitmentMasterData(res=>{
    //   this.loaderService.display(false);
    //   if (res.status == "OK") {
    //     this.jobArray=res.data.job_title;
    //     this.relExperience=res.data['qualification'];
        
    //   }})
    this.candidateListData();
  }

  detailsView(id, req){
    // this.router.navigate(['modules/recruitment/candidate-details'])

    this.router.navigate(['modules/recruitment/candidate-details/'+id],{ queryParams: {req:req}})
  }
    /*
  * @ desc   : method for calling api for opening list
  * @ author  : ashiq
  */
 candidateListData() {
  this.loaderService.display(true);
  this.CandidateListService.getCandidateList(this.queryObject, response => {
      if (response.data && response.data.length > 0) {
          this.candidateList     = response.data;
          this.currentPage       = this.queryObject['page'];
          this.totalRecords      = response.count;
          for(let i=0;i<this.candidateList.length;i++){
            this.candidateList[i].job_title=this.candidateList[i].job_title+" "+ "(" + this.candidateList[i].job_code +")";
          }
          this.loaderService.display(false);
      }
      else {
        this.candidateList = [];
        this.loaderService.display(false);
    }
  })
}

/*
  * @ desc   : method for pass page number  through api
  * @ author  : ashiq
  */
 pageChangeEvent(page) {
  this.queryObject['page'] = page;
  this.candidateListData();
}

getpage(eve) {
  if (eve > 10 || this.recordsPerPage != 10) {
     this.recordsPerPage = eve;
     this.queryObject['page_limit'] = eve;
     this.queryObject['page'] = 1;
     this.currentPage = 1;
     this.candidateListData();
  }
}

  /*
 author : dipin
 desc   : send Filter Data
 params :
*/
  filterData(event) {
    if (event || this.advanceFilterData) {
      this.advanceFilterData = event;
      this.currentPage = 1;
      if (this.advanceFilterData) {
        if (this.advanceFilterData.job)
          if (this.advanceFilterData.job.selected.length) {
            this.queryObject.jobTiltle = this.advanceFilterData.job.selected[0].id;
          }
        if (this.advanceFilterData.bsValue)
          this.queryObject.t_dt = this.CandidateListService.formatForApi(this.advanceFilterData.bsValue);
          
      if(this.advanceFilterData.requirement)
        if(this.advanceFilterData.requirement.selected.length)
         this.queryObject.stat=this.advanceFilterData.requirement.selected[0].value
         
      if(this.advanceFilterData.relExp)
         if(this.advanceFilterData.relExp.selected.length)
          this.queryObject.rel_exp=this.advanceFilterData.relExp.selected[0].value
      }
      if(event==undefined){
        this.queryObject.stat=null;
        this.queryObject.t_dt=null;
        this.queryObject.jobTiltle=null;
        this.queryObject.rel_exp=null;
      }
      this.queryObject.page = this.currentPage ;
      this.candidateListData();
    }

    else{
      this.advanceFilterData = undefined;
      this.queryObject.stat=null;
      this.queryObject.t_dt=null;
      this.queryObject.jobTiltle=null;
      this.queryObject.rel_exp=null;
    }
     
   
  }

 /*
  * @ desc   : method for sorting   training list
  * @ author  : ashiq
  */
 sortCandidateList(label) {
  let currentSortStatus = this.filterSort[label] ? this.filterSort[label].rev : true;
  this.filterSort = {};
  this.filterSort[label] = { rev: !currentSortStatus }
  this.filterSort["label"] = label;
  this.queryObject.sort = `${this.filterSort[label].rev ? '-' : ''}${label}`
  this.candidateListData();
}

 /*
  * @ desc   : method for focus cursor in search box of  training list
  * @ author  : ashiq
  */
 inputfocus(){
  setTimeout(() => {this.inputEl.nativeElement.focus();},100)
}

  /*
  * @ desc   : method for search in  training list
  * @ author  : ashiq
  */
 searchList(keyword) {
  if ( this.searchKeyword || this.searchD.trim() != ''){
       this.searchKeyword = keyword;
       this.queryObject.keyword = this.searchKeyword ? this.searchKeyword : '';
       this.queryObject.page = 1;
       this.candidateListData();
   }
}

filterApply() { //this.filterSelect is a copy of selected value
  let range = this.dateRangeValue == undefined ? null : this.dateRangeValue ;
  let status = this.statusSelected && this.statusSelected.selected && this.statusSelected.selected[0] && this.statusSelected.selected[0].value ? this.statusSelected.selected[0].value : 0;
  let loader = this.CandidateListService.checkFilterStatus(range, status);
  if (loader) {
    this.filterActive = true;
    if (this.statusSelected.selected.length) {
      if (this.statusSelected.selected[0].status == "New") {
        this.queryObject.stat = "1";
      } else if (this.statusSelected.selected[0].status == "Interview Sheduled") {
        this.queryObject.stat = "2";
       }
      else if (this.statusSelected.selected[0].status == "Interview Cancelled") {
        this.queryObject.stat = "3";
      }
      else if (this.statusSelected.selected[0].status == "Shortlisted") {
        this.queryObject.stat = "4";
      }
      else if (this.statusSelected.selected[0].status == "Rejected") {
        this.queryObject.stat = "5";
      }
      else if (this.statusSelected.selected[0].status == "Selected") {
        this.queryObject.stat = "6";
      }
      else if (this.statusSelected.selected[0].status == "On Hold") {
        this.queryObject.stat = "7";
      }
      else if (this.statusSelected.selected[0].status == "Joined") {
        this.queryObject.stat = "8";
      }
      else if (this.statusSelected.selected[0].status == "Offered") {
        this.queryObject.stat = "9";
      }
      else if (this.statusSelected.selected[0].status == "Withdrawn") {
        this.queryObject.stat = "10";
      }
    }
    else {
      this.queryObject.stat = null;

    }

    if (this.titleSelected.selected.length) {
      this.queryObject.jobTiltle = this.titleSelected.selected[0].id;
    }
    else {
      this.queryObject.jobTiltle = null;
    }

    

    // if (this.dateRangeValue) {
    //    this.queryObject.reqstart = this.CandidateListService.formatForApi(this.dateRangeValue[0]);
    //    this.queryObject.reqend = this.CandidateListService.formatForApi(this.dateRangeValue[1]);
    // } else {
    //   this.queryObject.reqstart = null;
    //   this.queryObject.reqend =null;
    // }
    if (this.statusSelected.selected.length == 0 &&this.dateRangeValue ==null) {
      this.filterActive = false;
      this.queryObject.stat = null;
      this.queryObject.jobTiltle = null;
      this.queryObject.reqend=null;
      this.queryObject.reqstart=null;
      this.currentPage = 1;
      this.queryObject.page =   this.currentPage ;

    }
    this.currentPage = 1;
    this.queryObject.page =   this.currentPage ;
    this.candidateListData();

  }
  else {
    this.filterActive = false;
    this.queryObject.jobTiltle=null;
    this.queryObject.stat = null;
    this.queryObject.mngstat  = null;
    this.queryObject.reqend=null;
    this.queryObject.reqstart=null
    this.currentPage = 1;
    this.queryObject.page =   this.currentPage ;
    this.filterStatVal= 0;


  }
}

/*
author : Nilena Alexander
desc   : filter cancel function

*/

filterCancel() {
  if (this.CandidateListService.checkFilterCanCancel()) {
    this.queryObject.stat = null
    this.queryObject.reqend=null;
    this.queryObject.reqstart=null;
    this.queryObject.mngstat  = null;
    this.queryObject.page = 1;
    this.filterStatVal= 0;
     this.queryObject.jobTiltle = null;
    this.candidateListData();
  }
  this.filterActive = false;
  this.CandidateListService.clearFilterStatus();
  this.dateRangeValue = null;
  this.statusChecked = null;
}




// dateRangeChange(event) {
//   this.dateRangeValue = event;
// }

 /*
  * @ desc   : filter event triggered when filter applied
  * @ author : ashiq
  */
 filterStatusEvent(event) {
  if (event.selectedIndex.length != 0) {
    this.statusChecked = event.selectedIndex;
  }
  else {
    this.statusChecked = [];
  }
  this.statusSelected = event;
}

filterExperienceEvent(event) {
  if (event.selectedIndex.length != 0) {
    this.ExperienceChecked = event.selectedIndex;
  }
  else {
    this.ExperienceChecked = [];
  }
  this.ExperienceSelected = event;
}

filterTitleEvent(event){
  if (event.selectedIndex.length != 0) {
    this.typeTitleChecked = event.selectedIndex;
  }
  else {
    this.typeTitleChecked = [];
  }
  this.titleSelected = event;
}


}
