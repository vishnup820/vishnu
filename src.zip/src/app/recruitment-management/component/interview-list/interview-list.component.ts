import { Component, OnInit,  ViewChild , ElementRef  } from '@angular/core';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { InterviewListService } from '../../services/interview-list/interview-list.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { CookieService } from 'ngx-cookie-service';
import {CandidateListService} from  '../../services/candidate-list/candidate-list.service';
import { CommonFilesService } from '../../services/common/common-files.service';
import { ConstantServicesService } from '../../../shared/services/constant/constant-services.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';

@Component({
  selector: 'app-interview-list',
  templateUrl: './interview-list.component.html',
  styleUrls: ['../../../../assets/content/css/recruitment.css']
})
export class InterviewListComponent implements OnInit {
  @ViewChild('foc') inputEl : ElementRef;

  queryObject         :   any        = {};
  searchValue         :   string     = "";
  searchKeyword       :   any        = "";
  searchTextBox       :   boolean    = false;
  dateShow            :   boolean    = false;
  otherDataList       :   any        = [];
  admindataList       :   any        = [];
  currentPage         :   number     = 1;
  recordsPerPage      :   number     = 10;
  totalRecords        :   number;
  advanceFilterData   :   any;
  searchD             :   any;
  selectedStatus      :   any;
  userData            :   any;
  currentState        :   any;
  filterStatus        :   boolean;
  adminRole           :   boolean = false;
  hrRole              :   boolean = false;
  assign              :   boolean = false;
  statusType          :   any;
  currentDate         :   Date;
  dataList            :   any        = [];
  expStatus           :   any        = [];

  constructor(private InterviewListService: InterviewListService,
    private LoaderActionsService: LoaderActionsService,
    private NotificationService: NotificationService,
    private CookieService      :CookieService,
    private TimezoneDetailsService: TimezoneDetailsService,
    private CandidateListService: CandidateListService,
    private CommonFilesService:CommonFilesService,
    private constSetup    : ConstantServicesService,
    private AclVerificationService : AclVerificationService,
    private Router: Router) { }

  ngOnInit() {
    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    if (this.CookieService.get("user-data")) {
      this.userData = JSON.parse(this.CookieService.get("user-data"));
   }
    this.dataList= [{
      "datas": "My Records", value: 1 , index : 0
    },
    {
      "datas": "Other Records",  value: 2 , index : 1
    },
    {
      "datas" : "Externals",  value: 3 , index : 2
    }];
    
    this.expStatus = [
      {
         "experience": "0 year", value: '0'
      },
      {
        "experience": "1 year", value: '1'
      },
      {
         "experience": "2 year",value: '2'
      }, 
      {
         "experience": "3 year", value: '3'
      },
      {
         "experience": "4 year", value: '4'
      },
      {
        "experience": "5 year", value: '5'
      },
      {
        "experience": "6 year", value: '6'
      },
      {
         "experience": "7 year", value : '7'
      },
      {
         "experience": "8 year", value: '8'
      },
      {
        "experience": "9 year", value: '9'
      },
      {
        "experience": "10 year", value: '10'
      },
      {
        "experience": "11 year", value: '11'
      },
      {
        "experience": "12 year", value: '12'
      },
      {
         "experience": "13 year", value: '13'
      },
      {
         "experience": "14 year", value: '14'
      },
      {
        "experience": "15 year", value : '15'
      }
   ] 
   this.adminRole = this.AclVerificationService.checkAclDummy('allemployee-list');
   this.hrRole = this.AclVerificationService.checkAclDummy('interviewer');
   this.assign = this.AclVerificationService.checkAclDummy('recruitment-assign');
    this.queryObject['page'] = this.currentPage;
    this.queryObject['page_limit'] = this.recordsPerPage;
    this.currentDate   = this.TimezoneDetailsService.toLocal(new Date());
    // if(this.userData.role_id==2 || this.userData.role_id==4 || this.userData.role_id==3 ||  this.userData.role_id==5 || this.userData.role_id==1){
      this.myInterviewData();
      this.currentState="myRecord";
      this.selectedStatus=[0];
    // }
    
  }


    /* @ desc    : date  conversionbasedon utcstarttime
   * @ author  : Nilena Alexander
   */
  dateConversion() {
    for (let i = 0; i < this.otherDataList.length; i++) {
      for(let  j = 0; j < this.otherDataList[i].interviewer_date.length; j++ ){
        let startTime = this.otherDataList[i].interviewer_date[j].date;
        let sStart = startTime.split(" ");

      let tempFirst = this.TimezoneDetailsService.getLocalDate(sStart[0] + " " + sStart[1]);
      this.otherDataList[i].interviewer_date[j].date = new Date(tempFirst).getFullYear() + "-" + (Number(new Date(tempFirst).getMonth()) + 1) + "-" + new Date(tempFirst).getDate();
    }
  }
  }
  /**method forutc conversion
       * @ author  : Nilena Alexander
       */

  utcConvert() {
    for (let i = 0; i < this.otherDataList.length; i++) { 
      for(let  j = 0; j < this.otherDataList[i].time.length; j++ ){
        let startTime = this.otherDataList[i].time[j].start_time;
        let endTime = this.otherDataList[i].time[j].end_time;
        let sStart = startTime.split(":");
        let eStart = endTime.split(":");
        let time1 = this.TimezoneDetailsService.getTimeNow(sStart[0] + ":" + sStart[1]);
        let time2 = this.TimezoneDetailsService.getTimeNow(eStart[0] + ":" + eStart[1]);
        let time3 = this.tConvert(time1);
        let time4 = this.tConvert(time2);
        this.otherDataList[i].time[j].end_time= time3+'-'+time4;
   
    }
  }
  }

    /*
  * @ desc   : method for calling api for other interview list
  * @ author  : ashiq
  */
 otherInterviewData() {
  this.LoaderActionsService.display(true);
  this.queryObject['scope']="other";


  if(!this.advanceFilterData){
    this.queryObject['r_sd_dt']=this.CommonFilesService.formatForApi(this.TimezoneDetailsService.toLocal(new Date()))
  }else{
    this.queryObject['r_sd_dt']==this.CommonFilesService.formatForApi(this.currentDate);
  }

  // this.constSetup.filterData=this.currentDate;
  // this.filterData(null);
  // this.queryObject['t_dt']=`${this.currentDate.getFullYear()}-${this.currentDate.getMonth()+1}-${this.currentDate.getDate()}`;
  this.InterviewListService.getOtherList(this.queryObject, response => {
      if (response.data && response.data.length > 0) {
          this.otherDataList = response.data;
          for(let i=0;i<this.otherDataList.length;i++){
            this.otherDataList[i].job_position=this.otherDataList[i].job_position+" "+ "(" + this.otherDataList[i].job_code +")";
          }

          this.dateConversion()
          this.utcConvert()
        
          this.currentPage       = this.queryObject.page;
          this.totalRecords      = response.count;
          this.LoaderActionsService.display(false);
      }
      else {
        this.otherDataList = [];
        this.LoaderActionsService.display(false);
    }
  })
}

    /*
  * @ desc   : method for calling api for my interview list
  * @ author  : ashiq
  */
 myInterviewData() {
  this.LoaderActionsService.display(true);
  this.queryObject['scope']="my_records";
  this.InterviewListService.getOtherList(this.queryObject, response => {
      if (response.data && response.data.length > 0) {
          this.otherDataList     = response.data;
          for(let i=0;i<this.otherDataList.length;i++){
            this.otherDataList[i].job_position=this.otherDataList[i].job_position+" "+ "(" + this.otherDataList[i].job_code +")";
          }
     
          this.dateConversion()
          this.utcConvert()
          // for (let i = 0; i < this.otherDataList.length; i++) { 
          //   for(let  j = 0; j < this.otherDataList[i].time.length; j++ ){
          //     this.otherDataList[i].time[j].start_time = "date "+this.otherDataList[i].time[j].start_time;
          //     this.otherDataList[i].time[j].end_time = "date "+this.otherDataList[i].time[j].end_time;
          //     let startsplitArray=this.otherDataList[i].time[j].start_time.split(' ');
          //     this.otherDataList[i].time[j].start_time=this.TimezoneDetailsService.getTimeNow(startsplitArray[1]);
          //     let endsplitArray=this.otherDataList[i].time[j].end_time.split(' ');
          //     this.otherDataList[i].time[j].end_time=this.TimezoneDetailsService.getTimeNow(endsplitArray[1]);
          //     this.otherDataList[i].time[j].start_time=this.tConvert(this.otherDataList[i].time[j].start_time);
          //     this.otherDataList[i].time[j].end_time=this.tConvert(this.otherDataList[i].time[j].end_time);
          //     this.otherDataList[i].time[j].end_time=this.otherDataList[i].time[j].start_time+'-'+this.otherDataList[i].time[j].end_time;
          //   }
        
          // }
         

          this.currentPage       = this.queryObject.page;
          this.totalRecords      = response.count;
          this.LoaderActionsService.display(false);
      }
      else {
        this.otherDataList = [];
        this.LoaderActionsService.display(false);
    }
  })
}


    /*
  * @ desc   : method for calling api for my interview list
  * @ author  : ashiq
  */
 externalInterviewData() {
  this.LoaderActionsService.display(true);
  this.queryObject['scope']="external";
  this.InterviewListService.getOtherList(this.queryObject, response => {
      if (response.data && response.data.length > 0) {
          this.otherDataList     = response.data;
          for(let i=0;i<this.otherDataList.length;i++){
            this.otherDataList[i].job_position=this.otherDataList[i].job_position+" "+ "(" + this.otherDataList[i].job_code +")";
          }
          this.dateConversion()
          this.utcConvert()
          // for (let i = 0; i < this.otherDataList.length; i++) { 
          //   for(let  j = 0; j < this.otherDataList[i].time.length; j++ ){
          //     this.otherDataList[i].time[j].start_time = "date "+this.otherDataList[i].time[j].start_time;
          //     this.otherDataList[i].time[j].end_time = "date "+this.otherDataList[i].time[j].end_time;
          //     let startsplitArray=this.otherDataList[i].time[j].start_time.split(' ');
          //     this.otherDataList[i].time[j].start_time=this.TimezoneDetailsService.getTimeNow(startsplitArray[1]);
          //     let endsplitArray=this.otherDataList[i].time[j].end_time.split(' ');
          //     this.otherDataList[i].time[j].end_time=this.TimezoneDetailsService.getTimeNow(endsplitArray[1]);
          //     this.otherDataList[i].time[j].start_time=this.tConvert(this.otherDataList[i].time[j].start_time);
          //     this.otherDataList[i].time[j].end_time=this.tConvert(this.otherDataList[i].time[j].end_time);
          //     this.otherDataList[i].time[j].end_time=this.otherDataList[i].time[j].start_time+'-'+this.otherDataList[i].time[j].end_time;
          //   }
        
          // }
          this.currentPage       = this.queryObject.page;
          this.totalRecords      = response.count;
          this.LoaderActionsService.display(false);
      }
      else {
        this.otherDataList = [];
        this.LoaderActionsService.display(false);
    }
  })
}

  /*
 author : ashiq
 desc   : send Filter Data
 params :
*/
// filterData(event) {
//   if (event || this.advanceFilterData) {
//     this.advanceFilterData = event;
//     this.currentPage = 1;
//     if (this.advanceFilterData.bsValue)
//     this.queryObject.t_dt = this.CandidateListService.formatForApi(this.advanceFilterData.bsValue);
//     if( this.dateShow==false){
//       this.myInterviewData();
//     }
//     if(this.dateShow==true){
//       this.otherInterviewData();
//     }

//   }
//   else
//     this.advanceFilterData = undefined;
// }

  /*
 author : dipin
 desc   : send Filter Data
 params :
*/
  filterData(event) {
    if (event || this.advanceFilterData) {
      this.advanceFilterData = event;
      this.currentPage = 1;
      if (this.advanceFilterData) {
        if (this.advanceFilterData.job)
          if (this.advanceFilterData.job.selected.length) {
            this.queryObject['r_sd_rqd'] = this.advanceFilterData.job.selected[0].id;
          }
        if (this.advanceFilterData.bsValue)
          this.queryObject['r_sd_dt'] = this.CandidateListService.formatForApi(this.advanceFilterData.bsValue);
        this.currentDate = this.advanceFilterData.bsValue;
        setTimeout(() => {
          this.currentDate = this.advanceFilterData.bsValue
        }, 500);
        if (this.advanceFilterData.relExp)
          if (this.advanceFilterData.relExp.selected.length)
            this.queryObject['rev'] = this.advanceFilterData.relExp.selected[0].value
      }
      if (event == undefined) {
        if (this.currentState == "otherRecord") {
          this.currentDate = this.TimezoneDetailsService.toLocal(new Date());
          this.queryObject['r_sd_dt'] = this.CommonFilesService.formatForApi(this.currentDate);

          this.constSetup.dateStatus(this.currentDate);
        }
        if (this.currentState == "myRecord") {
          this.queryObject['r_sd_dt'] = null;
        }
        if (this.currentState == "externals") {
          this.queryObject['r_sd_dt'] = null;
        }
        this.queryObject['rev']=null;
        this.queryObject['r_sd_rqd']=null;
      }
      if (this.currentState == "myRecord") {
        this.myInterviewData();
      }
      if (this.currentState == "otherRecord") {
        this.otherInterviewData();
      }
      if (this.currentState == "externals") {
        this.externalInterviewData();
      }
    }
    else{
      if (this.currentState == "otherRecord") {
        this.constSetup.dateStatus(this.TimezoneDetailsService.toLocal(new Date()));
        this.currentDate = this.TimezoneDetailsService.toLocal(new Date());
      }
      this.advanceFilterData = undefined;
      this.queryObject['r_sd_rqd'] = null;
      this.queryObject['rev'] = null;

    }
  

  }


 /*
  * @ desc   : method for search in  interview list
  * @ author  : ashiq
  */
 searchList(keyword) {
  if ( this.searchKeyword || this.searchD.trim() != ''){
       this.searchKeyword = keyword;
       this.queryObject.keyword = this.searchKeyword ? this.searchKeyword : '';
       this.queryObject.page = 1;
       if( this.currentState=="myRecord"){
        this.myInterviewData();
      }
      if( this.currentState=="otherRecord"){
        this.otherInterviewData();
      
      }
      if( this.currentState=="externals"){
        this.externalInterviewData();
      }

   }
}

 /*
  * @ desc   : method for focus cursor in search box of  interview list
  * @ author  : ashiq
  */
 inputfocus(){
  setTimeout(() => {this.inputEl.nativeElement.focus();},100)
}

 /*
  * @ desc   : method for pass page number  through api
  * @ author  : ashiq
  */
 pageChangeEvent(page) {
  this.queryObject.page = page;
  if( this.currentState=="myRecord"){
    this.myInterviewData();
  }
  if( this.currentState=="otherRecord"){
    this.otherInterviewData();
  }
  if( this.currentState=="externals"){
    this.externalInterviewData();
  }
}

  getpage(eve) {

    if (eve > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = eve;
      this.queryObject['page_limit'] = eve;
      this.queryObject['page'] = 1;
      this.currentPage = 1;
      if (this.currentState == "myRecord") {
        this.myInterviewData();
      }
      if (this.currentState == "otherRecord") {
        this.otherInterviewData();
      }
      if (this.currentState == "externals") {
        this.externalInterviewData();
      }
    }

  }

 /*
  * @ desc   : method for selecting all data/ mydata/ otherdata in  training list
  * @ author  : ashiq
  */
 selectDataList(e) {
   if(e.selected && e.selected.length){
    if(e.selected[0].datas=="My Records"){
      this.currentState="myRecord";
      this.dateShow=false;
      this.queryObject['r_sd_dt']=null;
      // this.advanceFilterData = undefined;
      localStorage.setItem('dropDownStatus', 'myRecord');
      this.constSetup.dateStatus(null);
     this.myInterviewData();
    }
    if(e.selected[0].datas=="Other Records"){
     this.currentState="otherRecord";
     this.dateShow=true;
     localStorage.setItem('dropDownStatus', 'otherRecord');
     this.constSetup.dateStatus(this.TimezoneDetailsService.toLocal(new Date()));
    // localStorage.setItem('mytime', JSON.stringify(this.currentDate));
    //  this.constSetup.filterData=this.currentDate
     this.filterData(null);
     this.otherInterviewData();
    }
    if(e.selected[0].datas=="Externals"){
     this.currentState="externals";
     this.queryObject['r_sd_dt']=null;
    //  this.advanceFilterData = undefined;
     localStorage.setItem('dropDownStatus', 'externals');
     this.constSetup.dateStatus(null);
      this.externalInterviewData();
      this.dateShow=false;
    }

   }

}

utcConvertion(dataArray){
  for (let i = 0; i < dataArray.length; i++) {    
    for(let  j = 0; j < dataArray[i].interview_start_time.length; j++ ){
      let splitArray=dataArray[i].interview_start_time[j].start_time.split(' ');
    }
 
    // dataArray[i].shift_time_start = this.TimezoneDetailsService.getTimeNow(dataArray[i].shift_time_start);
    // dataArray[i].shift_time_end =   this.TimezoneDetailsService.getTimeNow(dataArray[i].shift_time_end);
    // dataArray[i].shift_time_start = this.tConvert(dataArray[i].shift_time_start);
    // dataArray[i].shift_time_end = this.tConvert(dataArray[i].shift_time_end);
  }

}

tConvert(time){
  // Check correct time format and split into components
  time = time.toString().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];
  if(time.length > 1) { // If time format correct
    time = time.slice (1);  // Remove full string match value
    time[5] = +time[0] < 12 ?' '+ 'AM' : ' '+  'PM'; // Set AM/PM
    time[0] = +time[0] % 12 || 12; // Adjust hours
  }
  return time.join (''); // return adjusted time or original string
}


detailedInfo(id,req){
  this.Router.navigate(['/modules/recruitment/feedback/'+id],{ queryParams: {req:req}})
  }




}
