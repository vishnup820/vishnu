import { Component, OnInit , ChangeDetectorRef} from '@angular/core';
import {
  RouterModule,
  Routes,
  Router
} from '@angular/router';

import {
  ActivatedRoute
} from '@angular/router';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { MalihuScrollbarService } from 'ngx-malihu-scrollbar';
import { CookieDataService } from '../../../shared/services/cookie-data/cookie-data.service';
import { CandidateDetailsService } from '../../services/candidate-detail/candidate-details.service';
import { globalVariables } from '../../constants/globals';
import { CommonFilesService } from '../../services/common/common-files.service';
import { Location } from '@angular/common';


declare var require: any;
var moment = require('moment');

@Component({
  selector: 'app-candidate-details',
  templateUrl: './candidate-details.component.html',
  styleUrls: ['../../../../assets/content/css/recruitment.css','../../../../assets/content/css/recruitmentChat.css']
})
export class CandidateDetailsComponent implements OnInit {
  //schedule form section variables
  round                : any;
  selectedRound        : any = [];
  roundSelected        : any;
  cancelObject         : any;
  initialVal           : any;
  showType             : boolean = false;
  interviewer          : any;
  selectedInterviewer  : any = [];
  interviewerSelected  : any;
  internalPeople       : any;
  externalPeople       : any;
  dateSelected         : any = [];
  minDate              : Date;

  startTime            : any = [];
  endTime              : any = [];

  venue                : any = [];

  locationList         : any;
  selectedLoc          : any = [];
  locSelected          : any;
  tab                 : any = {};
  candidateDetail     : any = {};
  selectedIndex       : number;
  index               : number = 2;
  arrow               : number = 1;
  address             : any = [];
  notes               : any = [];
  scheduleArray       : any = [];
  headerData          : any = [];
  StatItems           : any = [];
  selectedStat        : any = [];
  interviewInfoDetail : any = [];
  feedBackInfo        : any = [];
  statObj             : any = {};
  candidateId         : number;
  StatusId            : number;
  newID               : any;
  id                  : number = 0;
  comment             : string;
  commentErr          : boolean = false;
  statusErr           : boolean = false;
  enableAddress       : boolean = false;
  internal            : boolean = false;
  external            : boolean = false;
  submitted           : boolean = false;
  newScheduleStatus   : boolean = false;

  arrowShowAftersubmit: boolean = false;
  rightarrow          : boolean = false;
  toggle              : boolean = false;
  showTab             : boolean = false; 
  scrollLeft          : boolean = true;
  scrollEnd           : boolean = false;
  basicInfo           : boolean = true;
  interviewInfo       : boolean = false;
  updateInfo          : boolean = false;
  confirmBox          : boolean = false;
  cancelBox           : boolean = false;
  dropDown            : boolean 
  config = 'Are You Sure You Want To Change The Status?'
  public scrollbarOptions;   
 candidateStatus     : any 
 init : any 
  constructor(private notifications    : NotificationService,
          private loaderActionsService       : LoaderActionsService,
          private cookieService              : CookieService,
          private timezoneDetailsService     : TimezoneDetailsService,
          private malihuScrollbarService     : MalihuScrollbarService,
          private chRef                      : ChangeDetectorRef,
          private candidateDetails           : CandidateDetailsService,
          private commonFiles                : CommonFilesService,
          private activatedRoute             : ActivatedRoute,
          private router                     : Router,
          private location                   : Location
          ) {
            this.StatItems       = globalVariables.feedBackStatus;
            this.candidateStatus = globalVariables.CandidateStatus;
           }


  ngOnInit() {
    this.minDate = this.timezoneDetailsService.getCurrentDate();
    this.activatedRoute.params.subscribe(params =>
      this.candidateId = params.id);
    this.activatedRoute.queryParamMap.subscribe(params => {
      let req = params.get('req');
      this.newID = req
    })
    let self = this;
    this.scrollbarOptions = {
      axis: 'x', scrollInertia: 0, theme: 'dark', autoHideScrollbar: false, scrollButtons: { enable: true },
      callbacks: {
        onTotalScroll: function () {
          self.scrollEnd = true;
          self.chRef.detectChanges();
        },
        whileScrolling: function (this) {
          self.scrollLeft = false;
          self.scrollEnd = false;
          self.chRef.detectChanges();
        },
        onTotalScrollBack: function () {
          self.scrollLeft = true;
          self.chRef.detectChanges();
        }
      }
    }
    this.startTime[0] = this.timezoneDetailsService.getCurrentDate();
    this.endTime[0] = this.timezoneDetailsService.getCurrentDate();
    this.selectedRound = [1];
    this.selectedInterviewer = [1];
    this.selectedLoc = [1];
    this.dateSelected[0] = this.timezoneDetailsService.getCurrentDate();
    this.getBasicInfo();
  }

  /**
 * @ desc    : to get interview rounds from master data
 * @ author  : vinod 
 */
  setRound(event, index) {
    if (event.selected.length) {
      this.roundSelected = event.selected[0].id;
      this.scheduleArray[index]['interview_round_id'] = event.selected[0].id;
      this.scheduleArray[index]['interview_round_name']               = event.selected[0].name;
    }
  }

  /**
   * @ desc    : to get interviewer names from master data
   * @ author  : vinod 
   */
  setInterviewer(event, index) {
    if (event.selected.length) {
      this.interviewerSelected = event.selected[0].id;
      this.scheduleArray[index]['interviewer_id'] = event.selected[0].id;
    }
  }

  openWindow(url){
    window.open(url);
  }

  /**
   * @ desc    : date of scheduling
   * @ author  : vinod 
   */
  dateChange(date, index) {
    if (date) {
      this.dateSelected[index] = date;
      this.scheduleArray[index]['interview_date'] = this.formatForApi(date);
    }
  }

  /**
   * @ desc    : from time change event
   * @ author  : vinod 
   */
  changedFrom(time, event, index) {
    this.startTime[index] = time;
    this.scheduleArray[index]['start_time'] = time.toLocaleTimeString();
  }

  /**
   * @ desc    : to time change event
   * @ author  : vinod 
   */
  changedTo(time, event, index) {
    this.endTime[index] = time;
    this.scheduleArray[index]['end_time'] = time.toLocaleTimeString();
  }

  /**
   * @ desc    : venue change event
   * @ author  : vinod 
   */
  changeVenue(venue, index) {
    this.venue[index] = this.scheduleArray[index]['venue'];
  }
  /*
   *@author: Nilena Alexander
   *@desc  : to  get status fdrom dropdwn
   */
  getStatus(event) {
    if (event.selected.length > 0) {
      this.StatusId = event.selected[0].id
    }
  }
  /**
   * @ desc    : location change event
   * @ author  : vinod 
   */
  setLoc(locevent, index) {
    if (locevent.selected && locevent.selected.length && locevent.selected[0].status == true) {
      this.enableAddress = true;
    } else if (locevent) {
      this.enableAddress = false;
    } else {
      this.enableAddress = false;
    }
    if (locevent.selected && locevent.selected.length) {
      this.locSelected                         = (locevent.selected[0].id) ? locevent.selected[0].id : locevent.selected[0].name;
      this.scheduleArray[index]['location_id'] = this.locSelected;
      this.scheduleArray[index]["location_name"] = locevent.selected[0].name;
      this.scheduleArray[index]['address']     = locevent.selected[0].address;
      this.address[index]                      = locevent.selected[0].address;
    }
  }

  /**
   * @ desc    : address change event
   * @ author  : vinod 
   */
  changeAddress(event, index) {
    this.scheduleArray[index]['address'] = event;
    this.address[index] = event;
  }

  /**
   * @ desc    : notes change event
   * @ author  : vinod 
   */
  changeNotes(notes, index) {
    this.notes[index] = this.scheduleArray[index]['schedule_notes'];
  }

  /**
   * @ desc    : add new location event
   * @ author  : vinod 
   */
  showAddNew(newLoc,k) {
    if (newLoc.status) {
      this.enableAddress = true;
      this.locationList.push({address: '',id:'0',name: newLoc.value, status: '1',state: "0", tenant_id: "0" });
      this.scheduleArray[k].selectedLoc = [this.locationList.length - 1];
    } else {
      this.enableAddress = false;
    }
  }

  /**
 * @ desc    : submit schedule form
 * @ author  : vinod 
 */
  submitSchedule(index) {
    let isValid = this.checkFormValid(this.scheduleArray, this.id);
    if (!isValid) {
      this.loaderActionsService.display(true);
      this.newScheduleStatus = true;
      let obj = {
        "job_id": this.scheduleArray[index].job_id,
        "rc_candidate_id": this.scheduleArray[index].rc_candidate_id,
        "interview_round_id": this.scheduleArray[index].interview_round_id,
        "interviewer_id": this.scheduleArray[index].interviewer_id,
        "interview_date": this.formatForApi(this.scheduleArray[index].interview_date),
        "start_time": this.scheduleArray[index].start_time,
        "end_time": this.scheduleArray[index].end_time,
        "location_id": this.scheduleArray[index].location_id,
        "location_name":this.scheduleArray[index].location_name,
        "venue": this.scheduleArray[index].venue,
        "address": this.scheduleArray[index].address,
        "interviewer_type":this.scheduleArray[index].interviewer_type,
        "schedule_notes": this.scheduleArray[index].schedule_notes,
      };
      this.candidateDetails.addSchedule(obj,this.newID,this.candidateId,this.scheduleArray[index].id,response => {
        if (response.status == "OK") {
          this.getBasicInfo();
          this.getInteviewInfo()
          this.id = 0;
          this.scheduleArray[0].status = true;
          this.scheduleArray[0].valid = true;
          if (this.scheduleArray.length || !isValid) {
            this.showTab = true;
          }
          this.notifications.alertBoxValue("success", response.message);  
        }
        else {
          this.loaderActionsService.display(false);
          this.notifications.alertBoxValue("error", response.message);
        }
      })
    } else {
      this.newScheduleStatus = false;
    }
  }

  /**
 * @ desc    : tab click
 * @ author  : vinod 
 */
  selectTab(object, index) {
      this.loaderActionsService.display(true);
      this.id = index;
      for (var i = 0; i < this.scheduleArray.length; i++) {
        if (i == this.id) {
          this.scheduleArray[this.id].status = true;
        } else {
          this.scheduleArray[i].status = false;
        }
      }
      this.tab.selectedtab = index;
      this.loaderActionsService.display(false);
  }

  /**
 * @ desc    : check current form vali or not
 * @ author  : vinod 
 */
  checkFormValid(array, index) {
    this.submitted = false;
    let valid = false;
    if (array.length) {
      if (array[index].venue == "" || array[index].venue == null) {
        valid = true
        this.submitted = true;
      }
      if (array[index].address == "" || array[index].address == null) {
        valid = true
        this.submitted = true;
      }
      if (array[index].start_time == "" || array[index].start_time == null) {
        valid = true
        this.submitted = true;
      }
      if (array[index].end_time == "" || array[index].end_time == null) {
        valid = true
        this.submitted = true;
      }
      if (array[index].interviewer_type == "" || array[index].interviewer_type == null) {
        valid = true
        this.submitted = true;
      }
    }
    return valid;
  }

  /**
 * @ desc    : add new form
 * @ author  : vinod 
 */
  addNewInterview() {
    let isValid = this.checkFormValid(this.scheduleArray, this.id);
    if (!isValid) {
      if (this.scheduleArray.length < 6) {
        for (var i = 0; i < this.scheduleArray.length; i++) {
          this.scheduleArray[i].status = false;
        }
        this.selectedRound = [0];
        this.selectedInterviewer = [0];
        this.selectedLoc = [0];
        this.startTime[this.scheduleArray.length - 1] = this.timezoneDetailsService.getCurrentDate();
        this.endTime[this.scheduleArray.length - 1] = this.timezoneDetailsService.getCurrentDate();
        this.dateSelected[this.scheduleArray.length - 1] = this.timezoneDetailsService.getCurrentDate();
        this.venue[this.scheduleArray.length - 1] = "";
        this.address[this.scheduleArray.length - 1] = "";
        this.notes[this.scheduleArray.length - 1] = "";
        this.scheduleArray.push({
          "job_id": this.newID,
          "rc_candidate_id": this.candidateId,
          "interview_round_id": "",
          "interviewer_id": "",
          "interview_date": this.formatForApi(this.timezoneDetailsService.getCurrentDate()),
          "start_time": '',
          "end_time": '',
          "location_id": "",
          "location_name": '',
          "venue": "",
          "address": "",
          "interviewer_type": '',
          "schedule_notes": ""
        })
        this.newScheduleStatus = false;
        this.id = this.scheduleArray.length - 1;

      } else {
        this.notifications.alertBoxValue("warning", "maximum schedule exceed");
      }
    }
  }

  moveRight() {
    // this.arrow +=1;
    // this.headerData = [];
    // for(let i=3;i<this.scheduleArray.length;i++) {
    //   this.headerData.push(this.scheduleArray[i])
    // }
  }

  moveLeft() {
    // this.arrow -=1;
    // this.headerData = [];
    // for(let i=0;i<3;i++) {
    //   this.headerData.push(this.scheduleArray[i])
    // }
  }


  formatForApi(inputDate) {
    var date = new Date(inputDate);
    if (!isNaN(date.getTime())) {
      if ((Number(date.getMonth()) + 1) < 10) {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
      else {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
    }
  }

  /**
   * @ desc    : Method To get basic Info api
   * @ author  : Nilena  
   */
   getBasicInfo() {
    this.loaderActionsService.display(true);
    this.candidateDetails.showPepole(true, response => {
      if (response.status == "OK") {
        this.internalPeople = response.data;
            this.candidateDetails.getDetails(this.candidateId, this.newID, response => {
              if (response.status == "OK") {
                if (response.data) {
                 
                  this.candidateDetail = response.data.details;
                  if( this.candidateDetail.candidate_status_name==="InterviewScheduled"){
                    this.candidateDetail.candidate_status_name ="Interview Scheduled"
                  }
                  else if(this.candidateDetail.candidate_status_name==="InterviewCancelled"){
                    this.candidateDetail.candidate_status_name ="Interview Cancelled"
                  }
                  this.externalPeople  = response.masters.external_interviewer;
                  this.locationList    = response.masters.location;
                  this.round           = response.masters.interview_round;
                  this.candidateDetail.candidate_name = this.candidateDetail.first_name + " " + this.candidateDetail.last_name
                  this.interviewInfoDetail = response.data.interview_info.data;
                  this.feedBackInfo = response.data.feedback_info;
                  if (this.candidateDetail.drop_down == true) {
                    this.dropDown = true;
                    for (var i = 0; i < this.candidateStatus.length; i++) {
                      if (this.candidateDetail.candidate_status == this.candidateStatus[i].id) {
                        this.initialVal = this.candidateStatus[i].value;
                        break
                      } else {
                        this.initialVal = this.candidateDetail.candidate_status_name
                      }
                    }
                  } else {
                    this.dropDown = false;
                    this.initialVal = this.candidateDetail.candidate_status_name
                  }
                  if(this.interviewInfoDetail){
                    this.dateConversion();
                    this.utcConvert()
                  }
                

                  this.candidateDetails.editScheduleDetails(this.newID, this.candidateId, response => {
                    if (response.status == "OK" && response.data.length) {
                        this.scheduleArray = [];
                        for(let i = 0 ;i < response.data.length;i++){
                          if(response.data[i].schedule_status != 0){
                            this.scheduleArray.push(response.data[i]);
                          }
                        }
                        this.newScheduleStatus = true;
                        if(this.scheduleArray.length){
                          for (var i = 0; i < this.scheduleArray.length; i++) {
                            this.scheduleArray[i].valid = true;
                            this.scheduleArray[i].status = false;
                            for (var j = 0; j < this.round.length; j++) {
                              if (this.scheduleArray[i].interview_round_id == this.round[j].id) {
                                this.scheduleArray[i].selectedRound = [j];
                              }
                            }
                            this.startTime[i] = this.timezoneDetailsService.getLocalDate(this.scheduleArray[i].interview_date+" "+this.scheduleArray[i].start_time);
                            this.scheduleArray[i].interview_date = this.formatForApi(this.startTime[i]);
                            this.dateSelected.push(this.timezoneDetailsService.toLocal(this.scheduleArray[i].interview_date));
                            let scheduleStart = this.timezoneDetailsService.getTimeNow(this.scheduleArray[i].start_time.split(":")[0] + ':' + this.scheduleArray[i].start_time.split(":")[1]);
                            this.startTime[i].setHours(scheduleStart.split(":")[0]);
                            this.startTime[i].setMinutes(scheduleStart.split(":")[1]);
  
                            this.endTime[i] = this.timezoneDetailsService.getLocalDate(this.scheduleArray[i].interview_date+" "+this.scheduleArray[i].end_time);
                            let scheduleEnd = this.timezoneDetailsService.getTimeNow(this.scheduleArray[i].end_time.split(":")[0] + ':' + this.scheduleArray[i].end_time.split(":")[1]);
                            this.endTime[i].setHours(scheduleEnd.split(":")[0])
                            this.endTime[i].setMinutes(scheduleEnd.split(":")[1]);
  
                            this.venue.push(this.scheduleArray[i].venue);
                            this.notes.push(this.scheduleArray[i].schedule_notes);
                            this.startTime.push(this.scheduleArray[i].start_time);
                            this.endTime.push(this.scheduleArray[i].end_time);
                            if (this.scheduleArray[i].interviewer_type == 2) {
                              this.scheduleArray[i].showType    = true;
                              this.scheduleArray[i].interviewer = this.internalPeople;
                            }
                            else {
                              this.scheduleArray[i].showType = false;
                              this.scheduleArray[i].interviewer = this.externalPeople;
                            }
  
                            for (var k = 0; k < this.scheduleArray[i].interviewer.length; k++) {
                              if (this.scheduleArray[i].interviewer_id == this.scheduleArray[i].interviewer[k].id) {
                                this.scheduleArray[i].selectedInterviewer = [k];
                              }
                            }
                            for (var l = 0; l < this.locationList.length; l++) {
                              if (this.scheduleArray[i].location_id == this.locationList[l].id) {
                                this.scheduleArray[i].selectedLoc = [l];
                              }
                            }
                          }
                          this.scheduleArray[0].status = true;
                        }
                        else {
                          this.scheduleArray = [];
                          this.scheduleArray.push({
                            "job_id": this.newID,
                            "rc_candidate_id": this.candidateId,
                            "interview_round_id": "",
                            "interviewer_id": "",
                            "interview_date": this.formatForApi(this.timezoneDetailsService.getCurrentDate()),
                            "start_time": '',
                            "end_time": '',
                            "location_id": "",
                            "location_name":'',
                            "venue": "",
                            "address": "",
                            "interviewer_type":'',
                            "schedule_notes": ""
                          });
                          this.scheduleArray[0].status = true;
                          this.id = 0;
                        }
                        this.loaderActionsService.display(false);
                    }
                    else {
                      this.scheduleArray = [];
                      this.scheduleArray.push({
                        "job_id": this.newID,
                        "rc_candidate_id": this.candidateId,
                        "interview_round_id": "",
                        "interviewer_id": "",
                        "interview_date": this.formatForApi(this.timezoneDetailsService.getCurrentDate()),
                        "start_time": '',
                        "end_time": '',
                        "location_id": "",
                        "location_name":'',
                        "venue": "",
                        "address": "",
                        "interviewer_type":'',
                        "schedule_notes": ""
                      });
                      this.scheduleArray[0].status = true;
                      this.id = 0;
                      this.loaderActionsService.display(false);
                    }
                  })
                } else {
                  this.loaderActionsService.display(false)
                  this.candidateDetail = []
                  this.feedBackInfo = []
                  this.interviewInfoDetail = []
                }
              }
            })
      }
    });
  }

    /* @ desc    : date  conversionbasedon utcstarttime
   * @ author  : Nilena Alexander
   */
  dateConversion() {
    for (let i = 0; i < this.interviewInfoDetail.length; i++) {
      let tempFirst = this.timezoneDetailsService.getLocalDate(this.interviewInfoDetail[i].interview_date + " " + this.interviewInfoDetail[i].start_time);
      this.interviewInfoDetail[i].interview_date = new Date(tempFirst).getFullYear() + "-" + (Number(new Date(tempFirst).getMonth()) + 1) + "-" + new Date(tempFirst).getDate();
    }
  }
  /**method forutc conversion
       * @ author  : Nilena Alexander
       */

  utcConvert() {
    for (let i = 0; i < this.interviewInfoDetail.length; i++) {
        let startTime = this.interviewInfoDetail[i].start_time;
        let endTime = this.interviewInfoDetail[i].end_time;
        let sStart = startTime.split(":");
        let eStart = endTime.split(":");
        let time1 = this.timezoneDetailsService.getTimeNow(sStart[0] + ":" + sStart[1]);
        let time2 = this.timezoneDetailsService.getTimeNow(eStart[0] + ":" + eStart[1]);
        let time3 = this.timezoneDetailsService.timeTo12Convert(time1);
        let time4 = this.timezoneDetailsService.timeTo12Convert(time2);
        this.interviewInfoDetail[i].interview_time = time3 + "-" + time4;      
    }
  }
  /**
   * @ desc    : to change status
   * @ author  : Nilena  
   */
  setStatus(status, i) {
    this.selectedIndex = i;
    this.confirmBox = true
    this.statObj = {
      "candidate_status": status.id
    }
    return this.statObj
  }

  /**
   * @ desc    : to update status
   * @ author  : Nilena  
   */
  getPopupConfirm(event) {
    let status;
    this.confirmBox = false;
    if (event == true) {
      this.loaderActionsService.display(true);
      this.candidateDetails.statusUpdate(this.candidateId, this.statObj, response => {
        if (response.status == "OK") {
          this.loaderActionsService.display(false);

          this.notifications.alertBoxValue("success", response.message);
          this.getBasicInfo();
        }
        else {
          this.notifications.alertBoxValue("error", response.message);
          this.getBasicInfo();
        }
      })
    }
  }

  close(data, index,value) {
    if (this.scheduleArray.length) {
      if (index == 0) {
        if (this.scheduleArray.length > 1) {
          this.scheduleArray[index + 1].stat = true;
          this.selectTab(this.scheduleArray[index + 1], index + 1);
        }
        else{
          this.scheduleArray.push({
            "job_id": this.newID,
            "rc_candidate_id": this.candidateId,
            "interview_round_id": "",
            "interviewer_id": "",
            "interview_date":'',
            "start_time": '',
            "end_time": '',
            "location_id": "",
            "location_name":'',
            "venue": "",
            "address": "",
            "interviewer_type":'',
            "schedule_notes": "",
            "interview_round_name":'Round'
          });
          this.address = [];
        }
      } 
      else{
        this.scheduleArray[index - 1].stat = true;
        this.selectTab(this.scheduleArray[index - 1], index - 1);
      }
      this.loaderActionsService.display(true);
      this.candidateDetails.deleteSchedule(this.scheduleArray[index].id,value,response => {
        if (response.status == "OK") {
          this.notifications.alertBoxValue("success", response.message); 
          this.scheduleArray.splice(index, 1);
        }
        else {
          this.notifications.alertBoxValue("error", response.message);
          this.loaderActionsService.display(false);
        }
      })
      this.getBasicInfo();
      this.id = 0;
      this.scheduleArray[0].status = true;
      this.scheduleArray[0].valid = true;
      if (this.scheduleArray.length) {
        this.showTab = true;
      }
    }
  }

  /**
     * @ desc    : to go back
     * @ author  : Nilena  
     */
  backtoList() {
    this.router.navigate(['modules/recruitment/candidate-list'])
  }

  /**
 * @ desc    : to eduit
 * @ author  : Nilena  
 */
  edit() {
    this.router.navigate(['modules/recruitment/edit-candidate/', +this.candidateId])
  }
  /**
 * @ desc    :for feebbacktab status click 
 * @ author  : Nilena  
 */
  togglefeedBack(id){
    for (let i = 0; i < this.feedBackInfo.length; i++) {
      if (this.feedBackInfo[i].interview_round_id == id) {
        this.feedBackInfo[i].status = true;
      } else {
        this.feedBackInfo[i].status = false;
      }
    }
  }
    /**
  * @ desc    : to active  tab
  * @ author  : Nilena  
  */
 getFeedBackInfo() {
  for (let i = 0; i < this.feedBackInfo.length; i++) {
    if (i != 0)
      this.feedBackInfo[i].status = false;
    else
      this.feedBackInfo[i].status = true;
  }
}
 /**
 * @ desc    :for interviewtab status click 
 * @ author  : Nilena  
 */
  toggleManage(id) {
    
    for (let i = 0; i < this.interviewInfoDetail.length; i++) {
      if (this.interviewInfoDetail[i].id == id) {
        this.interviewInfoDetail[i].status = true;
      } else {
        this.interviewInfoDetail[i].status = false;
      }
    }
  }

  /**
  * @ desc    : to active  tab
  * @ author  : Nilena  
  */
  getInteviewInfo() {
    for (let i = 0; i < this.interviewInfoDetail.length; i++) {
      if (i != 0)
        this.interviewInfoDetail[i].status = false;
      else
        this.interviewInfoDetail[i].status = true;
    }
  }

  showPeople(index,value){
    if(value){
      this.scheduleArray[index].interviewer = this.internalPeople;
    }
    else{
      this.scheduleArray[index].interviewer = this.externalPeople;
    }
  }

  getCancelConfirm(event) {
    this.cancelBox = false;
    if (event.status == true) {
      this.close(this.cancelObject.data,this.cancelObject.i,event.value);
    }
  }
}

