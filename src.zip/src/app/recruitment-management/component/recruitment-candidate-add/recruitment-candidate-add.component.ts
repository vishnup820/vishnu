import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import {AddCandidateService} from  '../../services/add-candidate/add-candidate.service';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import {CommonFilesService} from '../../services/common/common-files.service';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';

@Component({
  selector: 'app-recruitment-candidate-add',
  templateUrl: './recruitment-candidate-add.component.html',
  styleUrls: ['../../../../assets/content/css/recruitment.css','../../../../assets/content/css/recruitmentChat.css']
})
export class RecruitmentCandidateAddComponent implements OnInit {
  selectedTitleIndex                 : any;
  selectedLocationIndex              : any;
  selectedStateIndex                 : any;
  selectedEducationalIndex           : any;
  selectedSourceIndex                : any;
  selectedOrganizationIndex          : any ;
  selectedOrganization               : any;
  enableAddress                      : boolean;
  addCandidateForm 		               : FormGroup;
  jobTitle 	                         : FormControl;
	firstName 			                   : FormControl;
	lastName 				 	                 : FormControl;
	emailId			                       : FormControl;
	mobileNumber 			                 : FormControl;
	state 	                           : FormControl;
	location 				                   : FormControl;
	totalexperience 			             : FormControl;
	relExperience 			               : FormControl;
	educationQualification 					   : FormControl;
	qualificationNote 				         : FormControl;
	currentOrganisation 				       : FormControl;
	currentPosition 				           : FormControl;
	currentCtc 	                       : FormControl;
	noticePeriod 					             : FormControl;
	resume 					                   : FormControl;
	resource 			                     : FormControl;
  resourceName 		                   : FormControl;
  resourceNote 		                   : FormControl;
  jobArray                           :any=[];
  qualificationArray                 :any=[];
  jobChecked                         :any=[];
  resourceData                       :any=[];
  Organizations                      :any=[];
  locationData                       :any=[];
  stateData                          :any=[];
  dummydata                          :any={};
  jobStatus                          :any;
  selectSourceStatus                 :any;
  eduNote                            :boolean=false;
  refNote                            :boolean=false;
  submitted                          :boolean=false;
  type                               :any;
  fileName                           :any;
  fileData                           :any;
  editCandidateId                    :any;
  requirementId                      :any;
  newOrganisationVal                 :any;
  config              	             :any;
  addId                              :any;
  adminRole                          :any;
  editStatus                         :boolean=false;
  isReference                        :boolean=false;
  confirmBox    			               :boolean = false;
  requirementPrivilege               :boolean = false;
  requirementPrivilege1              :boolean = false;
  requirementPrivilege2               :boolean = false;
  disableButton                      :boolean;
  queryobject                        : any        = {};

  constructor(private AddCandidateService     : AddCandidateService,
              private route				            : ActivatedRoute,
		          private cookieService		        : CookieService,
              private notificationService   	: NotificationService,
              private loaderActionsService    : LoaderActionsService,
	          	private router			          	: Router,
              private timeZone                : TimezoneDetailsService,
              private AclVerificationService  : AclVerificationService,
              private CommonFilesService      : CommonFilesService) { }

  ngOnInit() {
    this.loaderActionsService.display(true);

  
    this.AddCandidateService.getStateData(res=>{
      if (res.status == "OK") {
        this.stateData=res.data;
    }
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.editStatus = true;
        this.editCandidateId = params['id'];
        this.getCandidate(this.editCandidateId);
      }
    });
  });
 

    this.route.queryParams.subscribe(params => {
      this.addId = params['id'];
  });
    
    this.CandidateFormControls();
    this.createAddCandidateForm();
    this.resourceData=[{id:1,name:"Naukari"},{id:2,name:"Job Portal"},{id:3,name:"Reference"},{id:4,name:"Consultancy"}];


     
    this.requirementPrivilege = this.AclVerificationService.checkAclDummy('candidate-register');
    this.requirementPrivilege1 = this.AclVerificationService.checkAclDummy('schedule-interview');
    this.requirementPrivilege2 = this.AclVerificationService.checkAclDummy('interviewer');
    this.adminRole = this.AclVerificationService.checkAclDummy('allemployee-list');
    if( this.requirementPrivilege &&  this.requirementPrivilege1 &&  this.requirementPrivilege2 && !this.adminRole){
      let val="jobOpenings";
      this.queryobject['stat']=val;
    }

      
    this.AddCandidateService.getRecruitmentMasterData(res=>{
        // this.loaderActionsService.display(false);
        if (res.status == "OK") {
          this.qualificationArray=res.data['qualification'];
          this.Organizations=res.data['organization'];
          this.locationData=res.data.location;
        }
      })

      this.AddCandidateService.getRequirementData( this.queryobject, res=>{
        // this.loaderActionsService.display(false);
        if (res.status == "OK") {
          this.jobArray=res.data;
          if(this.jobArray.length!=0){
            for(let i=0;i<this.jobArray.length; i++){
              this.jobArray[i].job_title=this.jobArray[i].job_title+'   '+'('+this.jobArray[i].job_id + ')'
            }
          }
         if( this.addId ){ 
            for(var i=0;i<this.jobArray.length;i++){
              if(this.jobArray[i].id == this.addId){
                this.jobChecked=[i]
              }
            }
          }
        }
        setTimeout(() => {
          this.loaderActionsService.display(false);
        }, 1000);
    });
  }

  getCandidate(id) {
    // this.loaderActionsService.display(true);
    this.AddCandidateService.getCandidateData(id, res => {
      this.dummydata = res.data['details'];
      let masterData = res.masters;
      if (this.editStatus) {
        this.requirementId = this.dummydata.req_id;

        if (this.dummydata.state) {
          this.selectedStateIndex = []
          let index = this.CommonFilesService.matchingIndex(this.stateData, this.dummydata.state, "id");
          this.selectedStateIndex.push(index)
        }
        if (this.dummydata.req_id && this.jobArray) {
           for (var i = 0; i < this.jobArray.length; i++) {
            if (this.jobArray[i].id == this.dummydata.req_id) {
              this.jobChecked = [i]
            }
          }
        }
        if (this.dummydata.organisation_id ) {
          for (let i = 0; i < masterData.organization.length; i++) {
            if (this.dummydata.organisation_id == masterData.organization[i].id) {
              this.selectedOrganizationIndex = [i];
            }
          }
          this.newOrganisationVal = null;
        }
        if (this.dummydata.source) {
          for (let i = 0; i < this.resourceData.length; i++) {
            if (this.dummydata.source == this.resourceData[i].name) {
              this.selectedSourceIndex = [i];
            } else {
              this.resourceData.push({ id: 0, "name": this.dummydata.source });
              for (let i = 0; i < this.resourceData.length; i++) {
                if (this.resourceData[i].name == this.dummydata.source) {
                  this.selectedSourceIndex = [i]
                }
              }
            }
          }
          this.selectedSourceIndex = this.CommonFilesService.matchingIndex(this.resourceData, this.dummydata.source, "name");
          if (this.dummydata.source == 'Reference') {
            this.isReference = true;
          }
        }
        if (this.dummydata.qualification_id) {
          this.selectedEducationalIndex = this.CommonFilesService.matchingIndex(masterData.qualification, this.dummydata.qualification_id, "id");
        }
         if (this.dummydata && this.dummydata.ref_notes.trim().length) {
          this.refNote = true;
        }
        if (this.dummydata && this.dummydata.qualification_note.trim().length) {
          this.eduNote = true;
        }
        if (this.dummydata.candidate_file) {
          this.fileName = this.getFileName(this.dummydata.candidate_file);
          this.fileData = null;
        }
      }

      this.addCandidateForm.patchValue({
        //  jobTitle: this.dummydata.jobTitle,
        firstName: this.dummydata.first_name,
        lastName: this.dummydata.last_name,
        emailId: this.dummydata.email_id,
        mobileNumber: this.dummydata.mobile,
        state: this.dummydata.state,
        location: this.dummydata.location,
        totalexperience: this.dummydata.total_experience,
        relExperience: this.dummydata.relevant_experience,
        educationQualification: this.dummydata.qualification_id,
        qualificationNote: this.dummydata.qualification_note,
        currentOrganisation: this.dummydata.organisation_id,
        currentPosition: this.dummydata.current_postion,
        currentCtc: this.dummydata.current_ctc,
        noticePeriod: this.dummydata.notice_period,
        //  resume: this.dummydata.upload_resume,
        resource: this.dummydata.source,
        resourceName: this.dummydata.ref_user_name,
        resourceNote: this.dummydata.ref_notes
      });

      // setTimeout(() => {
      //   this.loaderActionsService.display(false);
      // }, 1000);
    })
  }


  	/*
	 * @desc : creating form  for add training
	 * @auth : Ashiq
	 */
  createAddCandidateForm() {
    this.addCandidateForm = new FormGroup({
      jobTitle: this.jobTitle,
      firstName: this.firstName,
      lastName: this.lastName,
      emailId: this.emailId,
      mobileNumber: this.mobileNumber,
      state: this.state,
      location: this.location,
      totalexperience: this.totalexperience,
      relExperience: this.relExperience,
      educationQualification: this.educationQualification,
      qualificationNote: this.qualificationNote,
      currentOrganisation: this.currentOrganisation,
      currentPosition: this.currentPosition,
      currentCtc: this.currentCtc,
      noticePeriod: this.noticePeriod,
      resume: this.resume,
      resource: this.resource,
      resourceName: this.resourceName,
      resourceNote: this.resourceNote
    })
  }

  /*
	* @desc : creating form control  for add training
	* @auth : Ashiq
	*/
  CandidateFormControls() {
    let emailPattern    = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$";
    this.jobTitle = new FormControl('',[Validators.required]);
    this.firstName = new FormControl('', [Validators.required ,this.noWhitespaceValidator]);
    this.lastName = new FormControl('', [Validators.required,this.noWhitespaceValidator]);
  this.emailId = new FormControl('', [Validators.required,this.noWhitespaceValidator, Validators.pattern(emailPattern)
  ]);
    this.mobileNumber = new FormControl('', [Validators.required,this.noWhitespaceValidator]);
    this.state = new FormControl('');
    this.location = new FormControl('', []);
    this.totalexperience = new FormControl('', [Validators.required,this.noWhitespaceValidator]);
    this.relExperience = new FormControl('', [Validators.required,this.noWhitespaceValidator]);
    this.educationQualification = new FormControl('');
    this.qualificationNote = new FormControl('');
    this.currentOrganisation = new FormControl('');
    this.currentPosition = new FormControl('');
    this.currentCtc = new FormControl('', []);
    this.noticePeriod = new FormControl('', [Validators.required]);
    this.resume = new FormControl('', []);
    this.resource = new FormControl('', [Validators.required]);
    this.resourceName = new FormControl('', []);
    this.resourceNote = new FormControl('', []);
  }



  addNewCandidate() {
    this.disableButton = true;
    let uploadValidate;
    if (this.fileName == undefined || this.fileName == '') {
      uploadValidate = true;
      setTimeout(() => {
        this.notificationService.alertBoxValue("error", "Please Upload Candidate Resume");
      }, 500);
    } else {
      uploadValidate = false
    }
    if (this.addCandidateForm.valid && !uploadValidate) {
      this.submitted = false;
      if (!this.isReference) {
        this.addCandidateForm.controls['resourceName'].setValue('');
        this.addCandidateForm.controls['resourceNote'].setValue('');
      }
      let addCandidateObj = {
        "req_id": this.requirementId,

        "job_title_id": this.jobTitle.value,

        "first_name": this.firstName.value,

        "last_name": this.lastName.value,

        "email_id": this.emailId.value,

        "mobile": this.mobileNumber.value,

        "state": this.state.value,

        "location": this.location.value,

        "total_experience": this.totalexperience.value,

        "relevant_experience": this.relExperience.value,

        "current_ctc": this.currentCtc.value,

        "notice_period": this.noticePeriod.value,

        "qualification_id": this.educationQualification.value,

        "qualification_note": this.qualificationNote.value,

        "organisation_id": this.currentOrganisation.value,

        "current_postion": this.currentPosition.value,

        "source": this.resource.value,

        "ref_user_name": this.resourceName.value,

        "ref_notes": this.resourceNote.value,

        "new_organization": this.newOrganisationVal ? this.newOrganisationVal : '',

        "upload_resume": (this.fileData) ? this.fileData : null,

        "candidate_file": (this.fileName) ? this.fileName : null

      }
      if (!this.editStatus) {
        this.loaderActionsService.display(true);
        this.AddCandidateService.addCandidateApi(addCandidateObj, response => {
          if (response.status == "OK") {
            this.router.navigate(['modules/recruitment/candidate-list'])
            // this.router.navigateByUrl("/modules/training/training-list");
            this.loaderActionsService.display(false);
            setTimeout(() => {
              this.notificationService.alertBoxValue("success", response.message);
            }, 500);
          }
          if (response.status == "FAIL" && response.message.candidate_file) {
            this.loaderActionsService.display(false);
            this.disableButton = false;
            setTimeout(() => {
              this.notificationService.alertBoxValue("error", response.message.candidate_file);
            }, 500);
          }
          else {
            this.loaderActionsService.display(false);
            setTimeout(() => {
              this.disableButton = false;
            }, 3000);
            this.notificationService.alertBoxValue("error", response.message);
          }
        })
      }
      if (this.editStatus) {
        this.AddCandidateService.updateCandidateApi(this.editCandidateId, addCandidateObj, response => {
          if (response.status == "OK") {
            this.router.navigate(['modules/recruitment/candidate-list'])
            // this.router.navigateByUrl("/modules/training/training-list");
            this.loaderActionsService.display(false);
            setTimeout(() => {
              this.notificationService.alertBoxValue("success", response.message);
            }, 500);
          }
          else {
            this.loaderActionsService.display(false);
            setTimeout(() => {
              this.disableButton = false;
            }, 3000);
            this.notificationService.alertBoxValue("error", response.message);
          }
        })
      }
    } else {
      this.submitted = true;
      setTimeout(() => {
        this.disableButton = false;
      }, 3000);
      if (this.jobStatus.selected.length == 0 || this.firstName.invalid || this.lastName.invalid || this.emailId.invalid || this.mobileNumber.invalid) {
        document.documentElement.scrollTop = 0;
      } else if (this.totalexperience.invalid || this.relExperience.invalid) {
        document.documentElement.scrollTop = 60;
      }
    }
  }
 
  newSource(event) {
    if (event.status) {
      this.resourceData.push({ id: null, name: event.value });
      this.selectedSourceIndex = [this.resourceData.length - 1];
    }
  }

  newOrganization(event) {
    if (event.status) {
      this.Organizations.push({ id: null, name: event.value });
      this.selectedOrganizationIndex = [this.Organizations.length - 1];
    }
  }

  selectJobTitle(events) {
    if (events.selected.length > 0) {
      this.requirementId=events.selected[0].id;
      this.addCandidateForm.patchValue({
        jobTitle: events.selected[0].id
      })
    }
  }

  selectState(events) {
    if (events.selected.length > 0) {
      this.addCandidateForm.patchValue({
        state: events.selected[0].id
      })
    }
  }

  selectEducational(events){
    if (events.selected.length > 0) {
      this.addCandidateForm.patchValue({
        educationQualification: events.selected[0].id
      })
    }
  }

  selectSource(events){
    if (events.selected.length > 0) {
      this.addCandidateForm.patchValue({
        resource: events.selected[0].name
      })
      if(events.selected[0].name=="Reference"){
        this.isReference=true;
      }else{
        this.isReference=false;
      }
    }
  }

  selectOrganization(events) {
    if (events.selected.length > 0) {
      if (events.selected[0].id == null) {
        this.newOrganisationVal = events.selected[0].name;
        this.addCandidateForm.patchValue({
          currentOrganisation: null
        })
      } else {
        // this.newOrganisationVal = events.selected[0].name;
        this.addCandidateForm.patchValue({
          currentOrganisation: events.selected[0].id
        })
      }
    }
  }

    /*
	* @desc : component for validate  white space
	* @auth : ASHIQ
    */
	noWhitespaceValidator(control: FormControl) {
		let isWhitespace = (control.value || '').trim().length === 0;
		let isValid = !isWhitespace;
		return isValid ? null : { 'whitespace': true }
	}



  /*
	* @desc : component for validate space
	* @auth : dipin
  */
	changeListener($event): void {
    this.readThis($event.target);
    }
  
      /*
	* @desc : component for validate space
	* @auth : dipin
    */
  readThis(inputValue: any): void {
    var file: File = inputValue.files[0];
    if (file != undefined) {
      this.type = inputValue.files[0].name.split('.').pop();
      if (this.type == "pdf") {
        var myReader: FileReader = new FileReader();
        this.fileName = file.name;
        myReader.onloadend = (e) => {
          this.fileData = myReader.result;
        }
        myReader.readAsDataURL(file);
      } else {
        setTimeout(() => {
          this.notificationService.alertBoxValue("error", "Only PDF file supported of max size limit 2MB ");
        }, 500);
      }
    }
    else {
      this.fileData = undefined;
      this.fileName = "";
    }
  }
  
  getFileName(url){
    let urlArray=url.split('/');
    return urlArray[urlArray.length-1]
  }

  backToList(){
    this.confirmBox = true;
		this.config = "Changes made will not be saved.Do you want to proceed? "
  }

  cancel() {
    window.history.back();
	}

}
