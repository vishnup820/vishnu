import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecruitmentCandidateAddComponent } from './recruitment-candidate-add.component';

describe('RecruitmentCandidateAddComponent', () => {
  let component: RecruitmentCandidateAddComponent;
  let fixture: ComponentFixture<RecruitmentCandidateAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecruitmentCandidateAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecruitmentCandidateAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
