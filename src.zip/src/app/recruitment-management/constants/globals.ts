export let globalVariables: any = {
    feedBackStatus  : [{ id:2, value:"Shortlisted"} ,{ id:3, value:"Rejected"} ,{ id:4, value:"On hold"}],
    CandidateStatus : [{ id:6, value:"Selected"} ,{ id:8, value:"Joined"} ,{ id:9, value:"Offered"},{id:10,value:"Withdrawn"}]
};

