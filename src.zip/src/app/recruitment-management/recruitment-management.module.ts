import { NgModule,ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { ClickOutsideModule } from 'ng4-click-outside';
import { BsDatepickerModule,BsDatepickerConfig} from 'ngx-bootstrap/datepicker';
import { GlobalErrorHandlerService } from '../global-error-handler.service';
import { FilterComponent } from './filter/filter/filter.component';
import { AuthGuardService } from '../shared/services/auth-guard/auth-guard.service';
import { RoleGuardService } from '../shared/services/role-guard/role-guard.service';
import { RecruitmentDetailsComponent } from './component/recruitment-details/recruitment-details.component';
import { RequirementListComponent } from './component/requirement-list/requirement-list.component';
import { RequirementAddComponent } from './component/requirement-add/requirement-add.component';
import { CandidateDetailsComponent } from './component/candidate-details/candidate-details.component';
import { RecruitmentCandidateListComponent } from './component/recruitment-candidate-list/recruitment-candidate-list.component';
import { RecruitmentCandidateAddComponent } from './component/recruitment-candidate-add/recruitment-candidate-add.component';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { FeedbackUpdateComponent } from './component/feedback-update/feedback-update.component';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { JobtittleComponent } from './component/masters/jobtittle/jobtittle.component';
import { EmploymentTypeComponent } from './component/masters/employment-type/employment-type.component';
import { InterviewRoundComponent } from './component/masters/interview-round/interview-round.component';
import { IndustryComponent } from './component/masters/industry/industry.component';
import { LocationComponent } from './component/masters/location/location.component';
import { SkillSetComponent } from './component/masters/skill-set/skill-set.component';
import { ExternalInterviewerComponent } from './component/masters/external-interviewer/external-interviewer.component';
import { RecruitmentTeamComponent } from './component/masters/recruitment-team/recruitment-team.component';
import { WorkExperienceComponent } from './component/masters/work-experience/work-experience.component';
import { QualificationComponent } from './component/masters/qualification/qualification.component';
import { OrganizationComponent } from './component/masters/organization/organization.component';
import { InterviewListComponent } from './component/interview-list/interview-list.component';

@NgModule({
  declarations: [RecruitmentDetailsComponent,
    RequirementListComponent,
    RequirementAddComponent,
    CandidateDetailsComponent,
    FilterComponent,
    RecruitmentCandidateListComponent,
    RecruitmentCandidateAddComponent,
    FeedbackUpdateComponent,
    JobtittleComponent,
    EmploymentTypeComponent,
    InterviewRoundComponent,
    IndustryComponent,
    LocationComponent,
    SkillSetComponent,
    ExternalInterviewerComponent,
    RecruitmentTeamComponent,
    WorkExperienceComponent,
    QualificationComponent,
    OrganizationComponent,
    InterviewListComponent],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    ClickOutsideModule,
    CKEditorModule,
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot(),
    RouterModule.forChild([
      {
        path        : 'details/:id',
		    component   : RecruitmentDetailsComponent,
        // canActivate : [RoleGuardService],
      },
      {
        path        : 'requirement-list',
		    component   : RequirementListComponent,
        // canActivate : [RoleGuardService],
      },
      {
        path        : 'requirement-approval',
		    component   : RequirementListComponent,
        // canActivate : [RoleGuardService],
      },
      {
        path        : 'requirement-openings',
		    component   : RequirementListComponent,
        // canActivate : [RoleGuardService],
      },
      {
        path        : 'requirement-add',
		    component   : RequirementAddComponent,
        // canActivate : [RoleGuardService],
      },
      {
        path        : 'candidate-details/:id',
        component   : CandidateDetailsComponent,
        // canActivate : [RoleGuardService],
      },
      {
        path        : 'candidate-list',
        component   : RecruitmentCandidateListComponent,
        // canActivate : [RoleGuardService],
      },
      {
        path        : 'add-candidate',
        component   : RecruitmentCandidateAddComponent,
        // canActivate : [RoleGuardService],
      },
      {
        path        : 'edit-candidate/:id',
        component   : RecruitmentCandidateAddComponent,
        // canActivate : [RoleGuardService],
      },
      {
        path        : 'feedback/:id',
        component   : FeedbackUpdateComponent,
        // canActivate : [RoleGuardService],
      },
      {
        path        : 'requirement-edit/:id',
        component   : RequirementAddComponent,
        // canActivate : [RoleGuardService],
      },
      {
        path        : 'master/jobtittle',
        component   : JobtittleComponent,
        canActivate : [RoleGuardService]
      },
      {
        path        : 'master/employee-type',
        component   : EmploymentTypeComponent,
        canActivate : [RoleGuardService]
      },
      {
        path        : 'master/interview-round',
        component   : InterviewRoundComponent,
        canActivate : [RoleGuardService],
      },
      {
        path        : 'master/location',
        component   : LocationComponent,
        canActivate : [RoleGuardService],
      },
      {
        path        : 'master/industry',
        component   :  IndustryComponent,
        canActivate : [RoleGuardService],
      },
      {
        path        : 'master/skill-set',
        component   : SkillSetComponent,
        canActivate : [RoleGuardService],
      },
      {
        path        : 'master/external-interviewer',
        component   : ExternalInterviewerComponent,
        canActivate : [RoleGuardService],
      },
      {
        path        : 'master/recruitment-team',
        component   : RecruitmentTeamComponent,
        canActivate : [RoleGuardService],
      },
      {
        path        : 'master/work-experience',
        component   : WorkExperienceComponent,
        canActivate : [RoleGuardService],
      },
      {
        path        : 'master/qualification',
        component   : QualificationComponent,
        canActivate : [RoleGuardService],
      },
      {
        path        : 'master/organization',
        component   : OrganizationComponent,
        canActivate : [RoleGuardService],
      },
      {
        path        : 'interview-list',
        component   : InterviewListComponent,
        // canActivate : [RoleGuardService],
      },
      {
        path       : '',
        redirectTo : '',
        canActivate : [RoleGuardService],
        pathMatch  : 'full'
      }
    ])
  ],
  exports:[
    FilterComponent
  ],
  providers:[
    {
      provide  : ErrorHandler,
      useClass : GlobalErrorHandlerService,
     }
  ]
})
export class RecruitmentManagementModule { }
