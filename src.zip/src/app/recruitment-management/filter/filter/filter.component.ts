import {
  Component,
  OnInit,
  OnChanges,
  SimpleChanges,
  Output,
  Input,
  EventEmitter ,
  Renderer,
  OnDestroy,
  ChangeDetectorRef
} from '@angular/core';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { MainFilterService } from '../../services/filter/main-filter.service';
import { ConstantServicesService } from '../../../shared/services/constant/constant-services.service';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';

@Component({
  selector: 'requirement-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {
  @Input() relStatus             : boolean;
  @Input() jobStatus             : boolean;
  @Input() workStatus            : boolean;
  @Input() requirementStatus     : boolean;
  @Input() filterStatus          : boolean;
  @Input() statusList            : any;
  @Input() relExpList            : any;
  @Input() titleChange           : boolean;
  @Input() interviewDate         : boolean;
  @Input() date                  : boolean = false;
  @Input() locationStatus        : boolean = false;
  @Output() selectedData  			 = new EventEmitter();
  @Output() openWindowStatus   	 = new EventEmitter();
  @Output() filterData    			 = new EventEmitter();
  
  filterCancel                         : boolean = false;
  work                           : any;
  workChecked                    : any = [];
  JobChecked                     : any = [];
  relExpChecked                  : any = [];
  workSelected                   : any;
  jobSelected                    : any;
  relExpSelected                 : any;

  filterStatusCheck              : boolean = false;
  change                         : boolean = false;
  emitData                       : boolean = false;
  loaderShow                     : boolean = false;
  listenFunc                     : any;
  startDate                      : any;

  selectedStat                   : any = [];
  requirement                    : any;
  jobData                        : any;
  relExperienceData              : any;
  requirementSelected            : any;
 
  requirementChecked             : any = [];
  dateValue                      : any;
  statusLeave                    : any;
  status                         : any;
  statusSelected                 : any;
  statusChecked                  : any = [];
  bsValue                        : any;
  statusLeaveSelect              : any;
  locations                      : any;
  locationsSelected              : any;
  locationsChecked               : any = [];
  subscription                   : any;
  userData                	     : any;
	minDate                      : any;
  titlelabel                     : boolean;
  interviewDateLabel             : boolean;
  buttonStatus                   : boolean = false;
  maxdate                        : any

  constructor(private renderer : Renderer,
  	private changeRef          : ChangeDetectorRef,
    private timeZone           : TimezoneDetailsService,
    private dataService        : MainFilterService,
    private constantServicesService :ConstantServicesService,
    private cookieService	  : CookieService,
    private router :Router) { }

  ngOnInit() {
    this.filterCancel = true;
    this.buttonStatus = false;
    this.startDate = this.timeZone.getCurrentDate();
    this.emitData = true;
    if(this.titleChange==true){
       this.titlelabel=true;  
    }else{
      this.titlelabel=false;  
    }
    if(this. interviewDate==true){
      this.interviewDateLabel=true;  
   }else{
     this.interviewDateLabel=false;  
   }

   if (this.cookieService.get("user-data")) {
    this.userData = JSON.parse(this.cookieService.get("user-data"));
    this.maxdate  = this.timeZone.toLocal(this.userData.end_date);
  }
    this.minDate=	this.timeZone.toLocal(this.userData.financialMin_date)
    this.dataService.getRequirementData(response => { 
      if (response.status == "OK") {
        this.jobData = response.data;
        if(this.jobData.length){
          for(let i=0;i<this.jobData.length;i++){
            this.jobData[i].job_title=this.jobData[i].job_title+" "+ "("+this.jobData[i].job_id+")";
          }
        }
        this.relExperienceData = this.relExpList
        this.filterCancel = false;
        this.buttonStatus = true;
      }
    })

    this.dataService.getMasterData(response => {
      if (response.status == "OK") {
        this.work = response.data.work_experience;
        this.locations = response.data.location;
        this.requirement = this.statusList;
        this.filterCancel = false;
        this.buttonStatus = true;
      }
    })

    this.constantServicesService.dateValue.subscribe((val: any) => {
      if (this.router.url == '/modules/recruitment/interview-list') {
        let status = localStorage.getItem('dropDownStatus');
        if (status == 'otherRecord') {
          this.dateValue = val.val
        }
        else {
          this.dateValue = null
        }
      }
    })
  }


  ngOnDestroy() {
    // this.dateValue=null
  }

  relExpEvent(event) {
    if (event.selectedIndex.length != 0) {
      this.relExpChecked = event.selectedIndex;
    }
    else {
      this.relExpChecked = [];
    }
    this.relExpSelected = event;
  }

  jobEvent(event) {

    if (event.selectedIndex.length != 0) {
      this.JobChecked = event.selectedIndex;
    }
    else {
      this.JobChecked = [];
    }
    this.jobSelected = event;
  }

  /*
  author :dipin
  desc   : work event of singleselect
  params :  event selected data
  */
  workEvent(event) {
    if (event.selectedIndex.length != 0) {
      this.workChecked = event.selectedIndex;
    }
    else {
      this.workChecked = [];
    }
    this.workSelected = event;
  }

  /*
  author :dipin
  desc   : requirement event of singleselect
  params : event selected data
  */
  requirementEvent(event) {
    if (event.selectedIndex.length != 0) {
      this.requirementChecked = event.selectedIndex;
    }
    else {
      this.requirementChecked = [];
    }
    this.requirementSelected = event;
  }

  /*
  author :dipin
  desc   : location event of singleselect
  params : event selected data
  */
  locationEvent(event) {
    if (event.selectedIndex.length != 0) {
      this.locationsChecked = event.selectedIndex;
    }
    else {
      this.locationsChecked = [];
    }
    this.locationsSelected = event;
  }

  dateChange(dateValue) {
    this.bsValue = dateValue;
  }

  /*
  author :dipin
  desc   : reset Form
  params :
  */
  reset() {
    this.emitData = false;
    let self = this;
    setTimeout(function () {
      self.emitData = true;
    }, 2000)
    // this.filterStatusCheck = false;
    this.statusChecked = [];
    this.workChecked = [];
    this.JobChecked = [];
    this.relExpChecked = [];
    this.requirementChecked = [];
    this.locationsChecked = [];
    this.selectedStat = [];
    this.workSelected = null;
    this.requirementSelected = null;
    this.statusSelected = null;
    this.bsValue = null;
    this.statusLeaveSelect = null;
    this.locationsSelected = null;
    this.dateValue = null;
    this.jobSelected = null;
    this.relExpSelected = null;
    this.selectedData.emit(undefined);
    this.closeFilter();
  }


  /*
  author :dipin
  desc   : submit Form
  params :
  */
  submit() {
    let emitStatus = [false, false, false, false, false, false];
    let tempStatus = false;
    let work = this.workSelected;
    let requirement = this.requirementSelected;
    let bsValue = this.bsValue;
    let location = this.locationsSelected;
    let job = this.jobSelected
    let relExp = this.relExpSelected

    if (this.workStatus)
      if (!work.selected.length) {
        emitStatus[0] = false;
      }
      else
        emitStatus[0] = true;
    else
      emitStatus[0] = false;

    if (this.requirementStatus)
      if (!requirement.selected.length) {
        emitStatus[1] = false;
      }
      else
        emitStatus[1] = true;
    else
      emitStatus[1] = false;

    if (this.locationStatus)
      if (!location.selected.length) {
        emitStatus[2] = false;
      }
      else
        emitStatus[2] = true;
    else
      emitStatus[2] = false;

    if (this.bsValue)
      emitStatus[3] = true;
    else
      emitStatus[3] = false;


    if (this.jobStatus)
      if (!job.selected.length) {
        emitStatus[4] = false;
      }
      else
        emitStatus[4] = true;
    else
      emitStatus[4] = false;

    if (this.relStatus)
      if (!relExp.selected.length) {
        emitStatus[5] = false;
      }
      else
        emitStatus[5] = true;
    else
      emitStatus[5] = false;

    for (var i = 0; i < emitStatus.length; i++) {
      if (emitStatus[i] == true) {
        tempStatus = true;
        break;
      }
      else
        tempStatus = false;
    }

    if (tempStatus == false) {
      this.selectedData.emit(undefined);
    }
    else {
      this.selectedData.emit({ work, requirement, bsValue, location, job, relExp});
    }
    this.closeFilter();
  }

  closeFilter() {
    this.filterStatusCheck = false;
    let filterStatusCheck = this.filterStatusCheck;
    this.openWindowStatus.emit(false);
  }
}
