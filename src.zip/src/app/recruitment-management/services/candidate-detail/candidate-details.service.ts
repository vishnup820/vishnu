import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class CandidateDetailsService {

  apiBaseUrl : string;

  constructor( private http:HttpClient) { 
    this.apiBaseUrl = globalVariables.apiBaseUrl;

  }
  getDetails(candidate_id, requirement_id, cb) {
    let url: string = this.apiBaseUrl + apiList.recruitment.addCandidate + "/" + candidate_id + "?req_id=" + requirement_id;
    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }
  getInterviewDetails(requirement_id, candidate_id, cb) {
    let url: string = this.apiBaseUrl + apiList.recruitment.interviewInfo + requirement_id + "/" + candidate_id;
    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }

  statusUpdate(candidate_id, obj, cb) {
    let url: string = this.apiBaseUrl + apiList.recruitment.dropDownVal + candidate_id;
    let promise = new Promise((resolve, reject) => {
      this.http.put(url, obj)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }

  addSchedule(obj, id, canId, sId, cb) {
    let url: string;
    if (sId != undefined) {
      url = this.apiBaseUrl + apiList.recruitment.updateFeedStatus + "/" + sId + "/" + id + "/" + canId + "?edit=1";
    }
    else
      url = this.apiBaseUrl + apiList.recruitment.updateFeedStatus + "/0/" + id + "/" + canId;

    let promise = new Promise((resolve, reject) => {
      this.http.put(url, obj)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }

  showPepole(value, cb) {
    let url: string;
    if (!value) {
      url = this.apiBaseUrl + apiList.recruitment.externalPeople;
    }
    else {
      url = this.apiBaseUrl + apiList.recruitment.people + "?fields=name";
    }

    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }

  showLocation(cb) {
    let url: string;
    url = this.apiBaseUrl + "/api/v1/recruitment/masters/get-other-master?type=location";
    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }

  editScheduleDetails(rId, eId, callBack) {
    let url: string = this.apiBaseUrl + "/api/v1/recruitment/scheduleInterview/0/" + rId + "/" + eId;
    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) callBack(res)
        })
    })
    return promise;
  }

  /*
  *  @desc   :method deleting get api call for delete one item
  *  @author :dipin
  */
  deleteSchedule(id,value,callBack) {
    let url: string = this.apiBaseUrl + "/api/v1/recruitment/scheduleInterview/" + id;
    let promise = new Promise((resolve, reject) => {
      this.http.patch(url,{reason_cancel : value})
        .toPromise()
        .then(res => {
          if (res) callBack(res)
        })
    })
    return promise;
  }
}
