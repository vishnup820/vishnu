import { TestBed } from '@angular/core/testing';

import { CandidateDetailsService } from './candidate-details.service';

describe('CandidateDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CandidateDetailsService = TestBed.get(CandidateDetailsService);
    expect(service).toBeTruthy();
  });
});
