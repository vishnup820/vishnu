import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import {apiList}  from '../../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class MainFilterService {
  userData        : any;
  apiBaseUrl      : string;
  constructor(private http : HttpClient) { this.apiBaseUrl = globalVariables.apiBaseUrl; }
    
  /*
 	 author : dipin
 	 desc   : get Master Data
  */
	getMasterData(cb) {
		let url: string = this.apiBaseUrl + apiList.recruitment.masterData;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);

				})
		})
	}

	  /*
 	 author : dipin
 	 desc   : get job Data
  */
 getRequirementData(cb) {
	let url: string = this.apiBaseUrl + apiList.recruitment.addRequirement;
	let promise: any = new Promise((resolve, reject) => {
		this.http.get(url)
			.toPromise()
			.then(res => {
				cb(res);

			})
	})
}
}
