import { TestBed } from '@angular/core/testing';

import { MainFilterService } from './main-filter.service';

describe('MainFilterService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MainFilterService = TestBed.get(MainFilterService);
    expect(service).toBeTruthy();
  });
});
