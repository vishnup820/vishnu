import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

import { apiList } from '../../../shared/constants/apilist';
import { globalVariables } from './../../../shared/constants/globals';

@Injectable({
  providedIn: 'root'
})
export class MasterService {
  apiBaseUrl: string;

  constructor(
    private http: HttpClient) { this.apiBaseUrl = globalVariables.apiBaseUrl; }

  /**
  * @ desc   : api requst to load Location
  * @ author  : hashid.n.k
  */
  getMasterData(queryObject, type, cb) {
    let url: string = this.apiBaseUrl + apiList.recruitment.getMasterData;
    url = url + this.generateQuery(queryObject, type);
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          res['status'] && res['data'] && res['data'].length ? cb(res) : cb(null);
        })
    })
  }

  generateQuery(queryObject, type) {
    let query = `?page=${queryObject.page ? queryObject.page : ''}&page_limit=${queryObject['page_limit'] ? queryObject['page_limit'] : ''}${queryObject.sort ? '&sort=' + queryObject.sort : ''}${queryObject.keyword ? '&keyword=' + queryObject.keyword : ''}${queryObject.loc ? '&loc=' + queryObject.loc : ''}${queryObject.status ? '&st=' + queryObject.status : ''}${queryObject.search ? '&keyword='+queryObject.search: ''}`
    query += '&' + type;
    return query;
  }

  /*
  author : vinod.k
  desc   : validation for white space in form
  params :
  */
  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }

  addMasterData(addUrl, data, cb) {
    let url: string = this.apiBaseUrl + addUrl;
    let promise: any = new Promise((resolve, reject) => {
      this.http.post(url, data)
        .toPromise()
        .then(res => {
          cb(res);
        });
    });
  }

  deleteMaster(deleteUrl, id, cb) {
    let url: string = this.apiBaseUrl + deleteUrl + '/' + id;
    let promise: any = new Promise((resolve, reject) => {
      this.http.delete(url)
        .toPromise()
        .then(res => {
          cb(res);
          // res['status'] && res['data'] && res['data'].length ? cb(res) : cb(null);
        });
    });
  }

  editMasterData(editUrl, data, id, cb) {
    let url: string = this.apiBaseUrl + editUrl + '/' + id;
    // url = url + this.generateQuery(queryObject,type);
    let promise: any = new Promise((resolve, reject) => {
      this.http.put(url, data)
        .toPromise()
        .then(res => {
          cb(res);
        });
    });
  }
  getPeople(data, cb) {
    let url: string = this.apiBaseUrl + apiList.people.details + '?fields=f_name,l_name,id,code';
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          res['status'] && res['data'] && res['data'].length ? cb(res) : cb(null);
        });
    });
  }

  position(event, index) {
    let yPosition = event.clientY;
    let formElement = event.target.querySelector('.edit-designation');
    let element = document.getElementsByClassName("list-user")[0];
    let innerheight = element.clientHeight;

    if (((innerheight) / 2) < yPosition && (index > 3)) {
      formElement.classList.add("position-top-department");
    } else {
      formElement.classList.remove("position-top-department");
    }
  }
}
