import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';

@Injectable({
  providedIn: 'root'
})
export class AddRequirementService {
  apiBaseUrl : string;
  constructor( private http: HttpClient,
    private AclVerificationService:AclVerificationService) { 
      this.apiBaseUrl = globalVariables.apiBaseUrl;
    }
     /*
  *  @desc   :method put api call for add onduty
  *  @author :nilena
  */
 addRequest(obj,id,cb) {

   if (id == null) {
    let url: string = this.apiBaseUrl+ apiList.recruitment.addRequirement;
    let promise = new Promise((resolve, reject) => {
      this.http.post(url, obj)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }
  else {
    let url: string = this.apiBaseUrl + apiList.recruitment.addRequirement +"/"+id;
    let promise = new Promise((resolve, reject) => {
      this.http.put(url, obj)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }
}


getEditDetails(id,cb){
  let url: string = this.apiBaseUrl+ apiList.recruitment.addRequirement+"/"+id;
  let promise = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        if (res) cb(res)
      })
  })
  return promise;
}
getMasterDetails(cb){
  let url: string = this.apiBaseUrl+ apiList.recruitment.masterData;
  let promise = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        if (res) cb(res)
      })
  })
  return promise;
}
}
