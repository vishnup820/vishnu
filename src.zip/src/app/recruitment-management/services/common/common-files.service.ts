import { Injectable } from '@angular/core';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

@Injectable({
  providedIn: 'root'
})
export class CommonFilesService {
   type     : any;
   fileName : any;
   fileData : any;
  constructor( private timezoneDetailsService :TimezoneDetailsService) { }

  	/*
	*  @desc   : make date to the format 'dd-mm-yyyy'
	*  @author : nilena
	*/
  formatForApi(inputDate) {
    var date = this.timezoneDetailsService.toLocal(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
      }
      else
        return undefined;
  }


  /*
  * @desc :  to process upload file
  * @auth : nilena
  */
 readThis(inputValue: any) {
  var file : File = inputValue.files[0];
  let self    = this;
  if (file   != undefined) {
    this.type = inputValue.files[0].name.split('.').pop();
    var reader: FileReader = new FileReader();
    this.fileName = file.name;
    reader.readAsDataURL(file);
    reader.onload = () => {
    self.fileData = reader.result;
    };
    // return  self.fileData, this.fileName;
  }
  else {
    self.fileData = undefined;
    self.fileName = "";
  }

  let value = { "fileData":self.fileData, "filename":self.fileName, "type":this.type}
  return  value
 }
 /*
  * @desc :method for matching index of two values
  * @auth : Nilena
  */
 matchingIndex(srcArray, compareValue, key) {
  for (var x in srcArray) {
    if (srcArray[x][key] == compareValue) {
      return x;
    }
  }
  return null;
}
 /**
   * @Author : Nilena Alexander  
   * @Desc   : To trim space in a text area
   */
  commonTrim(value){
    if(value && value.trim()!= ''){
      return value;
    }
  }

  /**
  * @Author : dipin  
  * @Desc   : PDF file view mode
  */
  downloadPdf(value,fileName) {
    let fileURL;
    var data = window.atob(value);
    var buf = new ArrayBuffer(data.length * 2);
    var bufView = new Uint8Array(buf);
    var file;

    for (var i = 0, strLen = data.length; i < strLen; i++) {
      bufView[i] = data.charCodeAt(i);
    }

    file = new Blob([buf], { type: 'application/pdf' });
    fileURL = URL.createObjectURL(file);

    var ua = navigator.userAgent.toLowerCase();
    if (ua.indexOf('safari') != -1) {
      if (ua.indexOf('chrome') > -1) {
        window.open(fileURL);
      }
      else {
        window.location.href = fileURL;
      }
    }
    else if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(file,fileName);
    }
    else
      window.open(fileURL);
  }
}
