import { TestBed } from '@angular/core/testing';

import { CommonFilesService } from './common-files.service';

describe('CommonFilesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CommonFilesService = TestBed.get(CommonFilesService);
    expect(service).toBeTruthy();
  });
});
