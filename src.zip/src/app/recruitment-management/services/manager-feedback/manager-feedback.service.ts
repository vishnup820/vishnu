import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';


@Injectable({
  providedIn: 'root'
})
export class ManagerFeedbackService {

  apiBaseUrl: string;
  constructor(private http: HttpClient,
    private AclVerificationService: AclVerificationService) {
    this.apiBaseUrl = globalVariables.apiBaseUrl;
  }


  getDetails(requirement_id, candidate_id, cb) {
    // let url: string = this.apiBaseUrl+ apiList.recruitment.interviewInfo +requirement_id+"/"+candidate_id;
    let url: string = this.apiBaseUrl + apiList.recruitment.addCandidate + "/" + candidate_id + "?req_id=" + requirement_id;

    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }


  updateStatus(obj,schedule_id,candidate_id,requirement_id,cb) {
    let url: string = this.apiBaseUrl + apiList.recruitment.updateFeedStatus +"/"+schedule_id + "/" + requirement_id+"/"+candidate_id;
    let promise = new Promise((resolve, reject) => {
      this.http.put(url,obj)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }

  getTabDetails(schedule_id, cb) {
    // let url: string = this.apiBaseUrl+ apiList.recruitment.interviewInfo +requirement_id+"/"+candidate_id;
    let url: string = this.apiBaseUrl + apiList.recruitment.updateFeedStatus+"/"+schedule_id+"/0/0"
    let promise = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }

}
