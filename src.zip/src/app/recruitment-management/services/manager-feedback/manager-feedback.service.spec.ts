import { TestBed } from '@angular/core/testing';

import { ManagerFeedbackService } from './manager-feedback.service';

describe('ManagerFeedbackService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ManagerFeedbackService = TestBed.get(ManagerFeedbackService);
    expect(service).toBeTruthy();
  });
});
