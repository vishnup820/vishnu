import { TestBed } from '@angular/core/testing';

import { RecruitmentListService } from './recruitment-list.service';

describe('RecruitmentListService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RecruitmentListService = TestBed.get(RecruitmentListService);
    expect(service).toBeTruthy();
  });
});
