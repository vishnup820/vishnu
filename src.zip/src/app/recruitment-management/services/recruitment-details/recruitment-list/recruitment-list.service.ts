/*
*  @desc   :service dealing get and post api calls for holiday calender
*  @author :dipin
*/
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../../shared/constants/globals';
import {apiList}  from '../../../../shared/constants/apilist';
import { TimezoneDetailsService } from '../../../../shared/services/timezone-details/timezone-details.service';

@Injectable({
  providedIn: 'root'
})
export class RecruitmentListService {

  selectedValues : any = [];
  selectedService: any = [];
  statusService  : boolean = false;
  apiBaseUrl     : string;
  constructor(
		private http: HttpClient,
		private timeZone : TimezoneDetailsService) 
		{ this.apiBaseUrl = globalVariables.apiBaseUrl;}

    /*
	*  @desc   :method dealing get api call for leave type details
	*  @author :dipin
	*/
	getDetails(page, per_page, advanceFilterData, searchValue, obj, approval, list, open, callBack) {
		let sortValue: any;
		let serchFilter: any;
		let params = '';
		let stat = "";
		let temp = "";

		if (obj)
			temp = (obj.type) ? "&sort=-" + obj.department : "&sort=" + obj.department;

		searchValue ? serchFilter = "&keyword=" + searchValue : serchFilter = "";
		if (advanceFilterData) {
			if (advanceFilterData.location)
				if (advanceFilterData.location.selected.length) {
					params = params + "&loc=" + advanceFilterData.location.selected[0].id;
				}
			if (advanceFilterData.work)
				if (advanceFilterData.work.selected.length) {
					params = params + "&workExp=" + advanceFilterData.work.selected[0].id;
				}
			if (advanceFilterData.requirement)
				if (advanceFilterData.requirement.selected.length) {
					if (approval)
						params = params + "&reqAprStat=" + advanceFilterData.requirement.selected[0].id;
					else if (open)
						params = params + "&reqProcStat=" + advanceFilterData.requirement.selected[0].id;
					else if (list)
						params = params + "&reqStat=" + advanceFilterData.requirement.selected[0].id;
				}
			if (advanceFilterData.bsValue)
				params = params + "&tDate=" + this.formatForApi(advanceFilterData.bsValue);
		}

		let url: string;
		if (approval)
			url = this.apiBaseUrl + apiList.recruitment.commonList + "?reqType=approval";
		else if (open)
			url = this.apiBaseUrl + apiList.recruitment.commonList + "?reqType=jobOpenings";
		else if (list)
			url = this.apiBaseUrl + apiList.recruitment.commonList + "?reqType=requester";

		url = url + "&page=" + page + "&page_limit=" + per_page + temp + params + serchFilter + stat;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	 /*
	*  @desc   :method deleting get api call for delete one item from leave type list
	*  @author :dipin
	*/
	deleteDetails(obj,callBack) {
		let url: string = this.apiBaseUrl + apiList.recruitment.commonList+"/"+obj;
		let promise = new Promise((resolve, reject) => {
			this.http.delete(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	    /*
   *  @desc   : make date to the format 'dd-mm-yyyy'
   *  @author : dipin
   */
   formatForApi(inputDate) {
    var date = this.timeZone.toLocal(inputDate);
    if(date)
    if (!isNaN(date.getTime())) {
      if ((Number(date.getMonth()) + 1) < 10) {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
      else {
        if (Number(date.getDate() < 10)) {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
        }
        else {
          return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
        }
      }
    }
    else
      return undefined;
  }
}
