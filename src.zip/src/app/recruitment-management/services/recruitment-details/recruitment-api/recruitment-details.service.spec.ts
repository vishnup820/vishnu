import { TestBed } from '@angular/core/testing';

import { RecruitmentDetailsService } from './recruitment-details.service';

describe('RecruitmentDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RecruitmentDetailsService = TestBed.get(RecruitmentDetailsService);
    expect(service).toBeTruthy();
  });
});
