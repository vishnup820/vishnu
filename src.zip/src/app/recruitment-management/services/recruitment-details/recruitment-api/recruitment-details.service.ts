/*
 author : Dipin Dinesh
 desc   : 
*/

import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

import { globalVariables } from '../../../../shared/constants/globals';
import { apiList }  from '../../../../shared/constants/apilist';
import { TimezoneDetailsService } from '../../../../shared/services/timezone-details/timezone-details.service';


@Injectable({
  providedIn: 'root'
})
export class RecruitmentDetailsService {
  apiBaseUrl  : string;

  constructor(
	  private http              : HttpClient,
	  private timeZone          : TimezoneDetailsService) {
  	this.apiBaseUrl = globalVariables.apiBaseUrl;
    }

    /*
 	 author : dipin
 	 desc   : get requirement details
    */
	getList(id, approval, list, open, cb) {
		let url: string;
		if (approval)
			url = this.apiBaseUrl + apiList.recruitment.addRequirement + "/" + id + "?reqType=approval";
		else if (open)
			url = this.apiBaseUrl + apiList.recruitment.addRequirement + "/" + id + "?reqType=jobOpenings";
		else if (list)
			url = this.apiBaseUrl + apiList.recruitment.addRequirement + "/" + id + "?reqType=requester";
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	/*
	*  @desc   :method get people list for admin drop down
	*  @author :dipin
	*/
	getPeople(callBack) {
		let url: string;
		url = this.apiBaseUrl + apiList.recruitment.getMasterData+"?type=recruitment-team";

		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					callBack(res);
				})
		})
	}

	changeStatus(id, status, approval, list, open, callBack) {
		let url: string;
		url = this.apiBaseUrl + apiList.recruitment.changeStaus + "/" + id;

		let promise = new Promise((resolve, reject) => {
			this.http.put(url, {
				"req_status": status
			})
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}
   
	checkStatus(config,idValue) {
		let status;
		if (config == 'Are You Sure You Want To Reject?') {
			status = 3;
		}
		else if (config == 'Are You Sure You Want To Approve?') {
			status = 2;
		}
		else if (config == 'Are You Sure You Want To Change The Status?') {
			  if(idValue == 'Created'){
				status = 1;
			  }
			  else if(idValue == 'Approved'){
				status = 2;
			  }
			  else if(idValue == 'Rejected'){
				status = 3;
			  }
			  else if(idValue == 'Cancelled'){
				status = 4;
			  }
			  else if(idValue == 'Processing'){
				status = 5;
			  }
			  else if(idValue == 'In Progress'){
				status = 6;
			  }
			  else if(idValue == 'New'){
				status = 7;
			  }
			  else if(idValue == 'Posted'){
				status = 8;
			  }
			  else if(idValue == 'Closed'){
				status = 11;
			  }
			  else if(idValue == 'Overdue'){
				status = 10;
			  }
			  else if(idValue == 'On Hold'){
				status = 9;
			  }
		}
		return status;
	}

	assign(obj,callBack){
		let url: string;
		url = this.apiBaseUrl + apiList.recruitment.assignPeople+"/"+obj.requirement_id;

		let promise: any = new Promise((resolve, reject) => {
			this.http.put(url,obj)
				.toPromise()
				.then(res => {
					callBack(res);
				})
		})
	}

	assignList(id,callBack){
		let url: string;
		url = this.apiBaseUrl + apiList.recruitment.assignPeople+"/"+id;

		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					callBack(res);
				})
		})
	}

	/*
    *  @desc   : make date to the format 'dd-mm-yyyy'
    *  @author : dipin
    */
	formatForApi(inputDate) {
		var date = this.timeZone.toLocal(inputDate);
		if (date)
			if (!isNaN(date.getTime())) {
				if ((Number(date.getMonth()) + 1) < 10) {
					if (Number(date.getDate() < 10)) {
						return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
					}
					else {
						return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
					}
				}
				else {
					if (Number(date.getDate() < 10)) {
						return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
					}
					else {
						return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
					}
				}
			}
			else
				return undefined;
	}
}
