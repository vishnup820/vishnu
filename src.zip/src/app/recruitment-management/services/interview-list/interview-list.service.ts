import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import {apiList}  from '../../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class InterviewListService {

  userData        : any;
  apiBaseUrl      : string;

  constructor(private http: HttpClient) { this.apiBaseUrl = globalVariables.apiBaseUrl;}

      /*
	*  @desc   :method dealing get api call for training-list
	*  @author :ashiq
	*/
  getOtherList(qobj,cb) {
		let url: string = this.apiBaseUrl+apiList.recruitment.interviewList;
		url = url + this.geturlparams(qobj);
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) cb(res)
				})
		})
		return promise;
  }

  geturlparams(qobj){
		let query = `?page=${qobj.page?qobj.page: ''}${qobj.sort?'&sort=' + qobj.sort:''}&page_limit=${qobj['page_limit']?qobj['page_limit']: ''}${qobj.scope?'&scope=' + qobj.scope:''}${qobj.t_st?'&t_st=' + qobj.t_st:''}${qobj.keyword?'&keyword=' + qobj.keyword:''}${qobj.r_sd_dt?'&r_sd_dt=' + qobj.r_sd_dt: ''}${qobj.r_sd_rqd?'&r_sd_rqd=' + qobj.r_sd_rqd: ''}${qobj.rev?'&rev=' + qobj.rev: ''}`
		return query;
	}
}
