import { TestBed } from '@angular/core/testing';

import { InterviewListService } from './interview-list.service';

describe('InterviewListService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: InterviewListService = TestBed.get(InterviewListService);
    expect(service).toBeTruthy();
  });
});
