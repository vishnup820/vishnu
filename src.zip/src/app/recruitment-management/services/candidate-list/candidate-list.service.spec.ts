import { TestBed } from '@angular/core/testing';

import { CandidateListService } from './candidate-list.service';

describe('CandidateListService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CandidateListService = TestBed.get(CandidateListService);
    expect(service).toBeTruthy();
  });
});
