import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import {apiList}  from '../../../shared/constants/apilist';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

@Injectable({
  providedIn: 'root'
})
export class CandidateListService {
  userData        : any;
  apiBaseUrl      : string;
  status          : any = 0;
  range           : any = null ;

  constructor(private http                      : HttpClient,
               private timezoneDetailsService   : TimezoneDetailsService) {
                this.apiBaseUrl = globalVariables.apiBaseUrl;
  }

   /*
	*  @desc   :method dealing get api call for opening-list
	*  @author :ashiq
	*/
  getCandidateList(qobj,cb) {
		let url: string = this.apiBaseUrl+apiList.recruitment.addCandidate;
    url = url + this.geturlparams(qobj);
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) cb(res)
				})
		})
		return promise;
  }
  
  geturlparams(qobj){
		let query = `?page=${qobj.page?qobj.page: ''}${qobj.sort?'&sort=' + qobj.sort:''}&page_limit=${qobj['page_limit']?qobj['page_limit']: ''}${qobj.rel_exp?'&rel_exp=' + qobj.rel_exp:''}${qobj.t_st?'&t_st=' + qobj.t_st:''}${qobj.jobTiltle?'&job_title=' + qobj.jobTiltle:''}${qobj.stat?'&cand_st=' + qobj.stat:''}${qobj.t_dt?'&date=' + qobj.t_dt: ''}${qobj.keyword?'&keyword=' + qobj.keyword:''}`
		return query;
  }

     	/*
  * @ desc   :  method to check value receving from filter is same or not
  * @ author  : nilena alexander
  */

 checkFilterStatus( stat, date ) {

  let ret = true ;
  if( stat == 0  && date == null &&
    (this.status == stat && this.range == date)
    ) {
    ret = false;
  }
  this.status = stat ;
  this.range = date ;
  return ret ;
}

	/*
	*  @desc   : make date to the format 'dd-mm-yyyy'
	*  @author : nilena
	*/
  formatForApi(inputDate) {
    var date = this.timezoneDetailsService.toLocal(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
      }
      else
        return undefined;
  }

  /*
* @ desc   :  method to check value receving from filter is same or not with previous val
* @ author  : nilena alexander
*/
checkFilterCanCancel() {

  let ret = true ;
  if( this.status == 0  && this.range == null ) {
    return false ;
  }
  return true ;
}

/*
* @ desc   :  method to clear filter
* @ author  : nilena alexander
*/

clearFilterStatus() {
  this.status = 0;
  this.range = null ;
}





}
