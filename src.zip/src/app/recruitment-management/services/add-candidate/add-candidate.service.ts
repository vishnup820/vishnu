import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import {apiList}  from '../../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class AddCandidateService {
  userData        : any;
  apiBaseUrl      : string;

  constructor(private http             : HttpClient) { this.apiBaseUrl = globalVariables.apiBaseUrl; }

  	/*
 	 author : ashiq
 	 desc   : get Master Data
    */
	 getRequirementData(obj,cb) {
		let url: string = this.apiBaseUrl + apiList.recruitment.addRequirement;
		url = url + this.geturlparams(obj);
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);

				})
		})
	}

	geturlparams(obj){
		let query = `${obj.stat?'?reqType='+obj.stat:''}`
		return query;
	}	

	  	/*
 	 author : ashiq
 	 desc   : get Master Data
    */
	 getRecruitmentMasterData(cb) {
		let url: string = this.apiBaseUrl + apiList.recruitment.masterData;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);

				})
		})
	}


		  	/*
 	 author : ashiq
 	 desc   : get state list Data
    */
   getStateData(cb) {
	let url: string = this.apiBaseUrl + apiList.recruitment.stateList;
	let promise: any = new Promise((resolve, reject) => {
		this.http.get(url)
			.toPromise()
			.then(res => {
				cb(res);

			})
	})
}



	  /*
	*  @desc   :method for add a new candidate 
	*  @author :ashiq
	*/

	addCandidateApi(obj,cb) {
		let url: string = this.apiBaseUrl + apiList.recruitment.addCandidate;
		let promise = new Promise((resolve, reject) => {
			this.http.post(url,obj)
				.toPromise()
				.then(res => {
					if (res) cb(res)
				})
		})
		return promise;
	}



	 /*
	*  @desc   :method dealing get api call for get training 
	*  @author :ashiq
	*/
	getCandidateData(id, cb) {
		let url: string = this.apiBaseUrl + apiList.recruitment.addCandidate;
		url = url + '/' + id;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {

					if (res) cb(res)
				})
		})
		return promise;
	}


   /*
	*  @desc   :method dealing get api call for update-training list
	*  @author :ashiq
	*/

	updateCandidateApi(id, obj, cb) {
		let url: string = this.apiBaseUrl + apiList.recruitment.addCandidate+ "/" + id;
		let promise = new Promise((resolve, reject) => {
			this.http.put(url, obj)
				.toPromise()
				.then(res => {
					if (res) cb(res)
				})
		})
		return promise;
	}
	
}
