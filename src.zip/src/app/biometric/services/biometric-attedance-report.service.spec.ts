import { TestBed } from '@angular/core/testing';

import { BiometricAttedanceReportService } from './biometric-attedance-report.service';

describe('BiometricAttedanceReportService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BiometricAttedanceReportService = TestBed.get(BiometricAttedanceReportService);
    expect(service).toBeTruthy();
  });
});
