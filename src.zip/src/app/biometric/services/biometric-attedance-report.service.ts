import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../shared/constants/globals';
import {apiList}  from '../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class BiometricAttedanceReportService {
  userData        : any;
  apiBaseUrl      : string;

  constructor(private http: HttpClient) { this.apiBaseUrl = globalVariables.apiBaseUrl; }

    /*
	*  @desc   :method dealing get api call for training-list
	*  @author :ashiq
	*/
  getAttendanceList(filter,qobj,cb) {
		let url: string = this.apiBaseUrl+apiList.biometric.attendanceReport
		if(!filter)
			url = url + this.generateQuery(qobj);
		else
			url = url + this.generateDateQuery(qobj);		
		
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) cb(res)
				})
		})
		return promise;
  }
  
  		
	// geturlparams(qobj){
	// 	let query = `?page=${qobj.page?qobj.page: ''}${qobj.sort?'&sort=' + qobj.sort:''}&page_limit=${qobj['page_limit']?qobj['page_limit']: ''}`
	// 	return query;
  // }	
  
  generateQuery(queryObject) {
	// ?page=${queryObject.page}&perpage=${queryObject.page_limit}
		let query = `/${queryObject.id}?frmdte=${queryObject.frmdte}&todte=${queryObject.todte}${queryObject.sort?queryObject.sort:''}${queryObject.sts?queryObject.sts:''}`
		    // let query = `?frmdte=${queryObject.frmdte}&todte=${queryObject.todte}${queryObject.sort?queryObject.sort:''}`

    return query;
	}
	generateDateQuery(queryObject){
		// &page=${queryObject.page}&perpage=${queryObject.page_limit}
		let query = `?date=${queryObject.date?queryObject.date:''}${queryObject.sort?queryObject.sort:''}${queryObject.sts?queryObject.sts:''}${queryObject.keyword?queryObject.keyword:''}${queryObject.loc?queryObject.loc:''}`
    return query;
	}

  
   /*
	*  @desc   :method dealing get api call for manager list in add training category
	*  @author :ashiq
	*/

	getEmployeeApi(cb) {
		let url: string = this.apiBaseUrl + apiList.biometric.employeeList;
		this.http.get(url)
			.toPromise()
			.then(res => {
				cb(res);
			});
	}

 /*
       author : Nilena Alexander
       desc   : add class based on index
    */
   getClassByValue(index) {
    switch (index % 10) {
        case 0: return "default-avatar islamic-green";
        case 1: return "default-avatar limerick";
        case 2: return "default-avatar chilean-fire";
        case 3: return "default-avatar persian-pink";
        case 4: return "default-avatar deep-magenta";
        case 5: return "default-avatar gigas";
        case 6: return "default-avatar endeavour";
        case 7: return "default-avatar dodger-blue";
        case 8: return "default-avatar jordy-blue";
        case 9: return "default-avatar Light-sea-green";
        case 10: return "emp-profileimage";
    }
}

}
