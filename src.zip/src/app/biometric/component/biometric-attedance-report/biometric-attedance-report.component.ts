import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import {BiometricAttedanceReportService } from '../../services/biometric-attedance-report.service';
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { FilterService } from '../../../shared/services/filter/filter.service';

declare var require: any;
var moment = require('moment');
@Component({
  selector: 'app-biometric-attedance-report',
  templateUrl: './biometric-attedance-report.component.html',
  styleUrls: ['../../../../assets/content/css/biometrics.css']
})
export class BiometricAttedanceReportComponent implements OnInit {
  attendanceReport    :   any =  [] ;
  queryObject         :   any = {};
  empId               :   any;
  userData            :   any;
  ownerList 				  :   any;
  fromDate    		    :   any;
  toDate      		    :   any;
  employeeIdValue     :   any;
  selectedOwnerIds 		:   any;
  minDate 			      :   any;
  maxDate 			      :   any;
  employeeid          :   any;
  selectedTotalHour   :   any;
  selectedWorkingHour :   any;
  selectedOvertime    :   any;
  selectedstatusValue :   any;
  imgErr              :any =[];
  statusVal           : any;
  eventVal            : any;
  searchKeyword       : any = "";
  searchD             : any;
  totalRecords        : number;
  currentDay          : any;
  currentPage         : number = 1;
  recordsPerPage      : number = 10;
  totalHourList       :   any = [];
  selectedStatus      :   any = [];
  filterValue         :   any;
  filterEvent         :   any;
  currentDate         :   any;
  locationValue       : any;
  filterData          :   any = [];
  selectedLocation    :   any = []
  location            :   any = [];
  filterSort 			    :   any = {};
  searchTextBox       : boolean = false;
  showAdvanceFilter   :   boolean = false;
  filterActive        :   boolean = false;
  filterVal           :   boolean = false;
  enableDate          :   boolean = false;
  mainFilterVal       :   boolean = false;
  callStatus          :   boolean;
  @ViewChild('foc') inputEl:ElementRef;

  constructor(
      private biometricAttedanceReportService : BiometricAttedanceReportService,
      private loaderService                  : LoaderActionsService,
      private cookieService		               : CookieService,
      private notificationService            : NotificationService,
      private timezoneDetailsService         : TimezoneDetailsService,
      private timeZone                       : TimezoneDetailsService,
      private filterService                  : FilterService

  ) { }

  ngOnInit() {
    this.loaderService.display(true);
    this.callStatus=false;
    if (this.cookieService.get("user-data")) {
      this.userData = JSON.parse(this.cookieService.get("user-data"));
    
   }
   if (localStorage.getItem("itemsperpage")) {
    this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
  }
  else {
    this.recordsPerPage = 10;
  }
  this.filterService.getMasterData(res => {
    if (res.status == "OK") {
      this.location = res.data.location;
       }
      })
   this.filterData=[{ type:'Date',name:'VIEW BY DATE', value:1},{ type:'Employee',name:'VIEW BY EMPLOYEE', value:2} ]
   this.filterValue = [0]
    // setTimeout(() => {
    //   this.currentDate = this.timezoneDetailsService.getCurrentDate()
    // },200)
   
   this.currentDay  = moment(this.currentDate).format('dddd');  
  //  this.queryObject['id']=this.userData.user_id;
   this.employeeid=this.userData.user_id;
   this.minDate = this.timeZone.toLocal(this.userData.financialMin_date);
    let dateToday  = this.timeZone.getCurrentDate();
		// this.queryObject = {
    //   id      : this.userData.user_id,
		// 	frmdte: `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-1`,
		// 	todte : `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-${dateToday.getDate()}`,
    // }
    this.totalHourList=[{hour :  "1hour" , value : 1},
    {hour :  "2hour" , value : 2},{hour :  "3hour" , value : 3},
    {hour :  "4hour" , value : 4},{hour :  "5hour" , value : 5},
    {hour :  "6hour" , value : 6},{hour :  "7hour" , value : 7},
    {hour :  "8hour" , value : 8},{hour :  "9hour" , value : 9},
    {hour :  "10hour" , value : 10},{hour :  "11hour" , value : 11},
    {hour :  "12hour" , value : 12},{hour :  "13hour" , value : 13},
    {hour :  "14hour" , value : 14},{hour :  "15hour" , value : 15},
    {hour :  "16hour" , value : 16},{hour :  "17hour" , value : 17},
    {hour :  "18hour" , value : 18},{hour :  "19hour" , value : 19},
    {hour :  "20hour" , value : 20},{hour :  "21hour" , value : 21},
    {hour :  "22hour" , value : 22},{hour :  "23hour" , value : 23},
    {hour :  "24hour" , value : 24}];

    this.selectedStatus=[{status:"present",value :"present" ,id:1},
    {status:"absent",value :"absent", id:2},
    {status:"Leave",value :"Leave", id:6},
    {status:"Loss of Pay",value :"Loss of Pay", id:-1},
    {status:"Weekend",value :"Weekend", id:4},
    {status:"Holiday",value :"Holiday", id:5},
    {status:"On Duty",value :"On Duty", id:3}
  ]
       
  
	
  
    // this.attendanceListdata();
    this.getAllEmployee();
  
    this.maxDate = dateToday;
  }
  selectLocation(event){
    if (event.selected.length> 0) {
      this.locationValue = event.selected[0].id;
      this.queryObject.loc = (  this.locationValue) ? `${'&loc='}${ this.locationValue}` : '';
  }else{
    this.locationValue ='';
    this.queryObject.loc ='';
  }
}
  	/*
	*  @desc   : make date to the format 'dd-mm-yyyy'
	*  @author : nilena
	*/
  formatForApi(inputDate) {
    var date = this.timezoneDetailsService.toLocal(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
      }
      else
        return undefined;
  }

  mainFilterEvent(event){
    

    if (event.selected.length ){
      this.eventVal=event.selected[0].type;
      if(this.searchKeyword){
        
      this.searchD='';
      this.searchTextBox=false;
      this.queryObject.searchKeyword=''
      }

      if(this.filterActive)
      {
        this.selectedstatusValue=[0];
        this.showAdvanceFilter=false;
        this.filterActive=false;
        this.queryObject={}
        // this.queryObject.page = 1;
       this.currentPage = 1;
      }

      // this.filterCancel()

      if(event.selected[0].value == 1 ){
      this.enableDate = true;
      setTimeout(() => {
        this.currentDate=this.timezoneDetailsService.getCurrentDate()
        this.currentDay =moment(this.currentDate).format('dddd');  
      });

      this.queryObject={}
      this.queryObject.page = 1;
      this.currentPage = 1;
      this.queryObject.date = this.formatForApi(this.currentDate)
          // if( this.callStatus){
          //     this.attendanceListdata();
          //   }
   
      }
      
      if(event.selected[0].value == 2){
        this.currentPage=1;
        this.queryObject.paqe=1; 
        this.enableDate = false;
        this.queryObject['id']=this.userData.user_id;
        this.employeeid=this.userData.user_id;
        // this.queryObject.page = 1;
        this.currentPage = 1;
            let dateToday  = this.timeZone.getCurrentDate();
        this.queryObject = {
          id      : this.userData.user_id,
          frmdte: `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-1`,
          todte : `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-${dateToday.getDate()}`,
        }
        this.fromDate = new Date(this.queryObject['frmdte']);
        this.toDate   = new Date(this.queryObject['todte']);
        this.fromDate = this.timeZone.toLocal(this.queryObject['frmdte'])
        this.toDate   = this.timeZone.toLocal(this.queryObject['todte']);
        // this.attendanceListdata();
      }

    }
  }



  dateto(date){
    if(date){
      this.currentDate = date;
      this.currentDay = moment(this.currentDate).format('dddd');  
      this.queryObject.page = 1;
      this.currentPage = 1;
      this.queryObject.date=this.formatForApi(date);
    this.attendanceListdata();
    }
  }
 /*
  author : Arun Johnson
  desc   : add class based on index
 */
getClassByValue(index) {
  return this.biometricAttedanceReportService.getClassByValue(index);

}
inputfocus() {
  setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
}
searchList(keyword) {
  if ( this.searchKeyword || this.searchD.trim() != ''){  
  this.searchKeyword = keyword;
  this.queryObject.keyword = this.searchKeyword ? `${'&search='}${this.searchKeyword}` : '';
  this.currentPage = 1;

  this.queryObject.page = 1;
  this.attendanceListdata();
}
}
      /*
  * @ desc   : method for calling api for all/(employee)  training list
  * @ author  : ashiq
  */
 attendanceListdata() {
  this.loaderService.display(true);
  
  this.queryObject.page = this.currentPage;
  this.queryObject.page_limit = this.recordsPerPage;
  this.biometricAttedanceReportService.getAttendanceList(this.enableDate,this.queryObject ,response => {
      if (response.data && response.data.length > 0) {
          this.attendanceReport = response.data;
          this.currentPage = this.queryObject.page;
          this.totalRecords = Number(response.count);
          for(let k=0; k<this.attendanceReport.length;k++){
            this.attendanceReport[k].name = this.attendanceReport[k].first_name+ " "+ this.attendanceReport[k].last_name;
            if(!(this.attendanceReport[k].first_in==null ||this.attendanceReport[k].first_in=="" )){
              let a =this.attendanceReport[k].first_in.split(" ");
              let b = a[1].split(":");
              let c=b[0]+":"+b[1];
             
              // let afterUtc=this.timezoneDetailsService.getTimeNow(c);
              this.attendanceReport[k].first_in=c;
              let firstInDate=a[0];
              this.attendanceReport[k].firstIndate=firstInDate;
            }
            if(!(this.attendanceReport[k].last_out==null ||this.attendanceReport[k].last_out=="" )){
              let a =this.attendanceReport[k].last_out.split(" ");
              let b = a[1].split(":");
              let c=b[0]+":"+b[1];
              // let afterUtc=this.timezoneDetailsService.getTimeNow(c);
              this.attendanceReport[k].last_out=c;
              let lastOutDate=a[0];
              this.attendanceReport[k].lastOutDate=lastOutDate;
          
            }
            if(!(this.attendanceReport[k].shift_start==null ||this.attendanceReport[k].shift_start=="" )){
              let a =this.attendanceReport[k].shift_start.split(":");
              // let b = a[1].split(":");
              let c=a[0]+":"+a[1];
              // let afterUtc=this.timezoneDetailsService.getTimeNow(c);
              this.attendanceReport[k].shift_start=c;
            }
            if(!(this.attendanceReport[k].shift_end==null ||this.attendanceReport[k].shift_end=="" )){
              let a =this.attendanceReport[k].shift_end.split(":");
              let c=a[0]+":"+a[1];
              // let afterUtc=this.timezoneDetailsService.getTimeNow(c);
              this.attendanceReport[k].shift_end=c;
            }

            
          }
          this.currentPage       = this.queryObject.page;

        this.loaderService.display(false);
          
      }
      else {
        this.attendanceReport = [];
        this.loaderService.display(false);
    }
  })
}
 /*
  * @ desc   : method for pass page number  through api
  * @ author  : ashiq
  */
 pageChangeEvent(page) {
  this.queryObject.page = page;
  this.currentPage=page;
  // this.attendanceListdata();
}

//  /**
//   * @ desc   : TO implement pagination
//   * @ author  : Nilena Alexander
//   */
//  pageChangeEvent(page) {
//   this.queryObject.page = page;
//    this.currentPage = page;
//   this.attendanceListdata();
// }
/*
 * @ desc   : TO implement pagination
 * @ author  : Nilena Alexander
 */
getpage(eve) {
  if (eve > 10 || this.recordsPerPage != 10) {
    this.recordsPerPage = eve;
    // this.queryObject['page_limit'] = eve;
    // this.queryObject['page'] = 1;
    this.currentPage = 1;
   this.pageChangeEvent(this.currentPage);
  }
}

getAllEmployee() {
  this.biometricAttedanceReportService.getEmployeeApi(res => {
    this.ownerList = res.data;
    for (var i = 0; i < this.ownerList.length; i++) {
      this.ownerList[i].first_name = this.ownerList[i].first_name + " " + this.ownerList[i].last_name + " (" +this.ownerList[i].code+  ")";
    }
    this.selectedOwnerIds = [this.matchingIndex(this.ownerList, this.userData.user_id, "id")];

  })
}

selectStatusDats(event){
  if (event.selected.length >0 ){
    this.statusVal= event.selected[0].id;
    let statusid = event.selected[0].id;
    this.queryObject.sts = (statusid) ? `${'&sts='}${statusid}` : '';
  }else{
    this.statusVal=null;
    this.queryObject.sts = '';
  }
}

  /*
   author : ashiq
   desc   :sort function
   */
  sort(label) {
    let currentSortStatus = this.filterSort[label] ? this.filterSort[label].rev : true;
    this.filterSort = {};
    this.filterSort[label] = { rev: !currentSortStatus }
    this.filterSort["label"] = label;
    this.queryObject.sort = (this.filterSort[label].rev == true) ? `${'asc&sortField='}${label}` : `${'desc&sortField='}${label}`
    this.attendanceListdata();
  }


  applyFilter(){
    if(this.eventVal ==='Date'){
    if(this.statusVal || this.locationValue){
        this.filterVal= true;
        this.currentPage=1;
        this.queryObject.page=1;
        // this.queryObject['id']=this.employeeid;
        this.attendanceListdata();
        this.filterActive=true;
    }
    else{
      this.filterActive=false;
      this.queryObject.loc = '';
      this.showAdvanceFilter = false;
      this.attendanceListdata();
    }
  }
    else if(this.eventVal ==='Employee'){
      if(this.statusVal || this.fromDate || this.toDate){
      this.filterVal= true;
      this.currentPage=1;
      this.queryObject.page=1;
      this.queryObject['id']=this.employeeid;
      this.attendanceListdata();
      this.showAdvanceFilter = false;
      this.filterActive=true;
  }
  else{
    this.filterActive=false;
    this.currentPage=1;
    this.queryObject.page=1;
    this.showAdvanceFilter = false;
    this.attendanceListdata();
  }
}
  
  this.showAdvanceFilter = false;

  }

  filterCancel(){
    if(this.filterVal){
      this.filterVal= false;
      this.filterActive=false;
      this.selectedstatusValue=[0];
      this.selectedLocation=[0];

      if(this.eventVal=='Date'){
        this.queryObject.loc = '';
        this.queryObject.date= this.formatForApi(this.currentDate);
        this.queryObject.page = 1;
        this.queryObject.sts = '';

        this.currentPage = 1;
      }
      else{
        this.queryObject.page = 1;
        this.currentPage = 1;
        let dateToday  = this.timeZone.getCurrentDate();
        this.queryObject = {
          id      :this.employeeid,
          frmdte: `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-1`,
          todte : `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-${dateToday.getDate()}`,
        }
        this.queryObject['id']=this.employeeid;
        this.fromDate = this.timeZone.toLocal(this.queryObject['frmdte']);
        this.toDate   = this.timeZone.toLocal(this.queryObject['todte']);
        this.maxDate = dateToday;   
      }
      this.attendanceListdata();
      
    }
  }



  dateChange(label,date) {
    
		label == 'fromDate' ?
			this.queryObject['frmdte'] = `${this.fromDate.getFullYear()}-${this.fromDate.getMonth()+1}-${this.fromDate.getDate()}`
		:
			this.queryObject['todte'] = `${this.toDate.getFullYear()}-${this.toDate.getMonth()+1}-${this.toDate.getDate()}`;

		// this.fromDate = this.timeZone.toLocal(this.queryObject['frmdte']);
		// this.toDate   = this.timeZone.toLocal(this.queryObject['todte']);
	}

    /*
	 * @desc :method for matching index of two values
	 * @auth : Ashiq
	 */
	matchingIndex(srcArray, compareValue, key) {
		for (var x in srcArray) {
			if (srcArray[x][key] == compareValue) {
				return x;
			}
		}
		return null;
  }
  
  /**
	 * @ desc   :to perform sorting
	 * @ author  : ashiq
	 */
  sortDate(label) {
		let currentSortStatus = this.filterSort[label]?this.filterSort[label].rev: true;
		this.filterSort = {};
		this.filterSort[label] = {rev:!currentSortStatus}
    this.filterSort["label"] = label;
    // if(label=="attendance_date"){
    	this.queryObject.sort = (this.filterSort[label].rev == true)?`${'&sortField='}${label}${'&sort=Desc'}`:`${'&sortField='}${label}${'&sort=Asc'}`
    // }
    // if(label=="shift_start"){
    // 	this.queryObject.sort = (this.filterSort[label].rev == true)?`${'sortField='}${label}${'&sort=Desc'}`:`${'sortField='}${label}${'&sort=Asc'}`
    // }

	
    this.attendanceListdata();
  }
 




	/*
	 * @desc :method for select owner from multiselector
	 * @auth : Ashiq
	 */
	selectOwner(events) {
		if (events.selected.length > 0) {
      this.employeeid = events.selected[0].id;
      this.queryObject['id']=this.employeeid;
      this.currentPage =1
      this.attendanceListdata(); 
		}
	}


}
