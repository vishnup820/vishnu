import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BiometricAttedanceReportComponent } from './biometric-attedance-report.component';

describe('BiometricAttedanceReportComponent', () => {
  let component: BiometricAttedanceReportComponent;
  let fixture: ComponentFixture<BiometricAttedanceReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BiometricAttedanceReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BiometricAttedanceReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
