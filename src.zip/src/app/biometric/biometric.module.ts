import { NgModule,ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { AuthGuardService } from '../shared/services/auth-guard/auth-guard.service';
import { RoleGuardService } from '../shared/services/role-guard/role-guard.service';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BiometricAttedanceReportComponent } from './component/biometric-attedance-report/biometric-attedance-report.component';
import { GlobalErrorHandlerService } from '../global-error-handler.service';

@NgModule({
  declarations: [BiometricAttedanceReportComponent],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    RouterModule.forChild([

      {
        path       : 'attendance-report',
        canActivate : [RoleGuardService],
        component: BiometricAttedanceReportComponent
      },
      {
        path       : '',
        redirectTo : 'attendance-report',
        canActivate : [RoleGuardService],
        pathMatch  : 'full'
      },
    ])
  ],
  providers : [
       AuthGuardService,
       RoleGuardService,
        {
         provide  : ErrorHandler,
         useClass : GlobalErrorHandlerService,
        }
       ]
})
export class BiometricModule { }
