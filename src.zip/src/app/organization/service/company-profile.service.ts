import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

import {apiList}  from '../../shared/constants/apilist';
import { globalVariables } from './../../shared/constants/globals';

@Injectable({
  providedIn: 'root'
})
export class CompanyProfileService {
	apiBaseUrl  : string;

  constructor(
  	private http: HttpClient) {this.apiBaseUrl = globalVariables.apiBaseUrl; }

    /**
    * @ desc   : api to loard comapny details
    * @ author : hashid
    */
 	getCompany(filter, cb) {
			let url: string =  this.apiBaseUrl+apiList.company.details;
			let promise: any = new Promise((resolve, reject) => {
				this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
			})
    }

    /**
    * @ desc   : api to loard location details
    * @ author : dpin
    */
 	getLocations(cb) {
			let url: string =  this.apiBaseUrl + apiList.location.details;
			let promise: any = new Promise((resolve, reject) => {
				this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
			})
    }

      /*
    *  @desc   :authentication detail based on domain
    *  @author :vinod
    *  @params :user name & password
    */
    getDomain(domain,cb):void{
        let url: string = this.apiBaseUrl + apiList.auth.entityInfo+"?domain="+domain;
        this.http.get(url)
        .toPromise()
        .then(res=>{
            cb(res);
        });
    }
}
