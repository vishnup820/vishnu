import { TestBed } from '@angular/core/testing';

import { DesignationListingService } from './designation-listing.service';

describe('DesignationListingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DesignationListingService = TestBed.get(DesignationListingService);
    expect(service).toBeTruthy();
  });
});
