import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { apiList } from '../../shared/constants/apilist';
import { globalVariables } from './../../shared/constants/globals';

@Injectable({
	providedIn: 'root'
})

export class DepartmentListingService {
	apiBaseUrl  : string;

	constructor(
		private http: HttpClient) { this.apiBaseUrl = globalVariables.apiBaseUrl; }


  			/**
	* @ desc 	: api requst to load department
	* @ author	: hashid
	*/

	generateQuery(queryObject) {
		let query = `?page=${queryObject.page?queryObject.page: ''}
					&page_limit=${queryObject['page_limit']?queryObject['page_limit']: ''}
					${queryObject.sort?'&sort=' + queryObject.sort:''}
					${queryObject.keyword?'&keyword=' + queryObject.keyword: ''}
					${queryObject.dept?'&dept=' + queryObject.dept: ''}
					${queryObject.st?'&st=' + queryObject.st: ''}`

		return query;
	}

	getDepartment(queryObject,cb) {

		
		let url: string = this.apiBaseUrl+apiList.department.details;
		url = url + this.generateQuery(queryObject);
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					res['status'] && res['data'] && res['data'].length? cb(res) : cb(null);
				})
		})
	}


			/**
	* @ desc 	: api requst to load parent department
	* @ author	: hashid
	*/

		generateQery(queryObject) {
		let query = `/${queryObject}`

		return query;
	}
		getParentDepartment(queryObject,cb) {	
		let url: string = this.apiBaseUrl+apiList.department.parent;
		url = url + this.generateQery(queryObject);
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					res['status'] && res['data'] && res['data'].length? cb(res) : cb(null);
				})
		})
	}





	  			/**
	* @ desc 	: api requst to add new department
	* @ author	: Hashid.n.k
	*/

	
	addDepartment(data, cb) {
		let url: string = this.apiBaseUrl+apiList.department.details;
		let promise: any = new Promise((resolve, reject) => {
			this.http.post(url, data)
				.toPromise()
				.then(res => {
					res["status"] ? cb(res) : '';
				})
		})
	}

	  			/**
	* @ desc 	: api requst to edit  department from list
	* @ author	: Hashid.n.k
	*/

	editDepartment(data, id, cb) {
		let url: string = `${this.apiBaseUrl+apiList.department.details}/${id}`;
		let promise: any = new Promise((resolve, reject) => {
			this.http.put(url, data)
				.toPromise()
				.then(res => {
					res["status"] ? cb(res) : '';
				})
		})
	}

	  			/**
	* @ desc 	: delete department from  list
	* @ author	: Hashid.n.k
	*/


	deleteDepartment(id, cb) {
		let url: string = `${this.apiBaseUrl+apiList.department.details}/${id}`;
		let promise: any = new Promise((resolve, reject) => {
			this.http.request("delete", url)
				.toPromise()
				.then(res => {
					res["status"] ? cb(res) : '';
				})
		})
	}

	  			/**
	* @ desc 	: delete multiple department from  list
	* @ author	: Hashid.n.k
	*/

	deleteMultipleDepartment(data, cb) {
		let url: string = this.apiBaseUrl+apiList.department.details;
		let promise: any = new Promise((resolve, reject) => {
			this.http.request('delete', url, { body: { id: data } })
				.toPromise()
				.then(res => {
					res["status"] ? cb(res) : '';
				})
		})
	}


}


