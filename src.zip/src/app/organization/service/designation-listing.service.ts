import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

import {apiList}  from '../../shared/constants/apilist';
import { globalVariables } from './../../shared/constants/globals';

@Injectable({
  providedIn: 'root'
})
export class DesignationListingService {
apiBaseUrl  : string;
  constructor(
  	   private http              : HttpClient
       ) {this.apiBaseUrl = globalVariables.apiBaseUrl; }

        /**
  * @ desc   : api requst to get designation
  * @ author  : hashid
  */

  generateQuery(queryObject) {
    let query = `?page=${queryObject.page?queryObject.page: ''}&page_limit=${queryObject['page_limit']?queryObject['page_limit']: ''}${queryObject.sort?'&sort=' + queryObject.sort:''}${queryObject.keyword?'&keyword=' + queryObject.keyword: ''}${queryObject.desg?'&desg=' + queryObject.desg: ''}${queryObject.st?'&st=' + queryObject.st: ''}`

    return query;
  }

  getDesignation(queryObject,cb) {
    
    let url: string = this.apiBaseUrl+apiList.designation.details;
    url = url + this.generateQuery(queryObject);

    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          res['status'] && res['data'] && res['data'].length? cb(res) : cb(null);
        })
    })
  }

    

        /**
  * @ desc   : api requst to get designation
  * @ author  : hashid
  */

  addDesignation(data,cb) {
    let url     : string = this.apiBaseUrl+apiList.designation.details;
    let promise : any    = new Promise((resolve, reject) => {
      this.http.post(url,data)
        .toPromise()
        .then(res => {
          res["status"]? cb(res) : '';
        })
    })
  }

        /**
  * @ desc   : api requst to delete designation
  * @ author  : hashid
  */
  deleteDesignation(id, cb) {
    let url: string = `${this.apiBaseUrl+apiList.designation.details}/${id}`;
    let promise: any = new Promise((resolve, reject) => {
      this.http.request("delete", url)
        .toPromise()
        .then(res => {
          res["status"] ? cb(res) : '';
        })
    })
  }

        /**
  * @ desc   : api requst to delete multiple designation
  * @ author  : hashid
  */
  deleteMultipleDesignation(data, cb) {
    let url: string = this.apiBaseUrl+apiList.designation.details;
    let promise: any = new Promise((resolve, reject) => {
      this.http.request('delete', url, { body: { id: data } })
        .toPromise()
        .then(res => {
          res["status"] ? cb(res) : '';
        })
    })
  }

          /**
  * @ desc   : api requst to edit designation
  * @ author  : hashid
  */

  editDesignation(data, id, cb) {
    let url: string = `${this.apiBaseUrl+apiList.designation.details}/${id}`;
    let promise: any = new Promise((resolve, reject) => {
      this.http.put(url, data)
        .toPromise()
        .then(res => {
          res["status"] ? cb(res) : '';
        })
    })
  }
}
