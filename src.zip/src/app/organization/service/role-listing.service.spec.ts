import { TestBed } from '@angular/core/testing';

import { RoleListingService } from './role-listing.service';

describe('RoleListingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RoleListingService = TestBed.get(RoleListingService);
    expect(service).toBeTruthy();
  });
});
