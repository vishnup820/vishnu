import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

import {apiList}  from '../../shared/constants/apilist';
import { globalVariables } from './../../shared/constants/globals';

@Injectable({
  providedIn: 'root'
})
export class GroupListService {
  apiBaseUrl  : string;

  constructor(
   		private http              : HttpClient) { this.apiBaseUrl = globalVariables.apiBaseUrl;}



  generateQuery(queryObject) {
    let query = `?page=${queryObject.page?queryObject.page: ''}&page_limit=${queryObject['page_limit']?queryObject['page_limit']: ''}${queryObject.sort?'&sort=' + queryObject.sort:''}${queryObject.keyword?'&keyword=' + queryObject.keyword: ''}${queryObject.grp?'&grp=' + queryObject.grp: ''}${queryObject.state?'&st=' + queryObject.state: ''}`

    return query;
  }
        /**
  * @ desc   : api requst to get group
  * @ author  : hashid.n.k
  */

  getGroup(queryObject,cb) {
    let url     : string = this.apiBaseUrl+apiList.group.details;
    url = url + this.generateQuery(queryObject);

    let promise : any    = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

        /**
  * @ desc   : api requst to get group deatils for editing
  * @ author  : hashid.n.k
  */


  getGroupEditDetails(id, cb) {

    let url     : string = `${this.apiBaseUrl+apiList.group.details}/${id}`;
       let promise : any    = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
         res['data'].length? cb(res['data']): '';
        })
       })
  }

        /**
  * @ desc   : api requst to get user to userid to multi-selection of add form
  * @ author  : hashid.n.k
  */
  
  generateQry(queryObject) {
 let query = `?fields=id,code,name&sort=f_name&stat=1` 
  
    return query;
  }

  getUser(queryObject,id,cb){
      let url: string = this.apiBaseUrl + apiList.people.details;
        url = url + this.generateQry(queryObject);
    
   let promise : any    = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })

  }
        /**
  * @ desc   : api requst to add  group to the main list
  * @ author  : hashid.n.k
  */


  
  addGroup(data,cb) {
    let url     : string = this.apiBaseUrl+apiList.group.details;
    let promise : any    = new Promise((resolve, reject) => {
      this.http.post(url,data)
        .toPromise()
        .then(res => {
          res["status"]? cb(res) : '';
        })
    })
  }

        /**
  * @ desc   : api requst to delete a  group from list
  * @ author  : hashid.n.k
  */



  deleteGroup(id, cb) {
    let url: string = `${this.apiBaseUrl+apiList.group.details}/${id}`;
    let promise: any = new Promise((resolve, reject) => {
      this.http.request("delete", url)
        .toPromise()
        .then(res => {
          res["status"] ? cb(res) : '';
        })
    })
  }

        /**
  * @ desc   : api requst to perform multiple delete from  group list
  * @ author  : hashid.n.k
  */


  deleteMultipleGroup(data, cb) {
    let url: string = this.apiBaseUrl+apiList.group.details;
    let promise: any = new Promise((resolve, reject) => {
      this.http.request('delete', url, { body: { id: data } })
        .toPromise()
        .then(res => {
          res["status"] ? cb(res) : '';
        })
    })
  }

        /**
  * @ desc   : api requst to edit group
  * @ author  : hashid.n.k
  */



  editGroup(data, id, cb) {
    let url: string = `${this.apiBaseUrl+apiList.group.details}/${id}`;
    let promise: any = new Promise((resolve, reject) => {
      this.http.put(url, data)
        .toPromise()
        .then(res => {
          res["status"] ? cb(res) : '';
        })
    })
  }





}
