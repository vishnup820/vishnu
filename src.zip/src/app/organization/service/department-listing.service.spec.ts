import { TestBed } from '@angular/core/testing';

import { DepartmentListingService } from './department-listing.service';

describe('DepartmentListingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DepartmentListingService = TestBed.get(DepartmentListingService);
    expect(service).toBeTruthy();
  });
});
