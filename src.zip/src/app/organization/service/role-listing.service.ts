import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { apiList } from '../../shared/constants/apilist';
import { globalVariables } from './../../shared/constants/globals';

@Injectable({
  providedIn: 'root'
})
export class RoleListingService {
	apiBaseUrl  : string;

  constructor(private http: HttpClient) {this.apiBaseUrl = globalVariables.apiBaseUrl; }


    /**
	* @ desc 	: query method for filter, search & pagination
	* @ author	: ashiq
	*/

	geturlparams(queryObject){
		let query = `?page=${queryObject.page?queryObject.page: ''}&page_limit=${queryObject['page_limit']?queryObject['page_limit']: ''}${queryObject.sort?'&sort=' + queryObject.sort:''}${queryObject.keyword?'&keyword=' + queryObject.keyword:''}${queryObject.st?'&st=' + queryObject.st:''}`
		 return query;
	}
	

// url = url + this.geturlparams(queryObject);
	getRoleList(queryObject,cb) {
		
		let url: string = this.apiBaseUrl+apiList.role.addRole;
		 
		url = url + this.geturlparams(queryObject);
		
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) cb(res)
				})
		})
	}

	addRoleApi(obj,callBack) {

		let url: string = this.apiBaseUrl+apiList.role.addRole;
		let promise = new Promise((resolve, reject) => {
			this.http.post(url,obj)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}
    

   /*
	*  @desc   :method dealing get api call for  update role-list
	*  @author :ashiq
	*/
	editRoleApi(id,obj,callBack) {
		let url: string = this.apiBaseUrl+apiList.role.addRole+"/"+id;
		let promise = new Promise((resolve, reject) => {
			this.http.put(url,obj)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	

	
	

	    /*
	*  @desc   :method dealing get api call for  delete a role from list
	*  @author :ashiq
	*/
	deleteRole(id, cb) {
		let url: string = this.apiBaseUrl+apiList.role.addRole+"/"+id;
		let promise: any = new Promise((resolve, reject) => {
			this.http.delete(url)
				.toPromise()
				.then(res => {
					res["status"] ? cb(res) : '';
				})
		})
	}



   /**
	* @ desc 	: delete multiple role from  list
	* @ author	: ashiq
	*/

	deleteMultipleRole(data, cb) {
		let url: string = this.apiBaseUrl+apiList.role.deleteRoles;
		let promise: any = new Promise((resolve, reject) => {
			this.http.request('delete', url, { body: data})
				.toPromise()
				.then(res => {
					res["status"] ? cb(res) : '';
				})
		})
	}






}
