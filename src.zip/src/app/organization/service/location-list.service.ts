import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

import {apiList}  from '../../shared/constants/apilist';
import { globalVariables } from './../../shared/constants/globals';

@Injectable({
  providedIn: 'root'
})
export class LocationListService {
  apiBaseUrl  : string;

  constructor(
  	 private http : HttpClient) {this.apiBaseUrl = globalVariables.apiBaseUrl; }
          

          /**
  * @ desc   : api requst to edit Location from list
  * @ author  : hashid.n.k
  */


  editLocation(data, id, cb) {
    let url: string = `${this.apiBaseUrl+apiList.location.details}/${id}`;
    let promise: any = new Promise((resolve, reject) => {
      this.http.put(url, data)
        .toPromise()
        .then(res => {
          res["status"] ? cb(res) : '';
        })
    })
  }

 generateQuery(queryObject) {
    let query = `?page=${queryObject.page?queryObject.page: ''}&page_limit=${queryObject['page_limit']?queryObject['page_limit']: ''}${queryObject.sort?'&sort=' + queryObject.sort:''}${queryObject.keyword?'&keyword=' + queryObject.keyword: ''}${queryObject.loc?'&loc=' + queryObject.loc: ''}${queryObject.status?'&st=' + queryObject.status: ''}`

    return query;
  }


          /**
  * @ desc   : api requst to load Location
  * @ author  : hashid.n.k
  */

  getLocation(queryObject,cb) {
    
    let url: string = this.apiBaseUrl+apiList.location.details;
    url = url + this.generateQuery(queryObject);
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          res['status'] && res['data'] && res['data'].length? cb(res) : cb(null);
        })
    })
  }






            /**
  * @ desc   : api requst to load country list to multi selection in the add & edit form
  * @ author  : hashid.n.k
  */

  getCountry(cb){
     let url     : string = this.apiBaseUrl+apiList.country.details;
   let promise : any    = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })

  }

  gettimezones(id,cb){
     let url     : string = this.apiBaseUrl+apiList.timezone.times + "/" + id;
   let promise : any    = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

            /**
  * @ desc   : api requst to add Location from add form
  * @ author  : hashid.n.k
  */


  addLocation(data,cb) {
    let url     : string = this.apiBaseUrl+apiList.location.details;
    let promise : any    = new Promise((resolve, reject) => {
      this.http.post(url,data)
        .toPromise()
        .then(res => {
          res["status"]? cb(res) : '';
        })
    })
  }

            /**
  * @ desc   : api requst to delete Location from list
  * @ author  : hashid.n.k
  */


  deleteLocation(id, cb) {
    let url: string = `${this.apiBaseUrl+apiList.location.details}/${id}`;
    let promise: any = new Promise((resolve, reject) => {
      this.http.request("delete", url)
        .toPromise()
        .then(res => {
          res["status"] ? cb(res) : '';
        })
    })
  }

            /**
  * @ desc   : api requst to delete multiple  Location from list
  * @ author  : hashid.n.k
  */


  deleteMultipleLocation(data, cb) {
    let url: string = this.apiBaseUrl+apiList.location.details;
    let promise: any = new Promise((resolve, reject) => {
      this.http.request('delete', url, { body: { id: data } })
        .toPromise()
        .then(res => {
          res["status"] ? cb(res) : '';
        })
    })
  }







}
