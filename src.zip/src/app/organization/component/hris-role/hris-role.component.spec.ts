import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HrisRoleComponent } from './hris-role.component';

describe('HrisRoleComponent', () => {
  let component: HrisRoleComponent;
  let fixture: ComponentFixture<HrisRoleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HrisRoleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HrisRoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
