import { Component, OnInit , ViewChild,ElementRef} from '@angular/core';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { RoleListingService } from '../../service/role-listing.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { ConstantServicesService } from '../../../shared/services/constant/constant-services.service';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
// import { FilterService } from './../../../services/filter-service/filter.service';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-hris-role',
  templateUrl: './hris-role.component.html',
  styleUrls: ['./hris-role.component.css']

})
export class HrisRoleComponent implements OnInit {
   searchD               : any;
   statusArray           : any;
   roleObj               : any;
   statusVal             : any;
   advanceFilterData     : any;
   queryObject           : any  =  {};
   roleList              : any;
   selectedId            : any;
   selectid              : any;
   canceEdit             : any;
   dataa                 : any;
   statusSelected        : any;
   selectedStatusEdit    : any;
   selectedStatusAdd     : any;
   filterSort            : any  =  {};
   currentPage           : number     = 1;
   recordsPerPage        : number     = 10;
   totalRecords          : number;
   selectedRole          : Array<object> = [];
   searchKeyword         :  any        = "";
   submitted             : boolean;
   showAdvancedFilter    : boolean;
   searchTextBox         : boolean = false;
	 showForm              : boolean = false;
	 editStatus            : boolean = false;
   formPosition          : boolean = false;
   filterActive          : boolean = false;
    confirmBox           : boolean = false;
   showConfirmBox        : boolean = false;
   selectAllStatus       : boolean = false;
   disableSelect         : boolean = true;
	 roleForm 		         : FormGroup;
	 nameField 				     : FormControl;
   statusField           : FormControl;
   config                : any = "Are You Sure You Want To Delete?";
  allDeleteconfig        : any = "Are You Sure You Want To Delete All Roles?";
  @ViewChild('foc') inputEl:ElementRef;


  constructor(
  	  private RoleListingService		: RoleListingService,
	    private notifications 			  : NotificationService,
      private loader					      : LoaderActionsService,
      private constData	            : ConstantServicesService,
      private route                 : ActivatedRoute,
      private router                : Router  ) { }

  ngOnInit() {

    if(localStorage.getItem("itemsperpage")){
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else{
      this.recordsPerPage = 10;
    }
  	this.statusArray=[	{ "data": "Active", value: 1},
  	                    { "data": "Inactive", value: 2}
  	                 ]

  this.queryObject['page'] = this.currentPage;
  this.queryObject['page_limit'] = this.recordsPerPage;
	this.categoryRoleControls();
	this.createRoleForm();
  this.roleListdata();
}


/**
  * @ desc   : method to list roles
  * @ author  :ashiq
  */
   roleListdata() {
    this.loader.display(true);
    this.RoleListingService.getRoleList(this.queryObject, response => {
      if (response.data && response.data.length > 0) {
        this.roleList = response.data;
        this.totalRecords = response.count;
        this.checkProtectedRole();
        this.loader.display(false);
      }
      else {
        this.roleList = [];
        this.loader.display(false);
      }
    })
  }

  /**
  * @ desc   :creating a form group for add and edit role
  * @ author  :ashiq
  */
    createRoleForm(){
			this.roleForm = new FormGroup({
				nameField	  :	this.nameField,
        statusField : this.statusField
			})
		}

 /*
  * @ desc   : creating form controls for role forms
  * @ author  :ashiq
  */
  categoryRoleControls() {
 		this.nameField 			 = new FormControl('', [Validators.required]);
    this.statusField     = new FormControl('', [Validators.required]);
		}

  /**
  * @ desc   : method to check the api responds contain any protected roles
  * @ author  :ashiq
  */
  checkProtectedRole() {
    for (let i = 0; i < this.roleList.length; i++) {
        if (this.roleList[i].is_protected == 0) {
            this.disableSelect = false;
            break;
          }else{
              this.disableSelect = true;
            }
      }
  }
  
 /*
  * @ desc   : close a  add / edit form in active
  * @ author  :ashiq
  */
  toggleForm() {
     this.roleForm.reset();
     this.showForm = false;
     this.submitted  = false;
    
    // (click)="data.editStatus = false;$event.stopPropagation()"
 	 }

     toggleEditForm(data) {
     this.roleForm.reset();
     this.submitted  = false;
     data.editStatus=false;
    // (click)="data.editStatus = false;$event.stopPropagation()"
    }

    closeOthers(index) {
    for (let i = 0; i < this.roleList.length; i++) {
      if (i != index) {
        this.roleList[i].editStatus = false;
      }
    }
  }

  /**
  * @ desc   : Select all the role from role list
  * @ author  :ashiq
  */
  selectAll() {
    this.selectAllStatus = !this.selectAllStatus;
    this.selectedRole.length = 0;
    if (this.selectAllStatus) {
          this.roleList.map((item)=> item.is_protected==1?item.selectStatus=false:item.selectStatus=true)
             var selectedItem =  this.roleList.filter(function (item) {
            return !(item.is_protected === "1");
          });
            this.selectedRole = JSON.parse(JSON.stringify(selectedItem));
      }else{
           this.roleList.map((item)=> item.selectStatus?item.selectStatus=false:item.selectStatus=false)
        }
  }

/*
* @ desc   : individual select of role from role list
* @ author  :ashiq
*/
  itemSelected(data) {
    this.selectAllStatus = false;
    if (data.selectStatus)
        this.selectedRole.push(data);
    else {
      this.selectedRole = this.selectedRole.filter(item => item['id'] !== data.id);
    }
  }

/*
* @ desc   : delete  multiple role from list
* @ author  : ashiq
*/
  multiDelete() {
   if (this.selectedRole.length) {
      let data = []
      Object.keys(this.selectedRole).map((val, k) => {
        data.push(this.selectedRole[val].id)
      })
      this.loader.display(true);
      this.RoleListingService.deleteMultipleRole(data, (response) => {
        if (response.status == "OK") {
           this.selectAllStatus = false;
           this.selectedRole.length=0;
          this.notifications.alertBoxValue("success", response.message);
          this.roleListdata();
          this.checkProtectedRole();
          this.loader.display(false);
        }
        else {
          this.notifications.alertBoxValue("error", response.message);
          this.loader.display(false);
        }
      })
    }
  }

  /*
* @ desc   : confirmation pop up to delete all role list
* @ author  : ashiq
*/
  allDeleteConfirm(event){
     if(event==true){
       this.showConfirmBox=false;
       this.multiDelete()
     }
  }

  /*
   * @desc :method for matching index of two values
   * @auth : Ashiq
   */
  matchingIndex(srcArray, compareValue, key) {
    for (var x in srcArray) {
      if (srcArray[x][key] == compareValue) {
        return x;
      }
    }
    return null;
  }

  /*
   * @ desc   : method for focus cursor in search box of  training list
   * @ author  : ashiq
  */
  inputfocus(){
       setTimeout(() => {this.inputEl.nativeElement.focus();},100)
   }

 /*
  * @ desc   : method for search in  role list
  * @ author  : ashiq
  */
  searchList(keyword) {
     if ( this.searchKeyword || this.searchD.trim() != ''){  
          this.searchKeyword = keyword;
          this.queryObject.keyword = this.searchKeyword ? this.searchKeyword : '';
          this.queryObject.page = 1;
          this.roleListdata();
      }
  }

  /*
  * @ desc   : implement pagination in  role list
  * @ author  : ashiq
  */
  pageChangeEvent(page) {
     this.selectAllStatus = false;
      this.queryObject['page'] = page;
      this.currentPage = page;
      this.roleListdata();
  }
    /*
  * @ desc   : implement pagination in  role list for get next page
  * @ author  : ashiq
  */
   getpage(eve){
      if(eve>10 || this.recordsPerPage != 10){
        this.recordsPerPage = eve;
        this.queryObject['page_limit'] = eve;
        this.queryObject['page'] = 1;
        this.currentPage = 1;
        this.roleListdata();
      }
    }
   
    /*
  * @ desc   : imethod to open add/ edit form for role list
  * @ author  : ashiq
  */
 	 openEditForm(data, event, z){
      this.selectid=data.id;
      data.editStatus = true;
      this.selectedStatusEdit=this.matchingIndex(this.statusArray,data.status,"value")
      this.roleForm.setValue({nameField: data.name,statusField: data.status});
    } 

    /*
  * @ desc   : method to update a role in role list
  * @ author  : ashiq
  */
    editRoleSubmit(){
       if(!this.roleForm.valid){
            this.submitted  = true;
          }
           else{
              this.submitted  = false;
              this.loader.display(true);
              this.roleObj = {
                  "name"        : this.nameField.value,
                  "status"      : this.statusField.value
                }
              this.RoleListingService.editRoleApi(this.selectid,this.roleObj, response => {
                if(response.status == "OK"){
                  this.editStatus =false;
                   this.selectAllStatus=false;
                  this.roleForm.patchValue({
                    nameField: ""
                  })
                  this.router.navigateByUrl("/modules/organization/role");
                  this.roleListdata();
                  setTimeout(() => {
                            this.loader.display(false);
                            this.notifications.alertBoxValue("success", response.message);
                        }, 500);
                }
                if(response.status == "FAIL"){
                  this.loader.display(false);
                  this.notifications.alertBoxValue("error",response.data.name);
                }
             })
          }
     }

    /*
  * @ desc   :filter method  for role list
  * @ author  : ashiq
  */
  advanceFilter(filterData) {
      if(filterData || this.advanceFilterData){
        this.selectAllStatus = false;
        this.advanceFilterData=filterData;
        if(filterData && filterData.status && filterData.status.selected.length) {
           if(filterData.status.selected[0].name == 1)
             this.queryObject.st = 1
           else if(filterData.status.selected[0].name == 2)
             this.queryObject.st = 2
         }
         else {
           this.queryObject.st = null
         }
          if(this.queryObject.st != null){
             this.filterActive = true;
         }
         else{
           this.filterActive = false;
         }
         this.queryObject.page = 1;
         this.roleListdata(); 
      } 
      else{
        filterData= undefined;
      }
    }

  /*
  * @ desc   : status select for add role
  * @ author  : ashiq
  */

     selectStatusData(event){
     	  if (event.selected.length > 0) {
            this.roleForm.patchValue({
              statusField: event.selected[0].value
            })
          }
        else {
            this.roleForm.patchValue({
              statusField: ""
            })
         }
     }
     
  /*
  * @ desc   : status select for edit role
  * @ author  : ashiq
  */
     selectEditStatusData(event){
         if (event.selected.length > 0) {
              this.roleForm.patchValue({
              statusField: event.selected[0].value
            })
          }
        else {
               this.roleForm.patchValue({
                  statusField: ""
                })
             }
      }

  /*
  * @ desc   : method for sorting   training list
  * @ author  : ashiq
  */
  sortStatus(label) {
    let currentSortStatus = this.filterSort[label] ? this.filterSort[label].rev : true;
    this.filterSort = {};
    this.filterSort[label] = { rev: !currentSortStatus }
    this.filterSort["label"] = label;
    this.queryObject.sort = `${this.filterSort[label].rev ? '-' : ''}${label}`
    this.selectAllStatus=false;
    this.roleListdata(); 
  }

  /*
  * @ desc   : method to add a role in role list
  * @ author  : ashiq
  */
    addRole() {
       if(!this.roleForm.valid){
           this.submitted  = true;
        }
         else{
              this.submitted  = false;
              this.loader.display(true);
              this.roleObj = {
                "name"        : this.nameField.value,
                "status"      : this.statusField.value
              }
              this.RoleListingService.addRoleApi(this.roleObj, response => {
                if(response.status == "OK"){
                  this.showForm=false;
                  this.selectAllStatus=false;
                  this.roleForm.patchValue({
                    nameField: ""
                  })
                  this.router.navigateByUrl("/modules/organization/role");
                  this.roleListdata();
                  setTimeout(() => {
                          this.loader.display(false);
                          this.notifications.alertBoxValue("success", response.message);
                      }, 500);
                }
                if(response.status == "FAIL"){
                  this.loader.display(false);
                  this.notifications.alertBoxValue("error",response.data.name);
                }
             })
           }
      }
 /*
  * @desc : calling api for delete a  role from  list
  * @auth : Ashiq
    */
  deleteRole(id){
    this.confirmBox = true;
    this.selectedId = id;
  }
   /*
  * @desc : confirmation pop up for a delete a role from list
  * @auth : Ashiq
    */
   getPopupConfirm(event) {
      this.loader.display(true);
      this.confirmBox = false;
      this.selectAllStatus=false;
      if (event == true) {
          this.RoleListingService.deleteRole(this.selectedId, (response) => {
            if (response.status == 'OK') {
                 setTimeout(() => {
                        this.loader.display(false);
                         this.notifications.alertBoxValue("success", response.message);
                   }, 500);
                  this.roleListdata();
            }
             else {
                  this.notifications.alertBoxValue("error", response.message);
                  this.loader.display(false);
                }
        })
      }
  }

}
