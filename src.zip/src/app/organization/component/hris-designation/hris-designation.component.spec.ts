import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HrisDesignationComponent } from './hris-designation.component';

describe('HrisDesignationComponent', () => {
  let component: HrisDesignationComponent;
  let fixture: ComponentFixture<HrisDesignationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HrisDesignationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HrisDesignationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
