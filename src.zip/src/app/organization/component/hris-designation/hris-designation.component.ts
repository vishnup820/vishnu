/**
* @ name   : HrisDesignationComponent
* @ desc   : Manage Designation List
* @ author : Hashid.n.k
*/

import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { DesignationListingService } from '../../service/designation-listing.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';


@Component({
  selector: 'app-hris-designation',
  templateUrl: './hris-designation.component.html',
  styleUrls: ['./hris-designation.component.css']
})
export class HrisDesignationComponent implements OnInit {

  showForm            : boolean = false;
  designationFormError: boolean = false;
  selectAllStatus     : boolean = false;
  searchTextBox       : boolean = false;
  showConfirmBox      : boolean = false;
  showSearch: boolean;
  showAdvancedFilter: boolean;
  searchKeyword:any = "";
  currentPage           :  number     = 1;
  recordsPerPage        :  number     = 10;
  totalRecords          :  number;
  deleteSingle          : string;
  formPosition           : boolean = false;
  designation         : any;
  filterActive        : boolean = false;
  searchD             :   any;
  filterSort          : any = {};
  advanceFilterData :any;
  chosenObject        : any = {
    selected: {
      status: {}
    },
    status : [
      {label: 'Active', value: 1},
      {label: 'Inactive', value: 2}
    ],
    setEdit : {
      designation : [],
      status: []
    }

  }

  selectedDesignation : Array<object> = [];
  designationForm     : FormGroup;
  name                : FormControl;

  searchValue           :  any;
  queryObject: any ={};
 addClass :boolean=false;
  @ViewChild('foc') inputEl:ElementRef;


  constructor(
    private designationService: DesignationListingService,
    private notifications : NotificationService,
    private loader : LoaderActionsService
    ) { }

  ngOnInit() {
    if(localStorage.getItem("itemsperpage")){
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else{
      this.recordsPerPage = 10;
    }
      this.queryObject = {
        "page": this.currentPage,
        "page_limit": this.recordsPerPage,
      }
  	this.createFormControls();
	  this.createForm();
    this.loadDesignation();

  }

     /**
  * @ desc   : TO implement pagination
  * @ author  : hashid.nk
  */
  pageChangeEvent(page) {
      this.queryObject.page = page;
      this.loadDesignation();
  }
   /**
  * @ desc   : TO perform search operation
  * @ author  : hashid.nk
  */
  inputfocus(){
          setTimeout(() => {this.inputEl.nativeElement.focus();},100)
  }

  searchList(keyword) {
     if ( this.searchKeyword || this.searchD.trim() != ''){
     this.searchKeyword = keyword;
       this.queryObject.keyword = this.searchKeyword?this.searchKeyword:'';
      // this.queryObject.keyword = keyword?keyword:'';
      this.queryObject.page = 1;
      this.loadDesignation();
    }
  }
    /**
  * @ desc   : TO perform advance filter operation
  * @ author  : hashid.nk
  */
  advanceFilter(data) {
    if(data || this.advanceFilterData){
      this.advanceFilterData=data;
      if(data && data.designation && data.designation.selected.length) {
        this.queryObject.desg = data.designation.selected[0].id
      }
      else {
        this.queryObject.desg = null;
      }
      if(data && data.status && data.status.selected.length) {
         if(data.status.selected[0].name == 1)
           this.queryObject.st = 1
         else if(data.status.selected[0].name == 2)
           this.queryObject.st = 2
       }
       else {
         this.queryObject.st = null
       }
       this.queryObject.page = 1;
       if(this.queryObject.desg != null || this.queryObject.st != null){
           this.filterActive = true;
       }
       else{
         this.filterActive = false;
       }
      this.loadDesignation();
    }
    else{
      data= undefined;
    }
  }


    //       if(data.department && data.department.selected.length) {
    //     this.queryObject.dept = data.department.selected[0].id
    //   }
    //   if(data.status && data.status.selected.length) {
    //      if(data.status.selected[0].name == 1)
    //        this.queryObject.st = 1
    //      else if(data.status.selected[0].name == 2)
    //        this.queryObject.st = 2
    //    }
    //   this.loadDepartments();
    // }




   /**
  * @ desc   : Load Designation
  * @ author  : Hashid.n.k
  */


  loadDesignation() {
      let self = this;
      self.loader.display(true);
      this.designationService.getDesignation(this.queryObject,function(res){
        if(res) {
        self.designation = res.data;
        self.resetDesignation();
        self.currentPage = self.queryObject.page;
        self.totalRecords = res.count;
        self.loader.display(false);
        } else {
          self.designation = [];self.loader.display(false);
        }
    });
  }

     /**
  * @ desc   : reset Designation
  * @ author  : Hashid.n.k
  */


  resetDesignation() {
      this.designationForm.reset();
    this.selectedDesignation.length = 0;
    this.selectAllStatus           = false;

  }
      /**
  * @ desc   : reset Designation
  * @ author  : Hashid.n.k
  */


  createDesForm() {
    let form = {
      name: this.name.value,
      status: this.chosenObject.selected.status.selected[0].value
    }
      return form
  }

      /**
  * @ desc   : reset Designation
  * @ author  : Hashid.n.k

  */
  editForm(data) {
      if(!this.designationForm.valid || (this.chosenObject.selected.status.selected && this.chosenObject.selected.status.selected.length == 0)){
            this.designationFormError = true;
        } else {
          this.loader.display(true);
          let self = this;
          this.designationService.editDesignation(this.createDesForm(), data.id, (response) => {
             if (response.status == "OK") {

             this.loadDesignation()
             this.notifications.alertBoxValue("success", response.message);
             setTimeout(function(){
               self.loader.display(false);
              },600);
             }
             else{
               this.notifications.alertBoxValue("error", response.message);
               setTimeout(function() {
                 self.loader.display(false);
               },600);
             }
           })
        }
  }
     /**
  * @ desc   : delete  Designation from list
  * @ author  : Hashid.n.k

      let temp = [];
    for (var i = 0; i < this.tableData.length; i++) {
      if (this.tableData[i].checked) {
        temp.push(this.tableData[i].id);
      }
    }
    this.apiService.deleteMultipleCalender({ "id": temp }, response => {
      if (response.status == "OK") {
        this.getData(this.currentPage);
        this.notifications.alertBoxValue("success", response.message);
      }
      else {
        this.notifications.alertBoxValue("error", response.message);
      }
    })
  }
  */


  deleteDesignation(id) {
     this.loader.display(true);
      this.designationService.deleteDesignation(id, (response) => {
        if (response.status == "OK") {
           this.loadDesignation();
           this.notifications.alertBoxValue("success", response.message);
            this.loader.display(false);
         }
         else{
           this.notifications.alertBoxValue("error", response.message);
            this.loader.display(false);
         }

      })
  }

       /**
  * @ desc   : delete multiple Designation from list
  * @ author  : Hashid.n.k
  */


  multiDelete() {
      if(this.selectedDesignation.length) {
        let data = []
        Object.keys(this.selectedDesignation).map( (val,k) => {
          data.push(this.selectedDesignation[val].id)
        })
        this.designationService.deleteMultipleDesignation(data, (response) => {
          if (response.status == "OK") {
           this.loadDesignation();
           this.notifications.alertBoxValue("success", response.message);
         }
         else{
           this.notifications.alertBoxValue("error", response.message);
         }
        })
      }
  }
    /**
  * @ desc   :  delete confirmation
  * @ author  : hashid.nk
  */
  confirmPopup() {
      if(this.deleteSingle) {
        this.deleteDesignation(this.deleteSingle)
      } else {
        this.multiDelete()
      }
      this.queryObject.page = 1;
      this.showConfirmBox = false;
  }

         /**
  * @ desc   : TO ADD NEW  Designation TO list
  * @ author  : Hashid.n.k
  */

  submitForm() {
if(!this.designationForm.valid || (this.chosenObject.selected.status.selected && this.chosenObject.selected.status.selected.length == 0)){
            this.designationFormError = true;
        } else {
          this.loader.display(true);
          let form = {
            name: this.name.value,
            status: this.chosenObject.selected.status.selected[0].value
          }

           this.designationService.addDesignation(form, (response) => {
            if (response.status == "OK") {
             this.toggleForm(null);
             this.designationFormError = false;
             this.loadDesignation()
             this.showForm = false;
             this.notifications.alertBoxValue("success", response.message);
             this.loader.display(false);
             }
             else{
                this.showForm = false;
                this.notifications.alertBoxValue("error", response.message);
                this.loader.display(false);
             }
           })
        }
  }


  createFormControls() {
		this.name = new FormControl('', [Validators.required,this.noWhitespaceValidator]);
  }

      /*
    author : Arun Johnson
    desc   : validation for white space in form
    params :
  */
  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }

  createForm(): void {
 	  this.designationForm = new FormGroup({
	  name: this.name,
 	  });
  }


  /**
  * @ desc   : Select all the designation and update the status
  * @ author  : Hashid.n.k
  */
  selectAll() {
    this.selectAllStatus = !this.selectAllStatus;
    this.selectedDesignation.length = 0;
    this.designation.map((item) => item.selectStatus = this.selectAllStatus ? true : false);

    if (this.selectAllStatus) {
      this.selectedDesignation = JSON.parse(JSON.stringify(this.designation));
    }
  }

    /**
  * @ desc   : Select single designation and update selected array
  * @ author  :Hashid.n.k
  */

  itemSelected(data) {
    this.selectAllStatus = false;

    if (data.selectStatus)
      this.selectedDesignation.push(data);
    else {
      this.selectedDesignation = this.selectedDesignation.filter(designation => designation['id'] !== data.id);
    }
  }


  /**
  * @ desc   : Sort designation list according to the label
  * @ author  : Hashid.n.k
  */
  sortDesignation(label) {
    let currentSortStatus = this.filterSort[label]?this.filterSort[label].rev: true;
    this.filterSort = {};
    this.filterSort[label] = {rev:!currentSortStatus}
    this.filterSort["label"] = label;
    this.queryObject.sort = `${this.filterSort[label].rev? '-': ''}${label}`
    this.loadDesignation()
  }


  toggleForm(event) {
    this.showForm = !this.showForm;
    if(this.showForm){
      this.addClass = true;
    }
    else{
      this.addClass  = false;
    }
     this.designationForm.reset();
     this.designationFormError = false;
    // event?event.stopPropagation(): '';
  }

 /**
  * @ desc   : To perfom edit operation on list
  * @ author  : Hashid.n.k
  */
  openEditForm(data,event,z) {
      let yPosition = event.clientY;
      let innerheight = document.getElementById("userslist").clientHeight;
      if(((innerheight)/2) < yPosition && (z>3)){
        this.formPosition = true;
      }
      else{
       this.formPosition = false;
      }
      data.editStatus = true;
      this.chosenObject.setEdit.designation = [];
      this.chosenObject.setEdit.status = [];

      this.designation.filter((designation, index) => {
        if(designation['id'] == data.parent_id) {
          this.chosenObject.setEdit.designation.push(index)
        }
    })
    if(this.chosenObject.setEdit.designation.length == 0) {
      this.chosenObject.setEdit.designation.push(0)
    }
    this.chosenObject.status.filter((status, index) => {
        if(status['value'] == data.status) {
          this.chosenObject.setEdit.status.push(index)
        }
      })
      if(this.chosenObject.setEdit.status.length == 0) {
      this.chosenObject.setEdit.status.push(0)
    }

      this.designationForm.patchValue({
        name: data.name,
    });
  }

  getpage(eve){
    // if(eve>0){
    //   this.queryObject['page_limit'] = eve;
    //   this.recordsPerPage = eve;
    //   this.currentPage = 1;
    //   this.loadDesignation();
    // }
    // else{
    //   this.queryObject['page_limit'] = 10;
    //   this.recordsPerPage = 10;
    //   this.currentPage = 1;
    //   this.loadDesignation();
    // }
    if(eve>10 || this.recordsPerPage != 10){
      this.recordsPerPage = eve;
      this.queryObject['page_limit'] = eve;
      this.queryObject['page'] = 1;
      this.currentPage = 1;
      this.loadDesignation();
    }
    // else{
    //   this.recordsPerPage = 10;
    //   this.queryObject['page_limit'] = eve;
    //   this.queryObject['page'] = 1;
    //   this.currentPage = 1;
    //   this.loadDesignation();
    // }
  }
}
