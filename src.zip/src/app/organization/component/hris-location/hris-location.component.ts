/**
* @ name   : HrisLocationComponent
* @ desc   : Manage Location List
* @ author  : vinod.k
*/
import { Component, OnInit ,ViewChild,ElementRef,ChangeDetectorRef} from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import { LocationListService } from '../../service/location-list.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { ConstantServicesService } from '../../../shared/services/constant/constant-services.service';

@Component({
  selector: 'app-hris-location',
  templateUrl: './hris-location.component.html',
  styleUrls: ['./hris-location.component.css']
})
export class HrisLocationComponent implements OnInit {


	showForm	        : boolean = false;
  showSearch        : boolean;
  showAdvancedFilter: boolean;
	locationFormError : boolean = false;
  selectAllStatus   : boolean = false;
  showConfirmBox    : boolean = false;
  mulDelete         : boolean = false;
  searchTextBox     : boolean = false;
  searchKeyword     : any="";
	selectedLocationt : Array<object> = [];
	locName		        : FormControl;
	address		        : FormControl;
  longitude         : FormControl;
  lattitude         : FormControl;
  locationForm      : FormGroup;
  formPosition      : boolean = false;
  location          : any = [];
  countries         : any;
  searchD           : any;
  filterSort        : any = {};
  deleteSingle      : string;
  queryObject       : any ={};
  currentPage       : number = 1;
  recordsPerPage    : number = 10;
  totalRecords      : number;
  addClass          : boolean=false
  displayMultiSelect: boolean;
  filterActive      : boolean = false;
  dataa             : any;
  j                 : number = 1;
  timeZonedisable   : boolean = false;
  timeZoneEditdisable:boolean = false;
  zones             : any;
  tzone             : any = [];
  k                 : boolean = false;
  advanceFilterData  :any;

  @ViewChild('foc') inputEl:ElementRef;
  chosenObject          : any = {
    selected: {
      status: {},
      countries : {},
      timezones : {}
    },
    status : [
      {label: 'Active', value: 1},
      {label: 'Inactive', value: 2}
    ],
    setEdit : {
      countries : [],
      status: [],
      timezones:[]

    }
  }

  constructor(
  	private locationService: LocationListService,
    private notifications : NotificationService,
    private loader : LoaderActionsService,
    private constantServicesService : ConstantServicesService,
    private changeDetectorRef:ChangeDetectorRef) { }

  ngOnInit() {
    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    this.queryObject = {
      "page": this.currentPage,
      "page_limit": this.recordsPerPage,
    }
    this.createFormControls();
    this.createForm();
    this.loadLocation();
    this.loadCountry();
  }
  /**
* @ desc   : TO implement pagination
* @ author  : vinod.k
*/
  pageChangeEvent(page) {
    this.queryObject.page = page;
    this.loadLocation();
  }
  /**
 * @ desc   : TO perform search operation
 * @ author  : vinod.k
 */
  searchList(keyword) {
    if (this.searchKeyword || this.searchD.trim() != '') {
      this.searchKeyword = keyword;
      this.queryObject.keyword = this.searchKeyword ? this.searchKeyword : '';
      this.queryObject.page = 1;
      this.loadLocation();
    }
  }


  /**
* @ desc   : TO perform advance filter operation
* @ author  : vinod.k
*/
  advanceFilter(data) {
    if (data || this.advanceFilterData) {
      this.advanceFilterData = data;
      if (data && data.location && data.location.selected.length) {
        this.queryObject.loc = data.location.selected[0].id
      } else {
        this.queryObject.loc = null
      }

      if (data && data.status && data.status.selected.length) {
        this.queryObject.status = data.status.selected[0].name
      } else {
        this.queryObject.status = null;
      }
      this.queryObject.page = 1
      if (this.queryObject.loc != null || this.queryObject.status != null) {
        this.filterActive = true;
      }
      else {
        this.filterActive = false;
      }
      this.loadLocation();
    }
    else {
      data = undefined;
    }
  }
  /**
* @ desc   : to focus to input
* @ author  : vinod.k
*/

  inputfocus() {
    setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
  }

  /**
* @ desc   : to remove edit popup
* @ author  : vinod.k
*/
  removeEditpopup() {
    if (this.dataa) {
      this.dataa.editStatus = false;
    }
  }
  /**
* @ desc   : TO close the add and edit form
* @ author  : vinod.k
*/

  toggleForm(event) {
    this.showForm = !this.showForm;
    if (this.dataa) {
      this.dataa.editStatus = false;
    }
    if (this.showForm) {
      this.addClass = true;
    }
    else {
      this.addClass = false;
    }
    this.locationForm.reset();
    this.locationFormError = false;
    // event?event.stopPropagation(): '';
  }

  /**
* @ desc   : To loard the country list to add and edit form
* @ author  : vinod.k
*/


  loadCountry() {
    this.loader.display(true);
    let self = this;
    this.locationService.getCountry(function(res) {
      self.countries = res.data;
      self.loader.display(false);
    });

  }

  /**
* @ desc   : to reset Location after updating the main list
* @ author  : vinod.k
*/
  resetLocation() {
    this.locationForm.reset();
    this.selectedLocationt.length = 0;
    this.selectAllStatus = false;

  }

  /**
* @ desc   : subsidery function for edit form
* @ author  : vinod.k
*/
  createLocForm() {
    let form = {
      name: this.locName.value,
      country_id: (this.chosenObject.selected.countries.selected.length > 0) ? this.chosenObject.selected.countries.selected[0].id : null,
      status: this.chosenObject.selected.status.selected[0].value,
      address: this.address.value,
      lng: this.longitude.value,
      lat: this.lattitude.value,
      time_zone: (this.chosenObject.selected.timezones.selected.length > 0) ? this.chosenObject.selected.timezones.selected[0].name : null,
    }
    return form
  }

  /**
* @ desc   : to perform edit
* @ author  : vinod.k
*/
  editForm(data) {
    this.k = true;
    if (!this.locationForm.valid || (this.chosenObject.selected.status.selected && this.chosenObject.selected.status.selected.length == 0) || (this.chosenObject.selected.timezones.selected && this.chosenObject.selected.timezones.selected.length == 0) || (this.chosenObject.selected.countries.selected && this.chosenObject.selected.countries.selected.length == 0)) {
      this.locationFormError = true;
    } else {
      let self = this;
      this.loader.display(true);
      this.locationService.editLocation(this.createLocForm(), data.id, (response) => {
        if (response.status == "OK") {
          this.notifications.alertBoxValue("success", response.message);
          this.loadLocation()
          // setTimeout(function() {
            self.loader.display(false);
          // }, 600);
        }
        else {
          this.notifications.alertBoxValue("error", response.message);
          setTimeout(function() {
            self.loader.display(false);
          }, 600);
        }
      })
    }
  }

  /**
* @ desc   : To load location list
* @ author  : vinod.k
*/


  loadLocation() {
    let self = this;
    self.loader.display(true);
    this.locationService.getLocation(this.queryObject, function(res) {
      if (res) {
        self.location = res.data;
        self.resetLocation();
        self.totalRecords = res.count;
        self.currentPage = self.queryObject.page;
        self.loader.display(false);
      } else {
        self.location = [];
        self.loader.display(false);
      }
    });
  }



  /**
* @ desc   : To sort location
* @ author  : vinod.k
*/



  sortLocation(label) {
    let currentSortStatus = this.filterSort[label] ? this.filterSort[label].rev : true;
    this.filterSort = {};
    this.filterSort[label] = { rev: !currentSortStatus }
    this.filterSort["label"] = label;
    this.queryObject.sort = `${this.filterSort[label].rev ? '-' : ''}${label}`
    this.loadLocation();
  }
  /**
* @ desc   : for validation
* @ author  : vinod.k
*/
  createFormControls() {
    this.locName = new FormControl('', [Validators.required, this.noWhitespaceValidator]);
    this.address = new FormControl('', [Validators.required, this.noWhitespaceValidator]);
    this.longitude = new FormControl('');
    this.lattitude = new FormControl('');
  }
  /*
author : vinod.k
desc   : validation for white space in form
params :
*/
  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }
  /**
* @ desc   : for form validation
* @ author  :vinod.k
*/

  createForm(): void {
    this.locationForm = new FormGroup({
      locName: this.locName,
      address: this.address,
      longitude: this.longitude,
      lattitude: this.lattitude
    });
  }
  /**
* @ desc   : To perform mult-selection from main list
* @ author  : vinod.k
*/
  selectAll() {
    this.selectAllStatus = !this.selectAllStatus;
    this.selectedLocationt.length = 0;
    this.location.map((item) => item.selectStatus = this.selectAllStatus ? true : false);

    if (this.selectAllStatus) {
      this.selectedLocationt = JSON.parse(JSON.stringify(this.location));
    }
  }
  /**
* @ desc   : To select a location
* @ author  : vinod.k
*/

  itemSelected(data) {
    this.selectAllStatus = false;

    if (data.selectStatus)
      this.selectedLocationt.push(data);
    else {
      this.selectedLocationt = this.selectedLocationt.filter(location => location['id'] !== data.id);
    }
  }

  /**
* @ desc   : form to add new location
* @ author  : vinod.k
*/

  submitForm() {
    if (!this.locationForm.valid || (this.chosenObject.selected.status.selected && this.chosenObject.selected.status.selected.length == 0) || (this.chosenObject.selected.timezones.selected && this.chosenObject.selected.timezones.selected.length == 0) || (this.chosenObject.selected.countries.selected && this.chosenObject.selected.countries.selected.length == 0)) {
      this.locationFormError = true;
    } else {
      this.loader.display(true);
      let form = {
        name: this.locName.value,
        status: this.chosenObject.selected.status.selected[0].value,
        country_id: (this.chosenObject.selected.countries.selected.length > 0 && this.chosenObject.selected.countries) ? this.chosenObject.selected.countries.selected[0].id : null,
        address: this.address.value,
        lng: this.longitude.value,
        lat: this.lattitude.value,
        time_zone: (this.chosenObject.selected.timezones.selected.length > 0) ? this.chosenObject.selected.timezones.selected[0].name : null,
      }

      this.locationService.addLocation(form, (response) => {

        if (response.status == "OK") {
          this.loader.display(false);
          this.notifications.alertBoxValue("success", response.message);
          this.toggleForm(null);
          this.locationFormError = false;
          this.loadLocation();
        }
        else {
          this.loader.display(false);
          this.notifications.alertBoxValue("error", response.message);
        }

      })
    }
  }

  /**
* @ desc   : to delete location from location list
* @ author  :vinod.k
*/


  deleteLocation(id) {
    this.loader.display(true);
    this.locationService.deleteLocation(id, (response) => {
      if (response.status == "OK") {
        this.loadLocation();
        this.notifications.alertBoxValue("success", response.message);
        this.loader.display(false);
      }
      else {
        this.notifications.alertBoxValue("error", response.message);
        this.loader.display(false);
      }
    })
  }

  /**
* @ desc   : to delete multiple -location from location list
* @ author  : vinod.k
*/

  multiDelete() {
    if (this.selectedLocationt.length) {
      let data = []
      Object.keys(this.selectedLocationt).map((val, k) => {
        data.push(this.selectedLocationt[val].id)
      })
      this.loader.display(true);
      this.locationService.deleteMultipleLocation(data, (response) => {
        if (response.status == "OK") {
          this.loadLocation();
          this.notifications.alertBoxValue("success", response.message);
          this.loader.display(false);
        }
        else {
          this.notifications.alertBoxValue("error", response.message);
          this.loader.display(false);
        }
      })
    }
  }

  /**
* @ desc   :  delete confirmation
* @ author  : vinod.k
*/


  confirmPopup() {
    if (this.deleteSingle) {
      this.deleteLocation(this.deleteSingle)
    } else {
      this.multiDelete()
    }
    this.queryObject.page = 1;
    this.showConfirmBox = false;
  }


  /**
* @ desc   : form to perform edit
* @ author  : vinod.k
*/

  loadTimeZone(event) {
    var self = this;
    if (event && event.selected.length > 0) {
      self.locationService.gettimezones(event.selected[0].id, function(res) {
        if (res) {
          self.timeZonedisable = false;
          self.tzone = res.data[0].timezone.time_zone;
        }
      });
    }
    else {
      self.timeZonedisable = true;
    }
  }
  /*
  * @ desc   : function to open editform
  * @ author  : vinod.k
  */
  openEditForm(data, event, z) {
    this.k = false;
    let yPosition = event.clientY;
    let innerheight = document.getElementById("userslist").clientHeight;
    if (((innerheight) / 2) < yPosition && (z > 3)) {
      this.formPosition = true;
    }
    else {
      this.formPosition = false;
    }
    // data.editStatus = true;
    let target = event.target || event.srcElement || event.currentTarget;
    let idAttr = event.target.id;
    this.dataa = data;
    if (idAttr == "a") {
      var self = this;
      for (var i = 0; i < self.location.length; i++) {
        if (self.location[i].id == data.id) {
          data.editStatus = true;
        }
        else {
          self.location[i].editStatus = false;
        }
      }
      this.chosenObject.setEdit.countries = [];
      this.chosenObject.setEdit.status = [];
      this.chosenObject.setEdit.timezones = [];
      this.countries.filter((countries, index) => {
        if (countries['id'] == data.country_id) {
          this.chosenObject.setEdit.countries.push(index)
        }
      })
      this.chosenObject.status.filter((status, index) => {
        if (status['value'] == data.status) {
          this.chosenObject.setEdit.status.push(index)
        }
      })
      if (this.chosenObject.setEdit.status.length == 0) {
        this.chosenObject.setEdit.status.push(0)
      }
      this.locationForm.patchValue({
        locName: data.name,
        address: data.address,
        longitude: data.lng,
        lattitude: data.lat
      });

      if (data.country_id) {
        self.locationService.gettimezones(data.country_id, function(res) {
          if (res) {
            self.tzone = res.data[0].timezone.time_zone;
            self.timeZonedisable = false;
            for (var i = 0; i < self.tzone.length; i++) {
              if (self.tzone[i].name == data.time_zone) {
                self.chosenObject.setEdit.timezones = [i];
                break;
              }
            }
          }
        });
      }
      else {
        self.timeZonedisable = true;
      }
      self.k = true;
    }
  }

  /*
  * @ desc   : functiom to load timezone based on country selection
    * @ author  : vinod.k
    */
  loadTimeZoneonEdit(event) {
    var self = this;
    if (self.k == false && self.j == 2 && event && event.selected.length > 0) {
      self.locationService.gettimezones(event.selected[0].id, function(res) {
        if (res) {
          self.timeZoneEditdisable = false;
          // this.changeDetectorRef.detectChanges();
          self.tzone = res.data[0].timezone.time_zone;
        }
      });
    }
    else if (event && event.selected.length > 0) {
      self.timeZoneEditdisable = false;
    }
    else {
      self.timeZoneEditdisable = true;
      this.tzone = [];
    }
    self.j = 2;
  }

  getpage(eve) {
    if (eve > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = eve;
      this.queryObject['page_limit'] = eve;
      this.queryObject['page'] = 1;
      this.currentPage = 1;
      this.loadLocation();
    }
  }
}