import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HrisLocationComponent } from './hris-location.component';

describe('HrisLocationComponent', () => {
  let component: HrisLocationComponent;
  let fixture: ComponentFixture<HrisLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HrisLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HrisLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
