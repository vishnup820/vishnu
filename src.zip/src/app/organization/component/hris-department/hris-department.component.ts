/**
* @ name 	: HrisDepartmentComponent
* @ desc 	: Manage Department List
* @ author	: hashid
*/
import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { DepartmentListingService } from '../../service/department-listing.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { ConstantServicesService } from '../../../shared/services/constant/constant-services.service';

@Component({
  	selector: 'app-hris-department',
  	templateUrl: './hris-department.component.html',
  	styleUrls: ['./hris-department.component.css']
})

export class HrisDepartmentComponent implements OnInit {

	showForm: boolean = false;
  showSearch: boolean;
  showAdvancedFilter: boolean;
	selectAllStatus: boolean = false;
	departmentFormError: boolean = false;
	selectedDepartment: Array<object> = [];

	deleteSingle: string;
	showConfirmBox: boolean = false;
  searchKeyword :any = "";
	queryObject: any ={};
  formPosition : boolean = false;
	department:any = [];
  searchD :any;
  pardepartment:any =[];
  fullDepartment: any = [];
  filterActive:boolean = false;
  advanceFilterData :any;
	chosenObject: any = {
		selected: {
			department : {},
			status: {}
		},
		status : [
			{label: 'Active', value: 1},
			{label: 'Inactive', value: 2}
		],
		setEdit : {
			department : [],
			status: []
		}

	}

	filterSort : any = {};

	currentPage           : number = 1;
    recordsPerPage        : number = 10;
    totalRecords          : number;
  searchTextBox : boolean = false;
	departmentForm: FormGroup;
	name: FormControl;
  isOn :boolean=false;
  addClass  : boolean=false;
  displayMultiSelect: boolean;
  dataa :any;
  @ViewChild('foc') inputEl:ElementRef;
	constructor(
		private departmentService: DepartmentListingService,
		private notifications : NotificationService,
    private loader: LoaderActionsService,
    private constantServicesService:ConstantServicesService
	) { }

  ngOnInit() {
    if(localStorage.getItem("itemsperpage")){
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else{
      this.recordsPerPage = 10;
    }
    this.queryObject = {
      "page": this.currentPage,
      "page_limit": this.recordsPerPage,
    }
		this.createFormControls();
		this.createForm();
		this.loadDepartments();
  }

  setDepartment(department) {
    if (department) {
      this.fullDepartment = department;
    }
  }

  resetDepartment() {
    this.departmentForm.reset();
		this.selectedDepartment.length = 0;
		this.selectAllStatus = false;
  }
  inputfocus() {
    setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
  }

  /**
* @ desc 	: Load Department
* @ author	: hahid
*/
  loadDepartments() {
    // if(this.queryObject.dept != null || this.queryObject.st != null){
    //      this.filterActive = true;
    //  }
    let self = this;
    self.loader.display(true);
    this.departmentService.getDepartment(this.queryObject, function(res) {
      if (res) {
				self.department = res.data;
				self.resetDepartment();
				self.totalRecords = res.count;
				self.currentPage = self.queryObject.page;
        self.loader.display(false);
      } else {
        self.department = [];
        self.loader.display(false);
      }
		});
  }


  /*
author : hashid.nk
desc   : form controll
params :
*/

  createFormControls() {
		this.name = new FormControl('', [Validators.required, this.noWhitespaceValidator]);

  }
  //   closeAll() {
  //     this.displayMultiSelect = true;
  //      this.constantServicesService.popupStatus(this.displayMultiSelect);
  // }

  /*
author : hashid.nk
desc   : validation for white space in form
params :
*/
  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }



	createForm(): void {
		this.departmentForm = new FormGroup({
      name: this.name,
		});
	}

	/**
	* @ desc 	: Sort department list according to the label
	* @ author	: hashid
	*/
	sortDepartment(label) {
		let currentSortStatus = this.filterSort[label] ? this.filterSort[label].rev : true;
		this.filterSort = {};
		this.filterSort[label] = { rev: !currentSortStatus }
		this.filterSort["label"] = label;
		this.queryObject.sort = `${this.filterSort[label].rev ? '-' : ''}${label}`
		this.loadDepartments();
	}

	/**
	* @ desc 	: Select all the department and update the status
	* @ author	: hashid
	*/
  selectAll() {
		this.selectAllStatus = !this.selectAllStatus;
		this.selectedDepartment.length = 0;
		this.department.map((item) => item.selectStatus = this.selectAllStatus ? true : false);

		if (this.selectAllStatus) {
      this.selectedDepartment = JSON.parse(JSON.stringify(this.department));
		}
  }

  /**
* @ desc 	: Select single department and update selected array
* @ author	:hashid
*/
  itemSelected(data) {
		this.selectAllStatus = false;

		if (data.selectStatus)
      this.selectedDepartment.push(data);
		else {
      this.selectedDepartment = this.selectedDepartment.filter(department => department['id'] !== data.id);
		}
  }


  /**
* @ desc 	: create a department form
* @ author	: hahid
*/


  createDepForm() {
    let form = {
      name: this.name.value,
      parent_id: this.chosenObject.selected.department.selected.length ? this.chosenObject.selected.department.selected[0].id : null,
      status: this.chosenObject.selected.status.selected[0].value
    }
    return form
  }

  /**
* @ desc 	: validate and submit form
* @ author	: hahid
*/

  submitForm() {
    if (!this.departmentForm.valid || (this.chosenObject.selected.status.selected && this.chosenObject.selected.status.selected.length == 0)) {
      this.departmentFormError = true;
    } else {
      this.loader.display(true);
      this.departmentService.addDepartment(this.createDepForm(), (response) => {
        if (response.status == "OK") {
          this.notifications.alertBoxValue("success", response.message);
          this.toggleForm(null);
          this.departmentFormError = false;

          this.loadDepartments();
          this.loader.display(false);
        }
        else {
          this.notifications.alertBoxValue("error", response.message);
          this.loader.display(false);
        }
      })
    }
  }


  /**
* @ desc 	: validate and edit form
* @ author	: hahid
*/


  editForm(data) {
    if (!this.departmentForm.valid || (this.chosenObject.selected.status.selected && this.chosenObject.selected.status.selected.length == 0)) {
      this.departmentFormError = true;
    } else {
      this.loader.display(true);
      let self = this;
      this.departmentService.editDepartment(this.createDepForm(), data.id, (response) => {
        if (response.status == "OK") {
          this.notifications.alertBoxValue("success", response.message);
          this.loadDepartments();
          setTimeout(function() {
            self.loader.display(false);
          }, 600);
        }
        else {
          this.notifications.alertBoxValue("error", response.message);
          setTimeout(function() {
            self.loader.display(false);
          }, 600);
        }
      })
    }
  }

  /**
* @ desc 	: delete department from list
* @ author	: hahid
*/
  deleteDepartment(id) {
    this.loader.display(true);
    this.departmentService.deleteDepartment(id, (response) => {
      if (response.status == "OK") {
        this.notifications.alertBoxValue("success", response.message);
        this.loadDepartments();
        this.loader.display(false);
      }
      else {
        this.notifications.alertBoxValue("error", response.message);
        this.loader.display(false);
      }
    })
  }

  /**
* @ desc 	: delete  multiple department from list
* @ author	: hahid
*/

  multiDelete() {
    if (this.selectedDepartment.length) {
      let data = []
      Object.keys(this.selectedDepartment).map((val, k) => {
        data.push(this.selectedDepartment[val].id)
      })
      this.loader.display(true);
      this.departmentService.deleteMultipleDepartment(data, (response) => {
        if (response.status == "OK") {
          this.notifications.alertBoxValue("success", response.message);
          this.loadDepartments();
          this.loader.display(false);
        }
        else {
          this.notifications.alertBoxValue("error", response.message);
          this.loader.display(false);
        }
      })
    }
  }
  /**
* @ desc   :  delete confirmation
* @ author  : hashid.nk
*/


  confirmPopup() {
    if (this.deleteSingle) {
      this.deleteDepartment(this.deleteSingle)
    } else {
      this.multiDelete()
    }
    this.queryObject.page = 1;
    this.showConfirmBox = false;
  }
  removeEditpopup() {
    if (this.dataa) {
      this.dataa.editStatus = false;
    }
  }
  /**
* @ desc 	: toggle department form
* @ author	: hahid
*/

  toggleForm(event) {
    let self = this;
    setTimeout(function() {
      for (let i = 0; i < self.department.length; i++) {
        if (self.department[i].name == "Select" || self.department[i].name == "select") {
          self.department.splice(i, 1);
        }
      }
    });
    this.showForm = !this.showForm;
    if (this.dataa) {
      this.dataa.editStatus = false;
    }
    if (this.showForm) {
      this.addClass = true;
    }
    else {
      this.addClass = false;
    }

		this.departmentForm.reset();
    this.departmentFormError = false;
  }

  searchList(keyword) {
      if ( this.searchKeyword || this.searchD.trim() != ''){  
      this.searchKeyword = keyword;
      this.queryObject.keyword = this.searchKeyword ? this.searchKeyword : '';
      this.queryObject.page = 1;
      this.loadDepartments();
    }
  }

  setListData(event) {
    this.chosenObject.selected.department = event;
  }

  pageChangeEvent(page) {
    this.queryObject.page = page;
    this.loadDepartments();
  }

  advanceFilter(data) {
    if(data || this.advanceFilterData){
     this.advanceFilterData=data;
      if (data && data.department && data.department.selected.length) {
        this.queryObject.dept = data.department.selected[0].id
      } else {
        this.queryObject.dept = null;
      }
      if (data && data.status != null && data.status.selected.length) {
        if (data.status.selected[0].name == 1)
          this.queryObject.st = 1
        else if (data.status.selected[0].name == 2)
          this.queryObject.st = 2
      } else {
        this.queryObject.st = null
      }
      // this.loadDepartments();
      this.queryObject.page = 1
      if (this.queryObject.dept != null || this.queryObject.st != null) {
        this.filterActive = true;
      }
      else {
        this.filterActive = false;
      }
      this.loadDepartments();
    }else{
      this.advanceFilterData= undefined;
    }
    
    
  }

  /**
* @ desc   : Load  PARENT Department to the add portion
* @ author  : hahid
*/
  loadParentDepartments(id, cb) {
    let self = this;
    this.departmentService.getParentDepartment(id, function(res) {
      if (res) {
        self.pardepartment = res.data;
        cb();
      } else {
        self.pardepartment = [];
      }
    });
  }
  /**
* @ desc 	: To edit data from available list
* @ author	: hahid
*/

  openEditForm(data, event, z) {
    let yPosition = event.clientY;
    let innerheight = document.getElementById("userslist").clientHeight;
    if (((innerheight / 2) + 50) < yPosition && (z > 3)) {
      this.formPosition = true;
    }
    else {
      this.formPosition = false;
    }
    let target = event.target || event.srcElement || event.currentTarget;
    let idAttr = event.target.id;
    this.dataa = data;
    if (idAttr == "a") {
      let self = this;
      for (var i = 0; i < self.department.length; i++) {
        if (self.department[i].id == data.id) {
          data.editStatus = true;
        }
        else {
          self.department[i].editStatus = false;
        }
      }
      this.loadParentDepartments(data.id, function() {
        self.chosenObject.setEdit.department = [];
        self.chosenObject.setEdit.status = [];
        self.pardepartment.filter((pardepartment, index) => {
          if (pardepartment['id'] == data.parent_id) {
            self.chosenObject.setEdit.department.push(index);
          }
        })
        self.chosenObject.status.filter((status, index) => {
          if (status['value'] == data.status) {
            self.chosenObject.setEdit.status.push(index)
          }
        })
      });
      self.departmentForm.patchValue({
        name: data.name,
      });
    }
  }
  getpage(eve){
    if(eve>10 || this.recordsPerPage != 10){
      this.recordsPerPage = eve;
      this.queryObject['page_limit'] = eve;
      this.queryObject['page'] = 1;
      this.currentPage = 1;
      this.loadDepartments();
    }
    // else{
    //   this.recordsPerPage = 10;
    //   this.queryObject['page_limit'] = eve;
    //   this.queryObject['page'] = 1;
    //   this.currentPage = 1;
    //   this.loadDepartments();
    // }
  }
}
