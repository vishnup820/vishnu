import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HrisDepartmentComponent } from './hris-department.component';

describe('HrisDepartmentComponent', () => {
  let component: HrisDepartmentComponent;
  let fixture: ComponentFixture<HrisDepartmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HrisDepartmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HrisDepartmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
