import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HrisGroupComponent } from './hris-group.component';

describe('HrisGroupComponent', () => {
  let component: HrisGroupComponent;
  let fixture: ComponentFixture<HrisGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HrisGroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HrisGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
