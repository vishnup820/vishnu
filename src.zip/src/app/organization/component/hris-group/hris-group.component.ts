/**
* @ name   : HrisGroupComponent
* @ desc   : Manage group List
* @ author  : hashid.nk
*/
import { Component, OnInit ,ViewChild,ElementRef} from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import { GroupListService } from '../../service/group-list.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';

@Component({
  selector: 'app-hris-group',
  templateUrl: './hris-group.component.html',
  styleUrls: ['./hris-group.component.css']
})
export class HrisGroupComponent implements OnInit {

  showForm  		: boolean = false;
  showSearch: boolean;
  showAdvancedFilter: boolean;
  showConfirmBox	: boolean = false;
  selectAllStatus	: boolean = false;
  groupFormError	: boolean = false;
  searchTextBox     : boolean = false;
  currentPage       : number = 1;
  recordsPerPage    : number = 10;
  searchKeyword     : any="";
  totalRecords      : number;
  searchValue       : any;
  queryObject       : any ={};
  group     		: any = [];
  deleteSingle		: string;
  user      		: any;
  searchD       : any;
  formPosition      : boolean = false;
  selectedGroup		: Array<object> = [];
  groupForm			: FormGroup;
  name				: FormControl;
  description		:FormControl;
  addClass       : boolean =false;
  filterActive   : boolean = false;
	dataa :any;
	advanceFilterData:any;

    @ViewChild('foc') inputEl:ElementRef;

  filterSort 		: any = {};
  chosenObject		: any = {
	selected: {
	  status: {},
	  user : {}
	},
	status : [
	  {label: 'Active', value: 1},
	  {label: 'Inactive', value: 2}
	],
	  setEdit : {
	  user : [],
	  status: []
	}

  }




  constructor(
  	private groupService: GroupListService,
	private notifications : NotificationService,private loader : LoaderActionsService
  ){ }

  ngOnInit() {
    if(localStorage.getItem("itemsperpage")){
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else{
      this.recordsPerPage = 10;
    }
  	this.queryObject = {
  		"page": this.currentPage,
  		"page_limit": this.recordsPerPage,
  	}
	this.createFormControls();
	this.createForm();
	this.loadGroup();
	this.loadUser()


  }



  	   /**
  * @ desc   : TO implement pagination
  * @ author  : hashid.nk
  */
  pageChangeEvent(page) {
      this.queryObject.page = page;
  	  this.loadGroup();
  }

  /**
  * @ desc   : to focus input box
  * @ author  : vinod.k
  */
  inputfocus(){
          setTimeout(() => {this.inputEl.nativeElement.focus();},100)
    }
   /**
  * @ desc   : TO perform search operation
  * @ author  : hashid.nk
  */

  searchList(keyword) {
      if ( this.searchKeyword || this.searchD.trim() != ''){  
        this.searchKeyword = keyword;
        this.queryObject.keyword = this.searchKeyword?this.searchKeyword:'';
       // this.queryObject.keyword = keyword?keyword:'';
         this.queryObject.page = 1;
    		this.loadGroup();
      }
  }
    /**
  * @ desc   : TO perform advance filter operation
  * @ author  : hashid.nk
  */
  // advanceFilter(data) {


  //    if(data.status) {
  // 			this.queryObject.state = data.status.selected[0].name
  // 		}
  // 		   else {
  //        this.queryObject.state = null
  //      }
  // 		this.loadGroup();
  //   }





      advanceFilter(data) {
				if(data || this.advanceFilterData){
					this.advanceFilterData=data;
      if(data && data.group && data.group.selected.length) {
        this.queryObject.grp = data.group.selected[0].id
      }
      else {
        this.queryObject.grp = null;
      }
      if(data && data.status && data.status.selected.length) {
         if(data.status.selected[0].name == 1)
           this.queryObject.state = 1
         else if(data.status.selected[0].name == 2)
           this.queryObject.state = 2
       }
       else {
         this.queryObject.state = null
       }
     this.queryObject.page = 1
     if(this.queryObject.grp != null || this.queryObject.state != null){
           this.filterActive = true;
       }
       else{
         this.filterActive = false;
       }
      this.loadGroup();
		}
	else{
		data =undefined;
	}}
		


   	/**
	* @ desc 	: delete Group
	* @ author	: hashid.nk
	*/


	deleteGroup(id) {
	  this.loader.display(true);
	  this.groupService.deleteGroup(id, (response) => {
		 if (response.status == "OK") {
             this.loadGroup();
             this.notifications.alertBoxValue("success", response.message);
             this.loader.display(false);
             }
             else{
                this.notifications.alertBoxValue("error", response.message);
                this.loader.display(false);
             }

	  })
	}

   	/**
	* @ desc 	: delete multiple group from main list
	* @ author	: hashid.nk
	*/
	multiDelete() {
	  if(this.selectedGroup.length) {
		let data = []
		Object.keys(this.selectedGroup).map( (val,k) => {
		  data.push(this.selectedGroup[val].id)
		})
		this.loader.display(true);
		this.groupService.deleteMultipleGroup(data, (response) => {
		   if (response.status == "OK") {
             this.loadGroup();
             this.notifications.alertBoxValue("success", response.message);
             this.loader.display(false);
             }
             else{
                this.notifications.alertBoxValue("error", response.message);
                this.loader.display(false);
             }
		})
	  }
	}
   	/**
	* @ desc 	:  delete confirmation
	* @ author	: hashid.nk
	*/

	confirmPopup() {
  		if(this.deleteSingle) {
  			this.deleteGroup(this.deleteSingle)
  		} else {
  			this.multiDelete()
  		}
  		this.queryObject.page = 1;
  		this.showConfirmBox = false;
  	}


		/**
	* @ desc 	: to load the user to add and edit form
	* @ author	: hashid.nk
	*/

	// loadUser(){
	// 	let id: any
	// 	let self = this;
	// 	this.groupService.getUser(function(res){
	// 	self.user = res.data;
	// 	});
 // 	 }
	loadUser() {
		let id: any
		this.groupService.getUser(this.queryObject,id, res => {
			let data: any
			this.user = res.data;
			// this.filterPeople();
		})


	}


		/**
	* @ desc 	: To reset the group list after updation
	* @ author	: hashid.nk
	*/

	resetGroup() {
	  this.groupForm.reset();
		this.selectedGroup.length = 0;
		this.selectAllStatus      = false;

	}


		/**
	* @ desc 	: to load the group
	* @ author	: hashid.nk
	*/

	loadGroup() {
	  	let self = this;
	  	self.loader.display(true);
	    this.groupService.getGroup(this.queryObject,function(res){
	    	if(res.data.length) {

				self.group = res.data;
				self.resetGroup();
				self.totalRecords=res.count;
				self.currentPage = self.queryObject.page;
				self.loader.display(false);
  			} else {

  				self.group = [];
  				self.loader.display(false);
  			}
		});
	}
			/**
	* @ desc 	: to sort the group
	* @ author	: hashid.nk
	*/
	sortGroup(label) {
		let currentSortStatus = this.filterSort[label]?this.filterSort[label].rev: true;
		this.filterSort = {};
		this.filterSort[label] = {rev:!currentSortStatus}
		this.filterSort["label"] = label;
		this.queryObject.sort = `${this.filterSort[label].rev? '-': ''}${label}`
		this.loadGroup()
  	}



     /*
    author : hashid.nk
    desc   : form controll
    params :
  */

    createFormControls() {
		this.name = new FormControl('', [Validators.required,this.noWhitespaceValidator]);
		this.description = new FormControl('', [Validators.required,this.noWhitespaceValidator]);
 	}




        /*
    author : hashid.nk
    desc   : validation for white space in form
    params :
  */
  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }




		/**
	* @ desc 	: to perform form validation
	* @ author	: hashid.nk
	*/

 	createForm(): void {
  	 	this.groupForm = new FormGroup({
  		name: this.name,
  		description: this.description,

   		});
 	}

 			/**
	* @ desc 	: to select all the group from list
	* @ author	: hashid.nk
	*/

 	selectAll() {
		this.selectAllStatus = !this.selectAllStatus;
		this.selectedGroup.length = 0;
		this.group.map((item) => item.selectStatus = this.selectAllStatus ? true : false);

		if (this.selectAllStatus) {
	  		this.selectedGroup = JSON.parse(JSON.stringify(this.group));
		}
	}

			/**
	* @ desc 	: to select a group from list
	* @ author	: hashid.nk
	*/
	itemSelected(data) {
		this.selectAllStatus = false;

		if (data.selectStatus)
	 	 this.selectedGroup.push(data);
		else {
	  			this.selectedGroup = this.selectedGroup.filter(group => group['id'] !== data.id);
		}
	}

	removeEditpopup(){
		if(this.dataa){
      		this.dataa.editStatus = false;
    	}
	}
  	toggleForm(event) {
		this.showForm = !this.showForm;
		if(this.dataa){
      		this.dataa.editStatus = false;
    	}
		if(this.showForm){
      		this.addClass = true;
    	}
    	else{
      		this.addClass  = false;
    	}
		 this.groupForm.reset();
		 this.groupFormError = false;
		// event?event.stopPropagation(): '';
	}
				/**
	* @ desc 	: to push multple user to the array
	* @ author	: hashid.nk
	*/

	findSelectedIndex(obj){

	 	let arrayIndex=[];

	 	for(let i=0; i<obj.selected.length;i++) {
	 		arrayIndex.push(obj.selected[i].id)
	 	}
		// obj.selectedIndex.map((val)=> {
	 //    arrayIndex.push(obj.selected[val].id)
		// });

	  return arrayIndex
	}

				/**
	* @ desc 	: to add or edit group from  form
	* @ author	: hashid.nk
	*/


	submitForm() {
	  if(!this.groupForm.valid || (this.chosenObject.selected.user.selected && this.chosenObject.selected.user.selected.length == 0)
	  || (this.chosenObject.selected.status.selected && this.chosenObject.selected.status.selected.length == 0)  ){
			this.groupFormError = true;
	  }
		else {

		  let form = {
			name: this.name.value,
			description: this.description.value,
			status: this.chosenObject.selected.status.selected[0].value,
			// address: this.chosenObject.selected.user.selected[0].value,
			user_id: this.findSelectedIndex(this.chosenObject.selected.user)
		  }
		  this.loader.display(true);
		   this.groupService.addGroup(form, (response) => {
			  if (response.status == "OK") {
             	this.notifications.alertBoxValue("success", response.message);
             	this.toggleForm(null);
             	this.groupFormError = false;
             	this.loadGroup();
             	this.loader.display(false);
             }
             else{
                this.notifications.alertBoxValue("error", response.message);
                this.loader.display(false);
             }
		   })
		}
	}
					/**
	* @ desc 	: to open edit group from  form
	* @ author	: hashid.nk
	*/

	openEditForm(data,event,z) {
		let yPosition = event.clientY;
      let innerheight = document.getElementById("userslist").clientHeight;
      if(((innerheight)/2) < yPosition && (z >=3)){
        this.formPosition = true;
      }
      else{
       this.formPosition = false;
      }
		let target = event.target || event.srcElement || event.currentTarget;
        let idAttr = event.target.id;
        this.dataa = data;
      if(idAttr == "a"){
       let self = this;
        for(var i=0;i<self.group.length;i++){
          if(self.group[i].id == data.id){
            data.editStatus = true;
          }
          else{
            self.group[i].editStatus = false;
          }
        }
	  	this.groupService.getGroupEditDetails(data.id, function(response) {
		let x ;

		 // x = response[0].user_id.split(',');
		if(response[0].user_id != null){
			x = response[0].user_id.split(',')
		self.chosenObject.setEdit.status = [];
		self.chosenObject.setEdit.user = [];
		x.map((item, userIndex) => {
		  self.user.filter((user, index) => {
			if(user['id'] == item) {
			  self.chosenObject.setEdit.user.push(index)
			}
		  })
		})
	}
		if(self.chosenObject.setEdit.user.length == 0) {
      		self.chosenObject.setEdit.user.push(0)
    	}

		self.chosenObject.status.filter((status, index) => {
       	if(status['value'] == data.status) {
          		self.chosenObject.setEdit.status.push(index)
        	}
      	})

      	if(self.chosenObject.setEdit.status.length == 0) {
      		self.chosenObject.setEdit.status.push(0)
    	}

    	self.groupForm.patchValue({
        	name: data.name,
        	description: data.description
    	});


	  })
	  }

	}
						/**
	* @ desc 	: to  edit group from  form
	* @ author	: hashid.nk
	*/

	editForm(event, data) {
  		if(!this.groupForm.valid || (this.chosenObject.selected.user.selected && this.chosenObject.selected.user.selected.length == 0) ){
            this.groupFormError = true;
        } else {
        	let form={
        	name: this.name.value,
			status: this.chosenObject.selected.status.selected[0].value,
			user_id: this.findSelectedIndex(this.chosenObject.selected.user),
			description: this.description.value,
			}
			this.loader.display(true);
       		this.groupService.editGroup(form,data.id, (response) => {
          let self = this;
       		 if (response.status == "OK") {
             	this.notifications.alertBoxValue("success", response.message);
             	this.loadGroup();
              setTimeout(function(){
               self.loader.display(false);
              },600);
             }
             else{
                this.notifications.alertBoxValue("error", response.message);
              setTimeout(function(){
               self.loader.display(false);
              },600);
             }
       		})
        }
  	}

getpage(event){
  if(event>10 || this.recordsPerPage != 10){
      this.recordsPerPage = event;
      this.queryObject['page_limit'] = event;
      this.queryObject['page'] = 1;
      this.currentPage = 1;
      this.loadGroup();
    }
    // else{
    //   this.recordsPerPage = 10;
    //   this.queryObject['page_limit'] = event;
    //   this.queryObject['page'] = 1;
    //   this.currentPage = 1;
    //   this.loadGroup();
    // }
}

}
