/**
* @ name   : HrisCompanyComponent
* @ desc   : Manage company profile
* @ author  : hashid.n.k
*/
import { Component, OnInit } from '@angular/core';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CompanyProfileService } from '../../service/company-profile.service';
import { CookieService } from 'ngx-cookie-service';
import { CookieDataService } from '../../../shared/services/cookie-data/cookie-data.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-hris-company',
  templateUrl: './hris-company.component.html',
  styleUrls: ['./hris-company.component.css']
})
export class HrisCompanyComponent implements OnInit {

		company      : any;
    entityInfo   : any;
    addForm      : FormGroup;
    address      : FormControl;
    website      : FormControl;
    adminName    : FormControl;
    companyEmail : FormControl;
    emailData    : FormControl
    number       : FormControl;
    submitted    : boolean = false;


    constructor(
  	private companyProfileService: CompanyProfileService,
    private loader               : LoaderActionsService,
    private cookies              : CookieService ,
    private cookieService        : CookieDataService) { }

  ngOnInit() {
    let currentDomain = window.location.origin.split('/');
    currentDomain[2] = currentDomain[2].replace(':4200', '');//for local only
    if (this.cookies.get(currentDomain[2] + "Client")) {
      this.entityInfo = JSON.parse(this.cookies.get(currentDomain[2] + "Client"));
      this.createFormControls();
      this.createForm();
      this.setPatchValue();
      this.loadLocations();
      // this.loadCompany(null);
    }
  }

   /**
   * @ desc   : load comapny details
   * @ author  : hashid
   */
    loadCompany(filter) {
  		  let self = this;
  	  	this.companyProfileService.getCompany(filter,function(res){
			  self.company = res.data;
		  });
    }

   /**
   * @ desc   : load locations
   * @ author  : hashid
   */
    loadLocations() {
        let self = this;
        self.loader.display(true);
        this.companyProfileService.getLocations(function(res){
        self.company = res.data;
        self.loader.display(false);
      });
    }

  /*
  *  @desc   :Create and define form controls of createNew form
  *  @author :dipin
  */
  createFormControls() {
    let emailPattern    = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$";
    this.address      = new FormControl('', [Validators.required,this.noWhitespaceValidator]);
    this.website      = new FormControl('', [Validators.required, this.noWhitespaceValidator]);
    this.number       = new FormControl('', [Validators.required,this.noWhitespaceValidator]);
    this.emailData    = new FormControl('', [Validators.required,this.noWhitespaceValidator,Validators.pattern(emailPattern)]);
    this.adminName    = new FormControl('', [Validators.required,this.noWhitespaceValidator]);
    this.companyEmail = new FormControl('', [Validators.required,this.noWhitespaceValidator,Validators.pattern(emailPattern)]);
  }

  /*
  *  @desc   :create form itemForm and addForm
  *  @author :dipin
  */
  createForm() {
    this.addForm = new FormGroup({
      emailData    : this.emailData,
      website      : this.website,
      address      : this.address,
      number       : this.number,
      adminName    : this.adminName,
      companyEmail : this.companyEmail
    });
  }

   /*
    author : dipin
    desc   : validation for white space in form
    params :
  */
  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }

   /*
    author : dipin
    desc   : method to reset form
    params :
  */
  cancel(){
    this.addForm.reset();
    this.submitted = false;
    this.setPatchValue();
  }

   /*
   author : dipin
   desc   : method to set default value for form controls
   params :
  */
  setPatchValue() {
    this.addForm.patchValue({
      emailData: this.entityInfo.company_profile.data.email,
      website: this.entityInfo.company_profile.data.website,
      address: this.entityInfo.company_profile.data.address,
      number: this.entityInfo.company_profile.data.contact,
      adminName: this.entityInfo.company_profile.data.administrator,
      companyEmail: this.entityInfo.company_profile.data.from_email
    });
  }

   /*
    author : dipin
    desc   : method to submit data to server through api call
    params :
  */
  submitForm() {
    this.submitted = true;
    if (!this.addForm.valid) {
      return;
    }
    else {
      let currentUrl = window.location.origin.split('/');
      currentUrl[2] = currentUrl[2].replace(':4200', '');//for local only
      this.companyProfileService.getDomain(currentUrl[2], response => {
        if (response.status == "OK") {
          if(response.data){
            this.cookies.delete(currentUrl[2]+'Client');
            // this.entityInfo = response.data;
            // this.setPatchValue();
            this.cookieService.setClient(response.data, currentUrl[2]);
          }
        }
      })
    }
  }

}
