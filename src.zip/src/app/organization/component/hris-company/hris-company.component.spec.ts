import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HrisCompanyComponent } from './hris-company.component';

describe('HrisCompanyComponent', () => {
  let component: HrisCompanyComponent;
  let fixture: ComponentFixture<HrisCompanyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HrisCompanyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HrisCompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
