import { Component, OnInit  } from '@angular/core';

import { AclService } from '../../service/acl/acl.service'
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';

@Component({
  selector: 'app-acl',
  templateUrl: './acl.component.html',
  styleUrls: ['../../../../assets/content/css/acl.css']
})
export class AclComponent implements OnInit {
  
  roles                 : any;
  groups                : any;
  groupIndex            : any;
  roleIndex             : any;

  confirmBox            : boolean = false;
  
  constructor(
  	private aclService          : AclService,
    private notificationService : NotificationService,
    private loaderActionsService: LoaderActionsService) { }

  ngOnInit() {
    let data : any = [];
    this.loaderActionsService.display(true);
  	this.aclService.getListing(res=>{
      this.loaderActionsService.display(false);
  		this.roles = res.data.roles;
      this.groups =res.data.groups;
      for(let i=0;i<this.roles.length;i++) {
        data.push(false);
      }
      for(let i=0;i<this.groups.length; i++) {
          this.groups[i]['dummyroles'] = Object.assign([], data); 
      }
      for (let i = 0; i < this.groups.length; i++) {
        for (let j = 0; j < this.groups[i].allowed_roles.length; j++) {
          for(let k=0;k<this.roles.length;k++) {
            if(this.groups[i].allowed_roles[j] === this.roles[k].id){
              this.groups[i].dummyroles[k] = true;
            }
          }
        }
      }
  	})
  }

  /*
   author : Arun Johnson
   desc   : Call when change in check box
   params : 
  */
  check(event, groupIndex, roleIndex) {
    this.groups[groupIndex]['dummyroles'][roleIndex] = !this.groups[groupIndex]['dummyroles'][roleIndex];
    // this.groups    = groupIndex;
    // this.roleIndex = roleIndex;
    if (this.groups[groupIndex]['dummyroles'][roleIndex]) {
        this.loaderActionsService.display(true);
      this.aclService.requestPermission(this.groups[groupIndex], this.roles[roleIndex], res => {
          this.loaderActionsService.display(false);
        if(res.status == "OK") {
          this.notificationService.alertBoxValue("success",res.message.message);
        } else {
          this.notificationService.alertBoxValue("error",res.message.message);
        }
      })
    } else {
        this.loaderActionsService.display(true);
      this.aclService.deletePermission(this.groups[groupIndex], this.roles[roleIndex], res => {
          this.loaderActionsService.display(false);
        if(res.status == "OK") {
          this.notificationService.alertBoxValue("success",res.message.message);
        }else {
          this.notificationService.alertBoxValue("error",res.message.message);
        }
      })
    }
  }

  /*
   author : Arun Johnson
   desc   : trackByFn for ngFor
   params : 
  */
  trackByFn(index, item) {
    return index; // or item.id
  }

}
