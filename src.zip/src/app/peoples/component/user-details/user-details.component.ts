/*
 author : Arun Johnson
 desc   : user details Listing
*/

import { Component, OnInit } from '@angular/core';
import { Router , NavigationEnd} from '@angular/router';

import { UserDetailsService } from '../../services/user-details/user-details.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { CookieDataService } from '../../../shared/services/cookie-data/cookie-data.service';
import { ConstantServicesService } from '../../../shared/services/constant/constant-services.service';
import { FilterService } from '../../../shared/services/filter/filter.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})

export class UserDetailsComponent implements OnInit {

    peopleData            : any;
    dummyPeopleData       : any = [];
    searchValue           : any;
    advanceFilterData     : any;
    sort                  : any;
    config                : any;
    searchD               : any;
    entityInfo            : any;

    currentPage           : number = 1;
    recordsPerPage        : number = 10;
    totalRecords          : number;
    activeClass           : number = 0;
    deleteIndex           : number;
    deleteStatus          : number;


    checkBoxValue         : boolean = false;
    deleteIconStatus      : boolean = false;
    nodata                : boolean = false;
    filterStatus          : boolean = false;
    searchTextBox         : boolean = false;
    confirmBox            : boolean = false;

    filterSort            : any = {};
    queryObject           : any = {};

     constructor(
      private router                  : Router,
      private userDetailsService      : UserDetailsService,
      private notificationService     : NotificationService,
      private loaderActionsService    : LoaderActionsService,
      private cookieDataService       : CookieDataService,
      private cookieService           : CookieService,
      private constData               : ConstantServicesService,
      private filterService           : FilterService) { }

  ngOnInit() {
    if(localStorage.getItem("itemsperpage")){
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else{
      this.recordsPerPage = 10;
    }

    this.config = "Are You Sure You Want To Delete?"
    this.sort = {
      name:null,
      value:null
    }
    this.router.events.subscribe((evt) => {
            if (!(evt instanceof NavigationEnd)) {
                window.scrollTo(0, 0);
                 if(this.router.url.indexOf('/modules/employee')){
                   this.constData.selectedData = undefined;
                   this.constData.searchInput  = undefined;
                }
            }
    });
    this.advanceFilterData = this.constData.selectedData;
    let currentDomain = window.location.origin.split('/');
    currentDomain[2] = currentDomain[2].replace(':4200','');

    if(this.cookieService.get(currentDomain[2] + "Client")) {
      this.entityInfo = JSON.parse(this.cookieService.get(currentDomain[2] + "Client"));
    }

    if(this.constData.searchInput){
      this.searchTextBox = true;
    }
    this.searchValue       = this.constData.searchInput;
    this.searchD           = this.constData.searchInput;

    this.getPeople(this.currentPage);
    if(this.advanceFilterData){
      this.filterService.filterVar = [];
      if(this.constData.selectedData.bsValue){
        if(this.constData.selectedData.bsValue.selected[0]){
          this.filterService.filterVar['bsValue']     = this.constData.selectedData.bsValue.selected[0];
        }
      }
       if(this.constData.selectedData.department){
        if(this.constData.selectedData.department.selected[0]){
         this.filterService.filterVar['department']  = this.constData.selectedData.department.selected[0];
        }
      }
       if(this.constData.selectedData.designation){
        if(this.constData.selectedData.designation.selected[0]){
          this.filterService.filterVar['designation'] = this.constData.selectedData.designation.selected[0];
        }
      }
       if(this.constData.selectedData.group && this.constData.selectedData.group!=undefined && this.constData.selectedData.group.length){
        if(this.constData.selectedData.group.selected[0]){
               this.filterService.filterVar['group']       = this.constData.selectedData.group.selected[0];
        }
      }
       if(this.constData.selectedData.location){
        if(this.constData.selectedData.location.selected[0]){
          this.filterService.filterVar['location']    = this.constData.selectedData.location.selected[0];
        }
      }
       if(this.constData.selectedData.range){
        if(this.constData.selectedData.range.selected[0]){
          this.filterService.filterVar['range']       = this.constData.selectedData.range.selected[0];
        }
      }
      if(this.constData.selectedData.role){
        if(this.constData.selectedData.role.selected[0]){
          this.filterService.filterVar['role']        = this.constData.selectedData.role.selected[0];
        }
      }
      if(this.constData.selectedData.stat.length>0){
        if(this.constData.selectedData.stat.selected[0]){
          this.filterService.filterVar['stat']        = this.constData.selectedData.stat.selected[0];
        }
      }
      if(this.constData.selectedData.status){
        if(this.constData.selectedData.status.selected[0]){
          this.filterService.filterVar['status']     = this.constData.selectedData.status.selected[0];
        }
      }
      if (localStorage.getItem("userDetails")){
         localStorage.removeItem("userDetails");
      }
    }
    else if (localStorage.getItem("userDetails")) {
      this.advanceFilterData = JSON.parse(localStorage.getItem("userDetails"));
      this.filterService.filterVar['location'] = JSON.parse(localStorage.getItem("userDetails")).location.selected[0];
      localStorage.removeItem("userDetails");
    }
    else
      this.filterService.filterVar = [];

 
    // this.searchValue       = this.constData.searchInput;
    // this.searchD           = this.constData.searchInput;
    this.constData.selectedData = undefined;
    this.constData.searchInput = undefined;
   
  }


  getpage(event){
    if(event>10 || this.recordsPerPage != 10){
      this.recordsPerPage = event;
      this.currentPage = 1;
      this.getPeople(this.currentPage);
    }
  }

  /*
   author : Arun Johnson
   desc   : get people details
  */
  getPeople(page){
    this.checkBoxValue = false;
    this.deleteIconStatus = false;
    this.currentPage = page;
    this.loaderActionsService.display(true);
    this.userDetailsService.getPeople(this.currentPage,this.recordsPerPage,this.advanceFilterData,this.searchValue,this.queryObject,res => {
     this.loaderActionsService.display(false);
      if (res.status == "OK" && res.data && res.data.length) {
        this.totalRecords    = res.count;
        this.peopleData      = res.data;
        this.dummyPeopleData = res.data;
        this.peopleData.forEach((item, index) => {
          this.dummyPeopleData[index]["checkBoxStatus"] = false;
        });
      }
      else {
        this.dummyPeopleData  = [];
        this.nodata           = true;
        this.deleteIconStatus = false;
      }
    })
  }

  /*
  author : Arun Johnson
  desc   : select or reset all check box
  */
  selectReset() {
    if (!this.checkBoxValue) {
    this.dummyPeopleData.forEach((item, index) => {
      this.dummyPeopleData[index]["checkBoxStatus"] = true;
      if(1<index) {
        this.deleteIconStatus = true;
      }
    });
    }
    else {
    this.dummyPeopleData.forEach((item, index) => {
      this.dummyPeopleData[index]["checkBoxStatus"] = false;
    });
    this.deleteIconStatus = false;
    }
  }

  /*
   author : Arun Johnson
   desc   : select or reset  check box of passed index
   params : index of check box
  */
  checkBoxClick(index : number) {
    let status = 0;
    this.dummyPeopleData[index]["checkBoxStatus"] = !this.dummyPeopleData[index]["checkBoxStatus"];
    this.checkBoxValue = this.dummyPeopleData.every(function(value){
      return value.checkBoxStatus == true;
    })
    for(let index =0;index<this.dummyPeopleData.length;index++) {
      if(this.dummyPeopleData[index].checkBoxStatus) {
        status = status + 1;
      }
    }
    (1<status) ? this.deleteIconStatus = true : this.deleteIconStatus = false;
  }

  /*
   author : Arun Johnson
   desc   : delete the people
   params : index of check box
  */
  deleteindividualPeople() {
    let selectedPeople : any = this.dummyPeopleData[this.deleteIndex];
    this.loaderActionsService.display(true);
    this.userDetailsService.deletePeople(selectedPeople,res=>{
      this.loaderActionsService.display(false);
      if(res.status == "OK") {
        this.currentPage = 1;
        this.notificationService.alertBoxValue("success",res.message);
        this.getPeople(this.currentPage);
      } else {
          this.notificationService.alertBoxValue("error",res.message);
          this.nodata = true;
      }
    });
  }


  /*
   author : Arun Johnson
   desc   : sort
   params : based on value asc or desc will be performed.
  */
  sortDepartment(label) {
    let currentSortStatus = this.filterSort[label]?this.filterSort[label].rev: true;
    this.filterSort = {};
    this.filterSort[label] = {rev:!currentSortStatus}
    this.filterSort["label"] = label;
    this.queryObject.sort = `${this.filterSort[label].rev? '-': ''}${label}`;
    this.getPeople(this.currentPage);
  }
  /*
   author : Arun Johnson
   desc   : multiple delete
   params :
  */
  multipleDelete() {
    this.loaderActionsService.display(true);
    this.userDetailsService.multipleDelete(this.dummyPeopleData,res=>{
       this.loaderActionsService.display(false);
       if(res.status == "OK") {
        this.currentPage = 1;
        this.getPeople(this.currentPage);
        this.notificationService.alertBoxValue("success",res.message);
        this.deleteIconStatus = false;
      } else {
          this.notificationService.alertBoxValue("error",res.message);
      }
    })
  }

  /*
   author : Arun Johnson
   desc   : send Filter Data
   params :
  */
  filterData(event) {
   if (event || this.advanceFilterData) {
    this.advanceFilterData  = event;
    this.currentPage        = 1;
    this.constData.selectedData = event;
    this.getPeople(this.currentPage);
   }
   else
     this.advanceFilterData = undefined;
  }

  /*
   author : Arun Johnson
   desc   : Search  when enter key is pressed
  */
  search() {
    if (this.searchValue || this.searchD.trim() != '') {
      this.searchValue = this.searchD;
      this.constData.searchInput = this.searchD;
      this.currentPage = 1;
      this.getPeople(this.currentPage);
    }
  }

  /*
   author : Arun Johnson
   desc   : confirm popup
  */
  confirmPopup() {
    this.activeClass = 0;
    this.sort.name = null;
    this.sort.value = null;
    this.confirmBox = false;
    this.deleteIconStatus = false;
    if (this.deleteStatus == 1) {
      this.deleteindividualPeople();
    } else {
      this.multipleDelete();
    }
  }

  setStage(){
    localStorage.removeItem('editSection');
    this.constData.searchInput = this.searchD;
    this.constData.selectedData = this.advanceFilterData;
    this.router.navigate(['/modules/employee/add']);
  }

  /*
   author : Arun Johnson
   desc   : add class based on index
  */
  getClassByValue(index) {
    return this.userDetailsService.getClassByValue(index);

  }

  /*
   author : Arun Johnson
   desc   : click edit button
  */
  edit(data : any) {
    localStorage.removeItem('editSection');
    this.constData.searchInput = this.searchD;
    this.constData.selectedData = this.advanceFilterData;
    let type = btoa('edit');
    this.router.navigate(['/modules/employee/add/'+data.id],{queryParams: {type}});
  }

   setFocus() {
    window.setTimeout(function() {
      document.getElementById('searchField').focus();
    }, 1);
  }

  resetPassword(id) {
    this.loaderActionsService.display(true);
    this.userDetailsService.userPasswordReset(id, response => {
      if (response.status == "OK") {
        this.loaderActionsService.display(false);
        this.notificationService.alertBoxValue("success",response.message);
      }
      else {
        this.loaderActionsService.display(false);
        this.notificationService.alertBoxValue("error", response.message);
      }
    })
  }

  viewDetails(data){
    this.constData.searchInput = this.searchD;
    this.constData.selectedData = this.advanceFilterData;
    let type = btoa('view');
    this.router.navigate(['/modules/employee/view-employee/'+data.id]);
  }
  empDetails(event){
    event.stopPropagation();
  }
}
