import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { ConstantServicesService } from '../../../shared/services/constant/constant-services.service';
import { AddEmployeeService } from '../../services/add-employee/add-employee.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { UserDetailsService } from '../../services/user-details/user-details.service';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { AlertboxComponent } from 'src/app/shared/component/alertbox/alertbox.component';

declare var require: any;
var moment = require('moment');

@Component({
	selector: 'app-convert-to-employee',
	templateUrl: './convert-to-employee.component.html',
	styleUrls: ['./convert-to-employee.component.css',
		"../../../../assets/content/css/custom.css",
		"../../../../assets/content/css/recruitment.css","../../../../assets/content/css/crop-image.css"]
})
export class ConvertToEmployeeComponent implements OnInit {

	imageChangedEvent: any;
	croppedImage: any = " ";
	passCroppedImage: any;
	childrenList: any = [];
	tempstateList: any = [];
	expiryDocId	: any = [];
	editFormData: any;
	role: any;
	roleStatus: any;
	roleChecked: any;
	docNumberView       : any
	childChecked : any;
	showAlert : boolean = false;
	addNewDocNo : boolean = false;
	errorDocid	: boolean = false;
	docTypeValidation : boolean = false;
	loadermultiOnboard : boolean = false;
	fileData: any = [];
	fileName: any = [];
	department: any;
	shiftChecked : any;
	departmentSelected: any;
	departmentChecked: any;
	location: any;
	locationSelected: any;
	attendanceType: any;
	attendanceSelected: any;
	locationChecked: any;
	shiftSelected: any;
	marriedSelect: any;
	reportingManager: any;
	stateList: any = [];
	reportingManagerSelect: any;
	reportingChecked: any;
	lineManager: any;
	lineManagerSelected: any;
	lineChecked: any;
	employeeType: any = [{ "value": "Permanent" }, { "value": "Probation" }, { "value": "Contract" }, { "value": "Trainee" }, { "value": "Consultant" }];
	employeeTypeSelected: any;
	employeeTypeChecked: any;
	employeeGroup: any;
	sendPermissionData: any;
	tempCountrySelected: any;
	fileDataSec : any = [];
	groupChecked: any;
	employeeGroupSelected: any;
	status: any = [{ "value": "Active", "name": 1 }, { "value": "Inactive", "name": 2 }, { "value": "Resigned", "name": 3 }];
	statusSelected: any = [];
	statusChecked: any;
	roleSelected: any;
	minJoinDate : any;
	designation: any;
	designationSelected: any;
	designationChecked: any;
	gender: any = [{ "value": "Male", "name": "M" }, { "value": "Female", "name": "F" }, { "value": "Other", "name": "O" }];
	genderSelected: any;
	checkedGender: any;
	maritalStatus: any = [{ "data": "Married", "value": "Y" }, { "data": "Unmarried", "value": "N" }];
	materialChecked: any;
	attendanceChecked: any;
	maritalSelected :any;
	childSelect : any;
	fineSelected : any;
	periodSelected : any;
	permissionData: any;
	selectedGender: any;
	probationSelected: any;
	dateofRevl : any;
	probationChecked: any;
	stateWatched: boolean = false;
	stateSelect: any;
	photo: any;
	probationPeriod: any = [
		{ "data": "1 Month", "value": "1" },
		{ "data": "2 Month", "value": "2" },
		{ "data": "3 Month", "value": "3" },
		{ "data": "4 Month", "value": "4" },
		{ "data": "5 Month", "value": "5" },
		{ "data": "6 Month", "value": "6" },
		{ "data": "7 Month", "value": "7" },
		{ "data": "8 Month", "value": "8" },
		{ "data": "9 Month", "value": "9" },
		{ "data": "10 Month", "value": "10" },
		{ "data": "11 Month", "value": "11" },
		{ "data": "12 Month", "value": "12" }];


	maxDate: Date = new Date();

	minDate: Date = new Date("1900");
	dojMax: Date = new Date("2500")

	personalDetailError: boolean = false;
	pageStatus: boolean = false;
	showProbation: boolean = false;
	showOverridePopup: boolean = false;
	confirmBox: boolean = false;
	disable: boolean = false;
	lazyLoad: boolean = false;
	aclOverride: boolean = false;
	aclNewItem: boolean = false;
	dojError: boolean = false;
	dojErrorConvert: boolean = true;
	dobError: boolean = false;
	errorDate: boolean = false;
	showEmployee : boolean = false;
	viewPage: boolean = false;
	showPopUp: boolean = false;
	sameAbove: boolean = false;
	stateTempWatched: boolean = false;
	confirmBox4: boolean = false;
	employeeDetails: FormGroup;

	firstName: FormControl;
	lastName: FormControl;
	dob: FormControl;
	age: FormControl;
	date_of_joining: FormControl;
	emailId: FormControl;
	bloodGroup: FormControl;
	pincode: FormControl;
	landMark: FormControl;
	contactNumber: FormControl;
	personalEmailId: FormControl;
	displayName: FormControl;
	city: FormControl;
	permanetAddress: FormControl;
	middleName: FormControl;
	tempAddress: FormControl;
	fatherDob: FormControl;
	motherDob: FormControl;
	spouseDob: FormControl;
	empId: FormControl;
	userName: FormControl;
	emeNo: FormControl;
	emeName: FormControl;
	emeRelation: FormControl;
	extension: FormControl;
	country: FormControl;
	speedDial: FormControl;
	state: FormControl;
	landLine: FormControl;
	templandMark: FormControl;
	tempcountry: FormControl;
	tempstate: FormControl;
	temppincode: FormControl;
	fatherEmailId: FormControl;
	tempcity: FormControl;
	fatherName: FormControl;
	mEmail: FormControl;
	sEmail: FormControl;
	fatherCNo: FormControl;
	motherCNo: FormControl;
	spouseCNo: FormControl;
	motherName: FormControl;
	spouseName: FormControl;
	childrenListWork: any = [];
	childrenListEducation: any = [];
	// childrenListWork : any;
	masterList: any = [];
	masterListApi: any = [];
	childrenListDoc: any = [];
	dayTime: any = [];
	tempStateSelected: any;
	fileNameDoc: any = [];
	fileNameWork: any = [];
	financialYear : any;
	payperiod : any;
	countrySelect : any;
	groupSelect : any;
	fileNameEducation: any = [];
	countryList: any;
	emailData  : any;
	dateRangeValue    : any;
	dateValue         : any;
	maxdate           : any;
	maskUserIDname    : boolean = false;
	selectedEmailData : any = [];
	selectedEmail     : any = [];
	selectedNotify	  : any = [];
	showNotifyOnadd   : boolean = false;
	confirmBox1       : boolean = false;
	confirmBox2       : boolean = false;
	confirmBox3       : boolean = false;
	index1			  : any;
	index2			  : any;
	index3			  : any;
	index4            : any;
	viewSettings      :boolean = true;
	viewPersonal      :boolean = true;
	viewWork          :boolean = true;
	viewEducation     :boolean = true;
	viewDocument      :boolean = true;
	viewOffical       :boolean = true;
	ViewFamily        :boolean = true
	viewEmgergency    :boolean = true
	constructor(
		private route: ActivatedRoute,
		private locations: Router,
		private addEmployeeService: AddEmployeeService,
		private notificationService: NotificationService,
		private loaderActionsService: LoaderActionsService,
		private constData: ConstantServicesService,
		private userDetailsService: UserDetailsService,
		private changes: ChangeDetectorRef,
		private aclCheck: AclVerificationService,
		private timeZone: TimezoneDetailsService) { }

	ngOnInit() {

		this.userDetailsService.emailListing(response => {
			if (response.status == "OK") {
				if (response.data) {
					this.emailData = response.data;
				}
			}
		})
		this.addEmployeeService.getFullNotifyUsers(response => {
			if (response.status == "OK") {
				if (response.data) {
					this.selectedNotify = response.data;
					// this.selectedEmail = response.data[]
				
			}}
		})
		// this.minJoinDate = this.timeZone.getCurrentDate();
		var currentYear = new Date().getFullYear();
		let startYear = 1990;
		while (startYear <= currentYear) {
			this.dayTime.unshift({ name: startYear++ });
		}

		this.maxDate = this.timeZone.getCurrentDate();
		this.loaderActionsService.display(true);
		this.childrenList = [{name:'',gender:'',date:'',nameError:false,dateError:false,genderError:false}];
		this.aclNewItem = this.aclCheck.checkAcl('/modules/organization/role');
		this.aclOverride = this.aclCheck.checkAcl('/modules/organization/acl');
		this.disable = false;
		this.attendanceType = [{ name: 'Manual' }, { name: 'Biometric' }];
		this.route.snapshot.params['id'] ? this.pageStatus = false : this.pageStatus = true;
		this.createFormControls();
		this.createForm();
		if(this.route.url['value'][0].path == 'toemployee'){
			this.showEmployee = true;
		}
		if(this.showEmployee){
			this.maskUserIDname = false;
			this.loaderActionsService.display(true);
			this.addEmployeeService.getMasterData(res => {
				
				if (res.status == "OK") {
					this.department = res.data.department;
					this.designation = res.data.designation;
					this.location = res.data.location;
					this.employeeGroup = res.data.group;
					this.role = res.data.role;
					this.reportingManager = res.data.reporting_manager;
					this.lineManager = res.data.reporting_manager;
					this.masterListApi = res.data;
					
					if (this.role) {
						for (let i = 0; i < this.role.length; i++) {
							if (this.role[i].name.toUpperCase() == "EMPLOYEE") {
								this.roleChecked = [i];
								break;
							}
						}
					}
					
					this.addEmployeeService.getMaster(Res => {
						if (Res.status == "OK") {
							this.masterList = Res.data;
							this.disable = true;
							let id: any = this.route.snapshot.params['id'];
							this.addEmployeeService.getPeople(id,this.showEmployee, res => {
								
								let data: any = res.data;
								this.photo = data.photo;
								this.editFormData = res.data;
								if (res.status == "OK" && data) {
									data.status == '1' ? this.statusChecked = [0] : data.status == '2' ? this.statusChecked = [1] : data.status == '3' ? this.statusChecked = [2] : null;
									data.gender == 'M' ? this.checkedGender = [0] : data.gender == 'F' ? this.checkedGender = [1] : data.gender == 'O' ? this.checkedGender = [2] : null;
									(data.personalDetails.maritalStat == "1") ? this.materialChecked = [1] : this.materialChecked = [0];
									if(this.editFormData.financial_calendar_id)
									for(let i = 0;i < this.masterListApi.financial_year.length;i++){
										if(this.editFormData.financial_calendar_id == this.masterListApi.financial_year[i].id){
										   this.fineSelected = [i];
										   break;
										}
									}
									if(this.editFormData.date_of_relieving){
										this.dateofRevl = this.timeZone.getLocalDate(this.editFormData.date_of_relieving);
									}
		
									if(this.editFormData.pay_period_id)
									for(let i = 0;i < this.masterListApi.pay_period.length;i++){
										if(this.editFormData.pay_period_id == this.masterListApi.pay_period[i].id){
										   this.periodSelected = [i];
										   break;
										}
									}
		
									if(this.editFormData.shift_type_id)
									for(let i = 0;i < this.masterListApi.shift_type.length;i++){
										if(this.editFormData.shift_type_id == this.masterListApi.shift_type[i].id){
										   this.shiftChecked = [i];
										   break;
										}
									}
									this.setCheckStatus(this.editFormData);
									this.firstName.disable();
	                                this.lastName.disable();
									this.dob.disable();
									this.age.disable();
									this.bloodGroup.disable();
									this.pincode.disable();
									this.landMark.disable();
									this.contactNumber.disable();
									this.personalEmailId.disable();
									this.displayName.disable();
									this.city.disable();
									this.permanetAddress.disable();
									this.middleName.disable();
									this.tempAddress.disable();
									this.fatherDob.disable();
									this.motherDob.disable();
									this.spouseDob.disable();
									this.emeNo.disable();
									this.emeName.disable();
									this.emeRelation.disable();
									this.country.disable();
									this.state.disable();
									this.landLine.disable();
									this.templandMark.disable();
									this.tempcountry.disable();
									this.tempstate.disable();
									this.temppincode.disable();
									this.fatherEmailId.disable();
									this.tempcity.disable();
									this.fatherName.disable();
									this.mEmail.disable();
									this.sEmail.disable();
									this.fatherCNo.disable();
									this.motherCNo.disable();
									this.spouseCNo.disable();
									this.motherName.disable();
									this.spouseName.disable();
								}
								this.loaderActionsService.display(false);
							})
						}
					});
				}
			})
		}
		else {
			this.loaderActionsService.display(true);
			if(localStorage.getItem('editSection')){
				let value =localStorage.getItem('editSection')
				if(value ==='Official'){
					setTimeout(() => {
						var elem = document.getElementById("offi"); 
						elem.scrollIntoView(); 
					}, 500);
					this.viewSettings = false
					this.viewOffical  = true
					this.viewPersonal = false
					this.viewDocument = false
					this.viewWork     = false
					this.viewEducation= false
					this.ViewFamily   = false
					this.viewEmgergency=false
				}else if(value ==='Emergency'){
					setTimeout(() => {
						document.getElementById("job-nametitle").focus();
						document.getElementById("job-nametitle").scrollIntoView(true);
					}, 500);
					this.viewSettings = false
					this.viewOffical  = false
					this.viewPersonal = false
					this.viewDocument = false
					this.viewWork     = false
					this.viewEducation= false
					this.ViewFamily   = false
					this.viewEmgergency=true
				}else if(value ==='Settings'){
					setTimeout(() => {
						var elem = document.getElementById("cal1financial"); 
						elem.scrollIntoView(); 
					}, 500);
					this.viewSettings = true
					this.viewOffical  = false
					this.viewPersonal = false
					this.viewDocument = false
					this.viewWork     = false
					this.viewEducation= false
					this.ViewFamily   = false
					this.viewEmgergency=false
				}else if(value ==='Work'){
					setTimeout(() => {
						var elem = document.getElementById("worka"); 
						elem.scrollIntoView(); 
					}, 500);
					this.viewSettings = false
					this.viewOffical  = false
					this.viewPersonal = false
					this.viewDocument = false
					this.viewWork     = true
					this.viewEducation= false
					this.ViewFamily   = false
					this.viewEmgergency=false
				}else if(value ==='Education'){
					setTimeout(() => {
						var elem = document.getElementById("educa"); 
						elem.scrollIntoView(); 
					}, 500);
					this.viewSettings = false
					this.viewOffical  = false
					this.viewPersonal = false
					this.viewDocument = false
					this.viewWork     = false
					this.viewEducation= true
					this.ViewFamily   = false
					this.viewEmgergency=false
				}else if(value ==='Family'){
					setTimeout(() => {
						var elem = document.getElementById("famil"); 
						elem.scrollIntoView(); 
					}, 500);
					this.viewSettings = false
					this.viewOffical  = false
					this.viewPersonal = false
					this.viewDocument = false
					this.viewWork     = false
					this.viewEducation= false
					this.ViewFamily   = true
					this.viewEmgergency=false
				}else if(value ==='Documents'){
					setTimeout(() => {
						var elem = document.getElementById("doca"); 
						elem.scrollIntoView(); 
					}, 500);
					this.viewSettings = false
					this.viewOffical  = false
					this.viewPersonal = false
					this.viewDocument = true
					this.viewWork     = false
					this.viewEducation= false
					this.ViewFamily   = false
					this.viewEmgergency=false
				}else if(value ==='Personal'){
					setTimeout(() => {
						var elem = document.getElementById("personal"); 
						elem.scrollIntoView(); 
					}, 500);
					this.viewSettings = false
					this.viewOffical  = false
					this.viewPersonal = true
					this.viewDocument = false
					this.viewWork     = false
					this.viewEducation= false
					this.ViewFamily   = false
					this.viewEmgergency=false
				}else if(value ==='OfficialPersonal'){
					setTimeout(() => {
						var elem = document.getElementById("personal"); 
						elem.scrollIntoView(); 
					}, 500);
					this.viewSettings = false
					this.viewOffical  = true
					this.viewPersonal = true
					this.viewDocument = false
					this.viewWork     = false
					this.viewEducation= false
					this.ViewFamily   = false
					this.viewEmgergency=false
				}
			  }
			  else{
				this.viewSettings = true
				this.viewOffical  = true
				this.viewPersonal = true
				this.viewDocument = true
				this.viewWork     = true
				this.viewEducation= true
				this.ViewFamily   = true
				this.viewEmgergency=true
			  }

			this.addEmployeeService.getData('country', 0, response => {
				if (response.data && response.data.length > 0) {
					this.countryList = response.data;
					this.addEmployeeService.getMasterData(res => {
						if (res.status == "OK") {
							this.department = res.data.department;
							this.designation = res.data.designation;
							this.location = res.data.location;
							this.employeeGroup = res.data.group;
							this.role = res.data.role;
							this.reportingManager = res.data.reporting_manager;
							this.lineManager = res.data.reporting_manager;
							this.masterListApi = res.data;
							if (this.role) {
								for (let i = 0; i < this.role.length; i++) {
									if (this.role[i].name.toUpperCase() == "EMPLOYEE") {
										this.roleChecked = [i];
										break;
									}
								}
							}
							this.addEmployeeService.getMaster(Res => {
								if (Res.status == "OK") {
									this.masterList = Res.data;
									
									if (!this.pageStatus) {
										this.showNotifyOnadd = false;
										this.disable = true;
										let id: any = this.route.snapshot.params['id'];
										this.addEmployeeService.getPeople(id,this.showEmployee, res => {
											let data: any = res.data;
											this.photo = data.photo;
											this.editFormData = res.data;
										
											if (res.status == "OK" && data) {
											
												this.maskUserIDname = true;
												data.status == '1' ? this.statusChecked = [0] : data.status == '2' ? this.statusChecked = [1] : data.status == '3' ? this.statusChecked = [2] : null;
												data.gender == 'M' ? this.checkedGender = [0] : data.gender == 'F' ? this.checkedGender = [1] : data.gender == 'O' ? this.checkedGender = [2] : null;
												(data.personalDetails.maritalStat == "1") ? this.materialChecked = [1] : this.materialChecked = [0];
												if(this.editFormData.financial_calendar_id)
												for(let i = 0;i < this.masterListApi.financial_year.length;i++){
													if(this.editFormData.financial_calendar_id == this.masterListApi.financial_year[i].id){
													   this.fineSelected = [i];
													   break;
													}
												}
						
												if(this.editFormData.date_of_relieving && this.editFormData.date_of_relieving != "0000-00-00"){
													this.dateofRevl = this.editFormData.date_of_relieving
													// let revLyearChange =  this.editFormData.date_of_relieving.split('-');
													// this.dateofRevl = revLyearChange[2] + "-" + revLyearChange[1] + "-" + revLyearChange[0];
												}
				
												if(this.editFormData.personalDetails.permantAddrProof.length){
													for(let i = 0 ; i < this.editFormData.personalDetails.permantAddrProof.length;i++){
														this.fileData.push({fileName :this.editFormData.personalDetails.permantAddrProof[i].file_name,file_data :this.editFormData.personalDetails.permantAddrProof[i].file_path,type:this.getFileType(this.editFormData.personalDetails.permantAddrProof[i].file_name)})
													}
												}
												if(this.editFormData && this.editFormData.personalDetails && this.editFormData.personalDetails.presentAddrProof && this.editFormData.personalDetails.presentAddrProof.length){
													for(let i = 0 ; i < this.editFormData.personalDetails.presentAddrProof.length;i++){
														this.fileDataSec.push({fileName :this.editFormData.personalDetails.presentAddrProof[i].file_name,file_data :this.editFormData.personalDetails.presentAddrProof[i].file_path,type:this.getFileType(this.editFormData.personalDetails.presentAddrProof[i].file_name)})
													}
												}
												if(this.editFormData.pay_period_id)
												for(let i = 0;i < this.masterListApi.pay_period.length;i++){
													if(this.editFormData.pay_period_id == this.masterListApi.pay_period[i].id){
													   this.periodSelected = [i];
													   break;
													}
												}
					
												if(this.editFormData.personalDetails.permantCountry && this.editFormData.personalDetails.presentCountry)
												for (let i = 0; i < this.countryList.length; i++) {
												  if (this.countryList[i].id == this.editFormData.personalDetails.permantCountry) {
													this.countrySelect = [i];
												  }
												  if (this.countryList[i].id == this.editFormData.personalDetails.presentCountry) {
													this.tempCountrySelected = [i];
												  }
												}
					
												if(this.editFormData.shift_type_id)
												for(let i = 0;i < this.masterListApi.shift_type.length;i++){
													if(this.editFormData.shift_type_id == this.masterListApi.shift_type[i].id){
													   this.shiftChecked = [i];
													   break;
													}
												}
												
												if(this.editFormData.personalDetails.bloodGrp){
													let group = [{ name: 'A+', id: 1 }, { name: 'O+', id: 2 }, { name: 'B+', id: 3 }, { name: 'AB+', id: 4 },
													{ name: 'A-', id: 5 }, { name: 'O-', id: 6 }, { name: 'B-', id: 7 }, { name: 'AB-', id: 8 }];
													for(let i = 0;i < group.length;i++){
														if(this.editFormData.personalDetails.bloodGrp.toLowerCase() == group[i].name.toLowerCase()){
														   this.groupSelect = [i];
														   break;
														}
													}
												}
					
												if(this.editFormData.shift_type_id)
												for(let i = 0;i < this.masterListApi.shift_type.length;i++){
													if(this.editFormData.shift_type_id == this.masterListApi.shift_type[i].id){
													   this.shiftChecked = [i];
													   break;
													}
												}
					
												(this.editFormData.personalDetails.child == '1')?this.childChecked = [1]:this.childChecked = [0];
												(this.editFormData.personalDetails.isSamePresent == '1')?this.sameAbove = true:this.sameAbove = false;
												if(this.editFormData.personalDetails.child == '1'){
													let gender = [{ name: 'Male', id: 1 }, { name: 'Female', id: 2 }, { name: 'Other', id: 3 }];
													this.childrenList = [];
													if(this.editFormData.personalDetails.child_details.length){
													for (let i = 0; i < this.editFormData.personalDetails.child_details.length; i++) {
														this.childrenList.push({
														  name: this.editFormData.personalDetails.child_details[i].childName,
														  gender: this.editFormData.personalDetails.child_details[i].childGender,
														  date: (this.editFormData.personalDetails.child_details[i].childDob && this.editFormData.personalDetails.child_details[i].childDob != '0000-00-00')?this.editFormData.personalDetails.child_details[i].childDob:'',
														  nameError: false, dateError: false, genderError: false
														});
												 	  
													}
													}else{
														this.childrenList.push({name:'',gender:'',date:'',nameError:false,dateError:false,genderError:false});   
													   }
									
													  for (let j = 0; j < this.childrenList.length; j++) {
														for (let i = 0; i < gender.length; i++) {
														  if (gender[i].name == this.childrenList[j].gender) {
															this.childrenList[j].selected = [i];
														  }
														}
													  }
												}	
												if(this.editFormData.educationalQualification && this.editFormData.educationalQualification.length){
													this.childrenListEducation = [];
													for(let i = 0 ; i < this.editFormData.educationalQualification.length;i++){
														this.childrenListEducation.push({
															qualification:this.editFormData.educationalQualification[i].qualif ,qualificationSelect:undefined,yearSelect : undefined,
															year: this.editFormData.educationalQualification[i].yearPassout,fileData :[],institution: this.editFormData.educationalQualification[i].institute, address: this.editFormData.educationalQualification[i].certificate,
															qualificationError: false, yearError: false, institutionError: false
														});
													
														for(let k = 0 ; k < this.editFormData.educationalQualification[i].file_details.length;k++){
															this.childrenListEducation[i].fileData.push({fileName : this.editFormData.educationalQualification[i].file_details[k].certificate_name,file_data : this.editFormData.educationalQualification[i].file_details[k].certificate,type:this.getFileType(this.editFormData.educationalQualification[i].file_details[k].certificate_name)});
														  }
													  }
													  for(let i = 0 ; i < this.childrenListEducation.length;i++){
														for(let j = 0 ; j < this.masterList.qualification.length;j++){
															if(this.masterList.qualification[j].qualifId == this.editFormData.educationalQualification[i].qualif){
																this.childrenListEducation[i].qualificationSelect = [j];
															}
														  }
													  }
													  for(let i = 0 ; i < this.childrenListEducation.length;i++){
														for(let j = 0 ; j < this.dayTime.length;j++){
															if(this.dayTime[j].name == this.editFormData.educationalQualification[i].yearPassout){
																this.childrenListEducation[i].yearSelect = [j];
															}
														  }
													  }
												}
												else{
													this.childrenListEducation = [{
														qualification: undefined, qualificationSelect: undefined, yearSelect: undefined, year: undefined, institution: undefined, address: undefined,
														qualificationError: false, yearError: false, institutionError: false,fileData : undefined
													}];
												}
												if(this.editFormData.workExperince && this.editFormData.workExperince.length){
													this.childrenListWork = [];
													for(let i = 0 ; i < this.editFormData.workExperince.length;i++){
														this.childrenListWork.push({
														  designation: this.editFormData.workExperince[i].desig_name,designationSelect:undefined, organization: this.editFormData.workExperince[i].organization, fileData :[] ,from: (this.editFormData.workExperince[i].frmDate && this.editFormData.workExperince[i].frmDate != '0000-00-00')? this.editFormData.workExperince[i].frmDate:'-', to: (this.editFormData.workExperince[i].toDate &&  this.editFormData.workExperince[i].toDate != '0000-00-00')?this.editFormData.workExperince[i].toDate:'-',
														  designationError: false, organizationError: false, fromError: false, toError: false
														});
														for(let k = 0 ; k < this.editFormData.workExperince[i].file_details.length;k++){
															this.childrenListWork[i].fileData.push({fileName : this.editFormData.workExperince[i].file_details[k].certificate_name,file_data : this.editFormData.workExperince[i].file_details[k].certificate,type:this.getFileType(this.editFormData.workExperince[i].file_details[k].certificate_name)});
														  }
													  }
													  for(let i = 0 ; i < this.childrenListWork.length;i++){
														for(let j = 0 ; j < this.masterList.designation.length;j++){
															if(this.masterList.designation[j].desigId == this.editFormData.workExperince[i].desig){
																this.childrenListWork[i].designationSelect = [j];
															}
														  }
													  }
												}
												else{
													this.childrenListWork = [{
														designation: undefined, organization: undefined, from: undefined, to: undefined,
														designationError: false, organizationError: false, fromError: false, toError: false,fileData : undefined
													}];
												}
					
												if(this.editFormData.documents && this.editFormData.documents.length){
													this.childrenListDoc = [];
													for(let i=0;i<this.editFormData.documents.length;i++){
														if(this.editFormData.documents[i].docValidity=='0000-00-00')
														   this.editFormData.documents[i].docValidity=''  
													  }
													for(let i = 0 ; i < this.editFormData.documents.length;i++){
														this.childrenListDoc.push({ name: this.editFormData.documents[i].docType,nameSelect : undefined, expiry: this.editFormData.documents[i].docValidity, no: this.editFormData.documents[i].docNumber,nameError: false,docalreadyAdded:false, expiryErro: false, noError: false,docError : false,
														uploadLater:this.editFormData.documents[i].uploadLater,fileData :[]});
														for(let k = 0 ; k < this.editFormData.documents[i].file_details.length;k++){
														  this.childrenListDoc[i].fileData.push({fileName : this.editFormData.documents[i].file_details[k].doc_name,file_data : this.editFormData.documents[i].file_details[k].fileName,type:this.getFileType(this.editFormData.documents[i].file_details[k].doc_name)});
														}
													  }
													  for(let i = 0 ; i < this.childrenListDoc.length;i++){
														for(let j = 0 ; j < this.masterList.documentType.length; j++){
															if(this.masterList.documentType[j].docTypeId == this.editFormData.documents[i].docType){
																this.childrenListDoc[i].nameSelect = [j];
															}
															
														  }
													 }
													 
												}
												else{
													this.childrenListDoc = [{ name: undefined, expiry: undefined, no: undefined, nameError: false, expiryErro: false, noError: false,docalreadyAdded:false, uploadLater: 0,fileData:undefined,docError : false }];
												}
												this.setCheckStatus(this.editFormData);
												
												if(this.editFormData){
													
													for(let i=0;i<this.editFormData.documents.length;i++){
														if(this.editFormData.documents[i].docNumber==""){
															// this.editFormData.documents[i]["emptyDocNo"]='1';
															this.childrenListDoc[i]["emptyDocNo"] = "1"
														}
														else{
															this.childrenListDoc[i]["emptyDocNo"] = "";
														}
													}
												}
											}
											this.loaderActionsService.display(false);
										})
									}
									else {
										if(this.selectedNotify.length){
											this.selectedEmail = this.selectedNotify;
										}
										this.showNotifyOnadd = true;
										this.attendanceChecked = [];
										this.shiftChecked = []
										this.fineSelected = [];
										this.periodSelected = [];
										this.childrenListEducation = [{
											qualification: undefined, qualificationSelect: undefined, yearSelect: undefined, year: undefined, institution: undefined, address: undefined,
											qualificationError: false, yearError: false, institutionError: false,fileData : undefined
										}];
										this.childrenListWork = [{
											designation: undefined, organization: undefined, from: undefined, to: undefined,
											designationError: false, organizationError: false, fromError: false, toError: false,fileData : undefined
										}];
										this.childrenListDoc = [{ name: undefined, expiry: undefined, no: undefined, nameError: false, expiryErro: false, noError: false,docalreadyAdded:false, uploadLater: 0,fileData:undefined,docError : false }];
										this.loaderActionsService.display(false);
										
										
										 

									}
								}
							});
						}
					})
				}
			})
		}
		// this.loaderActionsService.display(false);

	}
	selStatus(event){
		if(event && event.selected && event.selected.length){
			this.statusSelected = event
			if(this.statusSelected.selected[0].value != 'Resigned'){
				this.dateofRevl='';
			}
		}else{
			this.statusSelected = []
		}
	}
	checkForm(event){
      if(event.selected[0]){
		  if(event.selected[0].name == 'Married'){
			this.spouseCNo.enable();
			this.spouseName.enable();
			this.spouseDob.enable();
			this.sEmail.enable();
		  }
		  else{
			this.spouseCNo.disable();
			this.spouseName.disable();
			this.spouseDob.disable();
			this.sEmail.disable();
		  }
	  }
	}

	dateChange(event,i){
		if(event && this.childrenList){
		   this.childrenList[i].date = event;
		}
	  }

	addNewDoc() {
		let stat;
		this.checkChildrenDoc(this.childrenListDoc.length - 1);
		for (let i = 0; i < this.childrenListDoc.length; i++) {
			if (!this.childrenListDoc[i].nameError  && !this.childrenListDoc[i].noError && !this.childrenListDoc[i].docError) {
				stat = true;
			}
			else {
				stat = false;
				break;
			}
			
		}
		if (stat)
			this.childrenListDoc.push({ name: undefined, expiry: undefined, no: undefined, nameError: false, expiryErro: false, noError: false,docalreadyAdded:false,uploadLater: 0,docError:false });
	}

	/*
	author : Arun Johnson
	desc   : set status in multiselect & add value to input box in form control
  */
	setCheckStatus(data) {
		for (let index = 0; index < this.reportingManager.length; index++) {
			if (this.reportingManager[index].id == data.reporting_manager_id) {
				this.reportingChecked = [index];
			}
		}
		let group: any = [];
		data.group ? group = data.group.split(",") : null;
		this.groupChecked = [];
		this.editFormData.group_name = [];
		for (let index = 0; index < (this.employeeGroup && this.employeeGroup.length); index++) {
			for (let j = 0; j < group.length; j++) {
				if (group[j] == this.employeeGroup[index].id) {
					this.groupChecked.push(index);
					this.editFormData.group_name.push(this.employeeGroup[index].name);
				}
			}
		}
		if (this.editFormData.attendance_type_id) {
			if (this.editFormData.attendance_type_id == "2") {
				this.attendanceChecked = [1];
			}
			else {
				this.attendanceChecked = [0];
			}
		}
		for (let index = 0; index < (this.employeeType && this.employeeType.length); index++) {
			if (this.employeeType[index].value == data.employee_type) {
				this.employeeTypeChecked = [index];
			}
		}
		for (let index = 0; index < (this.lineManager && this.lineManager.length); index++) {
			if (this.lineManager[index].id == data.line_manager_id) {
				if (this.viewPage)
					this.lineChecked = [index + 1];
				else
					this.lineChecked = [index];
			}
		}
		for (let index = 0; index < (this.role && this.role.length); index++) {
			if (this.role[index].id == data.role_id) {
				this.roleChecked = [index];
			}
		}
		for (let index = 0; index < (this.designation && this.designation.length); index++) {
			if (this.designation[index].id == data.designation_id) {
				this.designationChecked = [index];
			}
		}

		for (let index = 0; index < (this.department && this.department.length); index++) {
			if (this.department[index].id == data.department_id) {
				this.departmentChecked = [index];
			}
		}
		for (let index = 0; index < (this.location && this.location.length); index++) {
			if (this.location[index].id == data.location_id) {
				this.locationChecked = [index];
			}
		}
		for (let index = 0; index < (this.probationPeriod && this.probationPeriod.length); index++) {
			if (this.probationPeriod[index].value == data.probation_period) {
				this.probationChecked = [index];
			}
		}
		setTimeout( ()=>{
				for (let index = 0; index < this.tempstateList.length; index++) {
				
				if (this.tempstateList[index].id == data.personalDetails.presentState) {
					this.tempStateSelected = [index];
					break;
				}
			}
		},3000)
		
		
		let doj: any;
		let dob: any;

		if(this.showEmployee){
			 doj = '';
		}
		else{
			(data.date_of_joining && data.date_of_joining != "0000-00-00")? doj = this.timeZone.toLocal(data.date_of_joining) : doj = null;
		}
		(data.dob && data.dob != "0000-00-00") ? dob = this.timeZone.toLocal(data.dob) : dob = '';
			this.employeeDetails.patchValue({
			firstName: data.first_name,
			lastName: (data.last_name)?data.last_name:'',
			dob: dob,
			permanetAddress: data.personalDetails.permntAddress,
			tempAddress: data.personalDetails.presentAddress,
			middleName: data.middle_name,
			displayName: data.display_name,
			contactNumber: data.contact_number,
			empId: data.code,
			userName: data.username,	
			extension: data.extension,
			speedDial: data.speed_dial,
			emailId: data.email,
			date_of_joining: doj,
			personalEmailId: data.personal_email,
			age:  moment().diff(dob, 'years'),
			landLine: data.personalDetails.landLine,
			bloodGroup: data.personalDetails.bloodGrp,
			city: data.personalDetails.permantCity,
			pincode: data.personalDetails.permantPincode,
			landMark: data.personalDetails.permntLandmark,
			templandMark: data.personalDetails.presentLandmark,
			temppincode: data.personalDetails.presentPincode,
			tempcity: data.personalDetails.presentCity,
			fatherName: data.personalDetails.fatherName,
			mEmail: data.personalDetails.motherEmail,
			sEmail: data.personalDetails.spouseEmail,
			fatherCNo: data.personalDetails.fatherMob,
			motherCNo: data.personalDetails.motherMob,
			spouseCNo: data.personalDetails.spouseMob,
			motherName: data.personalDetails.motherNam,
			spouseName: data.personalDetails.spouseName,
			fatherDob: (data.personalDetails.fatherDob != "0000-00-00")?data.personalDetails.fatherDob:'',
			motherDob: (data.personalDetails.motherDob != "0000-00-00")?data.personalDetails.motherDob:'',
			spouseDob: (data.personalDetails.spouseDob != "0000-00-00")?data.personalDetails.spouseDob:'',
			fatherEmailId: data.personalDetails.fatherEmail,
			emeNo: data.personalDetails.emergencyContMob,
			emeName: data.personalDetails.emergencyContName,
			emeRelation: data.personalDetails.emergencyContRelation,
		})

	}

	selectQual(event, i) {
		if (event.selected[0]) {
			this.childrenListWork[i].qualification = event.selected[0];
		}
	}

	/*
	*  @desc   :delete files from the upload list
	*  @author :dipin
	*/
	deleteFileWork(value, index) {
		this.childrenListWork[index].fileData.splice(value, 1);
		if (this.childrenListWork[index].fileData.length == 0) {
			this.childrenListWork[index].fileData = undefined;
		}
	}

	/*
	*  @desc   :delete files from the upload list
	*  @author :dipin
	*/
	deleteFileDoc(value, index) {
		this.childrenListDoc[index].fileData.splice(value, 1);
		if (this.childrenListDoc[index].fileData.length == 0) {
			this.childrenListDoc[index].fileData = undefined;
		}
	}

	/*
	*  @desc   :delete files from the upload list
	*  @author :dipin
	*/
	deleteFileEducation(value, index) {
		this.childrenListEducation[index].fileData.splice(value, 1);
		if (this.childrenListEducation[index].fileData.length == 0) {
			this.childrenListEducation[index].fileData = undefined;
		}
	}

	open(url) {
		if (url)
			window.open(url);
	}

	selectQualEducation(event, i) {
		if (event.selected[0]) {
			this.childrenListEducation[i].qualification = event.selected[0];
		}
	}

	selectYear(event, i) {
		if (event.selected[0]) {
			this.childrenListWork[i].designation = event.selected[0];
		}
	}

	selectYearEducation(event, i) {
		if (event.selected[0]) {
			this.childrenListEducation[i].year = event.selected[0];
		}
	}

	setGender(event, i) {
		if (event.selected[0] && this.childrenList) {
			this.childrenList[i].gender = event.selected[0].name;
		}
	}

	addNewWork() {
		let stat;
		this.checkChildrenWork(this.childrenListWork.length - 1);
		for (let i = 0; i < this.childrenListWork.length; i++) {
			if (!this.childrenListWork[i].designationError && !this.childrenListWork[i].organizationError && !this.childrenListWork[i].fromError && !this.childrenListWork[i].toError) {
				stat = true;
			}
			else {
				stat = false;
				break;
			}
		}
		if (stat)
			this.childrenListWork.push({
				designation: undefined, organization: undefined, from: undefined, to: undefined,
				designationError: false, organizationError: false, fromError: false, toError: false
			});
	}

	checkChildrenEducation(i) {
		if(this.childrenListEducation){
			if (!this.childrenListEducation[i].qualification) {
				this.childrenListEducation[i].qualificationError = true;
			}
			else {
				this.childrenListEducation[i].qualificationError = false;
			}
			if (!this.childrenListEducation[i].year) {
				this.childrenListEducation[i].yearError = true;
			}
			else {
				this.childrenListEducation[i].yearError = false;
			}
			if (!this.childrenListEducation[i].institution) {
				this.childrenListEducation[i].institutionError = true;
			}
			else {
				this.childrenListEducation[i].institutionError = false;
			}
		}
	}

	addNewEducation() {
		this.checkChildrenEducation(this.childrenListEducation.length - 1);
		let stat;
		for (let i = 0; i < this.childrenListEducation.length; i++) {
			if (!this.childrenListEducation[i].qualificationError && !this.childrenListEducation[i].yearError && !this.childrenListEducation[i].institutionError) {
				stat = true;
			}
			else {
				stat = false;
				break;
			}
		}
		if (stat)
			this.childrenListEducation.push({
				qualification: undefined, qualificationSelect: undefined, yearSelect: undefined, year: undefined, institution: undefined, address: undefined,
				qualificationError: false, yearError: false, institutionError: false
			});
	}

	checkChildrenWork(i) {
		if(this.childrenListWork){
			if (!this.childrenListWork[i].designation) {
				this.childrenListWork[i].designationError = true;
			}
			else {
				this.childrenListWork[i].designationError = false;
			}
			if (!this.childrenListWork[i].organization) {
				this.childrenListWork[i].organizationError = true;
			}
			else {
				this.childrenListWork[i].organizationError = false;
			}
			if (!this.childrenListWork[i].from) {
				this.childrenListWork[i].fromError = true;
			}
			else {
				this.childrenListWork[i].fromError = false;
			}
			if (!this.childrenListWork[i].to) {
				this.childrenListWork[i].toError = true;
			}
			else {
				this.childrenListWork[i].toError = false;
			}
		}
	}
	//vinod
	//file change event trigger
	fileChangeEvent(event: any): void {
		let validFileExtensions = [".jpg", ".jpeg", ".bmp", ".png"];    	
		let j =  this.checkImageExtension(event.target.files)
		if(!j){
			return;
		}
		if (event.target.files.length) {
			this.showPopUp = true;
			this.imageChangedEvent = event;
		}
	}
	//vinod
	//method to check extension
	checkImageExtension(oForm){
			// var _validFileExtensions = [".jpg", ".jpeg", ".bmp", ".gif", ".png", ".pdf","doc","docx","dot"];
			var _validFileExtensions = [".jpg", ".jpeg", ".bmp", ".png"];   
            var sFileName = oForm[0].name
            if (sFileName.length > 0) {
                var blnValid = false;
                for (var j = 0; j < _validFileExtensions.length; j++) {
                    var sCurExtension = _validFileExtensions[j];
                    if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                        blnValid = true;
                        break;
                    }
                }
                
                if (!blnValid) {
					this.notificationService.alertBoxValue("error", "Unsupported file format");
                    // alert("Sorry, " + sFileName + " is invalid, allowed extensions are: " + _validFileExtensions.join(", "));
                    return false;
                }
            }
	return true;
	}
	//vinod
	//method to check extension
	checkImageExtensionwithPdf(oForm){
		var _validFileExtensions = [".jpg", ".jpeg", ".bmp", ".gif", ".png", ".pdf"];  
		var sFileName = oForm[0].name
		if (sFileName.length > 0) {
			var blnValid = false;
			for (var j = 0; j < _validFileExtensions.length; j++) {
				var sCurExtension = _validFileExtensions[j];
				if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
					blnValid = true;
					break;
				}
			}
			
			if (!blnValid) {
				this.notificationService.alertBoxValue("error", "Unsupported file format");
				// alert("Sorry, " + sFileName + " is invalid, allowed extensions are: " + _validFileExtensions.join(", "));
				return false;
			}
		}
return true;
}
	imageCropped(event: any) {
		this.croppedImage = event.base64;
	}

	cancelCrop() {
		this.showPopUp = false
	}
	

	toFrom(date, value) {
		let obj = {};
		obj[value] = date;
		this.employeeDetails.patchValue(obj);
	}

	setAddress() {
		this.sameAbove = !this.sameAbove;
		if (this.sameAbove == true) {
			this.employeeDetails.patchValue({
				templandMark: this.landMark.value,
				tempcountry: this.country.value,
				tempstate: this.state.value,
				temppincode: this.pincode.value,
				tempcity: this.city.value,
				tempAddress: this.permanetAddress.value
			});
			for (let i = 0; i < this.countryList.length; i++) {
				if (this.countryList[i].id == this.country.value) {
					this.tempCountrySelected = [i];
					break;
				}
			}
			this.tempstateList = this.stateList;
			for (let i = 0; i < this.tempstateList.length; i++) {
				if (this.tempstateList[i].id == this.state.value) {
					this.tempStateSelected = [i];
					break;
				}
			}
			this.fileDataSec = this.fileData
		}else{
			this.fileDataSec = [];
		}
	}

	/*
	author : Arun Johnson
	desc   : create Form Controls
  */
	createFormControls() {
		let alpha = "^[a-zA-Z ]*$";
		let beta = "^[a-zA-Z ]+[.]*[a-zA-Z]*$";
		let contactNumber = "^[0-9+() -]*$";
		let number = "^[0-9]*$";
		let useName = "^[a-zA-Z0-9._@]+$";
		let emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$";
		this.firstName = new FormControl('', [Validators.required, this.noWhitespaceValidator, Validators.pattern(beta)]);
		this.lastName = new FormControl('');
		this.dob = new FormControl('', [Validators.required]);
		this.date_of_joining = new FormControl('', [Validators.required]);
		this.personalEmailId = new FormControl('', [Validators.required, Validators.pattern(emailPattern)]);
		this.contactNumber = new FormControl('', [Validators.required, Validators.pattern(contactNumber)]);
		this.permanetAddress = new FormControl('');
		this.tempAddress = new FormControl('');
		this.middleName = new FormControl('', [Validators.pattern(beta)]);
		this.displayName = new FormControl('');
		this.extension = new FormControl('', [Validators.pattern(number)]);
		this.speedDial = new FormControl('', [Validators.pattern(number)]);
		this.empId = new FormControl('', [Validators.required, this.noWhitespaceValidator, Validators.pattern("^[a-zA-Z0-9]+$")]);
		this.emailId = new FormControl('', [Validators.pattern(emailPattern)]);
		this.userName = new FormControl('', [Validators.required,Validators.pattern(useName)]);
		this.age = new FormControl('', [Validators.required, Validators.pattern(contactNumber)]);
		this.landLine = new FormControl('', [Validators.pattern(contactNumber)]);
		this.bloodGroup = new FormControl('');
		this.country = new FormControl('');
		this.state = new FormControl('');
		this.city = new FormControl('');
		this.pincode = new FormControl('', [Validators.pattern(contactNumber)]);
		this.landMark = new FormControl('');
		this.templandMark = new FormControl('');
		this.tempcountry = new FormControl('');
		this.tempstate = new FormControl('');
		this.temppincode = new FormControl('');
		this.tempcity = new FormControl('');
		this.fatherName = new FormControl('');
		this.mEmail = new FormControl('');
		this.sEmail = new FormControl('');
		this.fatherCNo = new FormControl('');
		this.motherCNo = new FormControl('');
		this.spouseCNo = new FormControl('');
		this.motherName = new FormControl('');
		this.spouseName = new FormControl('');
		this.motherDob = new FormControl('');
		this.fatherDob = new FormControl('');
		this.spouseDob = new FormControl('');
		this.fatherEmailId = new FormControl('', [Validators.pattern(emailPattern)]);
		this.emeNo = new FormControl('', [Validators.pattern(contactNumber)]);
		this.emeName = new FormControl('');
		this.emeRelation = new FormControl('');
	}
	scrollTo(el: Element) {
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            const input: any = el.querySelector('.form-control');
            const pattern: any = el.querySelector('.pattern');
            // if(pattern){
            //   pattern.focus();
            // }
            if(input){
              input.focus();
            }
            const firstChild = el.firstChild;
            if(input === firstChild){
                input.focus();
            }
        }
    }
	/*
	author : Arun Johnson
	desc   : create Form Groups
  */
	createForm() {
		this.employeeDetails = new FormGroup({
			firstName: this.firstName,
			lastName: this.lastName,
			dob: this.dob,
			date_of_joining: this.date_of_joining,
			personalEmailId: this.personalEmailId,
			contactNumber: this.contactNumber,
			permanetAddress: this.permanetAddress,
			tempAddress: this.tempAddress,
			middleName: this.middleName,
			displayName: this.displayName,
			empId: this.empId,
			emailId: this.emailId,
			userName: this.userName,
			extension: this.extension,
			speedDial: this.speedDial,
			age: this.age,
			landLine: this.landLine,
			bloodGroup: this.bloodGroup,
			country: this.country,
			state: this.state,
			city: this.city,
			pincode: this.pincode,
			landMark: this.landMark,
			templandMark: this.templandMark,
			tempcountry: this.tempcountry,
			tempstate: this.tempstate,
			temppincode: this.temppincode,
			tempcity: this.tempcity,
			fatherName: this.fatherName,
			mEmail: this.mEmail,
			sEmail: this.sEmail,
			fatherCNo: this.fatherCNo,
			motherCNo: this.motherCNo,
			spouseCNo: this.spouseCNo,
			motherName: this.motherName,
			spouseName: this.spouseName,
			fatherDob: this.fatherDob,
			motherDob: this.motherDob,
			spouseDob: this.spouseDob,
			fatherEmailId: this.fatherEmailId,
			emeNo: this.emeNo,
			emeName: this.emeName,
			emeRelation: this.emeRelation,
		});
	}

	formControlValueSet(value, event, key) {
		if (event.selected[0]) {
			let obj = {};
			obj[value] = event.selected[0][key];
			this.employeeDetails.patchValue(obj);
		}
	}

	selectCountry(value, event, key, type) {
		if (event.selected[0]) {
			this.loadermultiOnboard=true;
			let obj = {};
			obj[value] = event.selected[0][key];
			this.employeeDetails.patchValue(obj);
			this.addEmployeeService.getData('state', event.selected[0].id, response => {
				if (response.data && response.data.length > 0) {
					if (type == 1) {
						this.tempstateList = response.data;
						if (this.editFormData && (this.stateTempWatched == false)) {
							for (let i = 0; i < this.stateList.length; i++) {
								if (this.stateList[i].id == this.editFormData.personalDetails.presentState) {
									this.tempStateSelected = [i];
									break;
								}
							}
							this.stateTempWatched = true;
						}
					}
					else {
						this.stateList = response.data;
						if (this.editFormData && (this.stateWatched == false)) {
							for (let i = 0; i < this.stateList.length; i++) {
								if (this.stateList[i].id == this.editFormData.personalDetails.permantState) {
									this.stateSelect = [i];
									break;
								}
							}
							this.stateWatched = true;
						}
					}
					this.loadermultiOnboard = false;
				}
				else {
					this.loadermultiOnboard = false;
				}
			})
		}
	}

	/*
	author : Arun Johnson
	desc   : validation for white space in form
	params :
  */
	noWhitespaceValidator(control: FormControl) {
		let isWhitespace = (control.value || '').trim().length === 0;
		let isValid = !isWhitespace;
		return isValid ? null : { 'whitespace': true }
	}

	/*
	author : Arun Johnson
	desc   : validation for contact number
	params :
  */
	contactValidation(event: any) {
		let vKey = 86;
		let cKey = 67;
		let aKey = 65;
		let xKey = 88;
		let specialKeys2: any = ['!', '@', '#', '$', '%', '^', '&', '*'];
		let specialKeys: any = ['Backspace', 'Tab', 'End', 'Home', 'Delete', 'Del'];
		if (specialKeys.indexOf(event.key) !== -1) {
			return;
		}
		if (specialKeys2.indexOf(event.key) !== -1) {
			event.preventDefault();
			return;
		}
		if (((96 <= event.keyCode && event.keyCode <= 105) || (48 <= event.keyCode && event.keyCode <= 57 || event.keyCode == 37 || event.keyCode == 189 || event.keyCode == 187 || event.keyCode == 107 || event.keyCode == 109 || event.keyCode == 39 || (event.keyCode == 86 && event.keyCode == 17) || (event.keyCode == 67 && event.keyCode == 17) || (event.keyCode == 65 && event.keyCode == 17) || (event.keyCode == 88 && event.keyCode == 17)) || (event.keyCode == 17 && event.ctrlKey))) {
		} else {
			event.preventDefault();
		}
	}
	
	/*
	author : Arun Johnson
	desc   : submit form
	params :
  */
	submitForm(value) {
		this.loaderActionsService.display(true);
		let validDoj: boolean = false;
		let tempStart = [], tempEnd = [];
		tempStart = this.employeeDetails.value.date_of_joining.split("-");
		if (this.employeeDetails.value.dob && this.employeeDetails.value.dob != '')
			tempEnd = this.employeeDetails.value.dob.split("-");
			// if (this.dobError && this.dojError && tempEnd.length && tempStart.length && moment(tempEnd[1] + "-" + tempEnd[0] + "-" + tempEnd[2], 'MM-DD-YYYY HH:mm').isSameOrAfter(moment(tempStart[1] + "-" + tempStart[2] + "-" + tempStart[0], 'MM-DD-YYYY HH:mm'))) {
			if(this.dobError && this.dojError && tempEnd.length && tempStart.length && moment(tempEnd[1]+"-"+tempEnd[0]+"-"+tempEnd[2],'MM-DD-YYYY HH:mm').isSameOrAfter(moment(tempStart[1]+"-"+tempStart[0]+"-"+tempStart[2],'MM-DD-YYYY HH:mm'))) {	
		this.notificationService.alertBoxValue("error", "Date of joining should be greater than Date of Birth");
			validDoj = true;
			this.loaderActionsService.display(false)
		}

		// if(this.childSelect.selected[0] && this.childSelect.selected[0].name == 'Yes')
		//  this.checkChildren(this.childrenList.length - 1);
		
		
		let statDoc = true;
		if (this.childrenListDoc)
		  for (let i = 0; i < this.childrenListDoc.length; i++) {
			if (!this.childrenListDoc[i].nameError && !this.childrenListDoc[i].noError && !this.childrenListDoc[i].expiryErro && !this.childrenListDoc[i].docError) {
				statDoc = true;
			}
			else {
				statDoc = false;
			  break;
			}
		  }
		else {
			statDoc = true;
		}

		let statWork = true;
		if (this.childrenListWork)
		for (let i = 0; i < this.childrenListWork.length; i++) {
			if (!this.childrenListWork[i].designationError && !this.childrenListWork[i].organizationError && !this.childrenListWork[i].fromError && !this.childrenListWork[i].toError) {
				statWork = true;
			}
			else {
				statWork = false;
				break;
			}
		}
		else
		  statWork = false;

		  let statEducation = true;
		  if(this.childrenListEducation)
		  for(let i = 0; i < this.childrenListEducation.length;i++){
			if(!this.childrenListEducation[i].qualificationError && !this.childrenListEducation[i].yearError && !this.childrenListEducation[i].institutionError){
			  statEducation = true;
			}
			else{
			  statEducation = false;
			  break;
			}
		}
		else
		  statEducation = false;

		if(this.childSelect.selected[0] && this.childSelect.selected[0].name != 'Yes'){
          this.childrenList = [];
		}
		let doR
		if(typeof this.dateofRevl =='object'){
			doR = this.formatForApi(this.dateofRevl);
		}else{
			doR = this.dateofRevl;
		}
		let doJ = this.employeeDetails.get('date_of_joining').value;
		let dateofrelieving = false;
		if((doR && doR != '0000-00-00') && (doJ && doJ != '0000-00-00')){
			let k = doJ.split('-')
			let newDojSplit = Number(k[2]) + "-" + Number(k[1]) + "-" + Number(k[0]);
				let newDor = new Date(doR);
				let newDoj = new Date(newDojSplit)
				if(newDoj > newDor){
					dateofrelieving = true;
			}
		}
		if(dateofrelieving){
			this.notificationService.alertBoxValue("error", 'date of releiving should be greater than date of joining');
			this.loaderActionsService.display(false)
		}
		for(let i = 0 ; i < this.childrenListDoc.length;i++){
			if(!this.childrenListDoc[i].nameError && this.childrenListDoc[i].name != undefined){
				var valueArr = this.childrenListDoc.map(function(item){ return item.name.docName });
				var isDuplicate = valueArr.some(function(item, idx){ 
				   return valueArr.indexOf(item) != idx 
				})
			}
		}
		if(isDuplicate){
			this.notificationService.alertBoxValue("error", "Duplicate Document Name Found");
			this.loaderActionsService.display(false)
		}
		if(this.childrenListDoc.length){
			for (let i = 0; i < this.childrenListDoc.length; i++) {
                            if( this.childrenListDoc[i].name != undefined ) {
				if( this.childrenListDoc[i].name.haveExpiry == "1" && this.childrenListDoc[i].expiry == undefined && this.childrenListDoc[i].name.docName != undefined || this.childrenListDoc[i].name.haveExpiry == "1" && this.childrenListDoc[i].expiry == "" && this.childrenListDoc[i].name.docName != undefined){
					this.errorDocid=true
				}
				else{
					this.errorDocid=false
				}
                            }
			}
		}
		// ||( !this.financialYear.selected[0])
		if (!statEducation || !statDoc || !statWork ||  dateofrelieving || isDuplicate || !this.genderSelected.selected[0] || !this.employeeGroupSelected.selected[0] || !this.designationSelected.selected[0]  || !this.attendanceSelected.selected[0]  || (!this.shiftSelected.selected[0]) || (!this.payperiod.selected[0] ) || (this.dob.value != '' && !this.dobError) || (this.showProbation && !this.probationSelected.selected[0]) || !this.dojError || !this.reportingManagerSelect.selected[0] || !this.locationSelected.selected[0] || !this.employeeDetails.valid || validDoj || (this.roleStatus.selected.length == 0) || this.errorDocid) {
			this.personalDetailError = true;
				this.personalDetailError = true;
				this.viewSettings = true
				  this.viewOffical  = true
				  this.viewPersonal = true
				  this.viewDocument = true
				  this.viewWork     = true
				  this.viewEducation= true
				  this.ViewFamily   = true
				  this.viewEmgergency=true
			setTimeout(()=>{
				const error = document.querySelector('.error');
			 if(error){
				this.loaderActionsService.display(false);
				 this.scrollTop(error);
			 }
			  return;
			})

			if (!this.firstName.valid) {
				document.getElementById("firstname").focus();
			}
			else if(!this.genderSelected.selected[0]){
				document.getElementById("gender").focus();
				document.getElementById("gender").scrollIntoView(false);
			}
			else if ((this.roleStatus.selected.length == 0)) {
				document.getElementById("role").focus();
				document.getElementById("role").scrollIntoView(false);
			}

			else if (!this.locationSelected.selected[0]) {
				document.getElementById("loc-prior").focus();
				document.getElementById("loc-prior").scrollIntoView(false);
			}
			else if (!this.reportingManagerSelect.selected[0]) {
				document.getElementById("rep-manage").focus();
				document.getElementById("rep-manage").scrollIntoView(false);
			}
			else if (!this.attendanceSelected.selected[0]) {
				document.getElementById("attendanceT").focus();
				document.getElementById("attendanceT").scrollIntoView(false);
			}
		}
		else {
			let tempData = [];
			if (this.sendPermissionData)
				for (var i = 0; i < this.sendPermissionData.length; i++) {
					for (var j = 0; j < this.sendPermissionData[i].groups.length; j++) {
						if (this.sendPermissionData[i].groups[j].access == 1) {
							tempData.push(this.sendPermissionData[i].groups[j].id);
						}
					}
				}
				let nofyArray = [];
				let notifyString;
				for(var i = 0;i<this.selectedEmailData.length;i++){
					nofyArray.push(this.selectedEmailData[i].label)
				}
				if(nofyArray.length){
					notifyString = nofyArray.toString();
				}
				
			this.addEmployeeService.submitForm(
				notifyString,
				this.passCroppedImage,
				this.editFormData,
				value,
				this.probationSelected,
				this.genderSelected,
				this.maritalSelected,
				this.roleStatus,
				this.designationSelected,
				this.departmentSelected,
				this.locationSelected,
				this.reportingManagerSelect,
				this.lineManagerSelected,
				this.employeeTypeSelected,
				this.employeeGroupSelected,
				this.statusSelected,
				this.employeeDetails, tempData, this.attendanceSelected,
				this.childrenList,
				this.childrenListWork,
				this.childrenListEducation,
				this.childrenListDoc,this.sameAbove,this.fileData,this.dateofRevl,
				this.financialYear,this.payperiod,
				this.shiftSelected,this.fileDataSec,res => {
					if (res.status == "OK") {
						this.sendPermissionData = [];
						if (value == "add") {
							let self = this;
							self.locations.navigate(['/modules/employee/details']);
							setTimeout(function () {
								self.notificationService.alertBoxValue("success", "Employee Added Successfully");
							});
							this.loaderActionsService.display(false);
						} else {
							let self = this;
							self.locations.navigate(['/modules/employee/details']);
							setTimeout(function () {
								self.notificationService.alertBoxValue("success", "Employee Details Updated Successfully");
							});
							this.loaderActionsService.display(false);
						}

					}
					else {
						this.loaderActionsService.display(false);
						if (res.data && res.data.username) {
							this.notificationService.alertBoxValue("error", res.data.username[0]);
						} else if (res.data && res.data.code) {
							this.notificationService.alertBoxValue("error", res.data.code[0]);
						} else if (res.data && res.data.code) {
							this.notificationService.alertBoxValue("error", res.data.code[0]);
						} else if (res.data && res.data.personal_email) {
							this.notificationService.alertBoxValue("error", res.data.personal_email[0]);
						} else if (res.data && res.data.username) {
							this.notificationService.alertBoxValue("error", res.data.username[0]);
						} else if (res.data && res.data.email) {
							this.notificationService.alertBoxValue("error", res.data.email[0]);
						} else if (res.data && res.data.contact_number) {
							this.notificationService.alertBoxValue("error", res.data.contact_number[0]);
						} else {
							this.notificationService.alertBoxValue("error", res.message);
						}
					}
				});
		}
	}

	back(){
		window.history.back();
	}

	convertToEmployee(){
			this.loaderActionsService.display(true)			
			this.personalDetailError = false;
			let tempData = [];
			if(this.sendPermissionData)
			for (var i = 0; i < this.sendPermissionData.length; i++) {
				for (var j = 0; j < this.sendPermissionData[i].groups.length; j++) {
					if (this.sendPermissionData[i].groups[j].access == 1) {
						tempData.push(this.sendPermissionData[i].groups[j].id);
					}
				}
			}
			let params,group = [];
			for (let i = 0; i < this.employeeGroupSelected.selected.length; i++) {
				group.push(this.employeeGroupSelected.selected[i].id);
			}

			params = {
				"onboard_id": this.route.snapshot.params['id'],
				"details": {
					"email": 	this.employeeDetails.value.emailId,
					"username": 	this.employeeDetails.value.userName,
					"code": 	this.employeeDetails.value.empId,
					"extension": 	this.employeeDetails.value.extension,
					"speed_dial":	this.employeeDetails.value.speedDial,
					"date_of_joining": 	this.formateDate2(this.employeeDetails.value.date_of_joining),
					"role_id": this.roleStatus.selected[0] ? this.roleStatus.selected[0].id : null,
					"department_id": this.departmentSelected.selected[0] ? this.departmentSelected.selected[0].id : null,
					"designation_id": this.designationSelected.selected[0] ? this.designationSelected.selected[0].id : null,
					"location_id": this.locationSelected.selected[0] ? this.locationSelected.selected[0].id : null,
					"reporting_manager_id":this.reportingManagerSelect.selected[0] ?this. reportingManagerSelect.selected[0].id : null,
					"line_manager_id": this.lineManagerSelected.selected[0] ? this.lineManagerSelected.selected[0].id : null,
					"employee_type":  this.employeeTypeSelected.selected[0] ? this.employeeTypeSelected.selected[0].value : null,
					"probation_period":  this.probationSelected.selected[0] ?this. probationSelected.selected[0].value : null,
					"financial_calendar_id": (this.financialYear.selected[0])?this.financialYear.selected[0].id:null,
					"pay_period_id": (this.payperiod.selected[0])?this.payperiod.selected[0].id:null,
					"shift_type_id": (this.shiftSelected.selected[0])?this.shiftSelected.selected[0].id:null,
					"date_of_relieving":this.formatForApi(this.dateofRevl),
					"group":group,
					"punch_type": (this.attendanceSelected.selected[0].type == "Manual") ? 2 : 1,
					"role_privilege_ids": tempData,
					"status": this.statusSelected.selected[0] ? this.statusSelected.selected[0].name : 1,
					"attendance_type_id":(this.attendanceSelected.selected[0].type == "Manual") ? 2 : 1,
				}
			}	 

			//  this.addEmployeeService.convertToEmployee(,
			// 	this.employeeDetails,
			// 	this.probationSelected,
			// 	this.roleStatus,
			// 	this.designationSelected,
			// 	this.departmentSelected,
			// 	this.locationSelected,
			// 	this.reportingManagerSelect,
			// 	this.lineManagerSelected,
			// 	this.employeeTypeSelected,
			// 	this.employeeGroupSelected,
			// 	this.statusSelected,
			// 	this.employeeDetails, tempData, this.attendanceSelected,
			//     this.dateofRevl,
			// 	this.financialYear,
			// 	 this.payperiod
			// 	,this.shiftSelected,res => {
				this.addEmployeeService.converttoEmployee(params,res => {
					
					if (res.status == "OK") {
						this.sendPermissionData = [];

						let self = this;
						self.locations.navigate(['/modules/employee/details']);
						setTimeout(function () {
							self.notificationService.alertBoxValue("success", "Candidate Converted To Employee Successfully");
						});
						this.loaderActionsService.display(false)					 

					}
					else {
						this.showAlert = false
						if (res.data && res.data.username) {
							this.notificationService.alertBoxValue("error", res.data.username[0]);
						} else if (res.data && res.data.code) {
							this.notificationService.alertBoxValue("error", res.data.code[0]);
						} else if (res.data && res.data.code) {
							this.notificationService.alertBoxValue("error", res.data.code[0]);
						} else if (res.data && res.data.personal_email) {
							this.notificationService.alertBoxValue("error", res.data.personal_email[0]);
						} else if (res.data && res.data.username) {
							this.notificationService.alertBoxValue("error", res.data.username[0]);
						} else if (res.data && res.data.email) {
							this.notificationService.alertBoxValue("error", res.data.email[0]);
						} else if (res.data && res.data.contact_number) {
							this.notificationService.alertBoxValue("error", res.data.contact_number[0]);
						} else {
							this.notificationService.alertBoxValue("error", res.message);
						}
						this.loaderActionsService.display(false);
					}
				});
		// }
	}

	formateDate2(date) {
		let newdate = date.split('-')
		let newdate2 = newdate[2]+"-"+(newdate[1])+"-"+newdate[0]
		if (newdate2) {
			let ndate = this.timeZone.toLocal(moment(newdate2, 'YYYY-MM-DD'));
			if (ndate) {
				return moment(ndate).format('YYYY-MM-DD')
			}
		} else
			return null;
	}
	scrollTop(el: Element) {
		if (el) {
			el.scrollIntoView({ behavior: 'smooth', block: 'center' });
			const input: any = el.querySelector('.form-control');
			const pattern: any = el.querySelector('.pattern');
			// if(pattern){
			//   pattern.focus();
			// }
			if(input){
			  input.focus();
			}
			const firstChild = el.firstChild;
			if(input === firstChild){
				input.focus();
			}
		}
	}
	/*
	author : Arun Johnson
	desc   : reset Form
	params :
  */
	reset() {
		if (!this.pageStatus) {
			this.setCheckStatus(this.editFormData);
		}
		else {
			this.checkedGender = !this.checkedGender;
			this.materialChecked = !this.materialChecked;
			this.roleChecked = !this.roleChecked;
			this.designationChecked = !this.designationChecked;
			this.lineChecked = !this.lineChecked;
			this.employeeTypeChecked = !this.employeeTypeChecked;
			this.groupChecked = !this.groupChecked;
			this.reportingChecked = !this.reportingChecked;
			this.departmentChecked = !this.departmentChecked;
			this.locationChecked = !this.locationChecked;
			this.statusChecked = !this.statusChecked;
			this.employeeDetails.reset();
		}
	}

	/*
	  author : Arun Johnson
	  desc   : if confirm button pressed
	 */
	confirmPopup() {
		// this.locations.navigate(['/modules/employee/details']);thu
		window.history.back()
	}

	/*
	author : dipin
	desc   : set date of birth
   */
	setDateDob(event) {
		this.dobError = event.status;
		this.employeeDetails.patchValue({
			dob : event.date,
		})
		if(this.dobError){
			this.employeeDetails.patchValue({
				age : moment().diff(moment(event.date, "DD-MM-YYYY"), 'years'), 
			})
		}
		else {
			this.employeeDetails.patchValue({
				age : '', 
			})
		}
	}

	/*
	*  @desc   : make date to the format 'dd-mm-yyyy'
	*  @author : nilena
	*/
	formatForApi(inputDate) {
		var date = this.timeZone.toLocal(inputDate);
		if (date)
		  if (!isNaN(date.getTime())) {
			if ((Number(date.getMonth()) + 1) < 10) {
			  if (Number(date.getDate() < 10)) {
				return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
			  }
			  else {
				return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
			  }
			}
			else {
			  if (Number(date.getDate() < 10)) {
				return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
			  }
			  else {
				return date.getDate() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
			  }
			}
		  }
		  else
			return undefined;
	  }
	  /*
	*  @desc   : make date to the format 'dd-mm-yyyy'
	*  @author : nilena
	*/
	formatForApi2(inputDate) {
		var date = this.timeZone.toLocal(inputDate);
		if (date)
		  if (!isNaN(date.getTime())) {
			if ((Number(date.getMonth()) + 1) < 10) {
			  if (Number(date.getDate() < 10)) {
				return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
			  }
			  else {
				return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
			  }
			}
			else {
			  if (Number(date.getDate() < 10)) {
				return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
			  }
			  else {
				return  date.getFullYear()+ "-" + (Number(date.getMonth()) + 1) + "-" +  date.getDate();
			  }
			}
		  }
		  else
			return undefined;
	  }
// 	isValidDate(date){
//     var matches = /^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/.exec(date);
//     if (matches == null) return false;
//     var d = matches[2];
//     var m = matches[1] - 1;
//     var y = matches[3];
//     var composedDate = new Date(y, m, d);
//     return composedDate.getDate() == d &&
//             composedDate.getMonth() == m &&
//             composedDate.getFullYear() == y;
// }
	/*
	author : dipin
	desc   : set date of joining
   */
  setDateJoining(event) {
	let pattern  = /^([0]?[1-9]|[1|2][0-9]|[3][0|1])[./-]([0]?[1-9]|[1][0-2])[./-]([0-9]{4}|[0-9]{2})$/
	//   this.dojError = event.status;
	this.employeeDetails.patchValue({
		date_of_joining: event.date
	})
	if(pattern.test(event.date)){
		this.dojError = true
	}else{
		this.dojError = false;
	}
}
	setDatJoining(event) {
	let pattern  = /^([0]?[1-9]|[1|2][0-9]|[3][0|1])[./-]([0]?[1-9]|[1][0-2])[./-]([0-9]{4}|[0-9]{2})$/
	let today = new Date () 
	today.setHours(0,0,0,0);
	let otherDay = event.date
	let v= otherDay.split('-')
	
	if(pattern.test(event.date)){
		if(v.length==3){
			if(v[3]!=''){
				let year = v[2]
				if(year.length==4){
					otherDay = new Date(v[2],(v[1]-1),v[0])
					if(otherDay >= today){
						this.employeeDetails.patchValue({
							date_of_joining: event.date
						})
						this.dojError = true;
						this.dojErrorConvert = true
					}
					else{
						this.dojErrorConvert =false
						this.dojError = true
						this.employeeDetails.patchValue({
							date_of_joining: ''
						})
						}	
				}
			}
		}
	}else{
		this.dojError = false;
		this.dojErrorConvert = true
		this.employeeDetails.patchValue({
			date_of_joining: ''
		})
	}
		// this.dojError = true;
	}
	formateDate(date) {
		if (date) {
			date = this.timeZone.toLocal(moment(date, 'YYYY-MM-DD'));
			if (date) {
				return moment(date).format('YYYY-MM-DD')
			}
		} else
			return null;
	}

	/*
	author : dipin
	desc   : set disable property for probation period when employee type is probation
   */
	setProbation() {
		if (this.employeeTypeSelected) {
			if (this.employeeTypeSelected.selected.length && this.employeeTypeSelected.selected[0].value == "Probation") {
				this.showProbation = true;
			}
			else {
				this.showProbation = false;
				this.probationChecked = [];
			}
		}
		else
			this.showProbation = false;
	}

	/*
	author : dipin
	desc   : change view page to edit view
   */
	editDetail() {
		let self = this;
		self.loaderActionsService.display(true);
		let type = btoa('edit');
		setTimeout(function () {
			self.viewPage = false;
			window.scrollTo(0, 0);
			self.locations.navigate(
				[],
				{
					relativeTo: this.router,
					queryParams: { type },
					queryParamsHandling: "merge"
				});
			self.loaderActionsService.display(false);
		}, 100);
	}

	/*
	author : dipin
	desc   : add class based on index
	*/
	getClassByValue() {
		return this.userDetailsService.getClassByValue(1);
	}

	/*
  author : dipin
  desc   : add class based on index
  */
	showAddNew(event) {
		if (event.status) {
			this.addEmployeeService.addCustomRole({ "name": event.value, "status": "1" }, res => {
				if (res.status == "OK") {
					this.role.push({ id: res.role_id, name: event.value });
					this.roleChecked = [this.role.length - 1];
					this.notificationService.alertBoxValue("success", res.message);
				}
				else {
					let temp = this.roleChecked;
					this.roleChecked = temp;
					this.notificationService.alertBoxValue("error", res.data.name[0]);
				}
			})
		}
	}

	/*
  author : dipin
  desc   : add class based on index
  */
	getPermissionData() {
		if (!this.permissionData || this.permissionData.length == 0) {
			this.lazyLoad = true;
			this.addEmployeeService.getPermissions(this.route.snapshot.params['id'], this.roleStatus.selected[0].id, res => {
				this.permissionData = res.data;
				this.lazyLoad = false;
				this.sendPermissionData = [];
			})
		}
	}

	/*
  author : dipin
  desc   : add class based on index
  */
	showExpand(k, value) {
		this.permissionData[k].status = value;
		if (value) {
			for (let i = 0; i < this.permissionData.length; i++) {
				if (i != k) {
					this.permissionData[i].status = false;
				}
			}
		}
	}

	/*
  author : dipin
  desc   : add class based on index
  */
	submitPermission() {
		
		this.showOverridePopup = false;
		this.sendPermissionData = Object.assign(this.permissionData);
	}

	checkClickOutside() {
		if (!this.lazyLoad) {
			this.showOverridePopup = false;
			this.permissionData = [];
			this.permissionData = Object.assign(this.sendPermissionData);
		}
	}

	removeDuplicates(arr) {
		let unique_array = []
		for (let i = 0; i < arr.length; i++) {
			if (unique_array.indexOf(arr[i]) == -1) {
				unique_array.push(arr[i])
			}
		}
		return unique_array
	}

	checkChildrenDoc(i) {
		if(this.childrenListDoc){
			if (!this.childrenListDoc[i].name) {
				this.childrenListDoc[i].nameError = true;
			}
			else {
				this.childrenListDoc[i].nameError = false;
			}
			// if (!this.childrenListDoc[i].expiry) {
			// 	this.childrenListDoc[i].expiryError = true;
			// }
			// else {
			// 	this.childrenListDoc[i].expiryError = false;
			// }
			if (!this.childrenListDoc[i].no) {
				this.childrenListDoc[i].noError = true;
			}
			else {
				this.childrenListDoc[i].noError = false;
			}
			// if ((!this.childrenListDoc[i].fileData) || this.childrenListDoc[i].fileData.length == 0 && (this.childrenListDoc[i].uploadLater == 0) ){
			// 	this.notificationService.alertBoxValue("error", "please upload document");
			// 	this.childrenListDoc[i].docError = true;
			// }
			// else {
			// 	this.childrenListDoc[i].docError = false;
			// }
		}
	}


	selectYearDoc(event, i) {
		
		if (event.selected[0]) {
			this.childrenListDoc[i].name = event.selected[0]
			for (let i = 0; i < this.childrenListDoc.length; i++) {
				if(this.childrenListDoc[i].name.haveExpiry == "1" ){
					this.childrenListDoc[i].docTypeValidation =true;
				}
				else{
					this.childrenListDoc[i].docTypeValidation =false;
				}
			}
		}
	}

	addNew(){
		 this.childrenList.push({name:'',gender:'',date:'',nameError:false,dateError:false,genderError:false});
	  }

	  checkChildren(i){
		  if(this.childrenList){
			if(this.childrenList[i].name.trim() == ''){
				this.childrenList[i].nameError = true;
			  }
			  else{
				this.childrenList[i].nameError = false;
			  }
			  if(this.childrenList[i].gender.trim() == ''){
				this.childrenList[i].genderError = true;
			  }
			  else{
				this.childrenList[i].genderError = false;
			  }
			  if(!this.childrenList[i].date){
				this.childrenList[i].dateError = true;
			  }
			  else{
				this.childrenList[i].dateError = false;
			  }
		  }
	}
	inputFilechange(input){
	}

	changeListenerWork($event, index): void {
		let workUploadEnabled = false;
			if(this.childrenListWork[index].designation){
				workUploadEnabled =true;
			}
			if(workUploadEnabled){
				this.readThisWork($event.target, index);
			}else{
				this.notificationService.alertBoxValue("error", "please choose a designation name");
	
			}
		
	}

	changeListener($event, index): void {
			this.readThis($event.target);
		
	}

	changeListenerSec($event, index): void {
		this.readThisSec($event.target);
	}

	changeListenerEducation($event, index): void {
		let eduUploadEnabled = false;
			if(this.childrenListEducation[index].qualification){
				eduUploadEnabled =true;
			}
			if(eduUploadEnabled){
				this.readThisEducation($event.target, index);
			}else{
				this.notificationService.alertBoxValue("error", "please choose a qualification name");
	
			}
	}

	changeListenerDoc($event, index): void {
		let docUploadEnabled = false;
			if(this.childrenListDoc[index].name){
				docUploadEnabled =true;
			}
		
		if(docUploadEnabled){
			this.readThisDoc($event.target, index);
		}else{
			this.notificationService.alertBoxValue("error", "please choose a document name");

		}
	}

	/*
	*  @desc   :method to check file input
	*  @author :vinod
	*/
	readThis(inputValue: any): void {
		let j = this.checkImageExtensionwithPdf(inputValue.files)
		if(!j){
			inputValue.value = '';
			return
		}
		let self = this;
		let fileSize: number = 0;
		let prevFileData;
		if (inputValue) {
			if (this.fileData)
				for (let i = 0; i < this.fileData.length; i++) {
					if(!Number(this.fileData[i].file_size)){
						this.fileData[i].file_size = 0;
					}
					fileSize = fileSize + Number(this.fileData[i].file_size);
				}

			for (let i = 0; i < inputValue.files.length; i++) {
				fileSize = fileSize + Number(inputValue.files[i].size);
			}
			if ((inputValue.files.length <= 5) && (!this.fileData || (this.fileData && (this.fileData.length + inputValue.files.length) <= 5)) && (Number(fileSize) <= 4194304)) {
				if (!this.fileData) {
					this.fileData = [];
					prevFileData = 0;
				}
				else {
					prevFileData = this.fileData.length;
				}
				let maxCount = Number(inputValue.files.length + this.fileData.length);
				let startCount = Number(this.fileData.length);

				for (let i = startCount; i < maxCount; i++) {
					var file: File;
					file = inputValue.files[i - prevFileData];
					if (file != undefined) {
						self.fileData.push({});
						self.fileData[i] = { fileName: "", type: "", file_data: "", file_size: "" };
						self.fileData[i].type = inputValue.files[i - prevFileData].name.split('.').pop();
						self.fileData[i].fileName = file.name;
						self.fileData[i].file_size = file.size;
						// if(self.fileData.length ==1){
						// 	inputValue.value = '';
						// }
					
						self.uploadProcess(file, i);
					}
					else {
						self.fileData[i] = undefined;
						self.fileName[i] = "";
					}
				}
			}
			else {
				if (Number(fileSize) > 4194304) {
					this.notificationService.alertBoxValue("error", "You Can Only Upload A Maximum Of Size 5 MB");
					inputValue.value = '';
					
				}
				else
					this.notificationService.alertBoxValue("error", "You Can Only Upload A Maximum Of 5 Files");
			}
		}
		else {
			self.fileData = undefined;
			self.fileName = undefined;
		}
		inputValue.value = '';
	}

	/*
	*  @desc   :method to check file input
	*  @author :vinod
	*/
	readThisSec(inputValue: any): void {
		let j = this.checkImageExtensionwithPdf(inputValue.files)
		if(!j){
			inputValue.value = '';
			return
		}
		let self = this;
		let fileSize: number = 0;
		let prevFileData;
		if (inputValue) {
			if (this.fileDataSec)
				for (let i = 0; i < this.fileDataSec.length; i++) {
					if(!Number(this.fileDataSec[i].file_size)){
						this.fileDataSec[i].file_size = 0;
					}
					fileSize = fileSize + Number(this.fileDataSec[i].file_size);
				}

			for (let i = 0; i < inputValue.files.length; i++) {
				fileSize = fileSize + Number(inputValue.files[i].size);
			}
			if ((inputValue.files.length <= 5) && (!this.fileDataSec || (this.fileDataSec && (this.fileDataSec.length + inputValue.files.length) <= 5)) && (Number(fileSize) <= 4194304)) {
				if (!this.fileDataSec) {
					this.fileDataSec = [];
					prevFileData = 0;
				}
				else {
					prevFileData = this.fileDataSec.length;
				}
				let maxCount = Number(inputValue.files.length + this.fileDataSec.length);
				let startCount = Number(this.fileDataSec.length);

				for (let i = startCount; i < maxCount; i++) {
					var file: File;
					file = inputValue.files[i - prevFileData];
					if (file != undefined) {
						this.fileDataSec.push({});
						this.fileDataSec[i] = { fileName: "", type: "", file_data: "", file_size: "" };
						this.fileDataSec[i].type = inputValue.files[i - prevFileData].name.split('.').pop();
						this.fileDataSec[i].fileName = file.name;
						this.fileDataSec[i].file_size = file.size;
						// inputValue.value = '';
						self.uploadProcessSec(file, i);
					}
					else {
						this.fileDataSec[i] = undefined;
						self.fileName[i] = "";
					}
				}
			}
			else {
				if (Number(fileSize) > 4194304) {
					this.notificationService.alertBoxValue("error", "You Can Only Upload A Maximum Of Size 5 MB");
					inputValue.value = '';
				}
				else
					this.notificationService.alertBoxValue("error", "You Can Only Upload A Maximum Of 5 Files");
			}
		}
		else {
			this.fileDataSec = undefined;
			self.fileName = undefined;
		}
		inputValue.value = '';
	}

	/*
	 *  @desc   :method to initiate upload process
	 *  @author :dipin
	 */
	uploadProcess(file, i) {
		let self = this;
		let reader = new FileReader();
		reader.readAsDataURL(file);
		reader.onload = () => {
			self.fileData[i].file_data = reader.result;
		};
	}

		/*
	 *  @desc   :method to initiate upload process
	 *  @author :dipin
	 */
	uploadProcessSec(file, i) {
		let self = this;
		let reader = new FileReader();
		reader.readAsDataURL(file);
		reader.onload = () => {
			self.fileDataSec[i].file_data = reader.result;
		};
	}

	/*
 *  @desc   :delete files from the upload list
 *  @author :dipin
 */
	deleteFile(value) {
		this.fileData.splice(value, 1);
		if (this.fileData.length == 0) {
			this.fileData = undefined;
		}
	}

	deleteFileSec(value) {
		this.fileDataSec.splice(value, 1);
		if (this.fileDataSec.length == 0) {
			this.fileDataSec = undefined;
		}
	}

	/*
	 *  @desc   :method to check file input
	 *  @author :dipin
	 */
	readThisDoc(inputValue: any, index): void {
		let j = this.checkImageExtensionwithPdf(inputValue.files)
		if(!j){
			inputValue.value = '';
			return
		}
		let self = this;
		let fileSize: number = 0;
		let prevFileData;
		if (inputValue) {
			if (this.childrenListDoc[index].fileData)
				for (let i = 0; i < this.childrenListDoc[index].fileData.length; i++) {
					if(!Number(this.childrenListDoc[index].fileData[i].file_size)){
						this.childrenListDoc[index].fileData[i].file_size = 0;
					}

					fileSize = fileSize + Number(this.childrenListDoc[index].fileData[i].file_size);
				}

			for (let i = 0; i < inputValue.files.length; i++) {
				fileSize = fileSize + Number(inputValue.files[i].size);
			}
			if ((inputValue.files.length <= 5) && (!this.childrenListDoc[index].fileData || (this.childrenListDoc[index].fileData && (this.childrenListDoc[index].fileData.length + inputValue.files.length) <= 5)) && (Number(fileSize) <= 4194304)) {
				if (!this.childrenListDoc[index].fileData) {
					this.childrenListDoc[index].fileData = [];
					prevFileData = 0;
				}
				else {
					prevFileData = this.childrenListDoc[index].fileData.length;
				}
				let maxCount = Number(inputValue.files.length + this.childrenListDoc[index].fileData.length);
				let startCount = Number(this.childrenListDoc[index].fileData.length);

				for (let i = startCount; i < maxCount; i++) {
					var file: File;
					file = inputValue.files[i - prevFileData];
					if (file != undefined) {
						self.childrenListDoc[index].fileData.push({});
						self.childrenListDoc[index].fileData[i] = { fileName: "", type: "", file_data: "", file_size: "" };
						self.childrenListDoc[index].fileData[i].type = inputValue.files[i - prevFileData].name.split('.').pop();
						self.childrenListDoc[index].fileData[i].fileName = file.name;
						self.childrenListDoc[index].fileData[i].file_size = file.size;
						self.uploadProcessDoc(file, i, index);
					}
					else {
						self.childrenListDoc[index].fileData[i] = undefined;
						self.fileNameDoc[i] = "";
					}
				}
			}
			else {
				if (Number(fileSize) > 4194304) {
					this.notificationService.alertBoxValue("error", "You Can Only Upload A Maximum Of Size 5 MB");
				}
				else
					this.notificationService.alertBoxValue("error", "You Can Only Upload A Maximum Of 5 Files");
			}
		}
		else {
			self.childrenListDoc[index].fileData = undefined;
			self.fileNameDoc = undefined;
		}
	}

	/*
	 *  @desc   :method to initiate upload process
	 *  @author :dipin
	 */
	uploadProcessWork(file, i, index) {
		let self = this;
		let reader = new FileReader();
		reader.readAsDataURL(file);
		reader.onload = () => {
			self.childrenListWork[index].fileData[i].file_data = reader.result;
		};
	}


	/*
	 *  @desc   :method to initiate upload process
	 *  @author :dipin
	 */
	uploadProcessEducation(file, i, index) {
		let self = this;
		let reader = new FileReader();
		reader.readAsDataURL(file);
		reader.onload = () => {
			self.childrenListEducation[index].fileData[i].file_data = reader.result;
		};
	}


	/*
	 *  @desc   :method to initiate upload process
	 *  @author :dipin
	 */
	uploadProcessDoc(file, i, index) {
		let self = this;
		let reader = new FileReader();
		reader.readAsDataURL(file);
		reader.onload = () => {
			self.childrenListDoc[index].fileData[i].file_data = reader.result;
		};
	}


	/*
	 *  @desc   :method to check file input
	 *  @author :dipin
	 */
	readThisEducation(inputValue: any, index): void {
		let j = this.checkImageExtensionwithPdf(inputValue.files)
		if(!j){
			inputValue.value = '';
			return
		}
		let self = this;
		let fileSize: number = 0;
		let prevFileData;
		if (inputValue) {
			if (this.childrenListEducation[index].fileData)
				for (let i = 0; i < this.childrenListEducation[index].fileData.length; i++) {
					if(!Number(this.childrenListEducation[index].fileData[i].file_size)){
						this.childrenListEducation[index].fileData[i].file_size = 0;
					}
					fileSize = fileSize + Number(this.childrenListEducation[index].fileData[i].file_size);
				}

			for (let i = 0; i < inputValue.files.length; i++) {
				fileSize = fileSize + Number(inputValue.files[i].size);
			}
			if ((inputValue.files.length <= 5) && (!this.childrenListEducation[index].fileData || (this.childrenListEducation[index].fileData && (this.childrenListEducation[index].fileData.length + inputValue.files.length) <= 5)) && (Number(fileSize) <= 4194304)) {
				if (!this.childrenListEducation[index].fileData) {
					this.childrenListEducation[index].fileData = [];
					prevFileData = 0;
				}
				else {
					prevFileData = this.childrenListEducation[index].fileData.length;
				}
				let maxCount = Number(inputValue.files.length + this.childrenListEducation[index].fileData.length);
				let startCount = Number(this.childrenListEducation[index].fileData.length);

				for (let i = startCount; i < maxCount; i++) {
					var file: File;
					file = inputValue.files[i - prevFileData];
					if (file != undefined) {
						self.childrenListEducation[index].fileData.push({});
						self.childrenListEducation[index].fileData[i] = { fileName: "", type: "", file_data: "", file_size: "" };
						self.childrenListEducation[index].fileData[i].type = inputValue.files[i - prevFileData].name.split('.').pop();
						self.childrenListEducation[index].fileData[i].fileName = file.name;
						self.childrenListEducation[index].fileData[i].file_size = file.size;
						self.uploadProcessEducation(file, i, index);
					}
					else {
						self.childrenListEducation[index].fileData[i] = undefined;
						self.fileNameEducation[i] = "";
					}
				}
			}
			else {
				if (Number(fileSize) > 4194304) {
					this.notificationService.alertBoxValue("error", "You Can Only Upload A Maximum Of Size 5 MB");
				}
				else
					this.notificationService.alertBoxValue("error", "You Can Only Upload A Maximum Of 5 Files");
			}
		}
		else {
			self.childrenListEducation[index].fileData = undefined;
			self.fileNameEducation = undefined;
		}
	}

	/*
	 *  @desc   :method to check file input
	 *  @author :dipin
	 */
	readThisWork(inputValue: any, index): void {
		let j = this.checkImageExtensionwithPdf(inputValue.files)
		if(!j){
			inputValue.value = '';
			return
		}
		let self = this;
		let fileSize: number = 0;
		let prevFileData;
		if (inputValue) {
			if (this.childrenListWork[index].fileData)
				for (let i = 0; i < this.childrenListWork[index].fileData.length; i++) {
					if(!Number(this.childrenListWork[index].fileData[i].file_size)){
						this.childrenListWork[index].fileData[i].file_size = 0;
					}
					fileSize = fileSize + Number(this.childrenListWork[index].fileData[i].file_size);
				}

			for (let i = 0; i < inputValue.files.length; i++) {
				fileSize = fileSize + Number(inputValue.files[i].size);
			}
			if ((inputValue.files.length <= 5) && (!this.childrenListWork[index].fileData || (this.childrenListWork[index].fileData && (this.childrenListWork[index].fileData.length + inputValue.files.length) <= 5)) && (Number(fileSize) <= 4194304)) {
				if (!this.childrenListWork[index].fileData) {
					this.childrenListWork[index].fileData = [];
					prevFileData = 0;
				}
				else {
					prevFileData = this.childrenListWork[index].fileData.length;
				}
				let maxCount = Number(inputValue.files.length + this.childrenListWork[index].fileData.length);
				let startCount = Number(this.childrenListWork[index].fileData.length);

				for (let i = startCount; i < maxCount; i++) {
					var file: File;
					file = inputValue.files[i - prevFileData];
					if (file != undefined) {
						self.childrenListWork[index].fileData.push({});
						self.childrenListWork[index].fileData[i] = { fileName: "", type: "", file_data: "", file_size: "" };
						self.childrenListWork[index].fileData[i].type = inputValue.files[i - prevFileData].name.split('.').pop();
						self.childrenListWork[index].fileData[i].fileName = file.name;
						self.childrenListWork[index].fileData[i].file_size = file.size;
						self.uploadProcessWork(file, i, index);
					}
					else {
						self.childrenListWork[index].fileData[i] = undefined;
						self.fileNameWork[i] = "";
					}
				}
			}
			else {
				if (Number(fileSize) > 4194304) {
					this.notificationService.alertBoxValue("error", "You Can Only Upload A Maximum Of Size 5 MB");
				}
				else
					this.notificationService.alertBoxValue("error", "You Can Only Upload A Maximum Of 5 Files");
			}
		}
		else {
			self.childrenListWork[index].fileData = undefined;
			self.fileNameWork = undefined;
		}
		// inputValue.value = '';
	}

	checkValid(){	
		if(!this.employeeDetails.valid ||  (!this.designationSelected.selected[0]) ||  ( !this.employeeGroupSelected.selected[0] )|| (!this.reportingManagerSelect.selected[0])|| ( !this.shiftSelected.selected[0]) || (!this.attendanceSelected && !this.attendanceSelected.selected[0]) ||  ( !this.payperiod.selected[0] )   ){
			this.personalDetailError = true;
			setTimeout(()=>{
				const error = document.querySelector('.error');
			 if(error){
				 this.scrollTo(error);
			 }
			 })
			return;
		}
		else{
			this.showAlert = true;
		}
	}
	deigSelected(event){
		this.designationSelected = event;
	}
	getFileType(filename){
		return filename.substr(filename.lastIndexOf('.') + 1);
	}
	removeChildrow(childArray,i){
		this.childrenList.splice(i,1)
	}
	childSelectevent(event){

	}
	openConfirmBoxone(i){
		this.index1 = i;
		this.confirmBox1 = true;
	}
	confirmPopup1(ev){
		if(ev){
			this.childrenListWork.splice(this.index1, 1);
			this.confirmBox1 = false;
		}else
		this.confirmBox1 = false;
		}
	openConfirmBoxtwo(i){
		this.index2 = i;
		this.confirmBox2 = true;
	}
	confirmPopup2(ev){
		if(ev){
			this.childrenListEducation.splice(this.index2, 1);
			this.confirmBox2 = false;
		}
		else
		this.confirmBox2 = false;
	}
	openConfirmBoxthree(i){
		this.index3 = i;
		this.confirmBox3 = true;
	}
	confirmPopup3(ev){
		if(ev){
			this.childrenListDoc.splice(this.index3,1)
			this.confirmBox3 = false;
		}else
		this.confirmBox3 = false;

		}
	openConfirmBoxfour(i){
		this.index4 = i;
		this.confirmBox4 = true;
	}
	confirmPopup4(ev){
		if(ev){
			this.childrenList.splice(this.index4,1)
			this.confirmBox4 = false;
		}else
		this.confirmBox4 = false;
	}
	checkPassword(event,i){
	 if (event.status == false && event.password != "") {
		this.childrenListDoc[i].addNewDocNo=true;
		this.docNumberView = event.doceNumber
		this.childrenListDoc[i]["no"] = this.docNumberView;
		this.childrenListDoc[i]["docNoView"] = this.docNumberView;
		this.childrenListDoc[i].showPopup = event.status;
	//  console.log(this.editFormData.documents[i]['docNumberview'])
	//  this.documents[index].showPopup = event.status;
	
	}
	else{
		this.addNewDocNo=false;
	}
	if(event.status == false && event.password == ""){
		this.childrenListDoc[i].showPopup = event.status;
	}
   }
   converDocNO(docNoNew,index){
	   if(docNoNew){
		this.childrenListDoc[index]["docNoView"] = '';
		this.childrenListDoc[index]["no"] = "******";
		this.childrenListDoc[index].showPopup = false
		this.childrenListDoc[index].addNewDocNo=false;
	   }
	
   }
}
