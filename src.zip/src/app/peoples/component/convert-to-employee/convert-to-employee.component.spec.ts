import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConvertToEmployeeComponent } from './convert-to-employee.component';

describe('ConvertToEmployeeComponent', () => {
  let component: ConvertToEmployeeComponent;
  let fixture: ComponentFixture<ConvertToEmployeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConvertToEmployeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConvertToEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
