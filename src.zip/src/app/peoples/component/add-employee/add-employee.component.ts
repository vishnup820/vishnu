// /*
//  author : Arun Johnson
//  desc   : Add employee
// */
// import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
// import { FormGroup, FormControl, Validators } from "@angular/forms";
// import { Router  , ActivatedRoute , NavigationEnd } from '@angular/router';
// import { ConstantServicesService } from '../../../shared/services/constant/constant-services.service';
// import { AddEmployeeService } from '../../services/add-employee/add-employee.service';
// import { NotificationService } from '../../../shared/services/notifications/notification.service';
// import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
// import { UserDetailsService } from '../../services/user-details/user-details.service';
// import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';
// import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';


// declare var require: any;
// var moment = require('moment');

// @Component({
// 	selector: 'app-add-employee',
// 	templateUrl: './add-employee.component.html',
// 	styleUrls: ['./add-employee.component.css',"../../../../assets/content/css/crop-image.css","../../../../assets/content/css/view-employee.css"]
// })
// export class AddEmployeeComponent implements OnInit {

//     imageChangedEvent      : any;
//     croppedImage           : any = " ";
//     passCroppedImage       : any;

//     editFormData           : any;
// 	role                   : any;
// 	roleStatus             : any;
// 	roleChecked            : any;
// 	department             : any;
// 	departmentSelected     : any;
// 	departmentChecked      : any;
// 	location               : any;
// 	locationSelected       : any;
// 	attendanceType         : any;
// 	attendanceSelected     : any;
// 	locationChecked        : any;
// 	reportingManager       : any;
//     reportingManagerSelect : any;
//     reportingChecked       : any;
//     lineManager            : any;
//     lineManagerSelected    : any;
//     lineChecked            : any;
//     employeeType           : any = [{"value":"Permanent"},{"value":"Probation"},{"value":"Contract"},{"value":"Trainee"},{"value":"Consultant"}];
//     employeeTypeSelected   : any;
//     employeeTypeChecked    : any;
//     employeeGroup          : any;
//     sendPermissionData     : any;
//     groupChecked           : any;
//     employeeGroupSelected  : any;
// 	status                 : any = [{"value" :"Active" ,"name": 1},{"value": "Inactive","name": 2},{"value": "Resigned","name": 3}];
// 	statusSelected         : any;
// 	statusChecked          : any;
// 	roleSelected           : any;
// 	designation            : any;
// 	designationSelected    : any;
// 	designationChecked     : any;
// 	gender                 : any = [{ "value": "Male" , "name" : "M"}, { "value": "Female" , "name" : "F"}, { "value": "Other" , "name" : "O"}];
// 	genderSelected         : any;
// 	checkedGender          : any ;
// 	maritalStatus          : any = [{"data":"Married","value":"Y"},{"data":"Unmarried","value":"N"}];
// 	materialChecked        : any;
// 	attendanceChecked      : any;
// 	maritalSelected        : any;
// 	permissionData         : any;
// 	selectedGender         : any;
// 	probationSelected      : any;
// 	probationChecked       : any;
// 	photo                  : any;
// 	selectedEmail     	   : any = [];
// 	dummypeoples		   : any;
// 	emailData         	   : any;
// 	selectedEmailData 	   : any;
// 	probationPeriod        : any = [
// 									{"data":"1 Month","value":"1"},
// 									{"data":"2 Month","value":"2"},
// 									{"data":"3 Month","value":"3"},
// 									{"data":"4 Month","value":"4"},
// 									{"data":"5 Month","value":"5"},
// 									{"data":"6 Month","value":"6"},
// 									{"data":"7 Month","value":"7"},
// 									{"data":"8 Month","value":"8"},
// 									{"data":"9 Month","value":"9"},
// 									{"data":"10 Month","value":"10"},
// 									{"data":"11 Month","value":"11"},
// 									{"data":"12 Month","value":"12"}];


// 	maxDate                 : Date = new Date();

// 	minDate                 : Date = new Date("1900");
// 	dojMax                   : Date = new Date("2500")

//     personalDetailError 	: boolean = false;
//     pageStatus              : boolean = false;
//     showProbation           : boolean = false;
//     showOverridePopup       : boolean = false;
//     confirmBox              : boolean = false;
//     disable                 : boolean = false;
//     lazyLoad                : boolean = false;
//     aclOverride             : boolean = false;
//     aclNewItem              : boolean = false;
//     dojError                : boolean = false;
//     dobError                : boolean = false;
//     errorDate               : boolean = false;
//     viewPage                : boolean = false;
//     showPopUp               : boolean = false;

// 	employeeDetails   		: FormGroup;

// 	firstName				: FormControl;
// 	lastName				: FormControl;
// 	dob                     : FormControl;
// 	date_of_joining         : FormControl;
//     emailId 				: FormControl;
//     contactNumber           : FormControl;
//     personalEmailId         : FormControl;
//     displayName             : FormControl;
//     permanetAddress         : FormControl;
//     middleName              : FormControl;
//     tempAddress             : FormControl;
//     empId                   : FormControl;
//     userName                : FormControl;
//     extension               : FormControl;
//     speedDial               : FormControl;

// 	constructor(
// 		private route              		: ActivatedRoute,
// 		private locations          		: Router,
// 		private addEmployeeService 		: AddEmployeeService,
// 		private notificationService 	: NotificationService,
// 		private loaderActionsService    : LoaderActionsService,
// 		private constData               : ConstantServicesService,
// 		private userDetailsService      : UserDetailsService,
// 		private changes                 : ChangeDetectorRef,
// 		private aclCheck                : AclVerificationService,
// 		private timeZone                : TimezoneDetailsService) { }

// 	ngOnInit() {
// 		this.maxDate = this.timeZone.getCurrentDate();
// 		this.loaderActionsService.display(true);
// 		this.aclNewItem  = this.aclCheck.checkAcl('/modules/organization/role');
// 	    this.aclOverride = this.aclCheck.checkAcl('/modules/organization/acl');
// 		this.disable = false;
// 		this.attendanceType = [{name:'Manual'},{name:'Biometric'}];
// 		// this.emailData=["onelast@gmail.com","lastone@gmail.com"];

// 		// this.emailData=[{"email":""},{"email":""},{"email":""},{"email":""},
// 		// {"email":""},{"email":""},{"email":""},{"email":""},{"email":""},
// 		// {"email":""},{"email":""},{"email":""},{"email":""},{"email":""},
// 		// {"email":""},{"email":""},{"email":""},{"email":""},{"email":""},
// 		// {"email":""},{"email":""},{"email":""},{"email":""},{"email":""},
// 		// {"email":""},{"email":""},{"email":""},{"email":""},{"email":""},
// 		// {"email":""},{"email":""},{"email":""},{"email":""},{"email":""},
// 		// {"email":""},{"email":""},{"email":""},{"email":""},{"email":""},
// 		// {"email":""},{"email":""},{"email":""},{"email":""},{"email":""},
// 		// {"email":""},{"email":""},{"email":""},{"email":""},{"email":""}
// 	    // ,{"email":"onelast@gmail.com"},{"email":"testone@gail.com"}];
// 		this.route.snapshot.params['id'] ? this.pageStatus = false : this.pageStatus = true;
// 		this.route.queryParamMap.subscribe(params => {
// 			if(params['params'].type)
// 			 if (atob(params['params'].type) == "view") {
// 			 	this.viewPage = true;
// 			 }
// 		});
// 		this.createFormControls();
// 		this.createForm();
// 		this.userDetailsService.emailListing(response => {
// 			if (response.status == "OK") {
// 				if (response.data) {
// 					this.emailData = response.data;
// 					// for (let i = 0; i < this.emailData.length; i++) {
// 					// 	if (this.emailData[i].email.trim() == "" || this.emailData[i].email == this.userData.rm_email || this.emailData[i].email == this.userData.email) {
// 					// 		this.emailData.splice(i, 1);
// 					// 	}
// 					// }
// 				}
// 			}
// 		})
// 		this.addEmployeeService.getMasterData(res=>{
// 			this.loaderActionsService.display(false);
// 			if (res.status == "OK") {
// 			this.department       = res.data.department;
// 			this.designation      = res.data.designation;
// 			this.location         = res.data.location;
// 			this.employeeGroup    = res.data.group;
// 			this.role             = res.data.role;
// 			this.reportingManager = res.data.reporting_manager;
// 			this.lineManager 	  = res.data.reporting_manager;

// 				if (this.role) {
// 					for (let i = 0; i < this.role.length; i++) {
// 						if (this.role[i].name.toUpperCase() == "EMPLOYEE") {
//                           this.roleChecked = [i];
//                           break;
// 						}
// 					}
// 				}
// 		    }
// 			// if (!this.pageStatus) {
// 			// 	this.loaderActionsService.display(true);
// 			// 	this.disable = true;
// 			// 	let id: any  = this.route.snapshot.params['id'];
// 			// 	this.addEmployeeService.getPeople(id, res => {
// 			// 		this.loaderActionsService.display(false);
// 			// 		let data: any = res.data;
// 			// 		this.photo = data.photo;
// 			// 		this.editFormData = res.data;
// 			// 		if (res.status == "OK" && data) {
// 			// 			data.status == '1' ? this.statusChecked = [0] :  data.status == '2' ? this.statusChecked = [1] : data.status == '3' ? this.statusChecked = [2] : null ;
// 			// 			data.gender == 'M' ? this.checkedGender = [0] : data.gender == 'F' ? this.checkedGender = [1] : data.gender == 'O' ? this.checkedGender = [2] : null;
// 			// 			data.marital_status == "Y" ? this.materialChecked = [0] : data.marital_status == "N" ? this.materialChecked = [1] : this.materialChecked = null;
// 			// 			this.setCheckStatus(this.editFormData);
// 			// 		}
// 			// 	})
// 			// }
// 			else{
// 				this.attendanceChecked = [0];

//                 this.userDetailsService.emailNotify(response => {
// 					if (response.status == "OK") {
// 						console.log(response.data.length)
// 						if(response.data.length>=1){
// 							this.dummypeoples=response.data.join();
// 							this.selectedEmail = this.dummypeoples.split(',');

// 						}
// 					}
// 				})
// 				// this.dummypeoples="onelast@gmail.com,lastone@gmail.com";
// 				// this.selectedEmail = this.dummypeoples.split(',');
// 			}
// 		})
// 	}

//     /*
//  	 author : Arun Johnson
//  	 desc   : set status in multiselect & add value to input box in form control
// 	*/
// 	setCheckStatus(data) {
// 		for(let index=0;index<this.reportingManager.length;index++) {
// 			if (this.reportingManager[index].id == data.reporting_manager_id) {
// 				this.reportingChecked = [index];
// 			}
// 		}
// 		let group : any = [];
// 		data.group ? group = data.group.split(",") : null;
// 		this.groupChecked = [];
// 		this.editFormData.group_name = [];
// 		for(let index=0;index<(this.employeeGroup && this.employeeGroup.length);index++) {
// 			for(let j = 0;j<group.length;j++) {
// 				if(group[j] == this.employeeGroup[index].id) {
// 					this.groupChecked.push(index);
// 					this.editFormData.group_name.push(this.employeeGroup[index].name);
// 				}
// 			}
// 		}
// 		if(this.editFormData.punch_type){
//             if(this.editFormData.punch_type == "Biometric"){
//               this.attendanceChecked = [1];
//             }
//             else{
//               this.attendanceChecked = [0];
//             }
// 		}
// 		for(let index=0;index<(this.employeeType && this.employeeType.length);index++) {
// 			if (this.employeeType[index].value == data.employee_type) {
// 				this.employeeTypeChecked = [index];
// 			}
// 		}
// 		for(let index=0;index<(this.lineManager && this.lineManager.length);index++) {
// 			if (this.lineManager[index].id == data.line_manager_id) {
// 				if(this.viewPage)
// 				   this.lineChecked = [index+1];
// 				else
// 					this.lineChecked = [index];
// 			}
// 		}
// 		for (let index = 0; index < (this.role && this.role.length); index++) {
// 			if (this.role[index].id == data.role_id) {
// 				this.roleChecked = [index];
// 			}
// 		}
// 		for (let index = 0; index < (this.designation && this.designation.length); index++) {
// 			if (this.designation[index].id == data.designation_id) {
// 				this.designationChecked = [index];
// 			}
// 		}

// 		for (let index = 0; index < (this.department && this.department.length); index++) {
// 			if (this.department[index].id == data.department_id) {
// 				this.departmentChecked = [index];
// 			}
// 		}
// 		for (let index = 0; index < (this.location && this.location.length); index++) {
// 			if (this.location[index].id == data.location_id) {
// 				this.locationChecked = [index];
// 			}
// 		}
// 		for (let index = 0; index < (this.probationPeriod && this.probationPeriod.length); index++) {
// 			if (this.probationPeriod[index].value == data.probation_period) {
// 				this.probationChecked = [index];
// 			}
// 		}
// 		let doj  : any;
// 		let dob  : any;
// 		data.date_of_joining ? doj = this.timeZone.toLocal(data.date_of_joining) : doj = null;
// 		(data.dob && data.dob != "0000-00-00")? dob = this.timeZone.toLocal(data.dob) : dob = '';
// 		this.employeeDetails.patchValue({
// 			firstName: data.first_name,
// 			lastName: data.last_name,
// 			dob: dob,
// 			permanetAddress: data.address,
// 			tempAddress    : data.temporary_address,
// 			middleName     : data.middle_name,
// 			displayName    : data.display_name,
// 			contactNumber  : data.contact_number,
// 			empId: data.code,
// 			userName: data.username,
// 			extension: data.extension,
// 			speedDial: data.speed_dial,
// 			emailId: data.email,
// 			date_of_joining: doj,
// 			personalEmailId : data.personal_email
// 		})
// 	}

// 	fileChangeEvent(event: any): void {
// 		if(event.target.files.length) {
// 			this.showPopUp = true;
// 			this.imageChangedEvent = event;
// 		}
// 	}

// 	imageCropped(event: any) {
// 		this.croppedImage = event.base64;
// 	}

// 	cancelCrop() {
// 		this.showPopUp = false
// 	}

//     /*
//  	 author : Arun Johnson
//  	 desc   : create Form Controls
// 	*/
// 	createFormControls() {
// 		let alpha           = "^[a-zA-Z ]*$";
// 		let beta            = "^[a-zA-Z ]+[.]*[a-zA-Z]*$";
// 		let contactNumber   = "^[0-9+() -]*$";
//         let number          = "^[0-9]*$";
//         let useName         = "^[a-zA-Z0-9._@]+$";
// 		let emailPattern    = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$";
// 		this.firstName 			 = new FormControl('', [Validators.required,this.noWhitespaceValidator,Validators.pattern(beta)]);
// 		this.lastName 			 = new FormControl('', [Validators.required,this.noWhitespaceValidator,Validators.pattern(beta)]);
// 		this.dob                 = new FormControl('');
// 		this.date_of_joining     = new FormControl('', [Validators.required]);
//         this.personalEmailId     = new FormControl('', [Validators.required,Validators.pattern(emailPattern)]);
//         this.contactNumber       = new FormControl('', [Validators.required,Validators.pattern(contactNumber)]);
//         this.permanetAddress     = new FormControl('', []);
//         this.tempAddress         = new FormControl('', []);
//         this.middleName          = new FormControl('', [Validators.pattern(beta)]);
//         this.displayName         = new FormControl('', []);
//         this.extension           = new FormControl('', [Validators.pattern(number)]);
//         this.speedDial           = new FormControl('', [Validators.pattern(number)]);
//         this.empId               = new FormControl('', [Validators.required, this.noWhitespaceValidator,Validators.pattern("^[a-zA-Z0-9]+$")]);
//         this.emailId        	 = new FormControl('', [Validators.pattern(emailPattern)]);
//         this.userName            = new FormControl('', [Validators.required,Validators.pattern(useName)]);
// 	}

//     /*
//  	 author : Arun Johnson
//  	 desc   : create Form Groups
// 	*/
//     createForm() {
//     	this.employeeDetails = new FormGroup({
//     		firstName        : this.firstName,
//     		lastName         : this.lastName,
//     		dob              : this.dob,
//     		date_of_joining  : this.date_of_joining,
//             personalEmailId  : this.personalEmailId,
//             contactNumber    : this.contactNumber,
//             permanetAddress  : this.permanetAddress,
//             tempAddress      : this.tempAddress,
//             middleName       : this.middleName,
//             displayName      : this.displayName,
//             empId            : this.empId,
//     		emailId          : this.emailId,
//     		userName         : this.userName,
//     		extension        : this.extension,
//     		speedDial        : this.speedDial,
//     	});
//     }

//     /*
//  	 author : Arun Johnson
//  	 desc   : validation for white space in form
//  	 params :
// 	*/
// 	noWhitespaceValidator(control: FormControl) {
// 		let isWhitespace = (control.value || '').trim().length === 0;
// 		let isValid = !isWhitespace;
// 		return isValid ? null : { 'whitespace': true }
// 	}

//     /*
//  	 author : Arun Johnson
//  	 desc   : validation for contact number
//  	 params :
// 	*/
// 	contactValidation(event : any) {
// 		let vKey = 86;
//   		let cKey = 67;
//   		let aKey = 65;
//   		let xKey = 88;
// 		let specialKeys2 : any = ['!','@','#','$','%','^','&','*'];
// 		let specialKeys  : any = [ 'Backspace', 'Tab', 'End', 'Home','Delete','Del'];
// 		if (specialKeys.indexOf(event.key) !== -1) {
//             return;
//         }
// 		if (specialKeys2.indexOf(event.key) !== -1) {
//       		event.preventDefault();
//       		return;
//     	}
// 		if((( 96 <= event.keyCode && event.keyCode <= 105) || (48 <= event.keyCode && event.keyCode <= 57 || event.keyCode == 37 || event.keyCode == 189 || event.keyCode == 187 || event.keyCode == 107 || event.keyCode == 109 || event.keyCode == 39  || (event.keyCode == 86 && event.keyCode == 17) || (event.keyCode == 67 && event.keyCode == 17)|| (event.keyCode == 65 && event.keyCode == 17) || (event.keyCode == 88 && event.keyCode == 17)) || (event.keyCode == 17 && event.ctrlKey))) {
// 		} else {
// 			event.preventDefault();
// 		}
//     }

//     /*
//  	 author : Arun Johnson
//  	 desc   : submit form
//  	 params :
// 	*/
// 	submitForm(value) {
// 		let maildata=[];
// 		console.log(this.selectedEmailData);
// 		for(let i=0;i<this.selectedEmailData.length;i++){
// 			maildata[i]=this.selectedEmailData[i].label;
// 		}
// 		console.log(maildata);
// 		let notfyData=maildata.join();
//         let validDoj : boolean = false;
//         let tempStart = [],tempEnd = [];
//         tempStart = this.employeeDetails.value.date_of_joining.split("-");
//         if(this.employeeDetails.value.dob && this.employeeDetails.value.dob != '')
//         	tempEnd   = this.employeeDetails.value.dob.split("-");
//         if(this.dobError && this.dojError && tempEnd.length && tempStart.length && moment(tempEnd[1]+"-"+tempEnd[0]+"-"+tempEnd[2],'MM-DD-YYYY HH:mm').isSameOrAfter(moment(tempStart[1]+"-"+tempStart[0]+"-"+tempStart[2],'MM-DD-YYYY HH:mm'))) {
//         	this.notificationService.alertBoxValue("error","Date of joining should be greater than Date of Birth");
//         	validDoj = true;
//         }

// 		if(!this.attendanceSelected.selected[0] || ( this.dob.value != '' && !this.dobError) || (this.showProbation && !this.probationSelected.selected[0]) || !this.dojError || !this.reportingManagerSelect.selected[0] || !this.locationSelected.selected[0] || !this.employeeDetails.valid || validDoj || (this.roleStatus.selected.length == 0)){
//             this.personalDetailError = true;
//             if(!this.firstName.valid){
//               document.getElementById("first-name").focus();
//             }
//             else if(!this.lastName.valid){
//               document.getElementById("last-name").focus();
//             }
//             else if(this.dob.value != '' && !this.dobError){
//               document.getElementById("date-birth").focus();
//               document.getElementById("date-birth").scrollIntoView(false);
//             }
//             else if(!this.contactNumber.valid){
//               document.getElementById("phone").focus();
//             }
//             else if(!this.personalEmailId.valid){
//               document.getElementById("email").focus();
//             }
//             else if(!this.empId.valid){
//               document.getElementById("emidEmployee").focus();
//               document.getElementById("emidEmployee").scrollIntoView(false);
//             }
//             else if((this.roleStatus.selected.length == 0)){
//               document.getElementById("role").focus();
//               document.getElementById("role").scrollIntoView(false);
//             }
//             else if(!this.date_of_joining.valid || !this.dojError){
//               document.getElementById("date-join").focus();
//               document.getElementById("date-join").scrollIntoView(false);
//             }
//             else if(!this.locationSelected.selected[0]){
//               document.getElementById("loc-prior").focus();
//               document.getElementById("loc-prior").scrollIntoView(false);
//             }
//             else if(!this.reportingManagerSelect.selected[0]){
//                document.getElementById("rep-manage").focus();
//                document.getElementById("rep-manage").scrollIntoView(false);
//             }
//             else if(!this.userName.valid){
//               document.getElementById("user-name").focus();
//             }
//             else if(!this.probationSelected.selected[0]){
//               document.getElementById("probation").focus();
//               document.getElementById("probation").scrollIntoView(false);
//             }
//             else if(!this.attendanceSelected.selected[0]){
//               document.getElementById("attendanceT").focus();
//               document.getElementById("attendanceT").scrollIntoView(false);
//             }
//         }
//         else {
//         	this.loaderActionsService.display(true);
// 			let tempData = [];
// 			if(this.sendPermissionData)
// 			for (var i = 0; i < this.sendPermissionData.length; i++) {
// 				for (var j = 0; j < this.sendPermissionData[i].groups.length; j++) {
// 					if (this.sendPermissionData[i].groups[j].access == 1) {
// 						tempData.push(this.sendPermissionData[i].groups[j].id);
// 					}
// 				}
// 			}
// 			// this.addEmployeeService.submitForm(
// 			// 	this.passCroppedImage,
// 			// 	this.editFormData,
// 			// 	value,
// 			// 	this.probationSelected,
// 			// 	this.genderSelected,
// 			// 	this.maritalSelected,
// 			// 	this.roleStatus,
// 			// 	this.designationSelected,
// 			// 	this.departmentSelected,
// 			// 	this.locationSelected,
// 			// 	this.reportingManagerSelect,
// 			// 	this.lineManagerSelected,
// 			// 	this.employeeTypeSelected,
// 			// 	this.employeeGroupSelected,
// 			// 	this.statusSelected,
// 			// 	this.employeeDetails,tempData,this.attendanceSelected,notfyData,res=>{
// 			// 		if(res.status == "OK")  {
// 			// 			this.sendPermissionData = [];
// 			// 			if (value == "add") {
// 			// 				let self = this;
// 			// 				self.locations.navigate(['/modules/employee/details']);
// 			// 				setTimeout(function() {
// 			// 					self.notificationService.alertBoxValue("success", "Employee Added Successfully");
// 			// 				});
// 			// 			} else {
// 			// 				let self = this;
// 			// 				self.locations.navigate(['/modules/employee/details']);
// 			// 				setTimeout(function() {
// 			// 					self.notificationService.alertBoxValue("success", "Employee Details Updated Successfully");
// 			// 				});
// 			// 			}

// 			// 		}
// 			// 		else {
// 			// 			if(res.data && res.data.username) {
// 			// 				this.notificationService.alertBoxValue("error",res.data.username[0]);
// 			// 			} else if(res.data && res.data.code) {
// 			// 				this.notificationService.alertBoxValue("error",res.data.code[0]);
// 			// 			}else if(res.data && res.data.code) {
// 			// 				this.notificationService.alertBoxValue("error",res.data.code[0]);
// 			// 			}else if(res.data && res.data.personal_email) {
// 			// 				this.notificationService.alertBoxValue("error",res.data.personal_email[0]);
// 			// 			}else if(res.data && res.data.username) {
// 			// 				this.notificationService.alertBoxValue("error",res.data.username[0]);
// 			// 			}else if(res.data && res.data.email) {
// 			// 				this.notificationService.alertBoxValue("error",res.data.email[0]);
// 			// 			}else if(res.data && res.data.contact_number){
// 			// 				this.notificationService.alertBoxValue("error",res.data.contact_number[0]);
// 			// 			}else  {
// 			// 				this.notificationService.alertBoxValue("error",res.message);
// 			// 			}
// 			// 		}
//             //         this.loaderActionsService.display(false);
// 			// });
//         }
// 	}

//     /*
//  	 author : Arun Johnson
//  	 desc   : reset Form
//  	 params :
// 	*/
// 	reset() {
//         if(!this.pageStatus) {
//         	this.setCheckStatus(this.editFormData);
//         }
//         else {
//         	this.checkedGender = !this.checkedGender;
//         	this.materialChecked = !this.materialChecked;
//         	this.roleChecked   = !this.roleChecked;
//         	this.designationChecked = !this.designationChecked ;
//         	this.lineChecked = !this.lineChecked;
//         	this.employeeTypeChecked = !this.employeeTypeChecked;
//         	this.groupChecked = !this.groupChecked;
//         	this.reportingChecked = !this.reportingChecked;
//         	this.departmentChecked = !this.departmentChecked;
//         	this.locationChecked = !this.locationChecked;
//         	this.statusChecked = !this.statusChecked;
//             this.employeeDetails.reset();
//         }
// 	}

// 	/*
//  	 author : Arun Johnson
//  	 desc   : if confirm button pressed
//  	*/
// 	confirmPopup() {
// 		this.locations.navigate(['/modules/employee/details']);
// 	}

//     /*
//  	 author : dipin
//  	 desc   : set date of birth
//  	*/
// 	setDateDob(event) {
// 		this.dobError = event.status;
// 		this.employeeDetails.patchValue({
// 			dob: event.date
// 		})
// 	}

//     /*
//  	 author : dipin
//  	 desc   : set date of joining
//  	*/
// 	setDateJoining(event) {
// 		this.dojError = event.status;
// 		this.employeeDetails.patchValue({
// 			date_of_joining: event.date
// 		})
// 	}

//     /*
//  	 author : dipin
//  	 desc   : set disable property for probation period when employee type is probation
//  	*/
// 	setProbation() {
// 		if (this.employeeTypeSelected) {
// 			if (this.employeeTypeSelected.selected.length && this.employeeTypeSelected.selected[0].value == "Probation") {
// 				this.showProbation = true;
// 			}
// 			else {
// 				this.showProbation = false;
// 				this.probationChecked = [];
// 			}
// 		}
// 		else
// 			this.showProbation = false;
// 	}

//     /*
//     author : dipin
//     desc   : change view page to edit view
//    */
// 	editDetail() {
// 		let self = this;
// 		self.loaderActionsService.display(true);
// 		let type = btoa('edit');
// 		setTimeout(function() {
// 			self.viewPage = false;
// 			window.scrollTo(0, 0);
// 			self.locations.navigate(
// 				[],
// 				{
// 					relativeTo: this.router,
// 					queryParams: { type },
// 					queryParamsHandling: "merge"
// 				});
// 			self.loaderActionsService.display(false);
// 		}, 100);
// 	}

// 	/*
// 	author : dipin
// 	desc   : add class based on index
// 	*/
// 	getClassByValue() {
// 		return this.userDetailsService.getClassByValue(1);
// 	}

//     /*
// 	author : dipin
// 	desc   : add class based on index
// 	*/
// 	showAddNew(event) {
// 		if (event.status) {
// 			this.addEmployeeService.addCustomRole({"name":event.value,"status":"1"}, res => {
//                if(res.status == "OK"){
//                  this.role.push({id: res.role_id,name:event.value});
//                  this.roleChecked = [this.role.length - 1];
//                  this.notificationService.alertBoxValue("success", res.message);
//                }
//                else{
//                	let temp = this.roleChecked;
//                	this.roleChecked = temp;
//                	this.notificationService.alertBoxValue("error", res.data.name[0]);
//                }
// 			})
// 		}
// 	}

//     /*
// 	author : dipin
// 	desc   : add class based on index
// 	*/
// 	getPermissionData() {
// 		if (!this.permissionData || this.permissionData.length == 0) {
// 			this.lazyLoad = true;
// 			this.addEmployeeService.getPermissions(this.route.snapshot.params['id'], this.roleStatus.selected[0].id, res => {
// 				this.permissionData = res.data;
// 				this.lazyLoad = false;
// 				this.sendPermissionData = [];
// 			})
// 		}
// 	}

//     /*
// 	author : dipin
// 	desc   : add class based on index
// 	*/
// 	showExpand(k, value) {
// 		this.permissionData[k].status = value;
// 		if (value) {
// 			for (let i = 0; i < this.permissionData.length; i++) {
// 				if (i != k) {
// 					this.permissionData[i].status = false;
// 				}
// 			}
// 		}
// 	}

//     /*
// 	author : dipin
// 	desc   : add class based on index
// 	*/
// 	submitPermission() {
// 		this.showOverridePopup  = false;
// 		this.sendPermissionData = Object.assign(this.permissionData);
// 	}

// 	checkClickOutside() {
//       if(!this.lazyLoad) {
//          this.showOverridePopup      = false;
//          this.permissionData = [];
//          this.permissionData = Object.assign(this.sendPermissionData);
//       }
// 	}

// 	removeDuplicates(arr) {
// 		let unique_array = []
// 		for (let i = 0; i < arr.length; i++) {
// 			if (unique_array.indexOf(arr[i]) == -1) {
// 				unique_array.push(arr[i])
// 			}
// 		}
// 		return unique_array
// 	}
// }
