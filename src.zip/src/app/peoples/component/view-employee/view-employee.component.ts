import { Component, OnInit,ViewChild,ElementRef,ChangeDetectorRef } from '@angular/core';
import { RouterModule,Routes,Router} from '@angular/router';
import { ActivatedRoute} from '@angular/router';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { AddEmployeeService } from '../../services/add-employee/add-employee.service';

declare var require: any;
var moment = require('moment');

@Component({
  selector: 'app-view-employee',
  templateUrl: './view-employee.component.html',
  styleUrls: ['../../../../assets/content/css/view-employee.css']
})

export class ViewEmployeeComponent implements OnInit {

  sub 		 		 : any;
  age                : any
  emp_id	 		 : any;
  lastName			:	any;
  empDetails 	     : any = [];
  personalDetails	 : any;
  docNumberView       : any
  educationalDetails : any = [];
  workExp			 : any = [];
  documents			 : any = [];
  showWorkExp		 : boolean = false;


  constructor(private route                 : ActivatedRoute,
		private notificationService   		: NotificationService,
		private _router               		: Router,
		private loader                		: LoaderActionsService,
		private cookieService         		: CookieService,
		private timeZone              		: TimezoneDetailsService,
		private addEmployeeService			: AddEmployeeService
	    ) { }

  ngOnInit() {
  	this.sub = this.route.params.subscribe(params => {
  		this.emp_id = params.id;
  	})
  	this.getEmpDetails();
  } 

  getEmpDetails(){
  	this.loader.display(true)
  	this.addEmployeeService.geEmployeeDetails(this.emp_id,res=>{
  		if(res.status == "OK"){
			  this.empDetails = res.data;
			  if( (this.empDetails.middle_name == null ||this.empDetails.middle_name == ''||this.empDetails.middle_name == undefined) && (this.empDetails.last_name == null ||this.empDetails.last_name == ''||this.empDetails.last_name == undefined  ))
			  this.empDetails['fullname'] 	= this.empDetails.first_name
		  
		  else if(( this.empDetails.middle_name == null ||this.empDetails.middle_name == ''||this.empDetails.middle_name == undefined )&& (this.empDetails.last_name !== null ||this.empDetails.last_name !== ''||this.empDetails.last_name!== undefined ))
			  this.empDetails['fullname'] 	= this.empDetails.first_name + " " +  this.empDetails.last_name
			  else if(( this.empDetails.middle_name !== null ||this.empDetails.middle_name !== ''||this.empDetails.middle_name !== undefined )&& (this.empDetails.last_name == null ||this.empDetails.last_name == ''||this.empDetails.last_name == undefined ))
			  this.empDetails['fullname'] 	= this.empDetails.first_name + " " +  this.empDetails.last_name
		  
			  this.empDetails['reportingto']  = this.empDetails.reporting_manager_first_name + " " +  this.empDetails.reporting_manager_last_name
			  this.personalDetails 			= this.empDetails.personalDetails;
  			if(this.personalDetails){
  				this.personalDetails.display  = false;
				  this.personalDetails.display2 = false;}
				  
				  for(let i=0;i<this.empDetails.documents.length;i++){
					if(this.empDetails.documents[i].docValidity=='0000-00-00')
					   this.empDetails.documents[i].docValidity=''  
				  }
  			this.educationalDetails = this.empDetails.educationalQualification;
  				for (var i = 0; i < this.educationalDetails.length; ++i) {
  					this.educationalDetails[i].displayStatus = false;
  				}
			  this.workExp			= this.empDetails.workExperince;
			  let temp = false;
			  for(var i = 0;i<this.workExp.length;i++){
				  if(this.workExp[i].desig_name){
					temp = true;
					break;
				  }
			  }
			  if(temp){
				this.showWorkExp = false;
			  }else{
				  this.showWorkExp = true;
			  }
  				for (var i = 0; i < this.workExp.length; ++i) {
  					this.workExp[i].displayStatus = false;
  				}
  			this.documents			= this.empDetails.documents;
  				for (var i = 0; i < this.documents.length; ++i) {
  					this.documents[i].displayStatus = false;
  				}
  			if(this.educationalDetails){
  				for (let i = 0; i < this.educationalDetails.length; i++) {
              		for (let j = 0; j < this.educationalDetails[i].file_details.length; j++) {
                		this.educationalDetails[i].file_details[j].file_type = this.educationalDetails[i].file_details[j].certificate_name.split('.').pop();
              		}
            	}
  			}
  			if(this.workExp){
  				for (let i = 0; i < this.workExp.length; i++) {
              		for (let j = 0; j < this.workExp[i].file_details.length; j++) {
                		this.workExp[i].file_details[j].file_type = this.workExp[i].file_details[j].certificate_name.split('.').pop();
              		}
            	}
  			}
  			if(this.documents){
  				for (let i = 0; i < this.documents.length; i++) {
              		for (let j = 0; j < this.documents[i].file_details.length; j++) {
                		this.documents[i].file_details[j].file_type = this.documents[i].file_details[j].doc_name.split('.').pop();
              		}
            	}
  			}

  			if(this.personalDetails){
              for (let j = 0; j < this.personalDetails.permantAddrProof.length; j++) {
                this.personalDetails.permantAddrProof[j].file_type = this.personalDetails.permantAddrProof[j].file_name.split('.').pop();
              }
            }
            if(this.personalDetails){
              for (let j = 0; j < this.personalDetails.presentAddrProof.length; j++) {
                this.personalDetails.presentAddrProof[j].file_type = this.personalDetails.presentAddrProof[j].file_name.split('.').pop();
              }
            }
  			this.loader.display(false)
  		}else{
  			this.loader.display(false)
  		}
  	})
  }
  getAge(dob){
 	//var birthday = new Date(dob);
 //    var ageDifMs = Date.now() - birthday.getTime();
 //    var ageDate = new Date(ageDifMs);
 //    return Math.abs(ageDate.getUTCFullYear() - 1970);
	// }
	if (dob != undefined || dob != null || dob != '') {
 		this.age = moment().diff(dob, 'years');
 		return this.age
 	}
}

	viewDoc(details,j){
		if(details){
			window.open(details);
		}
	}
	viewExpdoc(details,j){
		if(details){
			window.open(details);
		}
	}
	viewDocdoc(details,j){
		if(details){
			window.open(details);
		}
	}
	viewPermanatDoc(details,j){
		if(details){
			window.open(details);
		}
	}
	viewPresentDoc(details,j){
		if(details){
			window.open(details);
		}
	}
	closeOtherDoc(index){
    	for(let i = 0 ; i < this.educationalDetails.length;i++){
      		if(i != index){
        		this.educationalDetails[i].displayStatus = false;
      		}
    	}
  	}
    closeOtherExpDoc(index){
    	for(let i = 0 ; i < this.educationalDetails.length;i++){
      		if(i != index){
        		this.educationalDetails[i].displayStatus = false;
      		}
    	}
  	}
    closeOtherDocDoc(index){
    	for(let i = 0 ; i < this.documents.length;i++){
     		if(i != index){
        		this.documents[i].displayStatus = false;
      		}
    	}
  	}
  // closeCurrent(index){
  // 	this.personalDetails.display = false;
  // }
  // closeCurrent2(){
  // 	this.personalDetails.display2 = false;
  // }
  editDetails(sectionName){
	localStorage.setItem('editSection', sectionName);
  	this._router.navigate(['modules/employee/add/' + this.emp_id])
  }

  getDuration(from,to){
	  if(from !="0000-00-00" && to != "0000-00-00"){
	var a 			= moment(to);
	var b 			= moment(from);

	var years = a.diff(b, 'year');
	b.add(years, 'years');

	var months = a.diff(b, 'months');
	b.add(months, 'months');

	var days = a.diff(b, 'days');
	return years + ' years, ' + months + ' months, ' + days + ' days';	
	}else{
		return '-'
	}

  	
  }
  backTolist(){
	this._router.navigate(['modules/employee/details'])
  }
  openImage(img){
	let replaceImgUrl=img.replace("-150X150", "");
	window.open(replaceImgUrl)
   }
   checkPassword(event,index){
	if (event.status == false) {
	this.docNumberView = event.doceNumber
	this.documents[index]['docNoPush']=this.docNumberView
    this.documents[index].showPopup = event.status;
   
   }
  }
  shoeHidePassword(docData,index){
	if(docData){
		this.documents[index]['docNoPush']=''
		this.documents[index].showPopup = false
	}
  }
}