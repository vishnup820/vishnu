import { NgModule,ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule , FormsModule} from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import {HTTP_INTERCEPTORS } from '@angular/common/http';
import { GlobalErrorHandlerService } from '../global-error-handler.service';

import { ClickOutsideModule } from 'ng4-click-outside';

import { SharedModule } from '../shared/shared.module';

// import { AddEmployeeComponent } from './component/add-employee/add-employee.component';
import { UserDetailsComponent } from './component/user-details/user-details.component';

import { UserDetailsService } from './services/user-details/user-details.service';
import { AddEmployeeService } from './services/add-employee/add-employee.service';
import { AuthGuardService } from '../shared/services/auth-guard/auth-guard.service';
import { PeopleInterceptorService } from './services/people-interceptor/people-interceptor.service';
import { RoleGuardService } from '../shared/services/role-guard/role-guard.service';
import { ImageCropperModule } from 'ngx-image-cropper';
import { ConvertToEmployeeComponent } from './component/convert-to-employee/convert-to-employee.component';
import { ViewEmployeeComponent } from './component/view-employee/view-employee.component';
@NgModule({
  declarations: [UserDetailsComponent, ConvertToEmployeeComponent, ViewEmployeeComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    BsDatepickerModule.forRoot(),
    ClickOutsideModule,
    ImageCropperModule,
    RouterModule.forChild([
      {
        path        : 'add/:id',
        canActivate : [RoleGuardService],
        component   :  ConvertToEmployeeComponent,
      },
      {
        path        : 'add',
        canActivate : [RoleGuardService],
        component   :  ConvertToEmployeeComponent,
      },
      {
        path        : 'toemployee/:id',
        // canActivate : [RoleGuardService],
        component   :  ConvertToEmployeeComponent,
      },
      {
        path        : '',
        canActivate : [RoleGuardService],
        redirectTo  : 'details',
        pathMatch   : 'full'
      },
      {
        path        : 'details',
        canActivate : [RoleGuardService],
        component   :  UserDetailsComponent,
      },
      {
        path        : 'view-employee/:id',
        // canActivate : [RoleGuardService],
        component   :  ViewEmployeeComponent,
      }
    ])
  ],
  providers : [
  PeopleInterceptorService,
    UserDetailsService,
    AddEmployeeService,
      {
      provide: HTTP_INTERCEPTORS,
      useClass: PeopleInterceptorService,
      multi: true,
    },
    {
      provide  : ErrorHandler,
      useClass : GlobalErrorHandlerService,
     }
  ]
})
export class PeoplesModule { }
