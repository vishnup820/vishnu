/*
 author : Arun Johnson
 desc   : user details Listing
*/

import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

import { globalVariables } from '../../../shared/constants/globals';
import { apiList }  from '../../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {

  apiBaseUrl  : string;

  constructor(
  	private http              : HttpClient) {
  	this.apiBaseUrl = globalVariables.apiBaseUrl;
    }

    /*
 	 author : Arun Johnson
 	 desc   : get people details
    */
	getPeople(page, per_page, advanceFilterData, searchValue, sort, cb) {
		let sortValue: any;
		sort.sort ? sortValue =  '&sort='+sort.sort : sortValue = "";
		let serchFilter: any;
		searchValue ? serchFilter = "&keyword=" + searchValue : serchFilter = "";
		let params: any
		advanceFilterData ? params = this.advanceFilterApi(advanceFilterData) : params = "";
		let url: string = this.apiBaseUrl + apiList.people.details;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "?page=" + page + "&page_limit=" + per_page + params + serchFilter + sortValue)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	/*
 	 author : Arun Johnson
 	 desc   : delete People
    */
	deletePeople(selectedPeople, cb) {
		let url: string = this.apiBaseUrl + apiList.people.details;
		let promise: any = new Promise((resolve, reject) => {
			this.http.delete(url + "/" + selectedPeople.id)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

    /*
 	 author : Arun Johnson
 	 desc   : delete multiple People
    */
	multipleDelete(data, cb) {
		let datas = [];
		for (let i = 0; i < data.length; i++) {
			if (data[i].checkBoxStatus == true) {
				datas.push(data[i].id)
			}
		}
		let passObject = { "id": datas };
		let url: string = this.apiBaseUrl + apiList.people.details;
		let promise: any = new Promise((resolve, reject) => {
			this.http.request("delete", url, { body: passObject })
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

    /*
 	 author : Arun Johnson
 	 desc   : sort
    */
	sorting(data) {
		let label  : any = data.label;
		let order  : any = data.label;
		// let passValue: any;
		// label == "+" ? passValue = "&sort=" + data.name : passValue = "&sort=" + data.value + data.name;
		// return passValue;
	}

	/*
 	 author : Arun Johnson
 	 desc   : Advance Filter
    */
	advanceFilterApi(data) {
		let status: any = (data.status && data.status.selected[0]) ? "stat=" + data.status.selected[0].name + "&" : "";
		let role: any = (data.role && data.role.selected[0]) ? "role=" + data.role.selected[0].id + "&" : "";
		let location: any = (data.location && data.location.selected[0]) ? "loc=" + data.location.selected[0].id + "&" : "";
		let designation: any = (data.designation && data.designation.selected[0]) ? "desg=" + data.designation.selected[0].id + "&" : "";
		let department: any = (data.department && data.department.selected[0]) ? "dept=" + data.department.selected[0].id + "&" : "";
		let parms: any = "&" + status + role + location + designation + department;
		return parms.substring(0, parms.length - 1);
	}

    /*
       author : Arun Johnson
       desc   : add class based on index
    */
    getClassByValue(index) {
        switch (index % 10) {
            case 0: return "default-avatar islamic-green";
            case 1: return "default-avatar limerick";
            case 2: return "default-avatar chilean-fire";
            case 3: return "default-avatar persian-pink";
            case 4: return "default-avatar deep-magenta";
            case 5: return "default-avatar gigas";
            case 6: return "default-avatar endeavour";
            case 7: return "default-avatar dodger-blue";
            case 8: return "default-avatar jordy-blue";
            case 9: return "default-avatar Light-sea-green";
            case 10: return "emp-profileimage";
        }
	}
	
 /*
  *  @desc   : get all users email id
  *  @author :ashiq
  */
 emailListing(cb) {
    let url: string;
    url = this.apiBaseUrl +"/api/v1/people?fields=email&sort=email";
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

  emailNotify(cb) {
    let url: string;
    url = this.apiBaseUrl + apiList.people.emailNotify;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

  userPasswordReset(user, cb) {
		let url: string = this.apiBaseUrl + apiList.auth.sendMail;
        this.http.post(url,{"search" : user})
        .toPromise()
        .then(res=>{
            cb(res);
        });
	}
}
