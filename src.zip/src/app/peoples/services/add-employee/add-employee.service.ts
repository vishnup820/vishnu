/*
 author : Arun Johnson
 desc   : add user
*/
import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

import { globalVariables } from '../../../shared/constants/globals';
import { apiList }  from '../../../shared/constants/apilist';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { LoaderActionsService } from 'src/app/shared/services/loader/loader-actions.service';

declare var require: any;
var moment = require('moment');
@Injectable({
  providedIn: 'root'
})
export class AddEmployeeService {

   apiBaseUrl  : string;

   constructor(
  	private http              : HttpClient,
	  private timeZone : TimezoneDetailsService,
	  private 	loaderActionsService : LoaderActionsService) {
  	this.apiBaseUrl = globalVariables.apiBaseUrl; }



    /*
 	 author : Arun Johnson
 	 desc   : get People
    */
	getPeople(id,type, cb) {
		 let url : string;
		if(type)
		 url = this.apiBaseUrl + "/api/v1/selfOnboard";
		else
		 url = this.apiBaseUrl + apiList.people.details;
		 let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "/" + id)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	getMaster(callBack) {
		let url: string;
		url = this.apiBaseUrl + "/api/v1/onboardMaster";
		let promise = new Promise((resolve, reject) => {
		  this.http.get(url)
			.toPromise()
			.then(res => {
			  if (res) callBack(res)
			})
		})
		return promise;
	  }

	/*
 	 author : Arun Johnson
 	 desc   : get Master Data
    */
	getMasterData(cb) {
		let url: string = this.apiBaseUrl + apiList.people.master;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	/*
  *  @desc   :method for search via api call and return responce
  *  @author :dipin
  */
	getData(type, id, callBack) {
		let url: string;
		if (type == 'country') {
			url = this.apiBaseUrl + apiList.onboard.getMastersCountry;
		}
		else if (type == 'state') {
			url = this.apiBaseUrl + apiList.onboard.getMastersStates + id;
		}
		else if (type == 'other') {
			url = this.apiBaseUrl + apiList.onboard.getMasterData;
		}
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

    /*
 	 author : Arun Johnson
 	 desc   : submit Add/ edit Form
    */
	submitForm(
		notString,
		croppedImage,
		emplId,
		value,
		probationSelected,
		gender,
		maritalSelected,
		roleStatus,
		designationSelected,
		departmentSelected,
		locationSelected,
		reportingManager,
		lineManagerSelected,
		employeeTypeSelected,
		employeeGroupSelected,
		statusSelected,
		details, tempData, 
		attendanceType, 
		child, 
		work, 
		education, 
		doc,sameAbove,
		fileData,dateofRevl,
		financialYear,payperiod,shiftSelected,
		fileDataSec,
		 cb) {
		let parms: any;
		let group: any = [];
		let file_dataPerment = [],tempObj = [],file_dataPermentSec = [];
		let currentDomain = window.location.origin.split('/');
		currentDomain[2] = currentDomain[2].replace(':4200', '');//for local only
		for (let i = 0; i < employeeGroupSelected.selected.length; i++) {
			group.push(employeeGroupSelected.selected[i].id);
		}
		if(fileData)
        for(let i = 0 ; i < fileData.length;i++){
          if(fileData[i].file_data){
            file_dataPerment.push({'file_data' : fileData[i].file_data});
          }
		}
		
		if(child.length){
			for(let i = 0 ; i < child.length;i++){
			  tempObj.push({name : child[i].name,gender:child[i].gender,dob:(child[i].date)?this.formatForApi(child[i].date):''});
			}
			if(tempObj.length){
				for(var k = 0;k<tempObj.length;k++){
					// && tempObj[k].gender=="" && (tempObj[k].dob == "" || tempObj[k].dob == undefined)
					if(tempObj[k].name==""){
						tempObj.splice(k,1)
						k = 0;
					}
				}
			}
		}
	 if(child.length){
			let stat = false;
			for(let j = 0 ; j < child.length;j++){
			//   tempObj.push({name : child[i].name,gender:child[i].gender,dob:(child[i].date)?this.formatForApi(child[i].date):''});
				if(child[j].name !==null &&child[j].name !==''){
				stat = true;
				break;
			 	}
				else{
					stat = false;
				}
		
			}
			if(stat==false)
				child.length = 0

		}

		if(fileDataSec)
        for(let i = 0 ; i < fileDataSec.length;i++){
          if(fileDataSec[i].file_data){
            file_dataPermentSec.push({'file_data' : fileDataSec[i].file_data});
          }
		}
		let tempObjEdu = [],file_dataPermentEdu = [];
		if(education.length || education[0].qualification)
		for(let i = 0; i < education.length;i++){
			file_dataPermentEdu = [];
			if(education[i].fileData)
			for(let j = 0 ; j < education[i].fileData.length;j++){
				if(education[i].fileData[j].file_data){
				  file_dataPermentEdu.push({'file_data' : education[i].fileData[j].file_data});
				}
			}
		  tempObjEdu.push({
			  "qualification":(education && education[i] && education[i].qualification && education[i].qualification.qualifId)?education[i].qualification.qualifId:null,
				"institution":(education && education[i]  && education[i].institution)?education[i].institution:null,
			  "year_of_passout":(education && education[i] && education[i].year && education[i].year.name)?education[i].year.name:null,
			  "certificates_data":(file_dataPermentEdu)?file_dataPermentEdu:null,
			});
		}
		let tempObjWork = [],file_dataPermentWork = [];
		if(work.length || work[0].designation)
		for (let i = 0; i < work.length; i++) {
			file_dataPermentWork = [];
			if(work[i].fileData)
			for (let j = 0; j < work[i].fileData.length; j++) {
				if (work[i].fileData[j].file_data) {
					file_dataPermentWork.push({ 'file_data': work[i].fileData[j].file_data });
				}
			}
			tempObjWork.push({
				"designation": (work && work[i] &&  work[i].designation)?work[i].designation:null,
				"organization": (work && work[i] && work[i].organization)?work[i].organization:null,
				"from_date": (work && work[i] && work[i].from && work[i].from != '0000-00-00' &&  work[i].from != '-')?this.formatForApi(work[i].from):null,
				"to_date": (work && work[i] && work[i].to && work[i].to != '0000-00-00' &&  work[i].to != '-')?this.formatForApi(work[i].to):null,
				"certificate_data": (file_dataPermentWork)?file_dataPermentWork:null,
				"uploadLater": (work && work[i] && work[i].uploadLater)?work[i].uploadLater:null
			});
		}
		let tempObjDoc = [],file_dataPermentDoc = [];
		if(doc.length || doc[0].name)
			for (let i = 0; i < doc.length; i++) {
				file_dataPermentDoc = [];
				if(doc[i].fileData)
				for (let j = 0; j < doc[i].fileData.length; j++) {
					if (doc[i].fileData[j].file_data) {
						file_dataPermentDoc.push({ 'file_data': doc[i].fileData[j].file_data });
					}
				}
				tempObjDoc.push({
					"document_type": (doc && doc[i] && doc[i].name && doc[i].name.docTypeId)?doc[i].name.docTypeId:null,
					"document_validity": (doc && doc[i] && doc[i].expiry && doc[i].expiry != '0000-00-00')?this.formatForApi(doc[i].expiry):null,
					"document_number": (doc && doc[i] && doc[i].no)?doc[i].no:null,
					"upload_later": (doc && doc[i] && doc[i].uploadLater)?doc[i].uploadLater:null,
					"file_data": (file_dataPermentDoc)?file_dataPermentDoc:null
				});
			}
		
		parms = {
			"basic_details": {
				"notified_peoples" : (notString)?notString:null,
				"first_name": details.value.firstName.trim(),
				"last_name": (details && details.value && details.value.lastName)?details.value.lastName:null,
				"dob": this.formateDate(details.value.dob),
				"gender": gender.selected[0] ? gender.selected[0].name : null,
				"code": details.value.empId,
				"middle_name": details.value.middleName,
				"display_name": details.value.displayName,
				"temporary_address": details.value.tempAddress,
				"role_id": roleStatus.selected[0] ? roleStatus.selected[0].id : null,
				"designation_id": designationSelected.selected[0] ? designationSelected.selected[0].id : null,
				"date_of_joining":this.formateDate2(details.value.date_of_joining),
				"department_id": (departmentSelected && departmentSelected.selected && departmentSelected.selected[0]) ? departmentSelected.selected[0].id : null,
				"location_id": locationSelected.selected[0] ? locationSelected.selected[0].id : null,
				"email": details.value.emailId,
				"reporting_manager_id": reportingManager.selected[0] ? reportingManager.selected[0].id : null,
				"status": (statusSelected && statusSelected.selected && statusSelected.selected[0]) ? statusSelected.selected[0].name : 1,
				"username": details.value.userName,
				"extension": details.value.extension,
				"speed_dial": details.value.speedDial,
				"personal_email": details.value.personalEmailId,
				"contact_number": details.value.contactNumber,
				"marital_status": maritalSelected && maritalSelected.selected && maritalSelected.selected[0] ? maritalSelected.selected[0].id : null,
				"address": (details && details.value && details.value.permanetAddress)?details.value.permanetAddress:null,
				"line_manager_id": (lineManagerSelected && lineManagerSelected.selected &&lineManagerSelected.selected[0]) ? lineManagerSelected.selected[0].id : null,
				"group": group,
				"image_data": croppedImage,
				"probation_period": (probationSelected && probationSelected.selected && probationSelected.selected[0]) ? probationSelected.selected[0].value : null,
				"employee_type": (employeeTypeSelected && employeeTypeSelected.selected && employeeTypeSelected.selected[0]) ? employeeTypeSelected.selected[0].value : null,
				"domain": currentDomain[2],
				"role_privilege_ids": tempData,
				// "punch_type": (attendanceType.selected[0].name == "Manual") ? 2 : 1,
				"attendance_type_id": (attendanceType && attendanceType.selected && attendanceType.selected[0] && attendanceType.selected[0].type == "Biometric") ? 1 : 2,
				"financial_calendar_id":(financialYear && financialYear.selected && financialYear.selected[0])?financialYear.selected[0].id:null,
				"pay_period_id": (payperiod.selected[0])?payperiod.selected[0].id:null,
				"shift_type_id": (shiftSelected.selected[0])?shiftSelected.selected[0].id:null,
				"date_of_relieving":(dateofRevl)?this.formatForApi(dateofRevl):null,
			},
			"personalDetails": {
				"alternate_mobile": details.value.alNumber,
				"mothers_name": details.value.motherName,
				"mothers_email": details.value.mEmail,
				"mothers_mobile": details.value.motherCNo,
				"mothers_dob": (details.value.motherDob && details.value.motherDob != '0000-00-00')?this.formatForApi(details.value.motherDob):null,
				"fathers_name": details.value.fatherName,
				"fathers_email": details.value.fatherEmailId,
				"fathers_mobile": details.value.fatherCNo,
				"fathers_dob": (details.value.fatherDob && details.value.fatherDob != '0000-00-00')?this.formatForApi(details.value.fatherDob):null,
				"marital_status": maritalSelected && maritalSelected.selected && maritalSelected.selected[0] ? maritalSelected.selected[0].id : null,
				"spouse_name": (maritalSelected && maritalSelected.selected && maritalSelected.selected[0] && maritalSelected.selected[0].id =='1')? details.value.spouseName:null,
				"spouse_email": (maritalSelected && maritalSelected.selected && maritalSelected.selected[0] && maritalSelected.selected[0].id =='1')?details.value.sEmail:null,
				"spouse_mobile": (maritalSelected && maritalSelected.selected && maritalSelected.selected[0] && maritalSelected.selected[0].id =='1')?details.value.spouseCNo:null,
				"spouse_dob": (maritalSelected && maritalSelected.selected && maritalSelected.selected[0] && maritalSelected.selected[0].id =='1' && details.value.spouseDob)?this.formatForApi(details.value.spouseDob):null,
				"children": (child.length)?1:0,
				"blood_group": details.value.bloodGroup,
				"religion_id": details.value.religion,
				"caste_id": details.value.caste,
				"land_line_no": details.value.landLine,
				"permanent_address": details.value.permanetAddress,
				"permanent_landmark": details.value.landMark,
				"permanent_country": details.value.country,
				"permanent_state": details.value.state,
				"permanent_city": details.value.city,
				"permanent_pincode": details.value.pincode,
				"permanent_address_proof_data": file_dataPerment,
				"is_same_as_present":  (sameAbove)?1:0,
				"present_address": details.value.tempAddress,
				"present_landmark": details.value.templandMark,
				"present_country":details.value.tempcountry,
				"present_state": details.value.tempstate,
				"present_city": details.value.tempcity,
				"present_pincode": details.value.temppincode,
				"present_address_proof_data": file_dataPermentSec,
				"emergency_contact_name":details.value.emeName,
				"emergency_contact_mob": details.value.emeNo,
				"emergency_contact_relation": details.value.emeRelation,
				"is_experienced": (work.length >= 1)?1:0,
				"child_details": tempObj,
			},
			"educationalQualification" : tempObjEdu,
			"workExperince"            : tempObjWork,
			"documents"                : tempObjDoc
		}
		let url: string = this.apiBaseUrl + apiList.people.details;
		if (value == "add") {
			let promise: any = new Promise((resolve, reject) => {
				this.http.post(url, parms)
					.toPromise()
					.then(res => {
						cb(res);
					})
			})
		}
		else {
			let promise: any = new Promise((resolve, reject) => {
				this.http.put(url + "/" + emplId.id, parms)
					.toPromise()
					.then(res => {
						cb(res);
					})
			})
		}
	}
	formateDate2(date) {
		let newdate = date.split('-')
		let newdate2 = newdate[2]+"-"+(newdate[1])+"-"+newdate[0]
		if (newdate2) {
			let ndate = this.timeZone.toLocal(moment(newdate2, 'YYYY-MM-DD'));
			if (ndate) {
				return moment(ndate).format('YYYY-MM-DD')
			}
		} else
			return null;
	}

	convertToEmployee(id,editFormData,probationSelected,roleStatus,designationSelected,
		departmentSelected,locationSelected,
		reportingManagerSelect,
		lineManagerSelected,
		employeeTypeSelected,
		employeeGroupSelected,
		statusSelected,
		employeeDetails, tempData,attendanceSelected,dateofRevl,financialYear,payperiod,shiftSelected,cb){
			this.loaderActionsService.display(true)
		let params,group = [];
		for (let i = 0; i < employeeGroupSelected.selected.length; i++) {
			group.push(employeeGroupSelected.selected[i].id);
		}
		
		params = {
			"onboard_id": id,
			"details": {
				"email": editFormData.value.emailId,
				"username": editFormData.value.userName,
				"code": editFormData.value.empId,
				"extension": editFormData.value.extension,
				"speed_dial":editFormData.value.speedDial,
				"date_of_joining": editFormData.value.date_of_joining,
				"role_id": roleStatus.selected[0] ? roleStatus.selected[0].id : null,
				"department_id": departmentSelected.selected[0] ? departmentSelected.selected[0].id : null,
				"designation_id": designationSelected.selected[0] ? designationSelected.selected[0].id : null,
				"location_id": locationSelected.selected[0] ? locationSelected.selected[0].id : null,
				"reporting_manager_id":reportingManagerSelect.selected[0] ? reportingManagerSelect.selected[0].id : null,
				"line_manager_id": lineManagerSelected.selected[0] ? lineManagerSelected.selected[0].id : null,
				"employee_type":  employeeTypeSelected.selected[0] ? employeeTypeSelected.selected[0].value : null,
				"probation_period":  probationSelected.selected[0] ? probationSelected.selected[0].value : null,
				"financial_calendar_id": (financialYear.selected[0])?financialYear.selected[0].id:null,
				"pay_period_id": (payperiod.selected[0])?payperiod.selected[0].id:null,
				"shift_type_id": (shiftSelected.selected[0])?shiftSelected.selected[0].id:null,
				"date_of_relieving":this.formatForApi(dateofRevl),
				"group":group,
				"punch_type": (attendanceSelected.selected[0].name == "Manual") ? 2 : 1,
				"role_privilege_ids": tempData,
				"status": statusSelected.selected[0] ? statusSelected.selected[0].name : 1,
			}
		}
			let url: string = this.apiBaseUrl +"/api/v1/ConvertToEmployee";
				let promise: any = new Promise((resolve, reject) => {
					this.http.post(url, params)
						.toPromise()
						.then(res => {
							cb(res);
						})
				})
				this.loaderActionsService.display(false)

	}

	converttoEmployee(params,cb){
		// let params,group = [];
		// for (let i = 0; i < employeeGroupSelected.selected.length; i++) {
		// 	group.push(employeeGroupSelected.selected[i].id);
		// }

		// params = {
		// 	"onboard_id": id,
		// 	"details": {
		// 		"email": editFormData.value.emailId,
		// 		"username": editFormData.value.userName,
		// 		"code": editFormData.value.empId,
		// 		"extension": editFormData.value.extension,
		// 		"speed_dial":editFormData.value.speedDial,
		// 		"date_of_joining": editFormData.value.date_of_joining,
		// 		"role_id": roleStatus.selected[0] ? roleStatus.selected[0].id : null,
		// 		"department_id": departmentSelected.selected[0] ? departmentSelected.selected[0].id : null,
		// 		"designation_id": designationSelected.selected[0] ? designationSelected.selected[0].id : null,
		// 		"location_id": locationSelected.selected[0] ? locationSelected.selected[0].id : null,
		// 		"reporting_manager_id":reportingManagerSelect.selected[0] ? reportingManagerSelect.selected[0].id : null,
		// 		"line_manager_id": lineManagerSelected.selected[0] ? lineManagerSelected.selected[0].id : null,
		// 		"employee_type":  employeeTypeSelected.selected[0] ? employeeTypeSelected.selected[0].value : null,
		// 		"probation_period":  probationSelected.selected[0] ? probationSelected.selected[0].value : null,
		// 		"financial_calendar_id": (financialYear.selected[0])?financialYear.selected[0].id:null,
		// 		"pay_period_id": (payperiod.selected[0])?payperiod.selected[0].id:null,
		// 		"shift_type_id": (shiftSelected.selected[0])?shiftSelected.selected[0].id:null,
		// 		"date_of_relieving":this.formatForApi(dateofRevl),
		// 		"group":group,
		// 		"punch_type": (attendanceSelected.selected[0].name == "Manual") ? 2 : 1,
		// 		"role_privilege_ids": tempData,
		// 		"status": statusSelected.selected[0] ? statusSelected.selected[0].name : 1,
		// 	}
		// }
			let url: string = this.apiBaseUrl +"/api/v1/ConvertToEmployee";
				let promise: any = new Promise((resolve, reject) => {
					this.http.post(url, params)
						.toPromise()
						.then(res => {
							cb(res);
						})
				})

	}

    /*
 	 author : dipin
 	 desc   : format date
    */
	formateDate(date) {
		if (date) {
			date = this.timeZone.toLocal(moment(date, 'DD-MM-YYYY'));
			if (date) {
				return moment(date).format('YYYY-MM-DD')
			}
		} else
			return null;
	}

	 	/*
	*  @desc   : make date to the format 'dd-mm-yyyy'
	*  @author : dipin
	*/
	formatForApi(inputDate) {
		var date = new Date(inputDate);
		if(date)
		if (!isNaN(date.getTime())) {
			if ((Number(date.getMonth()) + 1) < 10) {
				if (Number(date.getDate() < 10)) {
					return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
				}
				else {
					return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
				}
			}
			else {
				if (Number(date.getDate() < 10)) {
					return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
				}
				else {
					return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
				}
			}
		}
	  else
	  	return undefined;
    }

	/*
 	author : dipin
 	desc   : get permissions for a particular user
    */
	getPermissions(id, rid, cb) {
		if (!id) {
			id = 0;
		}
		let url: string = this.apiBaseUrl + "/api/v1/people/" + id + "/user-privileges/" + rid;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	updatePermissions(id, obj, cb) {
		if (!id) {
			id = 0;
		}
		let url: string = this.apiBaseUrl + "/api/v1/people/" + id + "/user-privileges";
		let promise: any = new Promise((resolve, reject) => {
			this.http.put(url, obj)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	addCustomRole(obj, cb) {
		let url: string = this.apiBaseUrl + apiList.role.addRole;
		let promise: any = new Promise((resolve, reject) => {
			this.http.post(url, obj)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
	}

	geEmployeeDetails(empid,callback){
		let url: string = this.apiBaseUrl + "/api/v1/people/"+empid;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					callback(res);
				})
		})
	}
	getFullNotifyUsers(callback){
		let url: string = this.apiBaseUrl + "/api/v1/email-notifier?name=user_email_notifer";
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					callback(res);
				})
		})
	}
}
