/*
* @desc   : Intercept each server request and response and add common header
* @author : dipin
*/
import { Injectable, OnInit, Inject, Injector } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { CookieService } from 'ngx-cookie-service';
// import { AuthService } from '../auth/auth.service';
import { CookieDataService } from '../../../shared/services/cookie-data/cookie-data.service';

import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';

// import 'rxjs/add/operator/do';
// import 'rxjs/add/operator/catch';
// import 'rxjs/add/operator/mergeMap';
// import 'rxjs/add/observable/throw';
// import 'rxjs/add/operator/catch';
// import 'rxjs/Rx';

@Injectable({
	providedIn: 'root'
})
export class PeopleInterceptorService implements OnInit {
    
	userSession: any;
	apiBaseUrl: string;
	status: any = true;
	public cachedRequests: any = [];
	apilist : any = [];
	constructor(
		private cookieService: CookieService,
		private router: Router,
		private http: HttpClient,
		private cookieDataService: CookieDataService,
		public inj: Injector, public loaderInject: Injector
	) { this.apiBaseUrl = globalVariables.apiBaseUrl; }

	// private applyCredentials = (request: HttpRequest<any>, token: string) => {
	// 	if (this.status) {
	// 		return request.clone({
	// 			setHeaders: {
	// 				'Content-Type': 'application/json; charset=utf-8',
	// 				'Authorization': "Bearer " + JSON.parse(localStorage.getItem('session')).access_token
	// 			}
	// 		})
	// 	} else {
	// 		return request.clone({
	// 			setHeaders: {
	// 				'Content-Type': 'application/json; charset=utf-8'
	// 			}
	// 		})
	// 	}
	// }

	ngOnInit() {

	}

	// intercept(request: HttpRequest<any>, next: HttpHandler): Observable<any> {
	
		// let auth: any = this.inj.get(AuthService);
		// let authReq: any = this.applyCredentials(request, auth.getToken());
		// return next.handle(authReq)
		// 	.map((event: any) => {
		// 		if (event instanceof HttpResponse) {
		// 			return event;
		// 		}

		// 	})
		// 	.catch((err: any) => {
		// 		 if (err instanceof HttpErrorResponse) {
		// 			if ((err.status === 0 || err.status === 401)) {
		// 					this.status = false;
		// 					return auth.getNewAcessToken().switchMap((res) => {
		// 						if (res.status != 'FAIL') {
		// 							this.status = true;
		// 								localStorage.setItem('session', JSON.stringify({
  //       									"refresh_token"   : res.data.refresh_token,
  //      										 "access_token"   : res.data.access_token,
  //     									}))
  //     									return next.handle(this.applyCredentials(request, auth.getToken()));
		// 						}
		// 					});
		// 				    // }

		// 			} else if (err.status === 403) { //log back in!!

		// 				this.router.navigate(['/login']);

		// 			} else {

		// 				return Observable.throw(err);

		// 			}
		// 		}
  //             }
		// 	)
	// }

}
