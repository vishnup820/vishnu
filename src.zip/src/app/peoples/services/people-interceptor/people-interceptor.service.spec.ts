import { TestBed } from '@angular/core/testing';

import { PeopleInterceptorService } from './people-interceptor.service';

describe('PeopleInterceptorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PeopleInterceptorService = TestBed.get(PeopleInterceptorService);
    expect(service).toBeTruthy();
  });
});
