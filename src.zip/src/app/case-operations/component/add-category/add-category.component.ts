/*
* @desc : component for add category
* @auth : Ashiq
*/

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { AddCategoryService } from '../../services/add-category/add-category.service';
import { CategorylistService } from '../../services/category-list/categorylist.service';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';

@Component({
	selector: 'app-add-category',
	templateUrl: './add-category.component.html',
	styleUrls: ['./add-category.component.css']
})

export class AddCategoryComponent implements OnInit {

	addCategoryForm 		: FormGroup;
	nameField 				: FormControl;
	titleField 				: FormControl;
	responseTimeField 		: FormControl;
	resolutionTimeField 	: FormControl;
	managerField 			: FormControl;
	statusField 			: FormControl;
	descriptionField 		: FormControl;
	prefix                  : FormControl;
	from					: FormControl;
	selectedItems           : any=[];
	selectedIds              : any=[];
	tempEmployeeId           : any=[];
	selectedManagerData     : any;
	statusList 				: any;
	managerList 			: any;
	categoryObj 			: any;
    updateObj       		: any;
	id						: any;
	x                       : any;
	m_id            		: any;
	selectedManager			: any;
	selectedStatus  		: any;
	prefixValue             : any;
	editStatus      		: boolean = false;
	aclPermission           : boolean = false;
	submitted 		        : boolean = false;


    constructor(
    	private loaderService			: LoaderActionsService,
		private addCategoryService		: AddCategoryService,
	    private categorylistService		: CategorylistService,
		private notificationService 	: NotificationService,
		private route					: ActivatedRoute ,
		private router					: Router,
		private aclCheck                : AclVerificationService) {}

	ngOnInit() {
		this.aclPermission = this.aclCheck.checkAcl('/modules/case/case-list');
		this.getAllManagers();
		this.route.params.subscribe(params => {
			if (params['id']) {
				this.editStatus = true;
				this.id = params['id'];
				this.getCategory(this.id);
			}
		});
		this.statusList = [
			{
				"data": "Active", value: 1
			},
			{
				"data": "Inactive", value: 2
			}
		];
		this.selectedStatus = [0];
		this.categoryFormControls();
		this.createCategoryForm();
		this.addCategoryForm.patchValue({
			statusField: 1
		})
	}
	
	/*
	* @desc : creating form controls for add category
	* @auth : Ashiq
    */
   categoryFormControls() {
 		this.nameField 			 = new FormControl('', [Validators.required]);
		this.titleField 		 = new FormControl('', [Validators.required]);
		this.responseTimeField 	 = new FormControl('', [Validators.required]);
		this.resolutionTimeField = new FormControl('', [Validators.required]);
		this.managerField 		 = new FormControl('');
		this.statusField 		 = new FormControl('', [Validators.required]);
		this.descriptionField 	 = new FormControl('', [Validators.required]);
		this.prefix 	 		 = new FormControl('', [Validators.required]);
		this.from				 = new FormControl('', [Validators.required]);
	} 
	/*
	* @desc : creating form group for add category
	* @auth : Ashiq
    */
	createCategoryForm() {
		this.addCategoryForm = new FormGroup({
			nameField 			: this.nameField,
			titleField 			: this.titleField,
			responseTimeField 	: this.responseTimeField,
			resolutionTimeField : this.resolutionTimeField,
			managerField 		: this.managerField,
			statusField 		: this.statusField,
			descriptionField 	: this.descriptionField,
			prefix         		: this.prefix,
			from				: this.from
		})
	}

	/*
	* @desc : method for auto fill prefix
	* @auth : Ashiq
    */
	myFun(event, namefield, idField) {
		if (!this.editStatus) {
			if (event) {
				let obj = { "category_name": namefield.value, "id_prefix": idField.value ? idField.value : null }
				this.addCategoryService.getPrefix(obj, response => {
					if (response.status == "OK") {
						this.prefixValue = response.suggestion;
						this.prefix.setValue(this.prefixValue);
					}
					else {
						if (response.data && response.data['error-msg']) {
							this.notificationService.alertBoxValue("warning", response.data['error-msg']);
						}
					}
				})
			}
		}
	}
	/*
	* @desc : autofill generating method for from field
	* @auth : Ashiq
    */
	autofillFrom(val){
		if(val.value){
			let fromValue=val.value + " " + "Team";
			this.addCategoryForm.patchValue({
				from 			: fromValue
		})
	}}

   /*
	* @desc : Prefix generating method for category title
	* @auth : Ashiq
    */
	PerfixValidation(event) {
		var letters = /^[A-Za-z]+$/;
		if (event.key.match(letters)) {
			return true;
		}
		else {
			event.preventDefault();
			return false;
		}
	}
	/*
		* @desc :api call to get corresponding data by passing id
		* @auth : Ashiq
    */
	getCategory(id) {
		this.loaderService.display(true);
		this.addCategoryService.getCategory(id, (res) => {
			if(res.status){
				if(res.status==1){
					this.selectedStatus=[0];
				}else{
					this.selectedStatus=[1];
				}
			}
			this.getAllManagersId(res.managers);
			setTimeout(() => {
				this.addCategoryForm.patchValue({
					nameField 			: res.name,
					titleField 			: res.title,
					responseTimeField 	: res.response_time,
					resolutionTimeField : res.resolution_time,
					descriptionField 	: res.description,
					statusField     	: res.status,
					managerField		: res.managers,
					prefix              : res.code_prefix,
					from                : res.from_name
				});
			});
			this.loaderService.display(false);
		})
	}

	/*
	* @desc : api service to get  all managers
	* @auth : Ashiq
    */
	getAllManagers() {
		this.loaderService.display(true);
		this.addCategoryService.getManagerApi(res => {
			this.managerList = res.data;
			for (let i = 0; i < this.managerList.length; i++) {
				if (this.managerList[i].first_name) {
					this.managerList[i].first_name = this.managerList[i].first_name + " " + this.managerList[i].last_name + " " + "(" + this.managerList[i].code + ")";
				}
			}
			this.loaderService.display(false);
		})
	}


    /*
	* @desc : a new category is created
	* @auth : Ashiq
    */
	addCategory() {
		this.tempEmployeeId = [];
		if (this.selectedManagerData) {
			for (let i = 0; i < this.selectedManagerData.length; i++) {
			  this.tempEmployeeId.push( {"user_id":this.selectedManagerData[i].originalData.user_id });
			}
		  }
		if(this.addCategoryForm.valid && this.selectedManagerData.length>0){
			   this.submitted  = false;
			   this.categoryObj = {
				   "name"				: this.nameField.value.trim(),
				   "title"				: this.titleField.value,
				   "description"		: this.descriptionField.value,
				   "manager_id"		: this.tempEmployeeId,
				   "response_time"		: this.responseTimeField.value,
				   "resolution_time"	: this.resolutionTimeField.value,
				   "status"			: this.statusField.value,
				   "code_prefix"       : this.addCategoryForm.value.prefix,
				   "from_name"         : this.from.value
			   }
			   this.addCategoryService.getAddCategoryApi(this.categoryObj, response => {
				   if(response.status == "OK"){
					   this.router.navigateByUrl("/modules/case/category-list");
					   setTimeout(() => {
						   this.loaderService.display(false);
						   this.notificationService.alertBoxValue("success", response.message);
					   }, 500);
				   }
				   else{
					   this.loaderService.display(false);
					   if(response.status="FAIL")
						   if(response.data['code_prefix']){
							this.notificationService.alertBoxValue("error",response.data.code_prefix[0]);
						   }
						   if( response.status="FAIL" && response.data['name']){
							this.notificationService.alertBoxValue("error",response.data.name[0]);
						   }
						   if(  response.status="FAIL" && response.data['from_name']){
							   this.notificationService.alertBoxValue("error",response.data.from_name);
						   }
						   if(  response.status="FAIL" && response.data['manager_id']){
							   this.notificationService.alertBoxValue("error",response.data.manager_id);
						   }
						   if(  response.status="FAIL" && response.data['error-msg']){
							this.notificationService.alertBoxValue("error", response.data['error-msg']); 
						}
   
				   }
			   })
          }
     	else{
		  this.submitted  = true;
		}
	}

  /*
	* @desc : update the category
	* @auth : Ashiq
    */
	updateCategory() {
		this.tempEmployeeId = [];
		if (this.selectedManagerData) {
			for (let i = 0; i < this.selectedManagerData.length; i++) {
				this.tempEmployeeId.push({ "user_id": this.selectedManagerData[i].originalData.user_id });
			}
		}
		if (this.addCategoryForm.valid && this.selectedManagerData.length > 0) {
			this.prefixValue = this.addCategoryForm.value.prefix
			this.loaderService.display(true);
			this.updateObj = {
				"name": this.nameField.value.trim(),
				"title": this.titleField.value,
				"description": this.descriptionField.value,
				"manager_id": this.tempEmployeeId,
				"response_time": this.responseTimeField.value,
				"resolution_time": this.resolutionTimeField.value,
				"status": this.statusField.value,
				"from_name": this.from.value,
				"code_prefix": (this.prefix.value) ? this.prefix.value : this.prefixValue
			}
			this.categorylistService.updateCategoryDetails(this.id, this.updateObj, response => {
				if (response.status == "OK") {
					this.router.navigateByUrl("/modules/case/category-list");
					setTimeout(() => {
						this.loaderService.display(false);
						this.notificationService.alertBoxValue("success", response.message);
					}, 500);
				} else {
					if (response.status = "FAIL" && response.data['error-msg']) {
						this.notificationService.alertBoxValue("error", response.data['error-msg']);
					} else if (response.data.name)
						this.notificationService.alertBoxValue("error", response.data.name[0]);
					else
						this.notificationService.alertBoxValue("error", response.messages);
				}
			})
			this.loaderService.display(false);
		}
		else {
			this.submitted = true;
		}
	}

	 /*
	* @desc : select status from form using event
	* @auth : Ashiq
    */
	selectStatus(event) {
		if (event.selected.length > 0) {
			this.addCategoryForm.patchValue({
				statusField: event.selected[0].value
			})
		}
		else {
			this.addCategoryForm.patchValue({
			statusField: ""
			})
		}
	}

	 /*
	* @desc : get manager id from form using event
	* @auth : Ashiq
    */
	selectManager(events) {
		if (events.selected.length > 0) {
			this.m_id = events.selected[0].id;
			this.selectedManager = events.selected[0];
			this.addCategoryForm.patchValue({
				managerField: this.selectedManager
			});
		} else {
			this.addCategoryForm.patchValue({
				managerField: ""
			});
		}
	}

     /*
	* @desc :  method to get index of manager selected
	* @auth : Ashiq
    */
	getAllManagersId(manager_id) {
		this.addCategoryService.getManagerApi(res => {
			this.managerList = res.data;
			let managerArray = manager_id;
			for (let i = 0; i < this.managerList.length; i++) {
				if (this.managerList[i].first_name) {
					this.managerList[i].first_name = this.managerList[i].first_name + " " + this.managerList[i].last_name + " " + "(" + this.managerList[i].code + ")"
				}
				for (let j = 0; j < managerArray.length; j++) {
					if (this.managerList[i].user_id == managerArray[j].manager_id) {
						this.selectedIds.push({ id: this.managerList[i].id, name: this.managerList[i].first_name })
					}
				}
			}
			for (let k = 0; k < this.selectedIds.length; k++) {
				this.selectedItems[k] = this.selectedIds[k].name;
			}
		})
	}

    /*
	* @desc : redirect back to previous window
	* @auth : Ashiq
    */
	back(){
		   window.history.back();
    }
}
