/*
    *  @desc   : component deal with display details of case
    *  @author : dipin
    */
import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CaseOperationsService } from '../../services/case-service/case-operations.service';
import { Router  , ActivatedRoute } from '@angular/router';
import * as FileSaver from 'file-saver';
import { CookieService } from 'ngx-cookie-service';
import {formatDate } from '@angular/common';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { ConstantServicesService } from '../../../shared/services/constant/constant-services.service';
declare var require: any;
var moment = require('moment-timezone');
@Component({
  selector: 'app-my-request-details',
  templateUrl: './my-request-details.component.html',
  styleUrls: ['./my-request-details.component.css']
})
export class MyRequestDetailsComponent implements OnInit {

 selectedId : any;
  tableData  : any;
  textValue  : any = '';
  type       : any;
  userData   : any;
  empId      : any;
  idValue    : any;
  message    : any;
  fileName   : any;
  fileData   : any;
  newvalue   : any;
  config     : any;
  selectedTab :any;
  fileArray          : any=[];
  replyFileArray     : any=[];
  messageValue : any = '';
  showDiv    : boolean = false;
  lazyLoadNodata : boolean = false;
  lazyLoad   : boolean = false;
  displayChat   : boolean = false;
  confirmBox    : boolean = false;
  multipleFileClick  : boolean = false;
  stoppage : boolean = false;
  setDisable :boolean =true;
  maxSizeString : string = '' ;
  maxSizeInt : number = 5242880 ; //5 MB
  fileSizeArray :any=[];
  indexCounter : any =[];
  constructor(
    private loaderService : LoaderActionsService,
    private apiService  : CaseOperationsService,
            private notifications : NotificationService,
            private routeStatus   : Router,
            private route         : ActivatedRoute,
            private cookieService : CookieService,
            private cdr           : ChangeDetectorRef,
            private constSetup    : ConstantServicesService,
            private timeZone : TimezoneDetailsService) {}

  ngOnInit() {
    this.loaderService.display(true);
    this.config = " Are You Sure You Want To Change The Status?";


   
    if (this.constSetup.caseStatus) {
      this.tableData = {
        "id": this.constSetup.caseStatus.id,
        "creater_user_name": this.constSetup.caseStatus.creater_user_name,
        "creater_email": this.constSetup.caseStatus.creater_email,
        "subject": this.constSetup.caseStatus.subject,
        "description": this.constSetup.caseStatus.description,
        "case_category_name": this.constSetup.caseStatus.case_category_name
      }
      this.idValue = this.constSetup.caseStatus.case_status;
    }

    if (this.cookieService.get("user-data")) {
      this.userData = JSON.parse(this.cookieService.get("user-data"));
      this.empId = this.userData.user_id;
    }
    if (this.route.snapshot.params['id']) {
      this.selectedId = this.route.snapshot.params['id'];
    }
    else {
      this.selectedId = null;
    }
     
    this.apiService.getCaseDetails(this.selectedId, response => {
      if (response.status == "OK") {
        if (response.data) {
          this.tableData = response.data;
          this.stoppage=true;
          setTimeout( ()=>{
            this.loaderService.display(false);
          },1000)
         
          if(this.tableData.creater_code!=this.userData.employee_id ){
            this.loaderService.display(false);
            this.routeStatus.navigate(['not-found']);
          }
          this.idValue = this.tableData.case_status;
         
          this.lazyLoadNodata = true;
          this.apiService.getMessage(this.selectedId, response => {
            if (response.status == "OK") {
              let value = moment().tz(this.userData.time_zone).format('Z');
              value = value.replace( ':','');
              this.message = response.data;
              if (this.message) {
                for (var i = 0; i < this.message.length; i++) {
                  let tempName = this.message[i].people_name.split(' ');
                  this.message[i].rmName = [];
                  for (let m = 0; m < tempName.length; m++) {
                    if (tempName[m] != '') {
                      this.message[i].rmName.push(tempName[m]);
                    }
                  }
                  this.message[i].created_on = this.timeZone.getLocalDate(this.message[i].created_on);
                  if (this.message[i].child) {
                    for (var j = 0; j < this.message[i].child.length; j++) {
                      this.message[i].child[j].created_on = this.timeZone.getLocalDate(this.message[i].child[j].created_on);
                      let tempName = this.message[i].child[j].people_name.split(' ');
                      this.message[i].child[j].rmName = [];
                      for (let c = 0; c < tempName.length; c++) {
                        if (tempName[c] != '') {
                          this.message[i].child[j].rmName.push(tempName[c]);
                        }
                      }
                    }
                  }
                }
              }
              this.lazyLoadNodata = false;
            }
            else {
              this.lazyLoadNodata = false;
              this.notifications.alertBoxValue("error", response.message);
            }
          })
        }
      }
      else {
        this.tableData = [];
        this.loaderService.display(false);
      }
    });
    this.getMaxFileSize();
  }

	/*
	* @desc : api service to get  all employee
	* @auth : Ashiq
    */
	getMaxFileSize() {
            var self = this ;
		this.apiService.getMaxFileSize(res => {
			let maxSizeData = res.data.result;
                        self.maxSizeInt = maxSizeData ;
                        let maxSizeInt = (maxSizeData / 1024 / 1024) | 1 ;
                    self.maxSizeString = " of " + parseInt(maxSizeInt.toString() ) + " MB max" ;
		})
	}










   /*
    *  @desc   : method delete from main fileupload 
    *  @author : ashiq
    */
   deleteMainfile(index){
    this.fileSizeArray.splice(index,1);
    this.fileArray.splice(index, 1);
  }


   /*
    *  @desc   : method delete from sub fileupload 
    *  @author : ashiq
    */

  deleteSubfile(index){
    this.fileSizeArray.splice(index,1);
    this.replyFileArray.splice(index, 1);
  }



  individualFileDownload(type,data,index){
    let binary_string: any = window.atob(data.files_data);
    let types;
    if (type == "png" || type == "jpg" || type== "jpeg") {
        types = 'image/png';
      }
      else if (type == "pdf") {
        types = 'application/pdf';
      }
      else {
        types = "application/octet-stream";
      }
   
    let len: any = binary_string.length;
    let bytes: any = new Uint8Array(len);
    for (var k = 0; k < len; k++) {
      bytes[k] = binary_string.charCodeAt(k);
    }
    let file: any = new Blob([bytes.buffer], { type: types });
     FileSaver.saveAs(file, data.file_name);

  }



    /*
  *  @desc   :download attachment form leave list
  *  @author :ashiq
  */
 attachmentDownloadCommon(id, val) {
  this.loaderService.display(true);
  this.apiService.attachemntDownloadCaseDoc(id, val,res => {
    if (res.status != "success") {
      this.loaderService.display(false);
    }
    else {
      let binary_string: any = window.atob(res.data);
      let types;
      types = "application/zip";
      let len: any = binary_string.length;
      let bytes: any = new Uint8Array(len);
      for (var i = 0; i < len; i++) {
        bytes[i] = binary_string.charCodeAt(i);
      }
      let file: any = new Blob([bytes.buffer], { type: types });
        FileSaver.saveAs(file, "document " + this.timeZone.getCurrentDate().toDateString());
      this.loaderService.display(false);
    }
  })
}
  

    /*
    *  @desc   : method deal with download file
    *  @author : dipin
    */
  downloadFile(filedata) {
    let files = filedata;
    for (let i = 0; i < files.length; i++) {

      let types = files[i].file_name.split('.').pop();
      let binary_string: any = window.atob(files[i].file_data.split(',').pop());
      let len: any = binary_string.length;
      let bytes: any = new Uint8Array(len);
      if (types == "png" || types == "jpg" || types == "jpeg") {
        types = 'image/png';
      }
      else if (types == "plain") {
        types = 'text/plain';
      }
      else {
        types = 'application/pdf';
      }
      for (var j = 0; j < len; j++) {
        bytes[i] = binary_string.charCodeAt(i);
      }
      let file: any = new Blob([bytes.buffer], { type: types });
      FileSaver.saveAs(file);
    }
  }

  uploadshow(index){
    this.message[index].show=true;
    this.replyFileArray=[];
    for(let i=0;i< this.message.length;i++){
      if( this.message[i]!=index){
        this.message[i].show=false;
      }
    }
}

    /*
    *  @desc   : method deal with chat reply messages for a case
    *  @author : dipin
    */
  replyMessage(value, i) {
    if (value !== "" && value.trim() !== "") {
      this.lazyLoad = true;
      let temp;
      temp = {
        case_id: this.selectedId,
        created_by: this.empId,
        query: value.trim(),
        query_parent: this.message[i].id,
        image_data: this.replyFileArray
      };
      this.apiService.addMessage(temp, response => {
        if (response.status == "OK") {
          this.replyFileArray = [];
          this.messageValue = '';
          document.getElementById("reply-box").innerHTML = '';
          setTimeout(function () {
            document.getElementById("reply-box").focus();
          });
          // this.message[i].child.push({ people_name: this.message[i].child[j].people_name, people_pic: this.message[i].child[j].people_pic, query: value });
          this.getChatDetails();
        }
        else {
          this.lazyLoad = false;
          this.notifications.alertBoxValue("error", response.message);
        }
      })
    }
  }

    /*
    *  @desc   : change file content
    *  @author : dipin
    */
  changeListener($event,status,index?): void {
    if(status){
      this.readThis($event.target);
    }
    else {
       this.readReplyThis($event.target,index);
    }
  }

     /*
    *  @desc   : method deal with file download
    *  @author : ashiq
    */
   readReplyThis(inputValue: any,index): void {
    var file = inputValue.files;
   
    if (!this.validateFiles(file)) {
        return ;
    }

    for(let i=0;i<file.length;i++){
    if (file != undefined) {
      this.message[index].show=true;
      this.message[index].type = file[i].name.split('.').pop();
      this.message[index].fileName = file[i].name;
      this.message[index].type = this.message[index].type.toLowerCase() ;
                  this.uploadProcess(file[i], this.message[index].type ,"reply" ) ;
    }
    else {
      this.message[index].fileData = undefined;
      this.message[index].fileName = "";
      this.message[index].type     = undefined;
    }
  }
  }

  uploadProcess(file, type, val) {
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      setTimeout(() => {
        if (val == 'reply') {
          this.replyFileArray.push({ "fileName": file.name, "type": type, "file_data": reader.result,"fileSize" : file.size})
        } else {
          this.fileArray.push({ "fileName": file.name, "type": type, "file_data": reader.result,"fileSize" : file.size})
        }
      }, 500)
    };
  }

    validateFiles(files) {
     
        let totalSize = 0 ;
        for (let i = 0; i < files.length; i++) {
          this.fileSizeArray.push(files[i])
        }
        if( typeof files != 'undefined' && files !== null ) {
          
            for (let i = 0; i < this.fileSizeArray.length; i++) {
                if (this.fileSizeArray[i] != undefined) {
                    totalSize += this.fileSizeArray[i].size ;
                    /* if total size is greater than 5MB then identify the position of files */

                    if( totalSize > this.maxSizeInt) {
                       this.indexCounter.push({"index" : i})
                    }
                    let t = this.fileSizeArray[i].name.split('.').pop()
                    t = t.toLowerCase() ;
                    if(t == 'jpg' || t == 'png' || t == 'jpeg' || t == 'pdf'){
                    }
                    else {
                        this.notifications.alertBoxValue("error", "Unsupported file format.");
                        return false ;
                    }
                }
            }
            if ( totalSize > this.maxSizeInt ) {
              this.notifications.alertBoxValue("error", "Maximum allowed file size is " + parseInt((this.maxSizeInt/1024/1024).toString() ) + " MB" );
              /* remove files gerater than 5Mb remove from fileSizeArray*/
              for (let m = 0; m < this.indexCounter.length; m++) {
                this.fileSizeArray.splice(m, 1);
              }
              this.indexCounter = [];
              return false ;
            }
        }
        return true ;
    }
    /*
    *  @desc   : method deal with file download
    *  @author : ashiq
    */
  readThis(inputValue: any): void {
    var file = inputValue.files;
  
    if (!this.validateFiles(file)) {
        return ;
    }

    for (let i = 0; i < file.length; i++) {
      if (file != undefined) {
        this.type = inputValue.files[0].name.split('.').pop();
        this.fileName = file.name;
        this.type = this.type.toLowerCase() ;
        this.uploadProcess(file[i], this.type, "start");
      }
      else {
        this.fileData = undefined;
        this.fileName = "";
      }
    }
  }


   
    /*
    *  @desc   : method to start a new conversation
    *  @author : dipin
    */
  startNewChat(value) {
      
    if(value!=="" && value.trim()!=="" && this.setDisable){
      this.lazyLoad = true;
      let temp = {
        case_id: this.selectedId,
        created_by: this.empId,
        query: value.trim(),
        image_data: (this.fileArray.length>0) ? this.fileArray : []
      };
  
      this.setDisable=false;
      this.apiService.addMessage(temp, response => {
       
          setTimeout(() => {
            this.setDisable=true;
          },1000)
        if (response.status == "OK") {
          this.fileArray=[];
          this.getChatDetails();
          this.textValue = '';
          document.getElementById("chat-box").innerHTML = '';
          setTimeout(function() {
           document.getElementById("chat-box").focus();
          });
          this.fileData = undefined;
        }
        else {
          this.lazyLoad = false;
          this.notifications.alertBoxValue("error", response.message);
        }
      })
    }

  }

    /*
    *  @desc   : method deal with display chat information
    *  @author : dipin
    */
  getChatDetails() {
    this.lazyLoad = true;
    this.apiService.getMessage(this.selectedId, response => {
      if (response.status == "OK") {
        let value = moment().tz(this.userData.time_zone).format('Z');
        value = value.replace( ':','');
        this.message = response.data;
        if (this.message) {
          for (var i = 0; i < this.message.length; i++) {
            let tempName = this.message[i].people_name.split(' ');
            this.message[i].rmName = [];
            for (let m = 0; m < tempName.length; m++) {
              if (tempName[m] != '') {
                this.message[i].rmName.push(tempName[m]);
              }
            }
            this.message[i].created_on = this.timeZone.getLocalDate(this.message[i].created_on);
            if (this.message[i].child) {
              for (var j = 0; j < this.message[i].child.length; j++) {
                this.message[i].child[j].created_on = this.timeZone.getLocalDate(this.message[i].child[j].created_on);
                let tempName = this.message[i].child[j].people_name.split(' ');
                this.message[i].child[j].rmName = [];
                for (let c = 0; c < tempName.length; c++) {
                  if (tempName[c] != '') {
                    this.message[i].child[j].rmName.push(tempName[c]);
                  }
                }
              }
            }
          }
        }
        this.lazyLoad = false;
      }
      else {
        this.lazyLoad = false;
        this.notifications.alertBoxValue("error", response.message);
      }
    })
  }

    /*
    *  @desc   : method deal with change status of the case
    *  @author : dipin
    */
  changeStatus(value) {
     this.confirmBox = true;
     this.newvalue=value;

  }

  statusConfirm(event){
     if (event == true) {
        this.idValue=this.newvalue;
          this.loaderService.display(true);
          this.apiService.changeCase(this.idValue, this.selectedId, response => {
            if (response.status == "OK") {
                this.notifications.alertBoxValue("success", response.message);
                this.loaderService.display(false);
            }
            else {
                this.loaderService.display(false);
                this.notifications.alertBoxValue("error", response.message);
              }
      })
    }
}

  /*
    *  @desc   : method deal with conversion of date format
    *  @author : dipin
    */
  formatDate(inputDate) {
    var date = this.timeZone.toLocal(inputDate);
    if (!isNaN(date.getTime())) {
      if ((Number(date.getMonth()) + 1) < 10) {
        if (Number(date.getDate() < 10)) {
          return "0" + date.getDate() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
        }
        else {
          return date.getDate() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
        }
      }
      else {
        if (Number(date.getDate() < 10)) {
          return date.getDate() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
        }
        else {
          return date.getDate() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
        }
      }
    }
  }

  setFocusChat(){
     setTimeout(function(){
       document.getElementById('chat-box').focus();
         });
  }

  back(){
   
    this.routeStatus.navigate(['modules/case/my-request'],{queryParamsHandling:'preserve'} )
    
    }
   
   



  getClassByValue(index) {
        switch (index % 10) {
            case 0: return "default-avatar islamic-green";
            case 1: return "default-avatar limerick";
            case 2: return "default-avatar chilean-fire";
            case 3: return "default-avatar persian-pink";
            case 4: return "default-avatar deep-magenta";
            case 5: return "default-avatar gigas";
            case 6: return "default-avatar endeavour";
            case 7: return "default-avatar dodger-blue";
            case 8: return "default-avatar jordy-blue";
            case 9: return "default-avatar Light-sea-green";
            case 10: return "emp-profileimage";
        }
    }

    hideMessage(status,index?){
      if(status){
        for(let i = 0; i < this.message.length;i++){
          this.message[i].displayChat = false;
          this.message[i].fileData = undefined;
          this.message[i].fileName = "";
          this.message[i].type     = undefined;
        }
        this.messageValue = '';
      }
      else{
         document.getElementById("chat-box").innerHTML = '';
         this.textValue = '';
         this.fileData = undefined;
         this.fileName = "";
         this.type     = undefined;
        for(let i = 0; i < this.message.length;i++){
          if(i != index){
            this.message[i].displayChat = false;
            this.message[i].fileData = undefined;
            this.message[i].fileName = "";
            this.message[i].type     = undefined;
          }
        }
        setTimeout(function(){
          document.getElementById('reply-box').focus();
        });
      }
    }
}
