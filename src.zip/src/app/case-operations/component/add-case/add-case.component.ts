/*
* @desc : component for adding case by user
* @auth : dipin
 */
import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl, Validators,FormBuilder } from '@angular/forms';
import { AddCaseService } from '../../services/add-case/add-case.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';
import { CaseOperationsService } from '../../services/case-service/case-operations.service';

@Component({
  selector: 'app-add-case',
  templateUrl: './add-case.component.html',
  styleUrls: ['./add-case.component.css']
})
export class AddCaseComponent implements OnInit {
	addForm     		: FormGroup;
	subField    		: FormControl;
	descField   		: FormControl;
	attachField 		: FormControl;
	fileName    		: any;
	userData    		: any;
	fileData    		: any;
	type        		: any;
	empId           	: any;
    selectedId  		: any;
    EmployeeList 		: any;
    employee_id     	: any;
    selectEmployee 		: any;
    createObj        	: any;
	managerId		 	: any;
	createdBy           : any;
	caseObj             : any;
	adminCase           : boolean = false;
	selectedItems       : any=[];
	tempEmployeeList    : any=[];
	categoryManagerId   : any=[];
	fileArray           : any=[];
    colChange       	: boolean = false;
	aclPermission       : boolean = false;
	adminPrivilege     : boolean = false;
    submitted  	    	: boolean = false;
	assignable      	: boolean = false ;
	managerActive       : boolean = false ;
	noEmployee			: boolean = false ;
        maxSizeString : string = '' ;
        maxSizeInt : number = 5242880 ; //5 MB

	constructor(private apiService     : AddCaseService,
		        private route          : Router,
                private notifications  : NotificationService,
                private loaderService  : LoaderActionsService,
                private cookieService  : CookieService,
				private router         : ActivatedRoute,
				private aclVerif       : AclVerificationService,
                private aclCheck       : AclVerificationService,
                private caseOperationService        : CaseOperationsService
                ) { }

	ngOnInit() {
		this.aclPermission = this.aclCheck.checkAcl('/modules/case/case-list');
		this.adminPrivilege = this.aclVerif.checkAclDummy('allemployee-list');
		if (this.cookieService.get("user-data")) {
			this.userData = JSON.parse(this.cookieService.get("user-data"));
           this.createdBy=this.userData.user_id;
		if (this.userData.role_id == 1 || this.userData.role_id == 3) {
				this.empId = this.userData.user_id;
			}
			else if (this.userData.role_id == 4 || this.userData.role_id == 2) {
				this.empId = this.userData.user_id;
			}
		}
		if (this.router.snapshot.params['id2']) {
			this.managerId = this.router.snapshot.params['id2'];
		}

		if (this.router.snapshot.params['id']) {
			this.selectedId = this.router.snapshot.params['id'];
		}
		else {
			this.selectedId = null;
		}
            
		this.router.queryParams.subscribe(params => {
			this.categoryManagerId=params.prop;
		 })
		 if(this.categoryManagerId)
	   for(let i=0; i<this.categoryManagerId.length; i++){
		   if(this.createdBy==this.categoryManagerId[i]){
			 this.managerActive=true;
		   }
		}
		if(!this.aclPermission){
			this.colChange = true;
		}else{
			this.colChange = false;
		}
		if( ! this.assignable ) {
			this.colChange = true ;
		}
		this.getAllEmployee();
		this.createFormControls();
		this.createForm();
		this.getMaxFileSize();
		this.loaderService.display(false);
	}

	/*
    *  @desc   :Create and define form controls of createNew form
    *  @author :dipin
    */
	createFormControls() {
		this.subField     = new FormControl('', [Validators.required, this.noWhitespaceValidator]);
		this.descField    = new FormControl('', [Validators.required, this.noWhitespaceValidator]);
		this.attachField  = new FormControl('');
	}

	/*
    *  @desc   :create form itemForm and addForm
    *  @author :ashiq
    */
	createForm() {
		this.addForm = new FormGroup({
			subField    : this.subField,
			descField   : this.descField,
			attachField : this.attachField,
		});
	}

	/* @desc :method for matching index of two values
	 * @auth : Ashiq
	*/
	matchingIndex(srcArray, compareValue, key) {
		for (var x in srcArray) {
			if (srcArray[x][key] == compareValue) {
				return x;
			}
		}
		return null;
	}
	/*
	* @desc : method for back to category-list
	* @auth : dipin
    */
	back() {
		this.route.navigateByUrl("/modules/case/category-list");
	}
	/*
	* @desc : component for validate space
	* @auth : dipin
    */
	noWhitespaceValidator(control: FormControl) {
		let isWhitespace = (control.value || '').trim().length === 0;
		let isValid = !isWhitespace;
		return isValid ? null : { 'whitespace': true }
	}
	/*
	* @desc : api service to get  all employee
	* @auth : Ashiq
    */
	getAllEmployee() {
		this.loaderService.display(true);
		this.apiService.getEmployeeApi(res => {
			this.EmployeeList = res.data;
			for (let i = 0; i < this.EmployeeList.length; i++) {
				if (this.EmployeeList[i].first_name) {
					this.EmployeeList[i].first_name = this.EmployeeList[i].first_name + " " + this.EmployeeList[i].last_name + " " + "(" + this.EmployeeList[i].code + ")";
				}
			}
			this.selectedItems = [];
			this.loaderService.display(false);
		})
	}
	/*
	* @desc : api service to get  all employee
	* @auth : Ashiq
    */
	getMaxFileSize() {
            var self = this ;
		this.caseOperationService.getMaxFileSize(res => {
			let maxSizeData = res.data.result;
                        self.maxSizeInt = maxSizeData ;
                        let maxSizeInt = (maxSizeData / 1024 / 1024) | 1 ;
                    self.maxSizeString = " of " + parseInt(maxSizeInt.toString() ) + " MB max" ;
		})
	}
    /*
	* @desc : component for validate space
	* @auth : ashiq
    */
	addCase() {
            this.tempEmployeeList = [] ;
		if (this.selectEmployee !== undefined) {
			for (let i = 0; i < this.selectEmployee.length; i++) {
				this.tempEmployeeList.push({ "user_id": this.selectEmployee[i].originalData.user_id ? this.selectEmployee[i].originalData.user_id : '' });
			}
		}  
		for(let j=0;j<this.tempEmployeeList.length;j++){
			if(this.userData.user_id==this.tempEmployeeList[j].user_id){
				this.adminCase=true;
			}
		}
		if ( this.adminPrivilege || this.managerActive) {
			this.caseObj = {
				case_category_id: this.selectedId,
				description: this.descField.value,
				subject: this.subField.value,
				created_by: this.createdBy,
				users: this.tempEmployeeList,
				image_data: (this.fileArray.length>0) ? this.fileArray : []
			}
		} else {
			this.caseObj = {
				case_category_id: this.selectedId,
				description: this.descField.value,
				subject: this.subField.value,
				created_by: this.createdBy,
				image_data: (this.fileArray.length>0) ? this.fileArray : []
			}
		}
		this.createObj = this.caseObj;
		if ( this.adminPrivilege || this.managerActive) {
			if (this.addForm.valid && this.selectEmployee.length > 0) {
				this.submitted = false;
				this.loaderService.display(true);
				this.addcasApi();
			} else {
				this.submitted = true;
			}
		} else {
			if (this.addForm.valid) {
				this.submitted = false;
				this.loaderService.display(true);
				this.addcasApi();
			} else {
				this.submitted = true;
			}
		}
	}

    /*
	* @desc : method for navigate
	* @auth : ashiq
    */
	addcasApi() {
		this.apiService.addDetails(this.caseObj, response => {
			if (response.status == "OK") {
				this.selectedItems = [];
				this.addForm.reset();
				this.submitted = false;
				if (!this.adminPrivilege || !this.managerActive) {
					this.route.navigate(['/modules/case/my-request']);
				}
				if (this.adminPrivilege || this.managerActive) {
					if (this.adminCase) {
						this.route.navigate(['/modules/case/my-request']);
					} else {
						this.route.navigate(['/modules/case/category-list']);
					}
				}
				setTimeout(() => {
					this.loaderService.display(false);
					this.notifications.alertBoxValue("success", response.message);
				}, 800);
			}
			else {
				this.loaderService.display(false);
				this.notifications.alertBoxValue("error", response.message);
			}
		})
	}

	
	/*
	* @desc : component for validate space
	* @auth : dipin
    */
	deleteFile(i){
	 this.fileArray.splice(i, 1);
	}

    /*
	* @desc : component for validate space
	* @auth : dipin
    */
	changeListener($event): void {
		this.readThis($event.target);
	}
        
    validateFiles(files) {
        let totalSize = 0 ;
        if( typeof files != 'undefined' && files !== null ) {
            for (let i = 0; i < files.length; i++) {
                if (files[i] != undefined) {
                    totalSize += files[i].size;

                    let t = files[i].name.split('.').pop()
                    t = t.toLowerCase() ;
                    if(t == 'jpg' || t == 'png' || t == 'jpeg' || t == 'pdf'){
                    }
                    else {
                        this.notifications.alertBoxValue("error", "Unsupported file format.");
                        return false ;
                    }
                }
            }
            if ( totalSize > this.maxSizeInt ) {
                this.notifications.alertBoxValue("error", "Maximum allowed file size is " + parseInt((this.maxSizeInt/1024/1024).toString() ) + " MB" );
                return false ;
            }
        }
        return true ;
    }

    /*
	* @desc : component for validate space
	* @auth : dipin
    */
	readThis(inputValue: any): void {
		var file = inputValue.files;
            if (!this.validateFiles(file)) {
                return ;
            }
		for(let i=0;i<file.length;i++){

			if (file[i] != undefined) {
				this.type = file[i].name.split('.').pop();
                                this.type = this.type.toLowerCase() ;
				// var myReader: FileReader = new FileReader();
				this.fileName = file[i].name;
                                this.uploadProcess(file[i], i ,this.type )
			}
			else {
				this.fileData = undefined;
				this.fileName = "";
			}

		}
	
	}

	uploadProcess(file, i, type) {
		let reader = new FileReader();
		reader.readAsDataURL(file);
		reader.onload = () => {
			setTimeout(() => {
				this.fileArray.push({ "fileName": file.name, "type": type, "file_data": reader.result })
			}, 500)
		};
	}




}
