/*
* @desc : component for  category list
* @auth : Ashiq
*/

import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { CategorylistService } from '../../services/category-list/categorylist.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';

@Component({
	selector: 'app-category-list',
	templateUrl: './category-list.component.html',
	styleUrls: ['./category-list.component.css']
})

export class CategoryListComponent implements OnInit {

	categoryList : Array<object> = [] ;
    confirmBox   : boolean = false;
    config       : any = "Are You Sure You Want To Delete?";
    selectedId   : any;
    userData     : any;

 	constructor(	
 		private categorylistService		: CategorylistService,
		private loaderActionsService	: LoaderActionsService,
		private router					: Router,
		private route					: ActivatedRoute,
		private notificationService  	: NotificationService,
		private cookieService           : CookieService ) { }

	ngOnInit() {
		if (this.cookieService.get("user-data")) {
          this.userData = JSON.parse(this.cookieService.get("user-data"));
        }
        this.categoryListdata();
	}

    /*
	* @desc : calling api for getting category list for admin
	* @auth : Ashiq
    */
	categoryListdata() {
		this.loaderActionsService.display(true);
		this.categorylistService.getCategoryList(response => {
			if (response.data && response.data.length > 0) {
				this.categoryList = response.data;
				this.loaderActionsService.display(false);
			}
			else {
				this.categoryList = [];
				this.loaderActionsService.display(false);
			}
		})
	}

	/*
	* @desc : calling api for delete a  category from  list
	* @auth : Ashiq
    */
	deleteCategory(id){
		this.confirmBox = true;
		this.selectedId = id;
  	}

  	 /*
	*  @desc   :method to handle popup confirmation
  	*  @author :ashiq
	*/
	getPopupConfirm(event) {
		this.loaderActionsService.display(true);
		this.confirmBox = false;
		if (event == true) {
			this.categorylistService.deleteCategory(this.selectedId, (response) => {
				if (response.status == 'OK') {
                    this.notificationService.alertBoxValue("success", response.message);
                    this.categoryListdata();
					this.loaderActionsService.display(false);
				}
				else {
					this.notificationService.alertBoxValue("error", response.message);
					this.loaderActionsService.display(false);
				}
			})
		}
	}

  	/*
    * @desc : navigate  to category details page
    * @auth : Ashiq
    */
	gotoDetails(id) {
	 if(this.userData.role_id == 2)
		this.router.navigateByUrl('/modules/case/admin-categorydetail?id=' + id);
     else
		this.router.navigateByUrl('/modules/case/category-details?id=' + id);
	}
}