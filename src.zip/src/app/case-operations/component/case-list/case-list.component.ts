 /*
  * @desc : component for listing case
  * @auth : dipin
  */
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CaseOperationsService } from '../../services/case-service/case-operations.service';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';
import { ConstantServicesService } from '../../../shared/services/constant/constant-services.service';
import 'rxjs/add/operator/filter';
import { ApprovalsService } from '../../../onduty/services/onduty-approvals/approvals.service';

@Component({
  selector: 'app-case-list',
  templateUrl: './case-list.component.html',
  styleUrls: ['./case-list.component.css']
})
export class CaseListComponent implements OnInit {
  searchValue       : string ;
  searchTextBox     : boolean = false;
  filterStatus      : boolean = false;
  displayTab        : boolean = false;
  order             : boolean;
  currentPage       : any = 1;
  tableData         : any = [];
  editConfig        : any;
  advanceFilterData : any;
  selectValue       : any = 0;
  sort              : any;
  userData          : any;
  assignedList      : any = [];
  allList           : any = [];
  requestedList     : any = [];
  selectedId        : any;
  addStatus         : boolean = false;
  aclPermission     : boolean = false;
  forTitle          : boolean = false;
  forStatus         : boolean = false;
  editStatus        : boolean = false;
  checkAll          : boolean = false;
  multiDelete       : boolean = false;
  forWeek           : boolean = false;
  fixroute          : boolean = false;
  caseReqTab        : boolean = false;
  confirmBox        : boolean;
  recordsPerPage    : number  = 10;
  totalRecords      : number;
  totalSelected     : any = 0;
  setIndex          : any;
  empId             : any;
  setStack          : any;
  searchVal         : any;
  searchD           : any;

  constructor(  private apiService  : CaseOperationsService,
              private router        : Router,
              private notifications : NotificationService,
              private loaderService : LoaderActionsService,
              private cookieService : CookieService,
              private route         : ActivatedRoute,
              private constSetup    : ConstantServicesService,
              private aclCheck      : AclVerificationService,
              private ApprovalsService: ApprovalsService) { }

  ngOnInit() {
    this.confirmBox = false;
    this.aclPermission = this.aclCheck.checkAcl('/modules/case/case-list');
    let temp;
    if (this.cookieService.get("user-data")) {
      this.userData = JSON.parse(this.cookieService.get("user-data"));
      if (localStorage.getItem("itemsperpage")) {
        this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
      }
      else {
        this.recordsPerPage = 10;
      }
      if (!this.aclPermission && this.userData.role_id != 2) {
        this.empId = this.userData.user_id;
        this.getMyCategory();
      }
      else if (this.userData.role_id == 2 || this.aclPermission) {
        this.loaderService.display(true);
        this.empId = this.userData.user_id;
        this.apiService.getDetails(this.empId, response => {
       
          if (response.status == "OK") {
            this.allList = response['all-category'];
            this.assignedList = response['assigned-category'];
            this.requestedList = response['requested-category'];
            let stat = 0;
        
            if (this.route.snapshot.params['id']) {
              temp = this.route.snapshot.params['id'].split(",");
              stat = temp[1];
              if (temp)
                if (temp[2] == 0) {
                  this.displayTab = false;
                  this.caseReqTab = false;
                }
                if(temp[2] == 1){
                  this.displayTab = true;
                  this.caseReqTab=false;
                }
                if(temp[2] == 2) {
                  this.displayTab = false;
                  this.caseReqTab=true;
                }
            }


            if (this.requestedList){
               if ( this.requestedList.length){
                 for (var i = 0; i <  this.requestedList.length; i++) {
                  this.requestedList[i].status = false;
                 }
                 if(temp)
                 if(temp[2] == 2){
                    this.selectValue = stat;
                    this.requestedList[stat].status = true;
                    this.selectedId = this.requestedList[stat].id;
                    this.changeData(this.requestedList[stat].id, 1 );
                }
               }
            }

            if (this.allList){
              if (this.allList.length){
                for (var i = 0; i < this.allList.length; i++) {
                 this.allList[i].status = false;
                }
                if(temp)
                if(temp[2] == 1){
                   this.selectValue = stat;
                   this.allList[stat].status = true;
                   this.selectedId = this.allList[stat].id;
                   this.changeData(this.allList[stat].id, false);
               }
              }
           }



            if (this.assignedList) {
              if (this.assignedList.length) {
                for (var i = 0; i < this.assignedList.length; i++) {
                  this.assignedList[i].status = false;
                }
                if(!temp){
                    this.assignedList[0].status = true;
                    this.selectedId = this.assignedList[0].id;
                    this.changeData(this.assignedList[0].id, true);
                }
                else if(temp[2] == 0){
                  this.selectValue = stat;
                   this.assignedList[stat].status = true;
                    this.selectedId = this.assignedList[stat].id;
                    this.changeData(this.assignedList[stat].id, true);
                }
              }
              this.loaderService.display(false);
            } 
            
            
              //   if(temp)
              //   if(temp[2] == 1){
              //      this.selectValue = stat;
              //      this.allList[stat].status = true;
              //      this.selectedId = this.allList[stat].id;
              //      this.changeData(this.allList[stat].id, false);
              //  }
              //   this.loaderService.display(false);
          }
          else
            this.loaderService.display(false);
        })
      }
    }
  }
   /*
  author : Nilena Alexander
  desc   : add class based on index
 */
// getClassByValue(index) {
//   return this.ApprovalsService.getClassByValue(index);

// }




getClassByValue(index) {
  switch (index % 10) {
      case 0: return "default-avatar islamic-green";
      case 1: return "default-avatar limerick";
      case 2: return "default-avatar chilean-fire";
      case 3: return "default-avatar persian-pink";
      case 4: return "default-avatar deep-magenta";
      case 5: return "default-avatar gigas";
      case 6: return "default-avatar endeavour";
      case 7: return "default-avatar dodger-blue";
      case 8: return "default-avatar jordy-blue";
      case 9: return "default-avatar Light-sea-green";
      case 10: return "emp-profileimage";
  }
}





  /*
  * @desc : method for listing my case
  * @auth : dipin
  */
  // getMyCaseList() {
  //   this.loaderService.display(true);
  //   this.apiService.getMycases(this.empId, this.currentPage, this.advanceFilterData, this.searchValue, this.sort, response => {
  //     if (response.status == "OK") {
  //       if (response.data) {
  //         // let tableData=[];
  //         // tableData = response.data;
  //         // for(let i = 0;i<tableData.length;i++){
  //         //   let name = tableData[i].creater_user_name.split(" ");
  //         //   tableData[i].creater_first_name = name[0];
  //         //   tableData[i].creater_last_name = name[name.length];

  //         //   let assigneeName =  tableData[i].assigned_name.split(" ");
  //         //   tableData[i].assignee_first_name = assigneeName[0];
  //         //   tableData[i].assignee_last_name = assigneeName[assigneeName.length-1];

  //         // }
  //         this.tableData = response.data;
  //         if (response.count) {
  //           this.totalRecords = response.count;
  //         }
  //       }
  //       else
  //         this.tableData = [];
  //       this.loaderService.display(false);
  //     }
  //     else {
  //       this.loaderService.display(false);
  //     }
  //   })
  // }

  /*
  * @desc : method for listing details of selected case
  * @auth : dipin
  */
  viewDetails(i,value){
    if(!this.displayTab && !this.caseReqTab){
      this.constSetup.caseStatus = this.tableData[i];
      this.router.navigate(['/modules/case/my-case-details/'+this.tableData[i].id+"-"+this.selectValue+"-"+0]);
    }
    else if(this.displayTab && !this.caseReqTab){
      this.constSetup.caseStatus = this.tableData[i];
      this.router.navigate(['/modules/case/case-details/'+this.tableData[i].id+"-"+this.selectValue+"-"+1]);
   }
   else if(!this.displayTab && this.caseReqTab){
    this.router.navigate(['/modules/case/case-details/'+this.tableData[i].id+"-"+this.selectValue+"-"+2]);
   }
  }

  /*
  * @desc : method for my category listing
  * @auth : dipin
  */
  getMyCategory(){
    this.currentPage   = 1;
    this.searchTextBox = false;
    this.filterStatus = false;
    this.advanceFilterData = undefined;
    this.tableData = [];
    this.searchValue = "";
    if(this.assignedList){
      if(this.assignedList.length){
         this.assignedList[0].status = true;
         this.selectValue=0;
         this.changeData(this.assignedList[0].id,true);
      }
    }
    else {
      this.tableData  = [];
      this.selectedId = undefined;
    }

    if(this.assignedList)
    for(var i = 1; i < this.assignedList.length; i++){
      this.assignedList[i].status = false;
    }
  }

  /*
  * @desc : method for listing all the categories
  * @auth : dipin
  */
 getAllCategory(){
  this.tableData = [];
  this.currentPage   = 1;
  this.searchTextBox = false;
  this.advanceFilterData = undefined;
  this.filterStatus = false;
  this.searchValue = "";
  if(this.allList){
    if(this.allList.length){
      this.allList[0].status = true;
      this.changeData(this.allList[0].id,false);
    }
  }
  else {
    this.tableData = [];
    this.selectedId = undefined;
  }

  if(this.allList)
  for(var i = 1; i < this.allList.length; i++){
    this.allList[i].status = false;
  }
}

  /*
  author : dipin
  desc   : Search  when enter key is pressed
  */
  search(value) {
  if ( this.searchValue ||this.searchD.trim() != ''){
     this.searchValue = value;
     this.currentPage = 1;
    //  if(this.userData.role_id == 1 || this.userData.role_id == 3 || this.userData.role_id == 4)
    //    this.getMyCategory();
    //    else{
        if(!this.displayTab  && !this.caseReqTab)
        this.changeData(this.selectedId, true);
        else if(this.displayTab  && !this.caseReqTab)
        this.changeData(this.selectedId, false)
        else if(!this.displayTab  && this.caseReqTab)
        this.changeData(this.selectedId, 1)
        //  (this.displayTab)?this.changeData(this.selectedId,false):this.changeData(this.selectedId,true);
      //  }
  }
}

getCaseRequested(index){
  for (var i = 0; i < this.requestedList.length; i++) {
    if (index != i) {
      this.requestedList[i].status = false;
    }
    else {
      this.requestedList[i].status = true;
      this.changeData(this.requestedList[i].id,1);
    }
  }
}

   /*
  * @desc : method for handling selected category
  * @auth : dipin
  */
  setTrue(index,value:any) {
    this.selectValue = index;
    this.filterStatus = false;
    this.currentPage  = 1;
    if (value=="false")
    for (var i = 0; i < this.assignedList.length; i++) {
      if (index != i) {
        this.assignedList[i].status = false;
      }
      else {
        this.assignedList[i].status = true;
        this.changeData(this.assignedList[i].id,true);
      }
    }
  
    if (value=="true")
    for (var i = 0; i < this.allList.length; i++) {
      if (index != i) {
        this.allList[i].status = false;
      }
      else {
        this.allList[i].status = true;
        this.changeData(this.allList[i].id,false);
      }
    }
   
      if (value==1){
        for (var i = 0; i < this.requestedList.length; i++) {
          if (index != i) {
            this.requestedList[i].status = false;
          }
          else {
            this.requestedList[i].status = true;
            this.changeData(this.requestedList[i].id,1);
          }
        }
      }

  }

  /*
  * @desc   :toogle display of popup based on the add button click
  * @author :dipin
  */
  setAdd(value) {
    this.addStatus  = !this.addStatus;
    this.editStatus = false;
  }

   /*
  * @desc : method for listing filterdata
  * @auth : dipin
  */
  filterData(event) {
    if (event || this.advanceFilterData) {
      this.advanceFilterData = event;
      this.currentPage = 1;
      // if (this.userData.role_id == 1 || this.userData.role_id == 3 || this.userData.role_id == 4)
      //   this.getMyCategory();
      // else {
        if(!this.displayTab  && !this.caseReqTab)
        this.changeData(this.selectedId, true);
        else if(this.displayTab  && !this.caseReqTab)
        this.changeData(this.selectedId, false)
        else if(!this.displayTab  && this.caseReqTab)
        this.changeData(this.selectedId, 1)



        // (this.displayTab) ? this.changeData(this.selectedId, false) : this.changeData(this.selectedId, true);
      // }
    }
    else {
      this.advanceFilterData = undefined;
    }
  }



  // applyCaseRequestSort(value){
  //   let type = 0;
  //   if (value == 'cas_due')
  //     if (this.forTitle == true) {
  //       type = 1;
  //       this.forTitle = false;
  //     }
  //     else {
  //       type = 0;
  //       this.forTitle = true;
  //     }

  //   if (value == 'cas_st')
  //     if (this.forStatus == true) {
  //       type = 1;
  //       this.forStatus = false;
  //     }
  //     else {
  //       type = 0;
  //       this.forStatus = true;
  //     }
  //   this.sort = { department: value, type: type };
  //   this.loaderService.display(true);
  //   let status;
  //   status = 1;
  //   this.apiService.sortDetails({ department: value, type: type }, this.currentPage, this.selectedId,this.advanceFilterData,this.searchValue,status,response => {
  //     if (response.status == "OK") {
  //       this.tableData = response.data;
  //       this.loaderService.display(false);
  //     }
  //     else {
  //       this.tableData = [];
  //       this.loaderService.display(false);
  //     }
  //   })
  // }

  /*
  *  @desc   :method for apply sorting using api and update the table list
  *  @author :dipin
  */
  applySort(value,tab:any) {
  
    let type = 0;
    if (value == 'cas_due')
      if (this.forTitle == true) {
        type = 1;
        this.forTitle = false;
      }
      else {
        type = 0;
        this.forTitle = true;
      }

    if (value == 'cas_st')
      if (this.forStatus == true) {
        type = 1;
        this.forStatus = false;
      }
      else {
        type = 0;
        this.forStatus = true;
      }
    this.sort = { department: value, type: type };
    this.loaderService.display(true);
    let status;
    if(tab=="myCase"){
     status="false";
    }
    if(tab=="allCase"){
      status="true";
    }
    if(tab=="caseRequested"){
      status=1;
    }
   
    this.apiService.sortDetails({ department: value, type: type }, this.currentPage, this.selectedId,this.advanceFilterData,this.searchValue,status,response => {
      if (response.status == "OK") {
        this.tableData = response.data;
        let tableData=[];
         tableData= response.data;
         for(let i = 0;i<tableData.length;i++){
          if(tableData[i].request_name){
            let name = tableData[i].request_name.split(" ");
            tableData[i].request_first_name = name[0];
             tableData[i].request_last_name = name[name.length-1];
             
          }
         if(tableData[i].assigned_name){
          let assigneeName =  tableData[i].assigned_name.split(" ");
          tableData[i].assignee_first_name = assigneeName[0];
          tableData[i].assignee_last_name = assigneeName[assigneeName.length-1];

         }
         if(tableData[i].requested_name){
          let requested_name =  tableData[i].requested_name.split(" ");
          tableData[i].requested_first_name = requested_name[0];
          tableData[i].requested_last_name = requested_name[requested_name.length-1];
         }
         if(tableData[i].requested_to_name){
          let requested_name =  tableData[i].requested_to_name.split(" ");
          tableData[i].requested_to_name_first_name = requested_name[0];
          tableData[i].requested_to_name_last_name = requested_name[requested_name.length-1];
         }
         if(tableData[i]. assigned_to_user_name){
          let requested_name =  tableData[i]. assigned_to_user_name.split(" ");
          tableData[i].assignee_first_name = requested_name[0];
          tableData[i].assignee_last_name = requested_name[requested_name.length-1];
         }
        
        }
        this.tableData = tableData;
        this.loaderService.display(false);
      }
      else {
        this.tableData = [];
        this.loaderService.display(false);
      }
    })
  }

  /*
  * @desc : method for set focus for search field
  * @auth : dipin
  */
  setFocus() {
    window.setTimeout(function() {
      if(document.getElementById('searchField'))
       document.getElementById('searchField').focus();
    }, 1);
  }

  /*
  * @desc : method for change data based on category
  * @auth : dipin
  */
  changeData(id,value:any) {
    if (id) {
      this.loaderService.display(true);
      this.selectedId = id;
      this.apiService.takeCases(id, this.currentPage, this.advanceFilterData, this.searchValue, this.sort,value,this.empId,response => {
        if (response.status == "OK") {
          if (response.data) {
            let tableData = [];
            tableData = response.data;
            for(let i = 0;i<tableData.length;i++){
              if(tableData[i].request_name){
                let name = tableData[i].request_name.split(" ");
                tableData[i].request_first_name = name[0];
                 tableData[i].request_last_name = name[name.length-1];
                 
              }
             if(tableData[i].assigned_name){
              let assigneeName =  tableData[i].assigned_name.split(" ");
              tableData[i].assignee_first_name = assigneeName[0];
              tableData[i].assignee_last_name = assigneeName[assigneeName.length-1];
  
             }
             if(tableData[i].requested_name){
              let requested_name =  tableData[i].requested_name.split(" ");
              tableData[i].requested_first_name = requested_name[0];
              tableData[i].requested_last_name = requested_name[requested_name.length-1];
             }
             if(tableData[i].requested_to_name){
              let requested_name =  tableData[i].requested_to_name.split(" ");
              tableData[i].requested_to_name_first_name = requested_name[0];
              tableData[i].requested_to_name_last_name = requested_name[requested_name.length-1];
             }
             if(tableData[i]. assigned_to_user_name){
              let requested_name =  tableData[i]. assigned_to_user_name.split(" ");
              tableData[i].assignee_first_name = requested_name[0];
              tableData[i].assignee_last_name = requested_name[requested_name.length-1];
             }
            
            }
            this.tableData = tableData;
            if (response.count) {
              this.totalRecords = response.count;
            }
          }
          else
            this.tableData = [];
          this.loaderService.display(false);
        }
        else {
          this.loaderService.display(false);
        }
      })
    }
  }

  getpage(event) {
    if (event > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      if(!this.displayTab  && !this.caseReqTab)
      this.changeData(this.selectedId, true);
      else if(this.displayTab  && !this.caseReqTab)
      this.changeData(this.selectedId, false)
      else if(!this.displayTab  && this.caseReqTab)
      this.changeData(this.selectedId, 1)
    }
  }

  getAllCase(){
    this.tableData = [];
    this.currentPage   = 1;
    this.searchTextBox = false;
    this.advanceFilterData = undefined;
    this.filterStatus = false;
    this.searchValue = "";
    for(let i =0;i<this.requestedList.length;i++){
      if(this.requestedList[i].status===true){
        this.requestedList[i].status = false;
      }
      if(this.requestedList[i].status==1){
        this.requestedList[i].status = false;
      }
    }
    if(this.requestedList){
      if(this.requestedList.length){
        this.requestedList[0].status = true;
        this.changeData(this.requestedList[0].id,1);
      }
    }
    else {
      this.tableData = [];
      this.selectedId = undefined;
    }


    // if(this.allCaseList)
    // for(var i = 1; i < this.allCaseList.length; i++){
    //   this.allCaseList[i].status = false;
    // }
  }
  pageChangeEvent(event){
    this.currentPage = event;
    if(!this.displayTab  && !this.caseReqTab)
    this.changeData(this.selectedId, true);
    else if(this.displayTab  && !this.caseReqTab)
    this.changeData(this.selectedId, false)
    else if(!this.displayTab  && this.caseReqTab)
    this.changeData(this.selectedId, 1)
  }
}
