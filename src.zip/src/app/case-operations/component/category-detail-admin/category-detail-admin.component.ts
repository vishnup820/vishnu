/*
	* @desc : component for category details for admin
	* @auth : Ashiq
  */
 import { Component, OnInit } from '@angular/core';
 import { Router, ActivatedRoute, ParamMap } from '@angular/router';
 import { NotificationService } from '../../../shared/services/notifications/notification.service';
 
 import { CategorydetailService }  from '../../services/category-details/categorydetail.service';
 import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
 
 @Component({
	 selector: 'app-category-detail-admin',
	 templateUrl: './category-detail-admin.component.html',
	 styleUrls: ['./category-detail-admin.component.css']
 })
 
 export class CategoryDetailAdminComponent implements OnInit {
 
	 categoryDetailArray	: 	any =[];
	 mangerId     			: 	any =[];
	 id    					:	any;
	 userData               :   any;
	 popUpOpen				:   boolean=false;
 
	 constructor(	
			 private categorydetailService	: CategorydetailService,
			 private loaderActionsService	: LoaderActionsService,
			 private router					: Router,
			 private route					: ActivatedRoute,
			 private notificationService  	: NotificationService) { }
 
	 ngOnInit() {
			 this.loaderActionsService.display(true);
			 this.id = this.route.snapshot.queryParams['id'];
			 this.getCategoryDetailAdmin();
		 } 
	 
 
	 /*
	 * @desc :method to get admin category details
	 * @auth : Ashiq
		 */
 
		 getCategoryDetailAdmin() {
		 this.loaderActionsService.display(true);
		 this.categorydetailService.getCategoryDetailsAdmin(this.id, response => {
			 if (response.data) {
				 this.categoryDetailArray = response.data;
				 for(let i=0;i<this.categoryDetailArray.managers.length; i++){
					 this.mangerId[i]=this.categoryDetailArray.managers[i].manager_id;
				 }
				 this.loaderActionsService.display(false);
			 }
			 else {
				 this.notificationService.alertBoxValue("error", response.message);
				 this.loaderActionsService.display(false);
			 }
		 })
	 };
 
		/*
	 * @desc : method redirect to previous page
	 * @auth : Ashiq
		 */
		 back() {
			window.history.back();
	 }
 
 	popUptogle(){
 		this.popUpOpen=!this.popUpOpen
 	}
 
	 getClassByValue(index) {
		 switch (index % 10) {
				 case 0: return "default-avatar islamic-green";
				 case 1: return "default-avatar limerick";
				 case 2: return "default-avatar chilean-fire";
				 case 3: return "default-avatar persian-pink";
				 case 4: return "default-avatar deep-magenta";
				 case 5: return "default-avatar gigas";
				 case 6: return "default-avatar endeavour";
				 case 7: return "default-avatar dodger-blue";
				 case 8: return "default-avatar jordy-blue";
				 case 9: return "default-avatar Light-sea-green";
				 case 10: return "emp-profileimage";
		 }
	 }
 
 
	 /*
			* @desc : navigate to add case page
		* @auth : Ashiq
			*/
	 addCase() {
		 this.router.navigate(['/modules/case/add-case/' + this.id ]);
	 }
 }
 