/*
	* @desc : component for category details
	* @auth : Ashiq
  */
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { NotificationService } from '../../../shared/services/notifications/notification.service';

import { CategorydetailService }  from '../../services/category-details/categorydetail.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-category-details',
  templateUrl: './category-details.component.html',
  styleUrls: ['./category-details.component.css']
})

export class CategoryDetailsComponent implements OnInit {

	categoryDetailArray	: 	any =[];
	mangerId  					: 	any =[];
	id    				:	any;
    userData            :   any;

  constructor(
			private router                 : Router,
		 	private route                   : ActivatedRoute,
		 	private notifications           : NotificationService,
		 	private categorydetailService   : CategorydetailService,
		 	private loaderActionsService    : LoaderActionsService,
		 	private cookieService           : CookieService ) { }

	ngOnInit() {
     	if (this.cookieService.get("user-data")) {
       		this.userData = JSON.parse(this.cookieService.get("user-data"));
     	}
			this.id = this.route.snapshot.queryParams['id'];
			this.getCategoryDetailData();
	}

    /*
	 * @desc : calling api for getting category list
	 * @auth : Ashiq
     */
	getCategoryDetailData() {
		this.loaderActionsService.display(true);
		this.categorydetailService.getCategoryDetails(this.id, response => {
			if (response.data) {
				this.categoryDetailArray = response.data;
				for(let i=0;i<this.categoryDetailArray.managers.length; i++){
          this.mangerId[i]=this.categoryDetailArray.managers[i].manager_id;
				}
				this.loaderActionsService.display(false);
			}
			else {
				this.notifications.alertBoxValue("error", response.message);
				this.loaderActionsService.display(false);
			}
		})
	};


    /*
	 * @desc : navigate to add case page
	 * @auth : Ashiq
     */
	// addCase() {
	// 			this.router.navigate(['/modules/case/add-case/' + this.id + '/' + this.categoryDetailArray.manager_id]);
	// 		   }

	  /*
	 * @desc : navigate to previous page
	 * @auth : Ashiq
     */
	back() {
			window.history.back();
			}

}
