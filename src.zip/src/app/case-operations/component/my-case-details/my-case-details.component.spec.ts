import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyCaseDetailsComponent } from './my-case-details.component';

describe('MyCaseDetailsComponent', () => {
  let component: MyCaseDetailsComponent;
  let fixture: ComponentFixture<MyCaseDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyCaseDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyCaseDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
