import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { MyRequestService } from '../../services/my-request/my-request.service';
import { ConstantServicesService } from '../../../shared/services/constant/constant-services.service';
import { CaseOperationsService } from '../../services/case-service/case-operations.service';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';


@Component({
  selector: 'app-my-request',
  templateUrl: './my-request.component.html',
  styleUrls: ['./my-request.component.css']
})
export class MyRequestComponent implements OnInit {

  searchValue    : any ;
  searchD        : any ;
  searchTextBox  : boolean = false;
  filterStatus   : boolean = false;
  displayTab     : boolean = false;
  tableData      : any = [];
  editConfig     : any;
  advanceFilterData : any;
  sort           : any;
  userData       : any;
  assignedList   : any = [];
  allList        : any = [];
  myResponseData : any = [];
  filterSort     : any = {};
  selectedId     : any;
  selectValue    : number;
  addStatus      : boolean = false;
  forTitle       : boolean = false;
  forStatus      : boolean = false;
  editStatus     : boolean = false;
  checkAll       : boolean = false;
  multiDelete    : boolean = false;
  forWeek        : boolean = false;
  adminPrivilege : boolean = false;
  confirmBox     : boolean;
  recordsPerPage : number  = 10;
  totalRecords   : number;
  totalSelected  : any = 0;
  setIndex       : any;
  empId          : any;
  setStack       : any;
  config         :any;
  currentPage		 : number = 1;
  queryObject    : any ={};
  showFYDates    :boolean
  stoppage       :boolean=false;
  maxSizeString : string = '' ;
  maxSizeInt : number = 5242880 ; //5 MB
  
  constructor(private apiService  : MyRequestService,
            private router        : Router,
            private notifications : NotificationService,
            private loaderService : LoaderActionsService,
            private cookieService : CookieService,
            private activatedRoute: ActivatedRoute,
            private constSetup    : ConstantServicesService,
            private aclVerif      : AclVerificationService,
            private timeZone      : TimezoneDetailsService,
            private temp          : CaseOperationsService,
            private caseOperationService        : CaseOperationsService
            ) { }

  ngOnInit() {
    this.adminPrivilege = this.aclVerif.checkAclDummy('allemployee-list');
    this.queryObject={ "page": this.currentPage,}
    this.confirmBox = false;
    // this.queryObject['page'] = this.currentPage;
    this.queryObject['page_limit'] = this.recordsPerPage;
    if (this.cookieService.get("user-data")) {
      if (localStorage.getItem("itemsperpage")) {
        this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
      }
      else {
        this.recordsPerPage = 10;
      }
      this.userData = JSON.parse(this.cookieService.get("user-data"));
      this.empId = this.userData.user_id;
      let param1 = this.activatedRoute.snapshot.queryParams["status"];
      if(param1=="true"){
        this.getMyResponse();
        this.displayTab=true;
      }else{
        this.getMyCaseList(this.queryObject.page);
        this.displayTab=false;
      }
     
        // this.getMyCaseList(this.queryObject.page);
    }
    this.getMaxFileSize();
  }
	/*
	* @desc : api service to get  all employee
	* @auth : Ashiq
    */
	getMaxFileSize() {
            var self = this ;
		this.caseOperationService.getMaxFileSize(res => {
			let maxSizeData = res.data.result;
                        self.maxSizeInt = maxSizeData ;
                        let maxSizeInt = (maxSizeData / 1024 / 1024) | 1 ;
                    self.maxSizeString = " of " + parseInt(maxSizeInt.toString() ) + " MB max" ;
		})
	}
  pageChangeEvent(event){
    this.currentPage = event;
    if(!this.displayTab)
    this.getMyCaseList( this.currentPage);
     if(this.displayTab )
     this.getMyResponse();
  }

  getMyCaseList(page) {
    this.currentPage = page;
    this.stoppage=false;
    this.loaderService.display(true);
    this.apiService.getMycases(this.empId, this.currentPage, this.advanceFilterData, this.searchValue, this.sort, response => {
      if (response.status == "OK") {
        if (!response.count) {
          this.totalRecords =0;
        }
        if (response.data) {
        let tableData=response.data;
          for(let i =0;i<tableData.length;i++){
            if(tableData[i].requested_name){
              let requested_name =  tableData[i].requested_name.split(" ");
              tableData[i].requested_first_name = requested_name[0];
              tableData[i].requested_last_name = requested_name[requested_name.length-1];
             }
          }
          this.tableData = tableData;
          if (response.count) {
            this.totalRecords = response.count;
          }
        }
        else
          this.tableData = [];
        this.loaderService.display(false);
      }
      else {
        this.loaderService.display(false);
      }
    })
  }

  getClassByValue(index) {
    switch (index % 10) {
        case 0: return "default-avatar islamic-green";
        case 1: return "default-avatar limerick";
        case 2: return "default-avatar chilean-fire";
        case 3: return "default-avatar persian-pink";
        case 4: return "default-avatar deep-magenta";
        case 5: return "default-avatar gigas";
        case 6: return "default-avatar endeavour";
        case 7: return "default-avatar dodger-blue";
        case 8: return "default-avatar jordy-blue";
        case 9: return "default-avatar Light-sea-green";
        case 10: return "case-avatar";
    }
}


  // getClassByValue(index) {
  //   return this.ApprovalsService.getClassByValue(index);
  
  // }

  viewDetails(i ,displayTab){
     this.constSetup.caseStatus = this.tableData[i];
     this.router.navigate(['/modules/case/request-details/'+this.tableData[i].id ],{ queryParams: { status: this.displayTab } });
  }

  viewResponseDetail(i , displayTab){
    this.constSetup.caseStatus = this.tableData[i];
    this.router.navigate(['/modules/case/response-details/'+this.tableData[i].id ],{ queryParams: { status: this.displayTab } });
  }

  /*
   author : dipin
   desc   : Search  when enter key is pressed
  */
  search(value) {
    if ( this.searchValue ||this.searchD.trim() != ''){
        this.searchValue = value;
        this.currentPage = 1;
        this.queryObject.page = 1;
        this.currentPage=1;
	      this.queryObject.keyword = this.searchValue ? this.searchValue : '';
        if(this.displayTab){
         this.getMyResponse();
        }
        if(!this.displayTab){
        this.getMyCaseList(this.currentPage);
        }
       
      }
  }

  /*
  *  @desc   :toogle display of popup based on the add button click
  *  @author :dipin
  */
  setAdd(value) {
    this.addStatus  = !this.addStatus;
    this.editStatus = false;
  }

  filterData(event){
   if (event || this.advanceFilterData) {
    this.advanceFilterData  = event;
    this.currentPage        = 1;
    if(this.displayTab){
      this.filterDataResponse(this.advanceFilterData);
     }
     if(!this.displayTab){
     this.getMyCaseList(this.currentPage);
     }
   }
   else {
      this.advanceFilterData = undefined;
      this.queryObject.cas_st=null;
    }
    if(event==undefined){
      this.queryObject.cas_st=null;
      this.advanceFilterData = undefined;
      this.queryObject.range_filter=null;
    }
  }

  /*
  *  @desc   :method for apply sorting using api and update the table list
  *  @author :dipin
  */
  applySort(value,tab:any) {
    let type = 0;
    if (value == 'cas_cat_id')
      if (this.forTitle == true) {
        type = 1;
        this.forTitle = false;
      }
      else {
        type = 0;
        this.forTitle = true;
      }

    if (value == 'cas_st')
      if (this.forStatus == true) {
        type = 1;
        this.forStatus = false;
      }
      else {
        type = 0;
        this.forStatus = true;
      }

      
    this.sort = { department: value, type: type };
    this.loaderService.display(true);
    this.apiService.sortDetails({ department: value, type: type }, this.currentPage, this.selectedId,this.advanceFilterData,this.searchValue,response => {
      if (response.status == "OK") {
        this.tableData = response.data;
        this.loaderService.display(false);
      }
      else {
        this.tableData = [];
        this.loaderService.display(false);
      }
    })
  }

  sortResponse(label){
    let currentSortStatus = this.filterSort[label] ? this.filterSort[label].rev : true;
    this.filterSort = {};
    this.filterSort[label] = { rev: !currentSortStatus }
    this.filterSort["label"] = label;
    this.queryObject.sort = `${this.filterSort[label].rev ? '-' : ''}${label}`
    this.getMyResponse();
  }






  setFocus() {
    window.setTimeout(function() {
      document.getElementById('searchField').focus();
    }, 1);
  }

  deletefile(){
    this.config = "Are you sure you want to delete?";
    this.confirmBox = true;
 }

 getpage(event) {
   if (event > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      if(!this.displayTab)
      this.getMyCaseList(this.currentPage);
       if(this.displayTab )
       this.getMyResponse();
     
    }
  }

  getMyResponse(){
    this.queryObject['page'] = 1;
    this.queryObject['page_limit'] = this.recordsPerPage;
    this.loaderService.display(true);

    this.apiService.getMyResponses(this.empId, this.queryObject, response => {
      if (response.status == "OK"  && response && response.data && response.data.length > 0) {
        if (response.count) {
          this.totalRecords = response.count;
          this.stoppage=true;
        }
        this.tableData = response.data;
        this.loaderService.display(false);
      }else{
      this.tableData = []
      this.loaderService.display(false);
    }
   })
  }

  paginationManage(){
    this.loaderService.display(true);
    this.queryObject['page'] = 1;
    this.queryObject['range_filter'] = this.formatForApi(this.userData.start_date )+','+this.formatForApi(this.userData.end_date);

  }
    /*
  * @desc : method for handling selected category
  * @auth : dipin
  */
 setTrue(index,value) {
  this.selectValue = index;
  this.filterStatus = false;
  this.currentPage  = 1;
  if (value)
    for (var i = 0; i < this.allList.length; i++) {
      if (index != i) {
        this.allList[i].status = false;
      }
      else {
        this.allList[i].status = true;
        this.changeData(this.allList[i].id,false);
      }
    }
  else
     for (var i = 0; i < this.assignedList.length; i++) {
      if (index != i) {
        this.assignedList[i].status = false;
      }
      else {
        this.assignedList[i].status = true;
        this.changeData(this.assignedList[i].id,true);
      }
    }
}
/*
  * @desc : method for change data based on category
  * @auth : dipin
  */
 changeData(id,value) {
  if (id) {
    this.loaderService.display(true);
    this.selectedId = id;
    this.temp.takeCases(id, this.currentPage, this.advanceFilterData, this.searchValue, this.sort,value,this.empId,response => {
      if (response.status == "OK") {
        if (response.data) {
          let tableData = [];
          tableData = response.data;
          
          for(let i = 0;i<tableData.length;i++){
            let name = tableData[i].creater_user_name.split(" ");
           tableData[i].creater_first_name = name[0];
            tableData[i].creater_last_name = name[name.length-1];
            
          let assigneeName =  tableData[i].assigned_name.split(" ");
          tableData[i].assignee_first_name = assigneeName[0];
          tableData[i].assignee_last_name = assigneeName[assigneeName.length-1];

          }
          this.tableData = tableData;
          if (response.count) {
            this.totalRecords = response.count;
          }
        }
        else
          this.tableData = [];
        this.loaderService.display(false);
      }
      else {
        this.loaderService.display(false);
      }
    })
  }
}


filterDataResponse(advanceFilterData){
if (advanceFilterData){
				if (advanceFilterData.caseValue && advanceFilterData.caseValue.selected && advanceFilterData.caseValue.selected.length) {
					if (advanceFilterData.caseValue.selected[0].name == 'Reopen')
						this.queryObject.cas_st =  "Reopen";
					if (advanceFilterData.caseValue.selected[0].name == 'Closed')
          this.queryObject.cas_st= "Closed";
					if (advanceFilterData.caseValue.selected[0].name == 'Open')
					this.queryObject.cas_st= "Open";
					if (advanceFilterData.caseValue.selected[0].name == 'Awaiting')
					this.queryObject.cas_st= "Awaiting";
					if (advanceFilterData.caseValue.selected[0].name == 'In Progress')
          this.queryObject.cas_st= "In Progress";
          }else
          this.queryObject.cas_st= null;

          let params="";
          if (advanceFilterData.range) {
            this.queryObject.range_filter = this.formatForApi(advanceFilterData.range[0]) + ',' + this.formatForApi(advanceFilterData.range[1]);
            // params = params + "&cas_crn=" + this.formatForApi(advanceFilterData.range[0]) + "," + this.formatForApi(advanceFilterData.range[1]);
          }
      }
        else{
          this.queryObject.cas_st=null;
          this.queryObject['range_filter'] = this.formatForApi(this.userData.start_date )+','+this.formatForApi(this.userData.end_date);
        }
        this.getMyResponse();
}


formatForApi(inputDate) {
  var date = this.timeZone.toLocal(inputDate);
  if(date)
  if (!isNaN(date.getTime())) {
    if ((Number(date.getMonth()) + 1) < 10) {
      if (Number(date.getDate() < 10)) {
        return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
      }
      else {
        return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
      }
    }
    else {
      if (Number(date.getDate() < 10)) {
        return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
      }
      else {
        return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
      }
    }
  }
  else
    return undefined;
}

}
