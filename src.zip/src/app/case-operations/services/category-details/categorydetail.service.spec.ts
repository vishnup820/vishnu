import { TestBed } from '@angular/core/testing';

import { CategorydetailService } from './categorydetail.service';

describe('CategorydetailService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CategorydetailService = TestBed.get(CategorydetailService);
    expect(service).toBeTruthy();
  });
});
