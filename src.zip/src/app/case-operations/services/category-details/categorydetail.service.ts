/*
	* @desc : service for get category details 
	* @auth : Ashiq
  */
 
 import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import {apiList}  from '../../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class CategorydetailService {

  apiBaseUrl      : string;
  constructor(private http: HttpClient) { this.apiBaseUrl = globalVariables.apiBaseUrl;}

   /*
	*  @desc   :method dealing get api call for category details
	*  @author :ashiq
	*/
   getCategoryDetails(id,callBack) {
		let url: string = this.apiBaseUrl+apiList.caseOperation.categoryDetails+id;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}


	   getCategoryDetailsAdmin(id,callBack) {
		let url: string = this.apiBaseUrl+apiList.caseOperation.adminCategoryDetail+id;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}
	







}
