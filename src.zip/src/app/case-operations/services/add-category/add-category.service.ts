/*
	* @desc : service for add category /get category
	* @auth : Ashiq
  */
 

import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import {apiList}  from '../../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class AddCategoryService {
 	apiBaseUrl      : string;

	constructor(private http: HttpClient) {
		this.apiBaseUrl = globalVariables.apiBaseUrl;
	}

    /*
	*  @desc   :method dealing get api call for add-category
	*  @author :ashiq
	*/
	getAddCategoryApi(obj,callBack) {
		let url: string = this.apiBaseUrl+apiList.caseOperation.addCategory;
		let promise = new Promise((resolve, reject) => {
			this.http.post(url,obj)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

    /*
	*  @desc   :method dealing get api call for edit-category
	*  @author :ashiq
	*/
	getCategory(id, cb) {
		let url: string = this.apiBaseUrl+apiList.caseOperation.adminCategoryList;
			url = url + '/'+id;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res && res['data']) cb(res['data'])
				})
		})
		return promise;
	}
				


	 /*
	*  @desc   :method dealing get api call for manager list in add/edit category
	*  @author :ashiq
	*/
	getManagerApi(cb){
       let url: string = this.apiBaseUrl + apiList.caseOperation.getManagerList;
        this.http.get(url)
        .toPromise()
        .then(res=>{
            cb(res);
        });
       }


       getPrefix(obj,callBack) {
		let url: string = this.apiBaseUrl+apiList.caseOperation.prefix;
		let promise = new Promise((resolve, reject) => {
			this.http.post(url,obj)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

}



