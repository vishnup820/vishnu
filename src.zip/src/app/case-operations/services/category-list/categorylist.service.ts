/*
	* @desc : service for update category and delete category
	* @auth : Ashiq
  */

import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {HttpClient} from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import {apiList}  from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root'
})
export class CategorylistService {
  userData        : any;
  apiBaseUrl      : string;
  constructor(private http: HttpClient,private cookieService: CookieService) { this.apiBaseUrl = globalVariables.apiBaseUrl;
  if(this.cookieService.get("user-data")) {
          this.userData =  JSON.parse(this.cookieService.get("user-data"));
        }}

   /*
	*  @desc   :method dealing get api call for category-list
	*  @author :ashiq
	*/
    getCategoryList(cb) {
		let url: string = this.apiBaseUrl+apiList.caseOperation.categoryList;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) cb(res)
				})
		})
		return promise;
	}

   /*
	*  @desc   :method dealing get api call for  ucategory-list
	*  @author :ashiq
	*/
	updateCategoryDetails(id,obj,callBack) {
		let url: string = this.apiBaseUrl+apiList.caseOperation.updateCategory+"/"+id;
		let promise = new Promise((resolve, reject) => {
			this.http.put(url,obj)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

    /*
	*  @desc   :method dealing get api call for  delete a category from list
	*  @author :ashiq
	*/
	deleteCategory(id, cb) {
		let url: string = this.apiBaseUrl+apiList.caseOperation.updateCategory+"/"+id;
		let promise: any = new Promise((resolve, reject) => {
			this.http.delete(url)
				.toPromise()
				.then(res => {
					res["status"] ? cb(res) : '';
				})
		})
	}
}
