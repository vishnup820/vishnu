/*
*  @desc   :service dealing get and post api calls for calender list
*  @author :dipin
*/
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

@Injectable({
  providedIn: 'root'
})
export class MyRequestService {
 userData   : any;
 apiBaseUrl : string;

	constructor(
		private http: HttpClient,private cookieService: CookieService,private timezone : TimezoneDetailsService) {
		this.apiBaseUrl = globalVariables.apiBaseUrl;
		if(this.cookieService.get("user-data")) {
          this.userData =  JSON.parse(this.cookieService.get("user-data"));
        }
    }

	/*
  *  @desc   :method for sorting table emelents based on columns
  *  @author :dipin
  */
	sortDetails(obj, page, id, advanceFilterData, searchValue, callBack) {
		let temp = (obj.type) ? "-" + obj.department : obj.department;
		let sortValue: any;
		let serchFilter: any;
		let params = "";
		let url;
		searchValue ? serchFilter = "&keyword=" + searchValue : serchFilter = "";
		if (advanceFilterData) {
			if (advanceFilterData.range) {
				params = params + "&cas_crn=" + this.formatForApi(advanceFilterData.range[0]) + "," + this.formatForApi(advanceFilterData.range[1]);
			}
			if (advanceFilterData.caseValue)
			if (advanceFilterData.caseValue&& advanceFilterData.caseValue.selected && advanceFilterData.caseValue.selected.length) {
				if (advanceFilterData.caseValue.selected[0].name == 'Reopen')
						params = params + "&cas_st=Reopen";
					if (advanceFilterData.caseValue.selected[0].name == 'Closed')
						params = params + "&cas_st=Closed";
					if (advanceFilterData.caseValue.selected[0].name == 'Open')
						params = params + "&cas_st=Open";
					if (advanceFilterData.caseValue.selected[0].name == 'Awaiting')
						params = params + "&cas_st=Awaiting";
					if (advanceFilterData.caseValue.selected[0].name == 'In Progress')
						params = params + "&cas_st=In Progress";
				}
		}
		if (!temp) {
			temp = "";
		}
		let recordsPerPage;
		if (localStorage.getItem("itemsperpage")) {
			recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			recordsPerPage = 10;
		}
		url = this.apiBaseUrl + "/api/v1/people/" + JSON.parse(this.cookieService.get("user-data")).user_id + "/my-requests?" + "page=" + page + "&page_limit=" + recordsPerPage + params + serchFilter + "&sort=" + temp;

		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	getCase(id, page, advanceFilterData, searchValue, obj, callBack) {
		let temp;
		let sortValue: any;
		let serchFilter: any;
		let params = "";
		if (obj)
			temp = (obj.type) ? "-" + obj.department : obj.department;
		searchValue ? serchFilter = "&keyword=" + searchValue : serchFilter = "";
		if (advanceFilterData) {
			if (advanceFilterData.range) {
				params = params + "&cas_crn=" + this.formatForApi(advanceFilterData.range[0]) + "," + this.formatForApi(advanceFilterData.range[1]);
			}
			if (advanceFilterData.caseValue)
			if (advanceFilterData.caseValue&& advanceFilterData.caseValue.selected && advanceFilterData.caseValue.selected.length) {
				if (advanceFilterData.caseValue.selected[0].name == 'Reopen')
						params = params + "&cas_st=Reopen";
					if (advanceFilterData.caseValue.selected[0].name == 'Closed')
						params = params + "&cas_st=Closed";
					if (advanceFilterData.caseValue.selected[0].name == 'Open')
						params = params + "&cas_st=Open";
					if (advanceFilterData.caseValue.selected[0].name == 'Awaiting')
						params = params + "&cas_st=Awaiting";
					if (advanceFilterData.caseValue.selected[0].name == 'In Progress')
						params = params + "&cas_st=In Progress";
				}
		}
		if (!temp) {
			temp = "";
		}
		let recordsPerPage;
		if (localStorage.getItem("itemsperpage")) {
			recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			recordsPerPage = 10;
		}
		let url: string = this.apiBaseUrl + "/api/v1/case-categories/" + id + "/cases?" + "page=" + page + "&page_limit=" + recordsPerPage + params + serchFilter + "&sort=" + temp;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	/*
*  @desc   : make date to the format 'dd-mm-yyyy'
*  @author : dipin
*/
	formatForApi(inputDate) {
		var date = this.timezone.toLocal(inputDate);
		if(date)
		if (!isNaN(date.getTime())) {
			if ((Number(date.getMonth()) + 1) < 10) {
				if (Number(date.getDate() < 10)) {
					return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
				}
				else {
					return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
				}
			}
			else {
				if (Number(date.getDate() < 10)) {
					return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
				}
				else {
					return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
				}
			}
		}
	  else
	  	return undefined;
	}

	getCaseDetails(id, callBack) {
		let url: string = this.apiBaseUrl + "/api/v1/cases/" + id;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	getCaseMyDetails(id, callBack) {
		let url: string = this.apiBaseUrl + "/api/v1/cases/" + id;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	getMessage(id, callBack) {
		let url: string = this.apiBaseUrl + "/api/v1/case-comments/" + id;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	addMessage(obj, callBack) {
		let url: string = this.apiBaseUrl + "/api/v1/case-comments";
		let promise = new Promise((resolve, reject) => {
			this.http.post(url, obj)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	changeCase(status, id, callBack) {
		let url: string = this.apiBaseUrl + "/api/v1/cases/" + id + "/status";
		let promise = new Promise((resolve, reject) => {
			this.http.put(url, { case_status: status })
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	getMycases(id, page, advanceFilterData, searchValue, obj, callBack) {
		let temp;
		let sortValue: any;
		let serchFilter: any;
		let params = "";
		if (obj)
			temp = (obj.type) ? "-" + obj.department : obj.department;
		searchValue ? serchFilter = "&keyword=" + searchValue : serchFilter = "";
		if (advanceFilterData) {
			// advanceFilterData.range=null
			// if (advanceFilterData.range) {
			// 	params = params + "&cas_crn=" + this.formatForApi(advanceFilterData.range[0]) + "," + this.formatForApi(advanceFilterData.range[1]);
			// }
			if (advanceFilterData.caseValue)
			if (advanceFilterData.caseValue&& advanceFilterData.caseValue.selected && advanceFilterData.caseValue.selected.length) {
				if (advanceFilterData.caseValue.selected[0].name == 'Reopen')
						params = params + "&cas_st=Reopen";
					if (advanceFilterData.caseValue.selected[0].name == 'Closed')
						params = params + "&cas_st=Closed";
					if (advanceFilterData.caseValue.selected[0].name == 'Open')
						params = params + "&cas_st=Open";
					if (advanceFilterData.caseValue.selected[0].name == 'Awaiting')
						params = params + "&cas_st=Awaiting";
					if (advanceFilterData.caseValue.selected[0].name == 'In Progress')
						params = params + "&cas_st=In Progress";
				}
		}
		if (!temp) {
			temp = "";
		}
		let recordsPerPage;
		if (localStorage.getItem("itemsperpage")) {
			recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			recordsPerPage = 10;
		}
		let url: string = this.apiBaseUrl + "/api/v1/people/" + id + "/my-requests?" + "page=" + page + "&page_limit=" + recordsPerPage + params + serchFilter + "&sort=" + temp;
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
	}

	geturlparams(qobj){
		let query = `?page=${qobj.page?qobj.page: ''}&page_limit=${qobj['page_limit']?qobj['page_limit']: ''}${qobj.keyword?'&keyword=' + qobj.keyword:''}${qobj.sort?'&sort=' + qobj.sort:''}${qobj.cas_st?'&cas_st=' + qobj.cas_st:''}${qobj.range_filter?'&cas_crn=' + qobj.range_filter:''}`
		return query;
	}
	
	getMyResponses(id,qobj, cb){
		
		let url: string = this.apiBaseUrl +"/api/v1/people/"+id+"/case-reponse";
		url = url + this.geturlparams(qobj);
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) cb(res)
				})
		})
		return promise;
	}
}
