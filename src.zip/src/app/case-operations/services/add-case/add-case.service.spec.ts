import { TestBed } from '@angular/core/testing';

import { AddCaseService } from './add-case.service';

describe('AddCaseService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AddCaseService = TestBed.get(AddCaseService);
    expect(service).toBeTruthy();
  });
});
