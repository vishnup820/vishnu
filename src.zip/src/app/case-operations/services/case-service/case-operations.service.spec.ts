import { TestBed } from '@angular/core/testing';

import { CaseOperationsService } from './case-operations.service';

describe('CaseOperationsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CaseOperationsService = TestBed.get(CaseOperationsService);
    expect(service).toBeTruthy();
  });
});
