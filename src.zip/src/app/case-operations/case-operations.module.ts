import { NgModule,ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { ClickOutsideModule } from 'ng4-click-outside';
import { GlobalErrorHandlerService } from '../global-error-handler.service';
import { CaseOperationsService } from './services/case-service/case-operations.service';
import { BsDatepickerModule,BsDatepickerConfig} from 'ngx-bootstrap/datepicker';
import { CaseListComponent } from './component/case-list/case-list.component';
import { AuthGuardService } from '../shared/services/auth-guard/auth-guard.service';
import { RoleGuardService } from '../shared/services/role-guard/role-guard.service';
import { MyRequestComponent } from './component/my-request/my-request.component';
import { CategoryListComponent } from './component/category-list/category-list.component';
import { CaseDetailsComponent } from './component/case-details/case-details.component';
import { AddCategoryComponent } from './component/add-category/add-category.component';
import { CategoryDetailsComponent } from './component/category-details/category-details.component';
import { AddCaseComponent } from './component/add-case/add-case.component';
import { MyCaseDetailsComponent } from './component/my-case-details/my-case-details.component';
import { MyRequestDetailsComponent } from './component/my-request-details/my-request-details.component';
import { CategoryDetailAdminComponent } from './component/category-detail-admin/category-detail-admin.component';
import { ResponseDetailsComponent } from './component/response-details/response-details.component';


@NgModule({
   declarations: [CaseListComponent,
      MyRequestComponent,
      CategoryListComponent,
      CaseDetailsComponent,
      AddCategoryComponent,
      CategoryDetailsComponent,
      AddCaseComponent,
      MyCaseDetailsComponent,
      MyRequestDetailsComponent,
      CategoryDetailAdminComponent,
      ResponseDetailsComponent,
    ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    ClickOutsideModule,
    BsDatepickerModule.forRoot(),
    RouterModule.forChild([
      {
        path       : 'case-list',
        canActivate : [RoleGuardService],
        component  :  CaseListComponent,
      },
      {
        path       : 'case-list/:id',
        canActivate : [RoleGuardService],
        component  :  CaseListComponent,
      },
      {
        path       : 'category-details',
        canActivate : [RoleGuardService],
        component  :  CategoryDetailsComponent,
      },
      {
        path       : 'add-case/:id',
        canActivate : [RoleGuardService],
        component  :  AddCaseComponent,
      },
      {
        path       : 'my-case-details/:id',
        canActivate : [RoleGuardService],
        component  :  MyCaseDetailsComponent,
      },
      {
        path       : 'category-list',
        canActivate : [RoleGuardService],
        component  :  CategoryListComponent,
      },
      {
        path       : 'my-request',
        canActivate : [RoleGuardService],
        component  :  MyRequestComponent,
      },
      {
        path       : 'case-details/:id',
        canActivate : [RoleGuardService],
        component  :  CaseDetailsComponent,
      },
      {
        path       : 'add-category',
        canActivate : [RoleGuardService],
        component  :  AddCategoryComponent,
      },
      {
        path       : 'add-category/:id',
        canActivate : [RoleGuardService],
        component  :  AddCategoryComponent,
      },
      {
        path       : 'request-details/:id',
        canActivate : [RoleGuardService],
        component  :  MyRequestDetailsComponent,
      },
      {
        path       : 'response-details/:id',
        canActivate : [RoleGuardService],
        component  :  ResponseDetailsComponent,
      },
      {
        path       : 'admin-categorydetail',
        canActivate : [RoleGuardService],
        component  :  CategoryDetailAdminComponent,
      },
      {
        path       : '',
        redirectTo : 'category-list',
        canActivate : [RoleGuardService],
        pathMatch  : 'full'
      }
    ])
  ],
  providers: [
      {
        provide  : ErrorHandler,
        useClass : GlobalErrorHandlerService,
      }
    ],
})
export class CaseOperationsModule { }
