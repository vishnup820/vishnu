/*
*  @desc   :component for attendance marking
*  @author :vinod
*/

import {
	Component,
	OnInit,
	ChangeDetectorRef,
	OnDestroy
} from '@angular/core';
import {
	RouterModule,
	Routes,
	Router
} from '@angular/router';

import {
	ActivatedRoute
} from '@angular/router';

import {
	MarkAttendanceService
} from '../../services/mark-attendance.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

declare var require: any;
var moment = require('moment');

@Component({
	selector: 'app-hris-attendance-marking',
	templateUrl: './hris-attendance-marking.component.html',
	styleUrls: ['./hris-attendance-marking.component.css']
})
export class HrisAttendanceMarkingComponent implements OnInit ,OnDestroy{

	private sub			: any;
	selectedId          : any;
	currentZone         : any;
	currentId           : any;
	attendance			: any = [];
	people				: any = [];
	selectedEmp			: any = [];
	locationList        : any = [];
	locationSelected    : any = [];
	showForm			: boolean = false;
	disableClick        : boolean = false;
	dateToday			: Date;
	currentDate         : Date;
	queryObject			: any = {};
	minDate             : Date;
	nodata:boolean = false;
	addClass        :boolean=false;
	payPeriodStatus :boolean = false;
	saveButtonStatus:boolean=false;
	sDate : any;
	eDate   :any;
	usedata : any;
	changeVal : any;
	chosenObject		: any = {
		selected: [],
		status: [{
				label: 'Absent',
				value: 1
			},
			{
				label: 'Present',
				value: 2
			},
			{
				label: 'On Duty',
				value: 3
			},
			{
				label: 'Leave',
				value: 4
			}
			// ,
			// {
			// 	label: 'Onduty',
			// 	value: 3
			// },
			// {
			// 	label: 'Leave',
			// 	value: 4
			// }
		],
		setEdit: {
			attendance: [],
		},
		select: {
			employee: {},
			status: {}
		},


	}
	maxDate    : any
	config     : any
	confirmBox : boolean = false;
	confirm : boolean = false;

	overrides:number = 0;
	selectedItems	: any = [];
	disableOverRide	: boolean = false;
	rejectPopUp     : boolean = false;
	reasonTooverRide : any;
	reason			 : boolean = false;
	ondutyflag 		 : boolean = false;
	init 			 : number  = 0;
	finalSave        : boolean = false;
	peopleloader     : boolean = false;
	constructor(
		private markAttendanceService : MarkAttendanceService,
		private route                 : ActivatedRoute,
		private notificationService   : NotificationService,
		private _router               : Router,
		private loader                : LoaderActionsService,
		private changeDetectorRef     : ChangeDetectorRef,
		private cookieService         : CookieService,
		private timeZone              : TimezoneDetailsService
		) {}

	ngOnInit() {

		let self = this;
		if(this.cookieService.get("user-data")){
				this.usedata =	JSON.parse(this.cookieService.get("user-data"));
				this.minDate=this.timeZone.toLocal(this.usedata.financialMin_date);
				}

		self.currentZone = JSON.parse(this.cookieService.get("user-data")).time_zone;
		self.changeDetectorRef.detectChanges();
		this.sub = this.route.params.subscribe(params => {
			let temp = params.id.split('_');
			self.dateToday = this.timeZone.toLocal(temp[0]);
			if(temp[1] != 'add'){
			 self.selectedId = temp[1];
			 self.disableClick = true;
			}
		});
		self.loader.display(true);
		this.markAttendanceService.getLocations(response => {
			if (response.status == 'OK') {
				self.locationList = response.data;
				if (self.selectedId) {
					let userData = JSON.parse(this.cookieService.get("user-data"));
					for (let i = 0; i < self.locationList.location.length; i++) {
						if (self.locationList.location[i].id == self.selectedId) {
							this.locationSelected = [i];
							this.currentZone = self.locationList.location[i].timezone;
							this.currentId   = self.locationList.location[i].id;
							this.currentDate = this.getCurrentDate(self.locationList.location[i].timezone);
							localStorage.setItem('selectedPrevData',JSON.stringify({'id':self.currentId,'zone':self.currentZone,'date':self.currentDate}));
							self.maxDate = self.getCurrentDate(this.currentZone)
						}
					}
				}
				else {
					let temp = JSON.parse(localStorage.getItem("currentLoc"));
					// let loc  = JSON.parse(localStorage.getItem("currentLocid"));
					if(temp){
					for (let i = 0; i < self.locationList.location.length; i++) {
						if (self.locationList.location[i].id == temp.id) {
							this.locationSelected = [i];
							this.currentZone = self.locationList.location[i].timezone;
							this.currentId   = self.locationList.location[i].id;
							this.currentDate = this.getCurrentDate(self.locationList.location[i].timezone);
							localStorage.setItem('selectedPrevData',JSON.stringify({'id':self.currentId,'zone':self.currentZone, 'date':self.currentDate}));
							self.maxDate = self.getCurrentDate(this.currentZone)
						}
					}
					}else{
						for (let i = 0; i < self.locationList.location.length; i++) {
							if (self.locationList.location[i].id ==  this.usedata.location_id) {
						    this.locationSelected = [i];
							this.currentZone = self.locationList.location[i].timezone;
							this.currentId   = self.locationList.location[i].id;
							this.currentDate = this.getCurrentDate(self.locationList.location[i].timezone);
							localStorage.setItem('selectedPrevData',JSON.stringify({'id':self.currentId,'zone':self.currentZone, 'date':self.currentDate}));
							self.maxDate = self.getCurrentDate(this.currentZone)
					}
				}
				}
			}
			}
			else {
				self.loader.display(false);
				self.locationList = [];
			}
		})
	}

	toggleForm(event) {
		this.showForm = !this.showForm;
		if(this.showForm){
      		this.addClass = true;
    	}
    	else{
      		this.addClass  = false;
    	}
		event ? event.stopPropagation() : '';
		this.selectedItems = [];
	}


	/**
	 * @ desc   :to get added emplyees attendance
	 * @ author  : vinod
	 */


	submitForm() {
		let employee = this.chosenObject.select.employee.selected;
		let dummy = [];

		employee.map((item, index) => {
			dummy.unshift({
				id: item.id,
				first_name: item.name,
				last_name: '',
				application_type: "1",
				leave_type: 0,
				code:item.code,
				first_half_attendance: 2,
				second_half_attendance: 2,
				disable: true,
				photo  : item.photo,
				punch_type:item.punch_type,
				disabled : (item.punch_type == 'Manual')?false:true

			})
		})
		dummy = this.processData(dummy);
		localStorage.setItem('dummydata',JSON.stringify(dummy));
		Array.prototype.unshift.apply(this.attendance,dummy);
		this.filterPeople();
		this.disableOverRide = false;
	}

	/**
	 * @ desc   :post final attandeance status routing to listing page
	 * @ author  : vinod
	 */

	finalAttendanceconfirmed() {
		let self = this;
		self.loader.display(true);
		let userData = JSON.parse(this.cookieService.get("user-data"));
		this.queryObject.date = this.generateQuery(Date);
		let choosenobjSubmit = []
		// choosenobjSubmit = this.returnFinalObj(this.attendance,this.chosenObject.selected);
		// this.chosenObject.selected
		// (this.reasonTooverRide)?this.reasonTooverRide:null,this.overrides,choosenobjSubmit,
		let date =  `${this.dateToday.getFullYear()}-${this.dateToday.getMonth() + 1}-${this.dateToday.getDate()}`;
		this.markAttendanceService.postAttendance(this.chosenObject.selected,'Y', this.queryObject.date,this.currentZone,this.currentId,userData.user_id,date,function(res) {
			if (res.status == "OK") {
				self.loader.display(false);
				setTimeout(() => {
					self._router.navigate(['modules/attendance/listing']);
				}, 2000);
				self.notificationService.alertBoxValue("success", "Attendance Marking Finished Successfully");
				self.reasonTooverRide = null;
			}
			else {
				self.disableOverRide = false;
				self.loader.display(false);
				self.notificationService.alertBoxValue("error", res.message);
			}
		});
	}

	confirmSave(ev){
		if(ev == true){
      		this.finalSave = false;
      		this.finalAttendanceconfirmed();
     	}
    	else{
     	  this.finalSave = false;
    	}
	}
	finalAttendance() {
		this.finalSave = true;
	}
	saveAttendance(){
		let userData = JSON.parse(this.cookieService.get("user-data"));
		this.queryObject.date = this.generateQuery(Date);
		var self = this;
		self.loader.display(true);
		// let choosenobjSave = []
		// choosenobjSave = this.returnFinalObj(this.attendance,this.chosenObject.selected);
		// this.chosenObject.selected
		let date =  `${this.dateToday.getFullYear()}-${this.dateToday.getMonth() + 1}-${this.dateToday.getDate()}`;
		this.markAttendanceService.postAttendance(this.chosenObject.selected,'N', this.queryObject.date,this.currentZone,this.currentId,userData.user_id,date,function(res) {
			if (res.status == "OK") {
				self.disableOverRide = false;
				self.loader.display(false);
				// this.reasonTooverRide = null;
				self.notificationService.alertBoxValue("success", "Saved Successfully");
			}
			else {
				self.disableOverRide = false;
				self.loader.display(false);
				self.notificationService.alertBoxValue("error", res.message);
			}
		});
	}
	/**
	 * @ desc   :to return manual and overrided attendence
	 * @ author  : vinod
	 */
	returnFinalObj(att,obj){
	let choosenobj = [];
	for(var i=0;i<att.length;i++){
			if((att[i].id == obj[i].user_id && att[i].punch_type=="Biometric" && att[i].disabled==true)){
				// obj[i].display = true; 
			}else{
				choosenobj.push(obj[i]);
			}
		}
		return choosenobj;
	}
	/**
	 * @ desc   :to convert the date into requred format
	 * @ author  : vinod
	 */
	generateQuery(date) {
		let query = `${this.dateToday.getFullYear()}-${this.dateToday.getMonth() + 1}-${this.dateToday.getDate()}`;
		return query;
	}
	/**
	 * @ desc   : to check the field is editable
	 * @ author  : vinod
	 */
	enableEdit(data, firstHalf) {
		if(firstHalf) {
			return (data.first_half_attendance == 3 || data.first_half_attendance == 6) ? true : false
		} else {
			return (data.second_half_attendance == 3 || data.second_half_attendance == 6) ? true : false
		}
	}

	/**
	 * @ desc   :to return request body obj
	 * @ author  : vinod
	 */
	processData(data) {
		this.ondutyflag = false;
		let self = this;
		let f_half;
		let s_half;
		if (data) {
			data.forEach((item, index) => {
				item['attendance'] = {};
				if(item.first_half_attendance == 1 || item.first_half_attendance == 3) {
					if(item.first_half_attendance == 1){
						item['attendance'].firstClass = 'attendance-present';
						item['attendance'].firstHalf = [1];
						f_half = 1
					}
					else if(item.first_half_attendance == 3){
						self.ondutyflag = true;
						item['attendance'].firstClass = 'attendance-onduty';
						// item['attendance'].firstHalf = [1];
						item['attendance'].firstHalf = [2];
						f_half = 3
					}
				} else if (item.first_half_attendance == 2 || item.first_half_attendance == 6) {
					if(item.first_half_attendance == 2){
					 	item['attendance'].firstClass = 'attendance-absent';
						item['attendance'].firstHalf = [0];
						f_half = 2
					}
					else if(item.first_half_attendance == 6){
						item['attendance'].firstClass = 'attendance-leave';
						// item['attendance'].firstHalf = [0];
						item['attendance'].firstHalf = [3];
						f_half = 6
					}
				}

				if(item.second_half_attendance == 2 || item.second_half_attendance == 6) {
					if(item.second_half_attendance == 2){
						item['attendance'].secondClass = 'attendance-absent';
						item['attendance'].secondHalf = [0];
						s_half = 2;
					}
					else if(item.second_half_attendance == 6){
						item['attendance'].secondClass = 'attendance-leave';
						// item['attendance'].secondHalf = [0];
						item['attendance'].secondHalf = [3];
						s_half = 6;
					}
				} else if(item.second_half_attendance == 1 || item.second_half_attendance == 3) {
					if(item.second_half_attendance == 1){
						item['attendance'].secondClass = 'attendance-present';
						item['attendance'].secondHalf = [1];
						s_half = 1;
					}
					else if(item.second_half_attendance == 3){
						self.ondutyflag = true;
						item['attendance'].secondClass = 'attendance-onduty';
						// item['attendance'].secondHalf = [1];
						item['attendance'].secondHalf = [2];
						s_half = 3;
					}
				}
			

				self.chosenObject.selected.unshift({
					user_id: item.id,
					first_half_attendance : f_half,
					second_half_attendance : s_half,
					punch_type : item.punch_type
				})
			})
		}
		return data;
	}

	/**
	 * @ desc   : remove people from people list (if already added to attendance)
	 * @ author  : vinod
	 */

	filterPeople() {
		let dummy:any =[];
		let peopleDummy = [];
		this.attendance.map((item, index) => {
			if(dummy.indexOf(item.id) == -1)
				dummy.push(item.id)
		})
		this.people.map((item, index) => {
			if(dummy.indexOf(item.id) ==-1)
				peopleDummy.push(item)
		});
	    this.people = JSON.parse(JSON.stringify(peopleDummy));
	}

	/**
	 * @ desc   :load the attendance list
	 * @ author  : vinod
	 */
	loadAttendance() {
		let self = this;
		self.loader.display(true);
	 	self.currentZone = JSON.parse(this.cookieService.get("user-data")).time_zone;
	 	self.changeDetectorRef.detectChanges();
		let curDate = self.timeZone.getCurrentZoneDate(self.currentZone);
		this.queryObject.sortField = 'id';
		this.queryObject.date = this.generateQuery(Date);
		if (this.queryObject && this.currentZone && this.currentId)
			this.markAttendanceService.getAttendance(this.queryObject, this.currentZone, this.currentId, function(res) {
					curDate.setHours(0);
					curDate.setMinutes(0);
					curDate.setSeconds(0);
					self.dateToday.setHours(0);
					self.dateToday.setMinutes(0);
					self.dateToday.setSeconds(0);
					if(res.setPayPeriodExpiryStatus == 0 && curDate>=self.dateToday){
						self.payPeriodStatus = false;
					}
					else {
						self.payPeriodStatus = true;
					}
					if(res.saveBtnVisible=='Y'){
					self.saveButtonStatus=true;
					}else{
					self.saveButtonStatus=false;
					}
				if (res && res.data.length > 0) {
					self.attendance = self.processData(res.data);
					if(self.attendance.length){
						for(var i=0;i<self.attendance.length;i++){
							if(self.attendance[i].punch_type == "Manual"){
								self.attendance[i].disabled = false
							}else{
								self.attendance[i].disabled = true
							}
						}
					}
					self.nodata = false;
					self.loader.display(false);
				}
				else {
					self.loader.display(false);
					self.nodata = true;
					self.attendance = [];
				}
				self.loadPeople();
			});
	}

	/**
	 * @ desc   :load the employee list
	 * @ author  : vinod
	 */
	loadPeople() {
		this.peopleloader = true;
		this.queryObject.date = this.generateQuery(Date);
		this.markAttendanceService.getPeople(this.queryObject,this.currentId, res => {
			let data: any
			this.people = res.data;
			this.peopleloader = false;
			for(var i=0;i<this.people.length;i++){
				if(this.people[i].punch_type == "Manual"){
					this.people[i].disabled = false;
				}else{
					this.people[i].disabled = true;
				}
			}
			for(var i = 0;i<this.people.length;i++){
				this.people[i].names = this.people[i].name +" " + "(" + this.people[i].code + ")"
			}
			this.filterPeople();
		})
	}

	/**
	 * @ desc    : change absent to present and present to absent
	 * @ author  : vinod
	 */
	changeStatus(selected, data, index, firstHalf){
	  if(selected && selected.selected && selected.selected.length){
		for(let i =0;i<this.chosenObject.selected.length;i++){
			if(data.id==this.chosenObject.selected[i].user_id){
				if (firstHalf) {
					if (selected.selected[0].value == 1){
							this.chosenObject.selected[i].first_half_attendance = 2;
						}
					else if (selected.selected[0].value == 2)
						this.chosenObject.selected[i].first_half_attendance = 1;
					// else
					// 	this.chosenObject.selected[index].first_half = 3;
				} else {
					if (selected.selected[0].value == 1)
						this.chosenObject.selected[i].second_half_attendance = 2;
					else if (selected.selected[0].value == 2)
						this.chosenObject.selected[i].second_half_attendance = 1;
					// else
					// 	this.chosenObject.selected[index].second_half = 3;
				}
			}
		}

	  }
	  if(selected && selected.selected.length && (selected.selected[0].value == 1 || selected.selected[0].value == 2)){
		if(firstHalf) {
			if(data.disable || data.first_half_attendance == 1 || data.first_half_attendance == 2)
				this.attendance[index]['attendance'].firstClass = (selected.selected[0].value == 2)? 'attendance-present': 'attendance-absent';
			   // this.attendance[index]['attendance'].firstClass = (selected.selected[0].value == 2)? 'attendance-present':(selected.selected[0].value == 1)?'attendance-absent':'attendance-onduty';
		} else {
			if(data.disable || data.second_half_attendance == 1 || data.second_half_attendance == 2)
				this.attendance[index]['attendance'].secondClass = (selected.selected[0].value == 2)? 'attendance-present': 'attendance-absent';
				// this.attendance[index]['attendance'].secondClass = (selected.selected[0].value == 2)? 'attendance-present': (selected.selected[0].value == 1)?'attendance-absent':'attendance-onduty';
		}
	  }
	}

	/**
	 * @ desc    : triggered date change event(when bsvalue model updated)
	 * @ author  : vinod
	 */
	dateChange(event) {
		localStorage.setItem('prevdate',JSON.stringify({'event':event}));
		this.disableOverRide = false;
		if(!this.confirm){
			this.dateToday = event;
			this.chosenObject.selected = [];
			this.loadAttendance();
		}
		// this.confirm = true;
	}


	/**
	 * @ desc    : show avatar if no image
	 * @ author  : vinod
	 */
	getClassByValue(index) {
   	 return this.markAttendanceService.getClassByValue(index);
 	}

 	/**
	 * @ desc    : set user location
	 * @ author  : vinod
	 */

	setLocation(event) {
		let self = this;
		if (event.selected[0]) {
			localStorage.setItem('currentVal',JSON.stringify({'id':event.selected[0].id,'zone':event.selected[0].timezone,'name':event.selected[0].name}));
			if(localStorage.getItem("selectedPrevData")){
				self.changeVal = JSON.parse(localStorage.getItem("selectedPrevData"))
				if(self.changeVal.id == event.selected[0].id){
					this.confirmBox =false
					this.sub = this.route.params.subscribe(params => {
						localStorage.setItem('params',JSON.stringify({'id':params.id}));
						let temp = params.id.split('_');
						if(temp[1] && temp[1] != 'add'){
						 if(!this.confirm){
						   self.dateToday = this.timeZone.toLocal(temp[0]);
						   self.currentZone = event.selected[0].timezone;
						   self.currentId   = event.selected[0].id;
						   self.maxDate = self.getCurrentDate(event.selected[0].timezone)
						 }else{
							let date= new Date(JSON.parse(localStorage.getItem("prevdate")).event)
						    self.dateToday = date
						 }
						//   self.dateToday = this.timeZone.toLocal(temp[0]);
						//   self.currentZone = event.selected[0].timezone;
						//   self.currentId   = event.selected[0].id;
						//  self.maxDate = self.getCurrentDate(event.selected[0].timezone)
						 if(this.timeZone.toLocal( this.dateToday)>=this.timeZone.toLocal( this.maxDate)){
							this.dateToday= this.maxDate;
					   }							  
						}
						else {
						if(!this.confirm){
						  self.currentZone = event.selected[0].timezone;
						  self.currentId   = event.selected[0].id;
						  self.dateToday   = self.getCurrentDate(event.selected[0].timezone);
						  localStorage.setItem('currentLoc',JSON.stringify({'id':self.currentId,'zone':self.currentZone}));
						  self.maxDate = self.getCurrentDate(event.selected[0].timezone)}
						  else{
							let date= new Date(JSON.parse(localStorage.getItem("prevdate")).event)
							self.dateToday = date
							// self.dateToday   = self.getCurrentDate(event.selected[0].timezone);
							// self.maxDate = self.getCurrentDate(event.selected[0].timezone)
							

						  }
						}

						if(temp[0] && self.init == 0){
							self.dateToday = this.timeZone.toLocal(temp[0]);
							self.maxDate = self.getCurrentDate(event.selected[0].timezone)
							if(this.timeZone.toLocal( this.dateToday)>=this.timeZone.toLocal( this.maxDate)){
								this.dateToday= this.maxDate;
						   }
						}
					});
					self.init = 1;

				}else{
					this.confirmBox =true
				    this.config = "Any Changes will not be Saved, Do you wish to continue?"

				}
	

			}
			// localStorage.setItem('selectedPrevData',JSON.stringify({'id':self.currentId,'timezone':self.currentZone, 'date': self.dateToday }));

	
		}
		//  this.confirmBox =true
			//  this.config = "Changes made will not be saved.Do you want to proceed?"
	}
	cancelevent(event){
		// localStorage.setItem('selectedPrevData',JSON.stringify({'id':self.currentId,'timezone':self.currentZone, 'date': self.dateToday }));
		this.confirm = true;
		let locId;
		if(localStorage.getItem("selectedPrevData")){
			 locId = JSON.parse(localStorage.getItem("selectedPrevData")).id;
			 let ret = this.setIndex(locId)
			 if(ret){
				if(localStorage.getItem('dummydata')){
					let dummydata = JSON.parse(localStorage.getItem('dummydata'))
					this.processData(dummydata);
					this.filterPeople();
				}
			 }
		}	
		setTimeout( ()=>{
			this.confirm = false;
		})
		
	}

	setIndex(val){
		for(var i =0;i<this.locationList.location.length;i++){
			if(this.locationList.location[i].id == val){
				this.locationSelected = [i];
				return true;
			}
		}
	}

	locationSelect(event){
		let self = this;
		this.confirmBox =false
		if(localStorage.getItem("currentVal")){
			self.changeVal = JSON.parse(localStorage.getItem("currentVal"))
		}
		if(event==true){
			this.confirm =false
			this.sub = this.route.params.subscribe(params => {
				let temp = params.id.split('_');
				if(temp[1] && temp[1] != 'add'){
				  self.dateToday = this.timeZone.toLocal(temp[0]);
				  self.currentZone =	self.changeVal.zone;
				  self.currentId   =	self.changeVal.id;
				  self.maxDate = self.getCurrentDate(self.changeVal.zone)
				  if(this.timeZone.toLocal( this.dateToday)>=this.timeZone.toLocal( this.maxDate)){
					this.dateToday= this.maxDate;
			   }
				}
				else {
				  self.currentZone = 	self.changeVal.zone;
				  self.currentId   = 	self.changeVal.id;
				  self.dateToday   = self.getCurrentDate(	self.changeVal.zone);
				  localStorage.setItem('currentLoc',JSON.stringify({'id':self.changeVal.id,'zone':self.changeVal.id.currentZone, 'name':self.changeVal.name}));
				  self.maxDate = self.getCurrentDate(self.changeVal.zone)
				}
				if(temp[0] && self.init == 0){
					self.dateToday = this.timeZone.toLocal(temp[0]);
					self.maxDate = self.getCurrentDate(self.changeVal.timezone)
		
					if(this.timeZone.toLocal( this.dateToday)>=this.timeZone.toLocal( this.maxDate)){
						this.dateToday= this.maxDate;
				   }
				}
			});
			self.init = 1;
	    	  localStorage.setItem('selectedPrevData',JSON.stringify({'id':self.currentId,'zone':self.currentZone, 'date': self.dateToday }));
		}
	}


 	 getCurrentDate(input) {
		let userData = JSON.parse(this.cookieService.get("user-data"));
		if (userData.apply_datetime_conversion == '1' && input != undefined) {
			let value = moment().tz(input).format('Z');
			value = this.timeStringToFloat(value);
			value = value.replace(":", '.');
			return this.calcTime(value)
		}
		else {
			return new Date();
		}
	}

	timeStringToFloat(time) {
		var hoursMinutes = time.split(/[.:]/);
		var hours = parseInt(hoursMinutes[0], 10);
		var minutes = hoursMinutes[1] ? parseInt(hoursMinutes[1], 10) : 0;
		return (hours + minutes / 60).toString();
	}

	calcTime(offset, value?) {
		let d, utc, nd;
		if (value) {
			d = moment.utc(value).toDate();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
		else {
			d = new Date();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
	}

	getLocalDate(value, tz) {
		if (value) {
			let time = moment().tz(tz).format('Z');
			time = this.timeStringToFloat(time);
			time = time.replace(":", '.');
			return this.calcTime(time, value);
		}
		else {
			return new Date();
		}
	}

	override(){
		this.reason = true;
		this.rejectPopUp = true;
	}
	/**
	 * @ desc    : submit reason to override
	 * @ author  : vinod
	 */
	Submitreason(event){
		if(event.status == false){
			this.reasonTooverRide = event.value;
				this.overrides = 1;
				this.disableOverRide = true;
				if(this.people.length){
					for(var i=0;i<this.people.length;i++){
						if(this.people[i].punch_type == "Biometric"){
							this.people[i].disabled = false;
						}
					}
				}
				if(this.attendance.length){
					for(var i=0;i<this.attendance.length;i++){
						if(this.attendance[i].punch_type == "Biometric"){
							// && this.attendance[i].leave_type != 7 && this.attendance[i].leave_type != 8 && this.attendance[i].leave_type != 4
							this.attendance[i].disabled = false;
						}
					}
				}
				this.rejectPopUp = false;
	  		}else{
	  			this.rejectPopUp = false;
	  		}
		}
	/**
	  * @ desc    : submit reason to override
	  * @ author  : Nilena 
	  */
	tosubmit(){
		// this.confirmBox = true;
	  }

	  ngOnDestroy(){
		localStorage.removeItem("currentVal");
		localStorage.removeItem("selectedPrevData");
		localStorage.removeItem("prevdate");
		localStorage.removeItem("currentLoc");

	}
	}
	
	  