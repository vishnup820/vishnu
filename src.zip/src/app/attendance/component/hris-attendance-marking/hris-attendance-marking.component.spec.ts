import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HrisAttendanceMarkingComponent } from './hris-attendance-marking.component';

describe('HrisAttendanceMarkingComponent', () => {
  let component: HrisAttendanceMarkingComponent;
  let fixture: ComponentFixture<HrisAttendanceMarkingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HrisAttendanceMarkingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HrisAttendanceMarkingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
