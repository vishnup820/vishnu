/*
*  @desc   :component for add attendance report
*  @author :vinod
*/
import { Component, OnInit,ChangeDetectorRef } from '@angular/core';

import { ReportingService } from '../../services/reporting.service';
import { CookieService } from 'ngx-cookie-service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieDataService } from '../../../shared/services/cookie-data/cookie-data.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
// import { LopReportService } from '../../../report/services/lop-report/lop-report.service';

declare var require: any;
var moment = require('moment');

@Component({
	selector: 'app-hris-attendance-report',
	templateUrl: './hris-attendance-report.component.html',
	styleUrls: ['./hris-attendance-report.component.css']
})

export class HrisAttendanceReportComponent implements OnInit {

	dailyReport 		: Array<object> = [];
	statistics 			: any;
	chosenObject		: any = {
		userList : []
	}
	queryObject 		: any = {};
	fromDate    		: any;
	toDate      		: any;
	showAdvanceFilter   : boolean = false;
	usedata				: any;
	heading				: any;
	minDate 			: any;
	maxDate 			: any;
	listId              : any;
	old                 : any;
	old2                : any;
	new                 : any;
	cancel              : boolean = false;
	filterSort 			: any = {};
	j                   : number = 1;
	initialLoad         : number = 1;
	datechange          : boolean = false;
	// onduty           :boolean;
	filterActive        : boolean =false;
    selectedItems		: any;
	status      		: object = {
		absent				: {label: "Absent", class:"absent"},
		present				: {label: "Present", class:"present"},
		leave				: {label: "Leave", class:"leave"},
		firstHalfAbsent 	: {label: "First Half Absent", class:"first-half-absent"},
		secondHalfAbsent 	: {label: "Second Half Absent", class:"sec-half-absent"},
		firstHalfLeave 		: {label: "First Half Leave", class:"first-half-leave"},
		secondHalfLeave 	: {label: "Second Half Leave", class:"sec-half-leave"},
		weekend             : {label: "Week End", class:"absent"},
		holiday				: {label: "Holiday", class:"absent"},
		lossofpay           : {label: "Loss Of Pay", class:"lop"}
		// onDuty				: {label: "On Duty", class:"present"},
	}

	filterVal               : boolean       = false;
	firstHalfLeaveabsent	: boolean 	    = false;
    firstHalfLeavepresent	: boolean 	    = false;
    secondHalfLeaveabsent	: boolean 	    = false;
    secondHalfLeavepresent	: boolean 	    = false;
    firstHalfabsentpresent  : boolean       = false;
    firstHalfpresentabsent  : boolean       = false;
    firstHalfpresentLop 	: boolean       = false;
    firstHalfLopPresent 	: boolean       = false;
    firstHalfleaveLop   	: boolean 		= false;
    firstHalfLopLeave   	: boolean    	= false;
    firstHalfAbsentLop  	: boolean       = false;
    firstHalfLopAbsent  	: boolean   	= false;

    bAnyLop 				: boolean 		= false;
    present					: boolean 	 	= false;
    leave					: boolean  	 	= false;
    absent					: boolean     	= false;
    onduty					: boolean       = false;
    weekend					: boolean       = false;
    holiday					: boolean       = false;
    fulllop    				: boolean       = false;
    leaveStatus				: any;
    leaveTypeEvent   		: any;
    selectedLeaveStatus		: any 			= [];
    k						: number		= 1
    leaveId 				: any;
    userdetails 			: any;

    bLopFst					: boolean 		= false;
    bLopSnd 				: boolean 		= false;
    bLeaveLop				: boolean       = false;
    bLop					: boolean 		= false;
    clearfilter             : boolean       = false;
    todateObj    			: any ={};
    count					: number = 0;
    userlocId				: any;
    userzone				: any;
    keepOlddates			: number = 0;
    sdate 					: any;
    edate 					: any;
    finMonths				: any;
    selectedItemsPayperiod  : any = [];
    endcycle				: any;
    select				    : boolean = false;
    counter					: number = 1;
    currentPrevfrom  		: any;		 
	currentPrevto			: any;
	preventInitialCall      : number = 1;
	userId									:	any;

	constructor(
		private reportingService: ReportingService,
		private cookieService: CookieService,
		private loader: LoaderActionsService,
		private cservice:CookieDataService,
		private cdr: ChangeDetectorRef,
		private timeZone : TimezoneDetailsService
		) { }

	ngOnInit() {

	   		// this.toDate = this.timeZone.getCurrentDate();
	   this.loader.display(true);

	    let dateToday  = this.timeZone.getCurrentDate();
		// this.queryObject = {
		// 	frmdte: `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-1`,
		// 	todte : `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-${dateToday.getDate()}`,
		// }
		// this.fromDate = new Date(this.queryObject['frmdte']);
		// this.toDate   = new Date(this.queryObject['todte']);
		// this.old =  Object.assign({},this.queryObject);
  // 	 	this.fromDate = this.timeZone.toLocal(this.queryObject['frmdte'])
		// this.toDate   = this.timeZone.toLocal(this.queryObject['todte']);
  	 	this.maxDate = dateToday;
	   if(this.cookieService.get("user-data")){
  	    	this.usedata =	JSON.parse(this.cookieService.get("user-data"));
  	    	this.userlocId = JSON.parse(this.cookieService.get("user-data")).location_id;
					this.userzone  = JSON.parse(this.cookieService.get("user-data")).time_zone;
					this.minDate =	this.timeZone.toLocal(this.usedata.financialMin_date);
					this.userId=this.usedata.user_id;
			this.toGetFinanicalYear()
			if (this.usedata.role_id ==1 || this.usedata.role_id ==5){
				this.loadReport(this.usedata.user_id)
				this.heading="My Attendance Report"
			}else{
				this.loadUser()
				this.heading="Employee Attendance Report"
			}
  	 	}
		 // this.getCurrentDateobj(this.queryObject['frmdte']);

	}

	toGetFinanicalYear(){

		this.reportingService.getCurrentFinancialYear( (this.userId)?this.userId:null, (this.userlocId)?this.userlocId:null,(this.userzone)?this.userzone:null,res => {
			// res = {
			// 	"data": [

			// 		{
			// 			"display_period": "01 Apr 2018 - 30 Apr 2018",
			// 			"frmDate": "2018-04-01",
			// 			"toDate": "2018-04-30"
			// 		},
			// 		{
			// 			"display_period": "01 May 2018 - 31 May 2018",
			// 			"frmDate": "2018-05-01",
			// 			"toDate": "2018-05-31"
			// 		},
			// 		{
			// 			"display_period": "01 Jun 2018 - 30 Jun 2018",
			// 			"frmDate": "2018-06-01",
			// 			"toDate": "2018-06-30"
			// 		},
			// 		{
			// 			"display_period": "01 Jul 2018 - 31 Jul 2018",
			// 			"frmDate": "2018-07-01",
			// 			"toDate": "2018-07-31"
			// 		},
			// 		{
			// 			"display_period": "01 Aug 2018 - 31 Aug 2018",
			// 			"frmDate": "2018-08-01",
			// 			"toDate": "2018-08-31"
			// 		},
			// 		{
			// 			"display_period": "01 Sep 2018 - 30 Sep 2018",
			// 			"frmDate": "2018-09-01",
			// 			"toDate": "2018-09-30"
			// 		},
			// 		{
			// 			"display_period": "01 Oct 2018 - 31 Oct 2018",
			// 			"frmDate": "2018-10-01",
			// 			"toDate": "2018-10-31"
			// 		},
			// 		{
			// 			"display_period": "01 Nov 2018 - 30 Nov 2018",
			// 			"frmDate": "2018-11-01",
			// 			"toDate": "2018-11-30"
			// 		},
			// 		{
			// 			"display_period": "01 Dec 2018 - 31 Dec 2018",
			// 			"frmDate": "2018-12-01",
			// 			"toDate": "2018-12-31"
			// 		},
			// 		{
			// 			"display_period": "01 Jan 2019 - 31 Jan 2019",
			// 			"frmDate": "2019-01-01",
			// 			"toDate": "2019-01-31"
			// 		},
			// 		{
			// 			"display_period": "01 Feb 2019 - 28 Feb 2019",
			// 			"frmDate": "2019-02-01",
			// 			"toDate": "2019-04-02"
			// 		},
			// 		{
			// 			"display_period": "01 Mar 2019 - 31 Mar 2019",
			// 			"frmDate": "2019-03-01",
			// 			"toDate": "2019-03-31"
			// 		},				
			// 		{
			// 			"display_period": "01 Apr 2019 - 30 Apr 2019",
			// 			"frmDate": "2019-04-01",
			// 			"toDate": "2019-04-30"
			// 		},
			// 		{
			// 			"display_period": "01 May 2019 - 31 May 2019",
			// 			"frmDate": "2019-05-01",
			// 			"toDate": "2019-05-31"
			// 		},
			// 		{
			// 			"display_period": "01 Jun 2019 - 30 Jun 2019",
			// 			"frmDate": "2019-06-01",
			// 			"toDate": "2019-06-30"
			// 		},
			// 		{
			// 			"display_period": "01 Jul 2019 - 31 Jul 2019",
			// 			"frmDate": "2019-07-01",
			// 			"toDate": "2019-07-31"
			// 		},	      
			// 		 {
			// 		"display_period": "01 Aug 2019 - 31 Aug 2019",
			// 		"frmDate": "2019-08-01",
			// 		"toDate": "2019-08-31"
			// 		},
			// 		{
			// 			"display_period": "01 Sep 2019 - 30 Sep 2019",
			// 			"frmDate": "2019-09-01",
			// 			"toDate": "2019-09-30"
			// 		},
			// 		{
			// 			"display_period": "01 Oct 2019 - 31 Oct 2019",
			// 			"frmDate": "2019-10-01",
			// 			"toDate": "2019-10-31"
			// 		},
			// 		{
			// 			"display_period": "01 Nov 2019 - 30 Nov 2019",
			// 			"frmDate": "2019-11-01",
			// 			"toDate": "2019-11-30"
			// 		},
			// 		{
			// 			"display_period": "01 Dec 2019 - 31 Dec 2019",
			// 			"frmDate": "2019-12-01",
			// 			"toDate": "2019-12-31"
			// 		},
			// 		{
			// 			"display_period": "01 Jan 2020 - 31 Jan 2020",
			// 			"frmDate": "2020-01-01",
			// 			"toDate": "2020-01-31"
			// 		},
			// 		{
			// 			"display_period": "01 Feb 2020 - 29 Feb 2020",
			// 			"frmDate": "2020-02-01",
			// 			"toDate": "2020-02-29"
			// 		},
			// 		{
			// 			"display_period": "01 Mar 2020 - 31 Mar 2020",
			// 			"frmDate": "2020-03-01",
			// 			"toDate": "2020-03-31"
			// 		},
			// 		{
			// 			"display_period": "01 Apr 2020 - 30 Apr 2020",
			// 			"frmDate": "2020-04-01",
			// 			"toDate": "2020-04-06"
			// 		}
			// 	],
			// 	"endCycle": "29",
			// 	"status": "OK"
			// }
			 
			this.finMonths     = res.data;
			  this.endcycle = res.endCycle;
				this.selectedItemsPayperiod = [this.getIndex(this.finMonths,res.endCycle)]; 
       		})
	}

	getlastday(y,m){
    	return  new Date(y, m, 0).getDate();                      
    }
	getIndex(dateObj,endcycle) {
    let last = false;
    let tempDate;
    let currDate = this.getCurrentDate(this.userzone);
    let date = this.timeZone.getCurrentDate()
    let k = currDate.getMonth();
    if(endcycle == "29"){
      last  = true;
        endcycle = this.getlastday(currDate.getFullYear(),(currDate.getMonth()))
    }
    if ((currDate.getDate() > Number(endcycle)) && !last) {
      tempDate = moment(this.timeZone.toLocal(date.getFullYear() + "-"+ Number(date.getMonth()+1) + "-" + Number(endcycle)), 'MM-DD-YYYY HH:mm');
    }else if((currDate.getDate() < Number(endcycle)) && !last){
      tempDate = moment(this.timeZone.toLocal(date.getFullYear() + "-"+ Number(date.getMonth()) + "-" + Number(endcycle)), 'MM-DD-YYYY HH:mm');
    }else if((currDate.getDate() == Number(endcycle)) && !last){
      tempDate = moment(this.timeZone.toLocal(date.getFullYear() + "-"+ Number(date.getMonth()) + "-" + Number(endcycle)), 'MM-DD-YYYY HH:mm');
    }
    else{
      tempDate = moment(this.timeZone.toLocal(date.getFullYear() + "-"+ Number(date.getMonth()+1) + "-" + 1), 'MM-DD-YYYY HH:mm');
	}
    for(var i =0;i<dateObj.length;i++){
       let  h = this.formatForApi(date);
       if(moment(h).isBetween(moment(dateObj[i].frmDate).subtract(1,'d'), moment(dateObj[i].toDate).add(1,'d'))){
		return i;
       } 
      //   if(this.timeZone.toLocal(dateObj[i].frmDate)<tempDate.toDate() && this.timeZone.toLocal(dateObj[i].toDate)>tempDate.toDate()){
      //    return i;
      // }
    }
  }
  	formatForApi(inputDate) {
    var date = this.timeZone.toLocal(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
      }
      else
        return undefined;
  }
	setCurrentDate(){
	let dateToday  = this.timeZone.getCurrentDate();
		this.todateObj = {
			frmdte: `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-1`,
			todte : `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-${dateToday.getDate()}`,
		}
	}

	// getCurrentDateobj(dateinput){

	// 	var localTime = new Date(dateinput).toLocaleString("en-US", {timeZone: this.usedata.time_zone});
	// 	return  new Date(localTime);
	// }
	
	
	selectedMonth(event,ev){
		if(event && event.selected && event.selected.length){
			// this.selected = true;
			let k = event.selected[0].frmDate.split('-');
			let j = event.selected[0].toDate.split('-');
			this.queryObject = {
				frmdte: event.selected[0].frmDate,
				todte : event.selected[0].toDate,
			}
			this.fromDate = this.timeZone.toLocal(this.queryObject['frmdte']);
			this.toDate   = this.timeZone.toLocal(this.queryObject['todte']);
			this.currentPrevfrom    = this.fromDate;
			this.currentPrevto		= this.toDate;
	
		}
	}
	dateChange(label,date,ev) {
		label == 'fromDate' ?
			this.queryObject['frmdte'] = this.formatForApi(this.fromDate)
		:
			this.queryObject['todte'] = this.formatForApi(this.toDate);
		if(this.initialLoad == 2){
			this.new = this.queryObject
		}
		if(this.currentPrevfrom && this.fromDate && this.currentPrevto && this.toDate){
			// console.log(this.currentPrevfrom.toLocaleDateString())
			// console.log(this.fromDate.toLocaleDateString())
			// console.log(this.currentPrevto.toLocaleDateString())

			// console.log(this.toDate.toLocaleDateString())

			if(this.initialLoad == 2 && ((this.currentPrevfrom.toLocaleDateString() != this.fromDate.toLocaleDateString()) || (this.currentPrevto.toLocaleDateString() != this.toDate.toLocaleDateString()))){
				this.selectedItemsPayperiod = [];
			}
			
		}
		// if(this.initialLoad == 2 && (!this.selected) && (this.counter == 5 || this.counter > 5)){
		// 	this.selectedItemsPayperiod = [];
		// }
		// this.counter = this.counter+1;
		this.initialLoad = 2;
		// this.selected = false;
		// this.fromDate = this.timeZone.toLocal(this.queryObject['frmdte']);
		// this.toDate   = this.timeZone.toLocal(this.queryObject['todte']);
	}
	selectedLeave(event){
		if(event.selected.length>0){
			this.leaveTypeEvent = event.selected[0].name;
			this.leaveId = event.selected[0].id;
		}
		else{
			this.leaveTypeEvent = null;
			this.leaveId = null;
		}

	}


	showSelectedItem(){
		if(this.leaveStatus){
			for(var i=0;i<this.leaveStatus.length;i++){
				if(this.leaveStatus[i].name == this.leaveTypeEvent){
					this.selectedLeaveStatus = [i]
				}
			}
		}
	}

// filterApply(){
// 	if(this.leaveId ){
// 		this.loadReport();
// 	}
// else{
// 	this.filterActive = false;
// }

// }

	filterCancel(){
	if(this.filterVal){
		this.loader.display(true);
			this.filterVal = false;
			this.cancel = true;
			if(this.cookieService.get("user")){
				this.userdetails =	JSON.parse(this.cookieService.get("user"));
				this.usedata.user_id = this.userdetails.details.selected[0].id;
				for(var  i=0;i< this.chosenObject.userList;i++){
					if(this.chosenObject.userList[i].id == this.usedata.user_id){
						this.selectedItems = [i];
					}
				}
			}
			this.selectedLeaveStatus = [];
			let dateToday  = this.timeZone.getCurrentDate();
			this.queryObject = {
				frmdte: `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-1`,
				todte : `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-${dateToday.getDate()}`,
			}
			this.fromDate = this.timeZone.toLocal(this.queryObject['frmdte']);
			this.toDate   = this.timeZone.toLocal(this.queryObject['todte']);


			this.maxDate = dateToday;
			this.count = 0;
			if (this.usedata.role_id ==1 || this.usedata.role_id ==5){
					this.loadReport(this.usedata.user_id)
					this.heading="My Attendance Report"
				}else{
					this.loadUser()
					this.heading="Employee Attendance Report"
				}
		    this.selectedItemsPayperiod = [this.getIndex(this.finMonths,this.endcycle)];
		}
		else{
			this.loader.display(true);
			this.selectedLeaveStatus = [];
			this.filterActive =false;
			let dateToday  = this.timeZone.getCurrentDate();
			this.queryObject = {
				frmdte: this.old.frmdte,
				todte : this.old.todte
			}
			// this.queryObject = {
			// 	frmdte: `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-1`,
			// 	todte : `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-${dateToday.getDate()}`,
			// }
			this.fromDate = this.timeZone.toLocal(this.queryObject['frmdte']);
			this.toDate   = this.timeZone.toLocal(this.queryObject['todte']);	
	
			this.maxDate = dateToday;
			this.selectedItemsPayperiod = [this.getIndex(this.finMonths,this.endcycle)];
			this.loader.display(false);

		}

	}

	/*
*  @desc   :to load the report
*/

	loadReport(id?) {
		if(this.j == 2 && this.cancel != true){
			if(this.leaveId != null){
				this.filterActive = true;
			}
			else if(((new Date(this.old.frmdte) != new Date(this.new.frmdte)) || (new Date(this.old.todte) != new Date(this.new.todte)))){
				this.filterActive = true;
			}
		}
		else{
			this.filterActive = false;
			this.cdr.detectChanges();
		}
		if (this.usedata.role_id ==1 || this.usedata.role_id ==5){
			this.loadData(this.usedata.user_id)
				this.heading="My Attendance Report"
		}else{
			this.loadData(this.listId);
				this.heading="Employee Attendance Report"
			}
			this.j = 2;
			this.cancel = false;
			this.clearfilter = false;
	}

    loadData(ids){
    	if(this.count == 0){
    		this.queryObject = {
			frmdte: '',
			todte : '',
			}
    	}
    	let self = this;
		this.queryObject['id'] = ids;
		 self.loader.display(true);
		this.reportingService.getReport(this.userlocId,this.userzone,this.leaveId,this.queryObject,function(res) {
			if (res.data.attendance_details && res.data.attendance_details.length) {
				self.dailyReport = res.data['attendance_details'];

				self.queryObject = {
					frmdte: res.startDate,
					todte : res.endDate,
				}
				self.old =  Object.assign({},self.queryObject);
  				self.fromDate = self.timeZone.toLocal(self.queryObject['frmdte'])
				self.toDate   = self.timeZone.toLocal(self.queryObject['todte']);
			}
			else{
				self.queryObject = {
					frmdte: res.startDate,
					todte : res.endDate,
				}
				self.old =  Object.assign({},self.queryObject);
  				self.fromDate = self.timeZone.toLocal(self.queryObject['frmdte'])
				self.toDate   = self.timeZone.toLocal(self.queryObject['todte']);
				self.dailyReport=[];
				 // self.loader.display(false);
			}
			if(res.data.attendance_days && res.data.attendance_days.length) {
				self.statistics = res.data['attendance_days'][0];
				// self.loader.display(false);
			}
			if(self.k == 1){
				if(res.statusList && res.statusList.length>0){
					self.leaveStatus = res.statusList;
				}
			}
			if(self.keepOlddates == 0){
					self.sdate = res.startDate;
					self.edate = res.endDate;
			}
			self.k = 0;
			self.keepOlddates = 1;
			self.loader.display(false);
		});
		self.count = 1;
    }


/*
*  @desc   :to load the employee list to single selection
*  @author :hashid
*/

	loadUser() {
		let self = this;
		this.reportingService.getUser(this.usedata, (response) => {
			if(response.data && response.data.length) {
				self.chosenObject.userList = response.data
				for (var i = 0; i < self.chosenObject.userList.length; i++) {
							self.chosenObject.userList[i].name = self.chosenObject.userList[i].first_name + " " + self.chosenObject.userList[i].last_name + " (" + self.chosenObject.userList[i].code + ")";
				}
				for(var i=0;i<self.chosenObject.userList.length;i++){
					if(self.chosenObject.userList[i].id == this.usedata.user_id){
						this.selectedItems = [i];
					}
				}
			}
		})
	}

/*
*  @desc   to pick the date change
*  @author :hashid
*/

	clearDate() {
		// this.filterActive = false;
		this.clearfilter  = true;
		this.cancel = true;
		this.selectedLeaveStatus = [];
		if(this.cookieService.get("user")){
			this.userdetails =	JSON.parse(this.cookieService.get("user"));
			this.usedata.user_id = this.userdetails.details.selected[0].id;
			for(var  i=0;i< this.chosenObject.userList;i++){
				if(this.chosenObject.userList[i].id == this.usedata.user_id){
					this.selectedItems = [i];
				}
			}
		}
		let dateToday = this.timeZone.getCurrentDate();
		// let frmdte = `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-1` ;
		// let todte  = `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-${dateToday.getDate()}`;
		let frmdte = this.sdate;
		let todte  = this.edate;
		this.fromDate = this.timeZone.toLocal(frmdte);
		this.toDate   = this.timeZone.toLocal(todte);

		this.maxDate = dateToday;
		setTimeout(() => {
			this.loadReport();

		},1000)
		// this.clearfilter = false;
	}

	
	/*
*  @desc   :cpoplet the report depent on differnt user
*  @author :hashid
*/

	userSelected(user) {
	  this.userId=user.selected[0].id;
		this.userlocId = user.selected[0].location_id;
		this.userzone  = user.selected[0].timezone
		if(this.filterActive == false){
			this.cancel = true;
		}
		let dateToday  = this.getCurrentDate(user.selected[0].timezone);
		// this.queryObject = {
		// 	frmdte: `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-1`,
		// 	todte : `${dateToday.getFullYear()}-${dateToday.getMonth()+1}-${dateToday.getDate()}`,
		// }
		this.count = 0;
		this.keepOlddates = 0;
	    this.cservice.saveCookieOnUserSelection(user);
		this.listId =  user.selected[0].id
		this.loadReport(user.selected[0].id);
		if(this.preventInitialCall == 1){
			this.toGetFinanicalYear()
		}
       	this.preventInitialCall = 1;
		this.maxDate = dateToday;
	}

	/*
*  @desc   :to post the attendance
*  @author :vinod
*/

	markStatus(data) {
		let label                       : string ='';
		let classname                   : string = '';

        classname = 's-attendance-' + data.label_code ;
        
        label = data.label ;
	     // if(classname != undefined && label != undefined) {
	    	return `<p class='${classname}'><span></span>${label}</p>`
	    // };
	}

	  	/**
	 * @ desc   :to perform sorting
	 * @ author  : hashid
	 */
  		sortDate(label) {
		let currentSortStatus = this.filterSort[label]?this.filterSort[label].rev: true;
		this.filterSort = {};
		this.filterSort[label] = {rev:!currentSortStatus}
		this.filterSort["label"] = label;
		this.queryObject.sort = (this.filterSort[label].rev == true)?`${'sortField='}${label}${'&sort=Desc'}`:`${'sortField='}${label}${'&sort=Asc'}`
		this.loadReport();
	}

	getCurrentDate(input) {
		let userData = JSON.parse(this.cookieService.get("user-data"));
		if (userData.apply_datetime_conversion == '1') {
			let value = moment().tz(input).format('Z');
			value = this.timeStringToFloat(value);
			value = value.replace(":", '.');
			return this.calcTime(value)
		}
		else {
			return new Date();
		}
	}

	timeStringToFloat(time) {
		var hoursMinutes = time.split(/[.:]/);
		var hours = parseInt(hoursMinutes[0], 10);
		var minutes = hoursMinutes[1] ? parseInt(hoursMinutes[1], 10) : 0;
		return (hours + minutes / 60).toString();
	}

	calcTime(offset, value?) {
		let d, utc, nd;
		if (value) {
			d = moment.utc(value).toDate();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
		else {
			d = new Date();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
	}
}
