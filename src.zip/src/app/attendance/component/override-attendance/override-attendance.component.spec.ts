import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OverrideAttendanceComponent } from './override-attendance.component';

describe('OverrideAttendanceComponent', () => {
  let component: OverrideAttendanceComponent;
  let fixture: ComponentFixture<OverrideAttendanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OverrideAttendanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OverrideAttendanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
