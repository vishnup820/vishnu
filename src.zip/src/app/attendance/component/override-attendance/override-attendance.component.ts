import {
	Component,
	OnInit,
	ChangeDetectorRef
} from '@angular/core';
import {
	RouterModule,
	Routes,
	Router
} from '@angular/router';

import {
	ActivatedRoute
} from '@angular/router';

import {
	MarkAttendanceService
} from '../../services/mark-attendance.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

declare var require: any;
var moment = require('moment');

@Component({
  selector: 'app-override-attendance',
  templateUrl: './override-attendance.component.html',
  styleUrls: ['./override-attendance.component.css']
})
export class OverrideAttendanceComponent implements OnInit {

    private sub			: any;
	selectedId          : any;
	currentZone         : any;
	currentId           : any;
	attendance			: any = [];
	people				: any = [];
	selectedEmp			: any = [];
	locationList        : any = [];
	locationSelected    : any = [];
	showForm			: boolean = false;
	disableClick        : boolean = false;
	dateToday			: Date;
	currentDate         : Date;
	queryObject			: any = {};
	minDate             : Date;
	nodata:boolean = false;
	addClass        :boolean=false;
	payPeriodStatus :boolean = false;
	sDate : any;
	eDate   :any;
	usedata : any;
	chosenObject		: any = {
		selected: [],
		status: [{
				label: 'Absent',
				value: 1
			},
			{
				label: 'Present',
				value: 2
			},
			{
				label: 'On Duty',
				value: 3
			},
			{
				label: 'Leave',
				value: 4
			}
		],
		setEdit: {
			attendance: [],
		},
		select: {
			employee: {},
			status: {}
		},
	}
	overrides:number = 0;
	selectedItems	: any = [];
	disableOverRide	: boolean = false;
	rejectPopUp     : boolean = false;
	reasonTooverRide : any;
	reason			 : boolean = false;
	ondutyflag 		 : boolean = false;
	init 			 : number  = 0;
	finalSave        : boolean = false;
	temp3		     : any;
	reasonTo		 : any;
	submitted		 : boolean = false;
	peopleloader     : boolean = false;
	maxDate :any
	overrideStat	 : any =    [{status:"Current status",id:0,val:true},
					   	  {status:"Absent" ,id:1,val:false},
					   	  {status:"Present",id:2,val:false}
					   ]
					   str:any;
  constructor(
		private markAttendanceService : MarkAttendanceService,
		private route                 : ActivatedRoute,
		private notificationService   : NotificationService,
		private _router               : Router,
		private loader                : LoaderActionsService,
		private changeDetectorRef     : ChangeDetectorRef,
		private cookieService         : CookieService,
		private timeZone              : TimezoneDetailsService
		) {}

  ngOnInit() {
		let self = this;
		if(this.cookieService.get("user-data")){
			  this.usedata =	JSON.parse(this.cookieService.get("user-data"));
			  this.minDate=this.timeZone.toLocal(this.usedata.financialMin_date);
  	    }
		self.currentZone = JSON.parse(this.cookieService.get("user-data")).time_zone;
		self.maxDate = this.timeZone.getCurrentDate()
		self.changeDetectorRef.detectChanges();
		this.sub = this.route.params.subscribe(params => {
			let temp	= 	params.id.split('_');
			self.temp3  =   temp[2]
			self.dateToday = this.timeZone.toLocal(temp[0]);
			if(temp[1] != 'add'){
			 self.selectedId = temp[1];
			 self.disableClick = true;
			}
		});
		self.loader.display(true);
		this.markAttendanceService.getLocations(response => {
			if (response.status == 'OK') {
				self.locationList = response.data;
					let temp = JSON.parse(localStorage.getItem("currentLoc"));
					// let loc  = JSON.parse(localStorage.getItem("currentLocid"));
					if(temp){
					for (let i = 0; i < self.locationList.location.length; i++) {
						if (self.locationList.location[i].id == temp.id) {
							this.locationSelected = [i];
							this.currentZone = self.locationList.location[i].timezone;
							this.currentId   = self.locationList.location[i].id;
							this.currentDate = this.getCurrentDate(self.locationList.location[i].timezone);
						}
					}}else{
						for (let i = 0; i < self.locationList.location.length; i++) {
							if (self.locationList.location[i].id == this.usedata.location_id) {
								this.locationSelected = [i];
								this.currentZone = self.locationList.location[i].timezone;
								this.currentId   = self.locationList.location[i].id;
								this.currentDate = this.getCurrentDate(self.locationList.location[i].timezone);
							}
						}
					}
				}
			else {
				self.loader.display(false);
				self.locationList = [];
			}
		})
		// this.getValueWithPromise();
		// this.getValueWithAsync();
	}

	checkValue(str,data,index){
		this.str = str
		for(var i = 0;i<this.overrideStat.length;i++){
				if(this.overrideStat[i].id == data.id){
					this.overrideStat[i].val = true;
				}else{
					this.overrideStat[i].val = false;
				}
			}
				this.changeDetectorRef.detectChanges();
	}
	toggleForm(event) {
		this.showForm = !this.showForm;
		if(this.showForm){
      		this.addClass = true;
			this.submitted = false;
			document.getElementById("cedit").innerHTML = '';
			this.reasonTo = null;
    	}
    	else{
      		this.addClass  = false;
      		this.submitted = false;
      		this.reasonTo = null;
      		document.getElementById("cedit").innerHTML = '';
    	}
    	
		// this.changeDetectorRef.detectChanges();
		event ? event.stopPropagation() : '';
		this.selectedItems = [];
		this.str = "Current status";
		this.overrideStat =    [{status:"Current status",id:0,val:true},
					   	  {status:"Absent" ,id:1,val:false},
					   	  {status:"Present",id:2,val:false}
					   ]
		this.changeDetectorRef.detectChanges();
		// this.showFirststatus();
	}
		// showFirststatus(){
		// for(var i = 0;i<this.overrideStat.length;i++){
		// 		if(this.overrideStat[i].id == 1){
		// 			this.overrideStat[0].val = true;
		// 		}else{
		// 			this.overrideStat[i].val = false;
		// 		}
		// }
	// }

	reasonEntered(model){
	 if(model == '' || model == '' || !model.replace(/\s/g, '').length){
     		this.submitted = true;
     	}else{
     		this.submitted = false;
     	}
     }
	/**
	 * @ desc   :to get added emplyees attendance
	 * @ author  : vinod
	 */


	submitForm() {
	  if(this.reasonTo == null || this.reasonTo =='' || this.chosenObject.select.employee.selected.length<=0){
	  	this.submitted = true;
	  	this.showForm  = true;
	  }
	  else if(this.reasonTo && !this.reasonTo.replace(/\s/g, '').length){
	  		this.submitted = true;
	  		this.showForm  = true;
	  }
	  else{
	  	this.submitted = false;
		let employee = this.chosenObject.select.employee.selected;
		let dummy = [];

		employee.map((item, index) => {
			dummy.unshift({
				id: item.id,
				reason : this.reasonTo,
				first_name: item.first_name,
				last_name: item.last_name,
				application_type:item.application_type,
				leave_type: item.leave_type,
				code:item.code,
				first_half_attendance: item.first_half_attendance,
				second_half_attendance: item.second_half_attendance,
				disable: true,
				photo  : item.photo,
				punch_type:(item.punch_type)?item.punch_type:'Biometric',
				fullname: this.usedata.first_name + " " + this.usedata.last_name,
				overrider:this.usedata.user_id
				// ,
				// disabled : (item.punch_type == 'Manual')?false:true

			})
		})
		if(dummy){
				if(this.str == "Current status"){
					// this.loadPeople();
				}else if(this.str == "Absent"){
					for(var i=0;i<dummy.length;i++){
						if(dummy[i].first_half_attendance == 1){
							dummy[i].first_half_attendance  = 2
						}
						if(dummy[i].second_half_attendance == 1){
							dummy[i].second_half_attendance  = 2
						}
				}
				}else{
					for(var i=0;i<dummy.length;i++){
						if(dummy[i].first_half_attendance == 2){
							dummy[i].first_half_attendance  = 1
						}
						if(dummy[i].second_half_attendance == 2){
							dummy[i].second_half_attendance  = 1
						}
					}
			}
		}
		dummy = this.processData(dummy);
		Array.prototype.unshift.apply(this.attendance,dummy);
		this.filterPeople();
		this.disableOverRide = false;
		this.showForm  = false;
		this.reasonTo = null;
		}

	}

	/**
	 * @ desc   :post final attandeance status routing to listing page
	 * @ author  : vinod
	 */

	finalAttendanceconfirmed() {
		let self = this;
		self.loader.display(true);
		let userData = JSON.parse(self.cookieService.get("user-data"));
		self.queryObject.date = self.generateQuery(Date);
		let choosenobjSubmit = []
		// choosenobjSubmit = this.returnFinalObj(this.attendance,this.chosenObject.selected);
		self.markAttendanceService.postBiometricAttendance(self.chosenObject.selected, self.queryObject.date,self.currentZone,self.currentId,function(res) {
			if (res.status == "OK") {
				self.loader.display(false);
				setTimeout(() => {
					self._router.navigate(['modules/attendance/override-listing']);
				}, 2000);
				self.notificationService.alertBoxValue("success", "Attendance Override Finished Successfully");
				self.reasonTooverRide = null;
			}
			else {
				self.disableOverRide = false;
				self.loader.display(false);
				self.notificationService.alertBoxValue("error", res.message);
			}
		});
	}

	confirmSave(ev){
		if(ev == true){
      		this.finalSave = false;
      		this.finalAttendanceconfirmed();
     	}
    	else{
     	  this.finalSave = false;
    	}
	}
	finalAttendance() {
		this.finalSave = true;
	}
	/**
	 * @ desc   :to return manual and overrided attendence
	 * @ author  : vinod
	 */
	returnFinalObj(att,obj){
	let choosenobj = [];
	choosenobj= Array.from(obj);
	for(var i=0;i<att.length;i++){
			if((att[i].id == obj[i].user_id && att[i].punch_type=="Biometric" && att[i].disabled==true)){
				choosenobj.splice(i,1)
				// delete this.chosenObject.selected[i];
			}
		}
		return choosenobj;
	}
	/**
	 * @ desc   :to convert the date into requred format
	 * @ author  : vinod
	 */
	generateQuery(date) {
		let query = `${this.dateToday.getFullYear()}-${this.dateToday.getMonth() + 1}-${this.dateToday.getDate()}`;
		return query;
	}
	/**
	 * @ desc   : to check the field is editable
	 * @ author  : vinod
	 */
	// enableEdit(data, firstHalf) {
	// 	if(firstHalf) {
	// 		return (data.leave_type == 1 || data.leave_type == 3 || data.leave_type == 4 || data.leave_type == 5 || data.leave_type == 7 || data.leave_type == 8) ? true : false
	// 	} else {
	// 		return (data.leave_type == 1 || data.leave_type == 2 || data.leave_type == 4 || data.leave_type == 6 || data.leave_type == 7 || data.leave_type == 8) ? true : false
	// 	}
	// }
	enableEdit(data, firstHalf) {
		if(firstHalf) {
			return (data.first_half_attendance == 3 || data.first_half_attendance == 6) ? true : false
		} else {
			return (data.second_half_attendance == 3 || data.second_half_attendance == 6) ? true : false
		}
	}

	/**
	 * @ desc   :to return request body obj
	 * @ author  : vinod
	 */
	processData(data) {
		this.ondutyflag = false;
		let self = this;
		let f_half;
		let s_half;
		if (data) {
			data.forEach((item, index) => {
				item['attendance'] = {};
				if(item.first_half_attendance == 1 || item.first_half_attendance == 3) {
					if(item.first_half_attendance == 1){
						item['attendance'].firstClass = 'attendance-present';
						item['attendance'].firstHalf = [1];
						f_half = 1
					}
					else if(item.first_half_attendance == 3){
						self.ondutyflag = true;
						item['attendance'].firstClass = 'attendance-onduty';
						// item['attendance'].firstHalf = [1];
						item['attendance'].firstHalf = [2];
						f_half = 3
					}
				} else if (item.first_half_attendance == 2 || item.first_half_attendance == 6) {
					if(item.first_half_attendance == 2){
					 	item['attendance'].firstClass = 'attendance-absent';
						item['attendance'].firstHalf = [0];
						f_half = 2
					}
					else if(item.first_half_attendance == 6){
						item['attendance'].firstClass = 'attendance-leave';
						// item['attendance'].firstHalf = [0];
						item['attendance'].firstHalf = [3];
						f_half = 6
					}
				}

				if(item.second_half_attendance == 2 || item.second_half_attendance == 6) {
					if(item.second_half_attendance == 2){
						item['attendance'].secondClass = 'attendance-absent';
						item['attendance'].secondHalf = [0];
						s_half = 2;
					}
					else if(item.second_half_attendance == 6){
						item['attendance'].secondClass = 'attendance-leave';
						// item['attendance'].secondHalf = [0];
						item['attendance'].secondHalf = [3];
						s_half = 6;
					}
				} else if(item.second_half_attendance == 1 || item.second_half_attendance == 3) {
					if(item.second_half_attendance == 1){
						item['attendance'].secondClass = 'attendance-present';
						item['attendance'].secondHalf = [1];
						s_half = 1;
					}
					else if(item.second_half_attendance == 3){
						self.ondutyflag = true;
						item['attendance'].secondClass = 'attendance-onduty';
						// item['attendance'].secondHalf = [1];
						item['attendance'].secondHalf = [2];
						s_half = 3;
					}
				}
				// if(!self.isBiometricDisabled(item.id)) { 
			    // if(item.punch_type == 'Manual' || (item.punch_type == "Biometric" && item.disable == false))
					// first_half_attendance:  (item && item.attendance && item.attendance.firstHalf && (item.attendance.firstHalf[0]  == 0 || item.attendance.firstHalf[0]  == 3))? 0:1,
					// second_half_attendance: (item && item.attendance && item.attendance.secondHalf && (item.attendance.secondHalf[0] == 0 || item.attendance.secondHalf[0]  == 3))? 0:1,
				self.chosenObject.selected.unshift({
					user_id: item.id,
					// leave_type:item.leave_type,
					reason 	: (item.reason)?item.reason:null,
					dte: `${this.dateToday.getFullYear()}-${this.dateToday.getMonth() + 1}-${this.dateToday.getDate()}`,
					first_half_attendance : f_half,
					second_half_attendance : s_half,
					punch_type : item.punch_type,
					added_by   : (item.overrider)?item.overrider:null
				})
				// }
			
			})
		}
		return data;
	}

	filterPeople() {
		let dummy:any =[];
		let peopleDummy = [];
		this.attendance.map((item, index) => {
			if(dummy.indexOf(item.id) == -1)
				dummy.push(item.id)
		})
		this.people.map((item, index) => {
			if(dummy.indexOf(item.id) ==-1)
				peopleDummy.push(item)
		});
	    this.people = JSON.parse(JSON.stringify(peopleDummy));
	}

	/**
	 * @ desc   :load the attendance list
	 * @ author  : vinod
	 */
	loadAttendance() {
		let self = this;
		self.loader.display(true);
		// let curDate = self.timeZone.getCurrentDate();
		let curDate = self.timeZone.getCurrentZoneDate(self.currentZone);
		this.queryObject.sortField = 'id';
		this.queryObject.date = this.generateQuery(Date);
		if (this.queryObject && this.currentZone && this.currentId)
			this.markAttendanceService.getAttendanceOverride(this.queryObject, this.currentZone, this.currentId, function(res) {
				// self.sDate = res.startDate;
				// self.eDate = res.endDate;
				// if (self.eDate && self.sDate) {
					// if ((moment(self.dateToday).format('YYYY/MM/DD') >= moment(self.sDate).format('YYYY/MM/DD')) && (moment(self.dateToday).format('YYYY/MM/DD') <= (moment(self.getCurrentDate(self.currentZone)).format('YYYY/MM/DD')))) {
					curDate.setHours(0);
					curDate.setMinutes(0);
					curDate.setSeconds(0);
					self.dateToday.setHours(0);
					self.dateToday.setMinutes(0);
					self.dateToday.setSeconds(0);
					if(res.setPayPeriodExpiryStatus == 0 && curDate>=self.dateToday){
						self.payPeriodStatus = false;
					}
					// }
					else {
						self.payPeriodStatus = true;
					}
				// }
				if (res && res.data && res.data.length > 0) {
					self.attendance = self.processData(res.data);
					for(var i =0;i<self.attendance.length;i++){
						self.attendance[i].fullname = self.attendance[i].created_fname + " " +  self.attendance[i].created_lname
					}


					// if(self.attendance.length){
					// 	for(var i=0;i<self.attendance.length;i++){
					// 		if(self.attendance[i].punch_type == "Manual"){
					// 			self.attendance[i].disabled = false
					// 		}else{
					// 			self.attendance[i].disabled = true
					// 		}
					// 	}
					// }


					self.nodata = false;
					self.loader.display(false);
				}
				else {
					self.loader.display(false);
					self.nodata = true;
					self.attendance = [];
				}
				self.loadPeople();
			});
	}

	/**
	 * @ desc   :load the employee list
	 * @ author  : vinod
	 */
	loadPeople() {
		this.peopleloader  = true;
		this.queryObject.date = this.generateQuery(Date);
		this.markAttendanceService.getBiometricPeople(this.queryObject,this.currentId, this.currentZone,res => {
			let data: any
			this.people = res.data;
			this.peopleloader  = false;
			for(var i = 0;i<this.people.length;i++){
				this.people[i].names = this.people[i].first_name +" " + this.people[i].last_name + "(" + this.people[i].code + ")"
			}
			this.filterPeople();
		})


	}


	changeStatus(selected, data, index, firstHalf) {
	  if(selected && selected.selected && selected.selected.length){
		  for(let i =0;i<this.chosenObject.selected.length;i++){
			  if(data.id==this.chosenObject.selected[i].user_id){
				if (firstHalf) {
					if (selected.selected[0].value == 1){
						this.chosenObject.selected[i].first_half_attendance = 2;
						this.chosenObject.selected[i].added_by = this.usedata.user_id}
					else if (selected.selected[0].value == 2){
						this.chosenObject.selected[i].first_half_attendance = 1;
						this.chosenObject.selected[i].added_by = this.usedata.user_id}
					// else
					// 	this.chosenObject.selected[index].first_half = 3;
				} else {
					if (selected.selected[0].value == 1){
						this.chosenObject.selected[i].second_half_attendance = 2;
						this.chosenObject.selected[i].added_by = this.usedata.user_id}
					else if (selected.selected[0].value == 2){
						this.chosenObject.selected[i].second_half_attendance = 1;
						this.chosenObject.selected[i].added_by = this.usedata.user_id}
					// else
					// 	this.chosenObject.selected[index].second_half = 3;
				}
			  }
		  }
	
	  }
	  if(selected && selected.selected.length && (selected.selected[0].value == 1 || selected.selected[0].value == 2)){
		if(firstHalf) {
			if(data.disable || data.first_half_attendance == 1 || data.first_half_attendance == 2)
				this.attendance[index]['attendance'].firstClass = (selected.selected[0].value == 2)? 'attendance-present': 'attendance-absent';
			   // this.attendance[index]['attendance'].firstClass = (selected.selected[0].value == 2)? 'attendance-present':(selected.selected[0].value == 1)?'attendance-absent':'attendance-onduty';
		} else {
			if(data.disable  || data.second_half_attendance == 1 || data.second_half_attendance == 2)
				this.attendance[index]['attendance'].secondClass = (selected.selected[0].value == 2)? 'attendance-present': 'attendance-absent';
			    // this.attendance[index]['attendance'].secondClass = (selected.selected[0].value == 2)? 'attendance-present': (selected.selected[0].value == 1)?'attendance-absent':'attendance-onduty';
		}
	  }
	}

	dateChange(event) {
		this.dateToday = event;
		// if(this.attendance.length){
			this.disableOverRide = false;
		// }else{
			// this.disableOverRide = true;
		// }
		this.chosenObject.selected = [];
		this.loadAttendance();
	}

	getClassByValue(index) {
   	 return this.markAttendanceService.getClassByValue(index);
 	}

	setLocation(event) {
		let self = this;
		if (event.selected[0]) {
 			this.sub = this.route.params.subscribe(params => {
				let temp = params.id.split('_');
				self.temp3  =   temp[2]
				if(temp[1] && temp[1] != 'add'){
                  self.dateToday = this.timeZone.toLocal(temp[0]);
                  self.currentZone = event.selected[0].timezone;
				  self.currentId   = event.selected[0].id;
				}
				else {
				  self.currentZone = event.selected[0].timezone;
				  self.currentId   = event.selected[0].id;
				  self.dateToday   = self.getCurrentDate(event.selected[0].timezone);
				  self.maxDate = self.getCurrentDate(event.selected[0].timezone)
                  localStorage.setItem('currentLoc',JSON.stringify({'id':self.currentId,'zone':self.currentZone}));
				}
				if(temp[0] && self.init == 0){
					self.dateToday = this.timeZone.toLocal(temp[0]);
				}
			});
			self.init = 1;
		}
	}

 	 getCurrentDate(input) {
		let userData = JSON.parse(this.cookieService.get("user-data"));
		if (userData.apply_datetime_conversion == '1' && input != undefined) {
			let value = moment().tz(input).format('Z');
			value = this.timeStringToFloat(value);
			value = value.replace(":", '.');
			return this.calcTime(value)
		}
		else {
			return new Date();
		}
	}

	timeStringToFloat(time) {
		var hoursMinutes = time.split(/[.:]/);
		var hours = parseInt(hoursMinutes[0], 10);
		var minutes = hoursMinutes[1] ? parseInt(hoursMinutes[1], 10) : 0;
		return (hours + minutes / 60).toString();
	}

	calcTime(offset, value?) {
		let d, utc, nd;
		if (value) {
			d = moment.utc(value).toDate();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
		else {
			d = new Date();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
	}

	getLocalDate(value, tz) {
		if (value) {
			let time = moment().tz(tz).format('Z');
			time = this.timeStringToFloat(time);
			time = time.replace(":", '.');
			return this.calcTime(time, value);
		}
		else {
			return new Date();
		}
	}
	ngOnDestroy(){
		localStorage.removeItem("currentLoc");
	}

}
