/*
*  @desc   :component for attendance listing
*  @author :hashid
*/
import { Component, OnInit,OnDestroy } from '@angular/core';
import {
	RouterModule,
	Routes,
	Router
} from '@angular/router';

import { AttendanceListingService } from '../../services/attendance-listing.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';

declare var require: any;
var moment = require('moment');

@Component({
	selector: 'app-hris-attendance-listing',
	templateUrl: './hris-attendance-listing.component.html',
	styleUrls: ['./hris-attendance-listing.component.css']
})

export class HrisAttendanceListingComponent implements OnInit,OnDestroy {

	list: any = [];
	showAdvanceFilter	: boolean = false;
	queryObject 		: any = {};
	listMonth 			: Date;
	currentPage     	: number = 1;
    recordsPerPage      : number = 10;
    perpage      		: number = 10;
    totalRecords        : number;
	maxDate				: Date =	new Date(new Date().getFullYear(), 11, 31);
	nodata				:boolean = false;
	filterSort 			: any = {};
	fromDate			: any;
	locationList        : any;
	cTimeZone           : any;
	locationId          : any;
	locationSelected    : any = [];
	filterActive        : boolean = false;
	filterVal           :boolean =false;
	currentdate          : any;
    displayMonth         :  any;

    recalcFrom           : any;
	recalcTo  			 : any;
	Min 				 : any

    // Min 				 : Date = new Date('1900');
	Max					 : any;
	userData             : any
	minDate              : any;
    recObject			 : any = {};
    recButton			 : boolean = false;
    submitted			 : boolean = false;
    selectedData		 : any;
    predefinedId		 : any=[];
    lazyloader           : boolean = false;
    recDisable			 : boolean =false;


	constructor(
		private attendanceListingService: AttendanceListingService,
		private _router: Router,
		private loader: LoaderActionsService,
		private cookieService : CookieService,
		private timezoneDetailsService :TimezoneDetailsService,
		private notificationService :NotificationService) { }

	ngOnInit() {
		let self = this;
		this.Max	      = this.timezoneDetailsService.getCurrentDate();
	    this.recalcFrom   = this.timezoneDetailsService.getCurrentDate();
	    this.recalcTo	  = this.timezoneDetailsService.getCurrentDate();
	    this.recObject = {
			frmdte: `${this.recalcFrom.getFullYear()}-${this.recalcFrom.getMonth()+1}-${this.recalcFrom.getDate()}`,
			todte : `${this.recalcTo.getFullYear()}-${this.recalcTo.getMonth()+1}-${this.recalcTo.getDate()}`,
		}
		this.predefinedId = [{
			id: 1, name: "location"
		},
		{ id: 2, name: "user" },
		{ id: 3, name: "group" },
		{ id: 4, name: "department" },
		{ id: 5, name: "designation" }
		]

		if (this.cookieService.get("user-data")) {
			this.userData = JSON.parse(this.cookieService.get("user-data"));
			this.minDate= new Date(this.userData.financialMin_date);
		}



		// this.currentdate = new Date();
	    this.currentdate  = this.timezoneDetailsService.getCurrentDate();

		if (localStorage.getItem("itemsperpage")) {
			this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			this.recordsPerPage = 10;
		}
		self.loader.display(true);
		this.attendanceListingService.getLocations(response => {
			if (response.status == 'OK') {
				self.locationList = response.data;
				if (localStorage.getItem("currentLoc")) {
			      // this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
					let userData = JSON.parse(localStorage.getItem("currentLoc"));
					for (let i = 0; i < self.locationList.location.length; i++) {
						if (self.locationList.location[i].id == userData.id) {
							this.locationSelected = [i];
							this.cTimeZone = userData.zone;
							this.locationId = self.locationList.location[i].id;
						}
					}
					localStorage.removeItem("currentLoc");
		        }
		        else{
					let userData = JSON.parse(this.cookieService.get("user-data"));
					for (let i = 0; i < self.locationList.location.length; i++) {
						if (self.locationList.location[i].id == userData.location_id) {
							this.locationSelected = [i];
							this.cTimeZone = userData.time_zone;
							this.locationId = self.locationList.location[i].id;
						}
					}
		        }
				this.currentdate = this.getCurrentDate(this.cTimeZone);
				this.queryObject = {
					month: `${this.currentdate.getMonth() + 1}`,
					year: `${this.currentdate.getFullYear()}`,
					page: this.currentPage,
					limit: this.recordsPerPage,
				}
				this.loadAttendance();
			}
			else {
				self.loader.display(false);
				self.locationList = [];
			}
		})
	}

	locationEvent(event) {
		if (event[0]) {
			this.cTimeZone = event[0].timezone;
			this.currentdate = this.getCurrentDate(this.cTimeZone);
			this.queryObject = {
				month: `${this.currentdate.getMonth() + 1}`,
				year: `${this.currentdate.getFullYear()}`,
				page: this.currentPage,
				limit: this.recordsPerPage,
			}
			this.locationId = event[0].id;
			localStorage.setItem('currentLoc',JSON.stringify({'id':this.locationId,'zone':this.cTimeZone}));
		}
	}

	/**
	 * @ desc   :To apply filter function
	 * @ author  : nilena
	 */
	filterApply(){
		if( this.listMonth || this.currentdate){
			this.filterVal = true;
			this.filterActive = true;
			this.loadAttendance();
		}
		else{
			this.filterVal = false;
			this.filterActive =false;
		}
	}
	/**
	 * @ desc   :To Cancel filteractived
	 * @ author  : nilena
	 */
	filterCancel() {
		if (this.filterVal) {
			this.filterVal = false;
			this.listMonth = this.getCurrentDate(JSON.parse(this.cookieService.get("user-data")).time_zone);
			this.queryObject.month = this.listMonth.getMonth() + 1;
			this.queryObject.year = this.listMonth.getFullYear();
			let userData = JSON.parse(this.cookieService.get("user-data"));
			for (let i = 0; i < this.locationList.location.length; i++) {
				if (this.locationList.location[i].id == userData.location_id) {
					this.locationSelected = [i];
					this.cTimeZone  = userData.time_zone;
					this.locationId = userData.location_id;
				}
			}
			localStorage.setItem('currentLoc',JSON.stringify({'id':this.locationId,'zone':this.cTimeZone}));
			this.loadAttendance();
			this.locationId = undefined;
			this.listMonth = null;
		}
		else {
			this.filterVal = false;
			let userData = JSON.parse(this.cookieService.get("user-data"));
			for (let i = 0; i < this.locationList.location.length; i++) {
				if (this.locationList.location[i].id == userData.location_id) {
					this.locationSelected = [i];
					this.cTimeZone = userData.time_zone;
					this.locationId = userData.location_id;
				}
			}
			localStorage.setItem('currentLoc',JSON.stringify({'id':this.locationId,'zone':this.cTimeZone}));
			if (localStorage.getItem("currentLoc") && (JSON.parse(localStorage.getItem("currentLoc")).id == userData.location_id)) {
               this.loadAttendance();
			}
			this.listMonth = null;
			this.locationId = undefined;
		}
	}


	/**
	 * @ desc   :To load the available attendance list
	 * @ author  : hashid
	 */
	loadAttendance() {
			let self = this;
			 self.loader.display(true);
			 if(this.listMonth){
				this.displayMonth =	this.listMonth;
				this.queryObject.month = this.displayMonth.getMonth()+1;
			 }
				this.attendanceListingService.getAttenStatus(this.queryObject,this.cTimeZone,this.locationId,res => {
					if(res.data && res.data.length) {
						self.list = res.data;
						self.totalRecords=res.count;
						self.currentPage = self.queryObject['page']
						 self.loader.display(false);
						 this.nodata = false;
					} else {
						self.loader.display(false);
						this.nodata = true;
						this.list = [];
					}
				})
	}


	/**
	 * @ desc   :to pick the date chnage
	 * @ author  : hashid
	 */
	dateChange(label) {
		if(this.listMonth){
			this.displayMonth = this.listMonth;
			this.queryObject['month'] = this.listMonth.getMonth()+1;
			this.queryObject['year']  = this.listMonth.getFullYear();
		}
	}

	/**
	 * @ desc   :routing to attance marking page
	 * @ author  : hashid
	 */

	toMarkAttand() {
		this.listMonth = this.getCurrentDate(this.cTimeZone);
		let today = `${this.listMonth.getFullYear()}-${this.listMonth.getMonth()+1}-${this.listMonth.getDate()}`
		this._router.navigate(['modules/attendance/marking/'+today+'_add']);
	}

	/**
	 * @ desc   :to perform pagination
	 * @ author  : hashid
	 */
	pageChangeEvent(page) {
  		this.queryObject['page'] = page;
  		this.loadAttendance();
  	}

  	/**
	 * @ desc   :to perform sorting
	 * @ author  : hashid
	 */
  	sortDate(label) {
		let currentSortStatus = this.filterSort[label]?this.filterSort[label].rev: true;
		this.filterSort = {};
		this.filterSort[label] = {rev:!currentSortStatus}
		this.filterSort["label"] = label;
		this.queryObject.sort = (this.filterSort[label].rev == true)?`${'sortField='}${label}${'&sort=Desc'}`:`${'sortField='}${label}${'&sort=Asc'}`
		this.loadAttendance();
	}

	getpage(eve){
       if(eve > 10 || this.recordsPerPage != 10){
     	 this.recordsPerPage = eve;
     	 this.queryObject['limit'] = eve;
     	 this.queryObject['page'] = 1;
     	 this.currentPage = 1;
      	 this.loadAttendance();
   		}
	}

	getCurrentDate(input) {
		let userData = JSON.parse(this.cookieService.get("user-data"));
		if (userData.apply_datetime_conversion == '1' && input != undefined) {
			let value = moment().tz(input).format('Z');
			value = this.timeStringToFloat(value);
			value = value.replace(":", '.');
			return this.calcTime(value)
		}
		else {
			return new Date();
		}
	}

	timeStringToFloat(time) {
		var hoursMinutes = time.split(/[.:]/);
		var hours = parseInt(hoursMinutes[0], 10);
		var minutes = hoursMinutes[1] ? parseInt(hoursMinutes[1], 10) : 0;
		return (hours + minutes / 60).toString();
	}

	calcTime(offset, value?) {
		let d, utc, nd;
		if (value) {
			d = moment.utc(value).toDate();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
		else {
			d = new Date();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
	}

	//changes start here

	recalculatedateChange(rec,value){
		rec == 'refrom' ?
			this.recObject['frmdte'] = `${this.recalcFrom.getFullYear()}-${this.recalcFrom.getMonth()+1}-${this.recalcFrom.getDate()}`
		:
			this.recObject['todte'] = `${this.recalcTo.getFullYear()}-${this.recalcTo.getMonth()+1}-${this.recalcTo.getDate()}`;
		if(this.timezoneDetailsService.toLocal(this.recalcFrom)>=this.timezoneDetailsService.toLocal(this.recalcTo)){
 			this.recalcTo	= this.recalcFrom;
 		}
	}

	recalculate(){
		this.lazyloader = true;
		this.recDisable = true;
		this.submitted = true;
		let outputData = [];
		let nonOutData = [];
		let applicable = false;
		if (this.selectedData) {
			for (var i = 0; i < this.selectedData.applicable.length; i++) {
				for (var j = 0; j < this.predefinedId.length; j++) {
					if (this.predefinedId[j].name == this.selectedData.applicable[i].name) {
						if (this.selectedData.applicable[i].selectedAll == true) {
							outputData.push({ category: this.predefinedId[j].id, reference_id: 0 });
						}
						else {
							for (var k = 0; k < this.selectedData.applicable[i].list.length; k++) {
								if (this.selectedData.applicable[i].list[k].is_selected == 1) {
									outputData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.applicable[i].list[k].id });
								}
							}
						}
					}
				}
			}

			for (var i = 0; i < this.selectedData.notApplicable.length; i++) {
				for (var j = 0; j < this.predefinedId.length; j++) {
					if (this.predefinedId[j].name == this.selectedData.notApplicable[i].name) {
						if (this.selectedData.notApplicable[i].selectedAll == true) {
							nonOutData.push({ category: this.predefinedId[j].id, reference_id: 0 });
						}
						else {
							for (var k = 0; k < this.selectedData.notApplicable[i].list.length; k++) {
								if (this.selectedData.notApplicable[i].list[k].is_selected == 1) {
									nonOutData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.notApplicable[i].list[k].id });
								}
							}
						}
					}
				}
			}
		}
		if(!outputData.length && !nonOutData.length){
			applicable = true;
			this.lazyloader = false;
			this.recDisable = false;

		}else{
			applicable = false;
		}
		if(!applicable){
			let finalrecObj = {
				"from_date":this.recObject['frmdte'],
				"to_date"  :this.recObject['todte'],
				"applicable_for":outputData,
				"not_applicable_for" : nonOutData
			}
			this.attendanceListingService.recalcAttendence(finalrecObj,res=>{
			if(res.status == "OK"){
				this.cancelRec();
				this.notificationService.alertBoxValue("success",res.message);
				this.lazyloader = false;
				this.recDisable = false;
				setTimeout( ()=>{
					this.loadAttendance();
				},500)
			}else{
				this.notificationService.alertBoxValue("warning",res.message);
				this.lazyloader = false;
				this.recDisable = false;
			}
		})
		}
		// this.lazyloader = false;
	}

	toggleRec(){
		this.cancelRecVlidationOntoggle();
		this.recButton = !this.recButton;
	}
	cancelRec(){
		this.recButton = false;
		this.submitted = false;
		this.recalcFrom   = this.timezoneDetailsService.getCurrentDate();
	    this.recalcTo	  = this.timezoneDetailsService.getCurrentDate();
	}
	cancelRecVlidationOntoggle(){
		this.submitted = false;
		this.recalcFrom   = this.timezoneDetailsService.getCurrentDate();
	    this.recalcTo	  = this.timezoneDetailsService.getCurrentDate();
	}
	ngOnDestroy(){
		localStorage.removeItem("currentLoc");
	}
}