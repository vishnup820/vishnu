import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HrisAttendanceListingComponent } from './hris-attendance-listing.component';

describe('HrisAttendanceListingComponent', () => {
  let component: HrisAttendanceListingComponent;
  let fixture: ComponentFixture<HrisAttendanceListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HrisAttendanceListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HrisAttendanceListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
