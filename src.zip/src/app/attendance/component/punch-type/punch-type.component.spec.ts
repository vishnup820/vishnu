import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PunchTypeComponent } from './punch-type.component';

describe('PunchTypeComponent', () => {
  let component: PunchTypeComponent;
  let fixture: ComponentFixture<PunchTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PunchTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PunchTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
