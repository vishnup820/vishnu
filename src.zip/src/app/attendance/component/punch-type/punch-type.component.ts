import { Component, OnInit } from '@angular/core';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { FormGroup, FormControl, Validators, FormBuilder , ReactiveFormsModule } from '@angular/forms';
import {PunchTypeService} from '../../services/punch-type.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-punch-type',
  templateUrl: './punch-type.component.html',
  styleUrls: ['./punch-type.component.css']
})
export class PunchTypeComponent implements OnInit {

  dataList        : any = [];
  Editdata        : any = [];
  predefinedId    : any = [];
  selectedStatus  : any = [];
  statusArray     : any;
  selectedData    : any;
  selectId        : any;
  editStatus      : boolean = false;
  lazyLoad        : boolean = false;
  submitted       : boolean = false;
  applicableDisable : boolean = false;
  noApplicableValue : boolean = false;
  PunchForm       : FormGroup;
  punchType       : FormControl;
  applicableFor   : FormControl;
  notApplicableFor: FormControl;
  status          : FormControl;

  constructor(  
    private notifications 			  : NotificationService,
    private loader					      : LoaderActionsService,
    private route                 : ActivatedRoute,
    private punchTypeService      : PunchTypeService,
    private router                : Router  ) { }

  ngOnInit() {
    this.PunchControls();
    this.createPunchForm();
    this.punchTypeListdata();
    this.statusArray=[	{ "data": "Active", value: 1},
  	                    { "data": "Inactive", value: 2}
                     ]
    this.predefinedId = [
                      { id: 1, name: "location" },
                      { id: 2, name: "user" },
                      { id: 3, name: "group" },
                      { id: 4, name: "department" },
                      { id: 5, name: "designation" }
                    ]
  }



   /**
  * @ desc   :creating a form group for  edit punch type edit form
  * @ author  :ashiq
  */
 createPunchForm(){
  this.PunchForm = new FormGroup({
    punchType	  :	this.punchType,
    applicableFor : this.applicableFor,
    notApplicableFor:this.notApplicableFor,
    status          :this.status
  })
}

/*
* @ desc   : creating form controls for role forms
* @ author  :ashiq
*/
PunchControls() {
 this.punchType 			 = new FormControl('', []);
this.applicableFor     = new FormControl('', []);
this.notApplicableFor  = new FormControl('', []);
this.status            = new FormControl('', []);

}


  /**
  * @ desc   : method to list roles
  * @ author  :ashiq
  */
 punchTypeListdata() {
  this.loader.display(true);
  this.punchTypeService.punchTypeList( response => {
    if (response.data && response.data.length > 0) {
      this.dataList = response.data;
      this.loader.display(false);
    }
    else {
      this.dataList = [];
      this.loader.display(false);
    }
  })
}

editForm(data){
  if(data.type=="Manual"){
   this.applicableDisable=true;
  }else{
    this.applicableDisable=false;
  }
  data.editStatus = true;
  this.editStatus=true;
  this.noApplicableValue=false;
  this.selectId=data.id;
  this.getDetails( this.selectId);
  this.PunchForm.patchValue({
    punchType: data.type
  })
}

  getDetails(id) {
    let self = this;
    self.lazyLoad = true;
    this.punchTypeService.getEditDetails(this.selectId, function (response) {
      if (response) {
        self.Editdata = response[0];
        if (self.Editdata.status == 2) {
          self.selectedStatus = [1];
        }
        if (self.Editdata.status == 1) {
          self.selectedStatus = [0];
        }
        self.PunchForm.patchValue({
          status: self.Editdata.status
        })
        self.lazyLoad = false;
      }
    })
  }

formCancel(data){
  data.editStatus = false;
  this.noApplicableValue=false;
  this.Editdata=[];
  this.selectedStatus=[];
}

closeOthers(index) {
  for (let i = 0; i < this.dataList.length; i++) {
    if (i != index) {
      this.dataList[i].editStatus = false;
    }
  }
}

  updateForm(data) {
  this.lazyLoad =true
    let applicableInputData = [];
    let notapplicableInputData = [];

    if (this.selectedData) {
      for (var i = 0; i < this.selectedData.applicable.length; i++) {
        for (var j = 0; j < this.predefinedId.length; j++) {
          if (this.predefinedId[j].name == this.selectedData.applicable[i].name) {
            if (this.selectedData.applicable[i].selectedAll == true) {
              applicableInputData.push({ category: this.predefinedId[j].id, reference_id: 0 });
            }
            else {
              for (var k = 0; k < this.selectedData.applicable[i].list.length; k++) {
                if (this.selectedData.applicable[i].list[k].is_selected == 1) {
                  applicableInputData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.applicable[i].list[k].id });
                }
              }
            }
          }
        }
      }
      for (var i = 0; i < this.selectedData.notApplicable.length; i++) {
        for (var j = 0; j < this.predefinedId.length; j++) {
          if (this.predefinedId[j].name == this.selectedData.notApplicable[i].name) {
            if (this.selectedData.notApplicable[i].selectedAll == true) {
              notapplicableInputData.push({ category: this.predefinedId[j].id, reference_id: 0 });
            }
            else {
              for (var k = 0; k < this.selectedData.notApplicable[i].list.length; k++) {
                if (this.selectedData.notApplicable[i].list[k].is_selected == 1) {
                  notapplicableInputData.push({ category: this.predefinedId[j].id, reference_id: this.selectedData.notApplicable[i].list[k].id });
                }
              }
            }
          }
        }
      }
    }
    if(applicableInputData.length==0 && data.type!="Biometric"  ){
      this.noApplicableValue=true;
      this.lazyLoad =false

    }
    if (this.PunchForm.valid && applicableInputData.length>0 ||data.type=="Biometric" ) {
    let punchObj = {
        "applicable_for": applicableInputData,
        "not_applicable_for": notapplicableInputData,
        "status": this.status.value
      }
      this.punchTypeService.updatePunchApi(this.selectId, punchObj, response => {
      if (response.status == "OK") {
          data.editStatus = false;
          this.noApplicableValue=false;
          this.Editdata = [];
          this.selectedStatus = [];
          this.lazyLoad =false
          this.punchTypeListdata();
          setTimeout(() => {
            this.loader.display(false);
            this.notifications.alertBoxValue("success", response.message);
          }, 500);
        }
        if (response.status == "FAIL") {
          this.loader.display(false);
          this.lazyLoad = false;
        if( response.message)
          this.notifications.alertBoxValue("error",  response.message);
          else   if(response.data.name)
          this.notifications.alertBoxValue("error", response.data.name);
        }
      })
     
    }
    else {
      this.submitted = true;
    }
  }


  /*
  * @ desc   : status select for edit punch type status
  * @ author  : ashiq
  */
  selectEditStatusData(event) {
    if (event.selected.length > 0) {
      this.PunchForm.patchValue({
        status: event.selected[0].value
      })
    }
    else {
      this.PunchForm.patchValue({
        status: ""
      })
    }
  }



}
