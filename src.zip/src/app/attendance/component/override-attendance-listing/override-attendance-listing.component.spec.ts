import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OverrideAttendanceListingComponent } from './override-attendance-listing.component';

describe('OverrideAttendanceListingComponent', () => {
  let component: OverrideAttendanceListingComponent;
  let fixture: ComponentFixture<OverrideAttendanceListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OverrideAttendanceListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OverrideAttendanceListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
