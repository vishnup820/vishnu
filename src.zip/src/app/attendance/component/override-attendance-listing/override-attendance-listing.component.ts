/*
*  @desc   :component for overrided attendence listing
*  @author :vinod
*/
import { Component, OnInit ,OnDestroy} from '@angular/core';
import {
	RouterModule,
	Routes,
	Router
} from '@angular/router';

import { AttendanceListingService } from '../../services/attendance-listing.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';

declare var require: any;
var moment = require('moment');

@Component({
  selector: 'app-override-attendance-listing',
  templateUrl: './override-attendance-listing.component.html',
  styleUrls: ['./override-attendance-listing.component.css']
})
export class OverrideAttendanceListingComponent implements OnInit {
	list				: any = [];
	showAdvanceFilter	: boolean = false;
	queryObject 		: any = {};
	listMonth 			: Date;
	currentPage     	: number = 1;
    recordsPerPage      : number = 10;
    perpage      		: number = 10;
    totalRecords        : number;
 	minDate             : any;
	userData            : any;
	maxDate		  		: Date =	new Date(new Date().getFullYear(), 11, 31);
	nodata				: boolean = false;
	filterSort 			: any = {};
	fromDate			: any;
	locationList        : any;
	cTimeZone           : any;
	locationId          : any;
	locationSelected    : any = [];
	filterActive        : boolean = false;
	filterVal           : boolean =false;
	currentdate         : any;
    displayMonth        :  any;
    editid				: number = 1;
    viewid				: number = 2;

  	constructor(
  		private attendanceListingService  : AttendanceListingService,
		private _router					  : Router,
		private loader					  : LoaderActionsService,
		private cookieService 			  : CookieService,
		private timezoneDetailsService    : TimezoneDetailsService,
		private notificationService 	  : NotificationService) { }

  	ngOnInit() {
  		let self = this;
			this.currentdate  = this.timezoneDetailsService.getCurrentDate();

			if (this.cookieService.get("user-data")) {
				this.userData = JSON.parse(this.cookieService.get("user-data"));
				this.minDate=this.timezoneDetailsService.toLocal(this.userData.financialMin_date);
			}
		
  		if (localStorage.getItem("itemsperpage")) {
			this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
		}
		else {
			this.recordsPerPage = 10;
		}
  		this.loader.display(true);
  		this.attendanceListingService.getLocations(response => {
			if (response.status == 'OK') {
				self.locationList = response.data;
				if (localStorage.getItem("currentLoc")) {
			      // this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
					let userData = JSON.parse(localStorage.getItem("currentLoc"));
					for (let i = 0; i < self.locationList.location.length; i++) {

						if (self.locationList.location[i].id == userData.id) {
							this.locationSelected = [i];
							this.cTimeZone = userData.zone;
							this.locationId = self.locationList.location[i].id;
						}
					}
					localStorage.removeItem("currentLoc");
		        }
		        else{
					let userData = JSON.parse(this.cookieService.get("user-data"));
					for (let i = 0; i < self.locationList.location.length; i++) {
						if (self.locationList.location[i].id == userData.location_id) {
							this.locationSelected = [i];
							this.cTimeZone = userData.time_zone;
							this.locationId = self.locationList.location[i].id;
						}
					}
		        }
				this.currentdate = this.getCurrentDate(this.cTimeZone);
				this.queryObject = {
					month: `${this.currentdate.getMonth() + 1}`,
					year: `${this.currentdate.getFullYear()}`,
					page: this.currentPage,
					limit: this.recordsPerPage,
				}
				this.loadList();
			}
			else {
				self.loader.display(false);
				self.locationList = [];
			}
		})
  	}

  	loadList(){
  		this.loader.display(true);
  		this.attendanceListingService.getList(this.queryObject,(this.cTimeZone)?this.cTimeZone:null,(this.locationId)?this.locationId:null,response => {
  			if (response.status == 'OK') {
  				this.list = response.data;
  				this.totalRecords  =	response.count;
  				this.currentPage = this.queryObject['page']
  				this.loader.display(false);
  			}else{
  				this.list = [];
  				this.loader.display(false);
  			}
  			this.toLocalDate(this.list);
  		})
  	}

  	toLocalDate(listObj){
  		for(var i=0;i<listObj.length;i++){
  			// listObj[i].currentday = this.timezoneDetailsService.getLocalDate(listObj[i].override_date)
  			listObj[i].currentday =	moment(listObj[i].override_date).format('dddd');
  		}
  	}

  	locationEvent(event) {
		if (event[0]) {
			this.cTimeZone = event[0].timezone;
			this.currentdate = this.getCurrentDate(this.cTimeZone);
			if(this.listMonth){
				 this.queryObject = {
					month: `${this.listMonth.getMonth()+1}`,
					year: `${this.listMonth.getFullYear()}`,
					page: this.currentPage,
					limit: this.recordsPerPage,
				}
			}else{
				this.queryObject = {
					month: `${this.currentdate.getMonth()+1}`,
					year: `${this.currentdate.getFullYear()}`,
					page: this.currentPage,
					limit: this.recordsPerPage,
				}
			}
			this.locationId = event[0].id;
			localStorage.setItem('currentLoc',JSON.stringify({'id':this.locationId,'zone':this.cTimeZone}));
		}
	}

	dateChange(label) {
		if(this.listMonth){
			this.displayMonth = this.listMonth;
			this.queryObject['month'] = this.listMonth.getMonth()+1;
			this.queryObject['year']  = this.listMonth.getFullYear();
		}
	}

	getCurrentDate(input) {
		let userData = JSON.parse(this.cookieService.get("user-data"));
		if (userData.apply_datetime_conversion == '1' && input != undefined) {
			let value = moment().tz(input).format('Z');
			value = this.timeStringToFloat(value);
			value = value.replace(":", '.');
			return this.calcTime(value)
		}
		else {
			return new Date();
		}
	}

	filterApply(){
		if( this.listMonth || this.currentdate){
			this.filterVal = true;
			this.filterActive = true;
			this.loadList();
			// this.loadAttendance();
		}
		else{
			this.filterVal = false;
			this.filterActive =false;
		}
	}

	override(){
		this.listMonth = this.getCurrentDate(this.cTimeZone);
		let today = `${this.listMonth.getFullYear()}-${this.listMonth.getMonth()+1}-${this.listMonth.getDate()}`
		this._router.navigate(['modules/attendance/override-attendance/'+today+'_add']);	
	}

	filterCancel(){
		if (this.filterVal) {
			this.filterVal = false;
			this.listMonth = this.getCurrentDate(JSON.parse(this.cookieService.get("user-data")).time_zone);
			this.queryObject.month = this.listMonth.getMonth() + 1;
			this.queryObject.year = this.listMonth.getFullYear();
			let userData = JSON.parse(this.cookieService.get("user-data"));
			for (let i = 0; i < this.locationList.location.length; i++) {
				if (this.locationList.location[i].id == userData.location_id) {
					this.locationSelected = [i];
					this.cTimeZone  = userData.time_zone;
					this.locationId = userData.location_id;
				}
			}
			localStorage.setItem('currentLoc',JSON.stringify({'id':this.locationId,'zone':this.cTimeZone}));
			this.loadList();
			// this.filterCancel();
			this.locationId = undefined;
			this.listMonth = null;
		}
		else {
			this.filterVal = false;
			let userData = JSON.parse(this.cookieService.get("user-data"));
			for (let i = 0; i < this.locationList.location.length; i++) {
				if (this.locationList.location[i].id == userData.location_id) {
					this.locationSelected = [i];
					this.cTimeZone = userData.time_zone;
					this.locationId = userData.location_id;
				}
			}
			localStorage.setItem('currentLoc',JSON.stringify({'id':this.locationId,'zone':this.cTimeZone}));
			if (localStorage.getItem("currentLoc") && (JSON.parse(localStorage.getItem("currentLoc")).id == userData.location_id)) {
              this.loadList();
			}
			this.listMonth = null;
			this.locationId = undefined;
		}
	}

	editAttendence(data,index){

	}

	pageChangeEvent(page) {
  		this.queryObject['page'] = page;
  		this.loadList();
  	}

  	getpage(eve){
       if(eve > 10 || this.recordsPerPage != 10){
     	 this.recordsPerPage = eve;
     	 this.queryObject['limit'] = eve;
     	 this.queryObject['page'] = 1;
     	 this.currentPage = 1;
      	 this.loadList();
   		}
	}

	sortDate(label) {
		let currentSortStatus = this.filterSort[label]?this.filterSort[label].rev: true;
		this.filterSort = {};
		this.filterSort[label] = {rev:!currentSortStatus}
		this.filterSort["label"] = label;
		this.queryObject.sort = (this.filterSort[label].rev == true)?`${'sortField='}${label}${'&sort=Desc'}`:`${'sortField='}${label}${'&sort=Asc'}`
		this.loadList();
	}

	timeStringToFloat(time) {
		var hoursMinutes = time.split(/[.:]/);
		var hours = parseInt(hoursMinutes[0], 10);
		var minutes = hoursMinutes[1] ? parseInt(hoursMinutes[1], 10) : 0;
		return (hours + minutes / 60).toString();
	}

	calcTime(offset, value?) {
		let d, utc, nd;
		if (value) {
			d = moment.utc(value).toDate();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
		else {
			d = new Date();
			utc = d.getTime() + (d.getTimezoneOffset() * 60000);
			nd = new Date(utc + (3600000 * offset));
			return nd
		}
	}
	// ngOnDestroy(){
	// 	localStorage.removeItem("currentLoc");
	// }
}
