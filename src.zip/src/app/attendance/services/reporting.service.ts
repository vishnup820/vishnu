import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { apiList } from '../../shared/constants/apilist';
import { globalVariables } from './../../shared/constants/globals';

@Injectable({
  providedIn: 'root'
})

export class ReportingService {
  	apiBaseUrl: string;
  	usedata: any;

  	constructor(private http: HttpClient) {
  	 this.apiBaseUrl = globalVariables.apiBaseUrl; 
  	}

  	generateQuery(queryObject,id) {
      //new
		let query = `&frmdte=${queryObject.frmdte}&todte=${queryObject.todte}${'&'}${queryObject.sort?queryObject.sort:''}&sts=${id?id:''}`
		 //old
    // let query = `?frmdte=${queryObject.frmdte}&todte=${queryObject.todte}${'&'}${queryObject.sort?queryObject.sort:''}&sts=${id?id:''}`
    // let query = `?frmdte=${queryObject.frmdte}&todte=${queryObject.todte}${'&'}${queryObject.sort?queryObject.sort:''}`

    return query;
	}
  	getReport(location,timezone,leaveid,queryObject,cb) {
    //new
    let url: string = this.apiBaseUrl + `${apiList.markattendance.report}/${queryObject.id}` + "?location="+location + "&timezone="+timezone;
		
    //old
    // let url: string = this.apiBaseUrl + `${apiList.markattendance.report}/${queryObject.id}`;

		url = url + this.generateQuery(queryObject,leaveid);
		let promise: any = new Promise((resolve, reject) => {
	  		this.http.get(url)
				.toPromise()
				.then(res => {
					res && res['status'] == 'OK' && cb(res)
				})
		})
  	}

  	getUser(data, cb) {
  		let url: string;
  		if(data.role_id == 3 || data.role_id == 4){
  			url= `${this.apiBaseUrl}${apiList.people.details}/${data.user_id}/myteam` + "?stat=1"
  			
  		} 
  		else if(data.role_id == 2){
  		  url= this.apiBaseUrl + apiList.people.details;
  		}
      // else if(data.role_id == 5 || data.role_id == 1){

       // url = url + `?fields=id,code,name&sort=f_name&stat=1`;
      // }


  
		let promise: any = new Promise((resolve, reject) => {
	  	this.http.get(url)
				.toPromise()
				.then(res => {
					res && res['status'] == 'OK' && cb(res)
				})
		})
  		
  	}

    getCurrentFinancialYear(uid,locid,zone,cb){
          let url: string = this.apiBaseUrl + `${apiList.markattendance.payperiod}/${locid}` + "?timezone="+zone +"&uid="+uid;
        let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          res && res['status'] == 'OK' && cb(res)
        })
    })
    }
}
