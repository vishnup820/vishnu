import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

import {apiList}  from '../../shared/constants/apilist';
import { globalVariables } from './../../shared/constants/globals';

@Injectable({
  providedIn: 'root'
})
export class MarkAttendanceService {
	  apiBaseUrl  : string;

  constructor(	private http: HttpClient) {this.apiBaseUrl = globalVariables.apiBaseUrl; }

  generateQuery(queryObject) {
    let query = `?date=${queryObject.date}&sortField=id`
    return query;
  }

  /**
  * @ desc   :api to get   attandeance of a specific day
  * @ author  : hahid
  */
  SelectedEmployee(abc){
  }

  getAttendance(queryObject, location,currentId,cb) {
    let url: string = this.apiBaseUrl + apiList.markattendance.details;
    url = url + this.generateQuery(queryObject);
    if (location) {
      if (url.slice(-1) == '&')
        url = url + "timezone=" + location + "&loc=" + currentId;
      else
        url = url + "&timezone=" + location + "&loc=" + currentId;
    }
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

  /**
  * @ desc   :api to post  attandeance
  * @ author  : hahid
  */
  postAttendance(data,isSave,dte,zone,id,uId,date,cb) {
    let datas = {
       date:dte,
       save:isSave,
       users : data,
      zone_data :{
        loc      : id,
        timezone : zone
      },
      // u_id      : uId,
    }

    if(data.length == 0){
      datas["date"] = date
    }
    let url: string = `${this.apiBaseUrl+apiList.markattendance.details}`;

    let promise: any = new Promise((resolve, reject) => {
      this.http.post(url, datas)
        .toPromise()
        .then(res => {
          res["status"] ? cb(res) : '';
        }).catch(error =>{
        })
    })
  }

  generateQery(queryObject) {
    let query = `?fields=id,code,name,p_type,dp&sort=f_name&stat=1&g_doj=${queryObject.date}`
    return query;
  }

  /*
  author : hashid
  desc   : get People
  */
  getPeople(queryObject, id, cb) {
    let url: string = this.apiBaseUrl + apiList.people.details;
    url = url + this.generateQery(queryObject);
    if (id) {
      if (url.slice(-1) == '&')
        url = url + "loc="  + id;
      else
        url = url + "&loc=" + id;
    }
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

  getLocations(cb) {
      let url: string =  this.apiBaseUrl + apiList.people.master;
      let promise: any = new Promise((resolve, reject) => {
        this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
       })
     })
  }

  getClassByValue(index) {
        switch (index % 10) {
            case 0: return "default-avatar islamic-green";
            case 1: return "default-avatar limerick";
            case 2: return "default-avatar chilean-fire";
            case 3: return "default-avatar persian-pink";
            case 4: return "default-avatar deep-magenta";
            case 5: return "default-avatar gigas";
            case 6: return "default-avatar endeavour";
            case 7: return "default-avatar dodger-blue";
            case 8: return "default-avatar jordy-blue";
            case 9: return "default-avatar Light-sea-green";
            case 10: return "emp-profileimage";
        }
  }
 
  postBiometricAttendance(data,date,zone,id,cb) {
    let datas = {
       data : data,
      zone_data :{
        loc      : id,
        timezone : zone
      }
      // ,
      // u_id      : uId,
    }

    if(data.length == 0){
      datas["date"] = date
    }
    let url: string = `${this.apiBaseUrl+apiList.markattendance.overridesave}`;

    let promise: any = new Promise((resolve, reject) => {
      this.http.post(url, datas)
        .toPromise()
        .then(res => {
          cb(res)
          // res["status"] ? cb(res) : '';
        }).catch(error =>{
        })
    })
  }

  getAttendanceOverride(queryObject, location,currentId,cb){
     let url: string = this.apiBaseUrl + apiList.markattendance.overridesave;
    url = url + this.generateQuery(queryObject) + "&override=" + 1;
    if (location) {
      if (url.slice(-1) == '&')
        url = url + "timezone=" + location + "&loc=" + currentId;
      else
        url = url + "&timezone=" + location + "&loc=" + currentId;
    }
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

  getBiometricPeople(queryObject, id,zone, cb) {
    let url: string = this.apiBaseUrl + apiList.markattendance.biometricpeople;
    // url = url + this.generateQery(queryObject);
    if (id) {
      if (url.slice(-1) == '&')
        url = url + "?date=" + queryObject.date + "&loc="  + id + "&timezone="+ zone;
      else
        url = url + "?date=" + queryObject.date + "&loc=" + id + "&timezone="+ zone;
    }
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
}
