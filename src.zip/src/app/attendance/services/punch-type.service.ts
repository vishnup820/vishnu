import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { apiList } from '../../shared/constants/apilist';
import { globalVariables } from './../../shared/constants/globals';

@Injectable({
  providedIn: 'root'
})
export class PunchTypeService {
  apiBaseUrl  : string;

  constructor(private http: HttpClient) {this.apiBaseUrl = globalVariables.apiBaseUrl; }

	punchTypeList(cb){
		let url: string = this.apiBaseUrl + apiList.markattendance.punchType;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) cb(res)
				})
		})
	}



	  /*
	*  @desc   :method dealing get api call for  update punch type list
	*  @author :ashiq
	*/



	updatePunchApi(id, obj, cb) {
		let url: string = this.apiBaseUrl + apiList.markattendance.punchType + "/" + id;
		let promise = new Promise((resolve, reject) => {
			this.http.put(url, obj)
				.toPromise()
				.then(res => {
					if (res) cb(res)
				})
		})
		return promise;
	}



	      /**
  * @ desc   : api requst to get group deatils for editing
  * @ author  : ashiq
  */


	getEditDetails(id, cb) {
		let url: string = `${this.apiBaseUrl + apiList.markattendance.punchType}/${id}`;
		let promise: any = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					res['data'].length ? cb(res['data']) : '';
				})
		})
	}





}
