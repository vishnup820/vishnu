import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

import {apiList}  from '../../shared/constants/apilist';
import { globalVariables } from './../../shared/constants/globals';

@Injectable({
  providedIn: 'root'
})
export class AttendanceListingService {
	apiBaseUrl  : string;
  constructor(	private http: HttpClient) {this.apiBaseUrl = globalVariables.apiBaseUrl; }

  generateQuery(queryObject) {
    let query = `?month=${queryObject.month}&year=${queryObject.year?queryObject.year:''}&page=${queryObject.page?queryObject.page: ''}&limit=${queryObject['limit']?queryObject['limit']: ''}${'&'}${queryObject.sort?queryObject.sort:''}`;
    return query;
  }

  getLocations(cb) {
      let url: string =  this.apiBaseUrl + apiList.people.master;
      let promise: any = new Promise((resolve, reject) => {
        this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
       })
     })
  }


 getAttenStatus(queryObject,location,id,cb){
   let url  : string =this.apiBaseUrl + `${apiList.attendanceList.details}`;
   url = url + this.generateQuery(queryObject);

   if(location){
     if(url.slice(-1) == '&')
       url = url + "timezone="+location+"&loc="+id;
     else
       url = url + "&timezone="+location+"&loc="+id;
   }

   let promise : any    = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res)
        })
    })
  }
  recalcAttendence(recobj,cb) {
    let url: string = `${this.apiBaseUrl+apiList.markattendance.recalc}`;
    let promise: any = new Promise((resolve, reject) => {
      this.http.post(url, recobj)
        .toPromise()
        .then(res => {
          res?cb(res) : '';
        }).catch(error =>{
        })
    })
  }

  getList(queryObject,zone,locid,cb){
    let url  : string =this.apiBaseUrl + `${apiList.markattendance.overridelist}`;
    url = url + this.generateUrl(queryObject) + "&timezone=" + zone + "&loc="+ locid;
      let promise: any = new Promise((resolve, reject) => {
        this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
       })
     })
  }
  generateUrl(queryObject) {
    let query = `?month=${queryObject.month}&year=${queryObject.year?queryObject.year:''}&page=${queryObject.page?queryObject.page: ''}&limit=${queryObject['limit']?queryObject['limit']: ''}${'&'}${queryObject.sort?queryObject.sort:''}`;
    return query;
  }
}