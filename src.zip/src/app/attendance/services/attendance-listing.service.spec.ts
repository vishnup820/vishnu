import { TestBed } from '@angular/core/testing';

import { AttendanceListingService } from './attendance-listing.service';

describe('AttendanceListingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AttendanceListingService = TestBed.get(AttendanceListingService);
    expect(service).toBeTruthy();
  });
});
