import { TestBed } from '@angular/core/testing';

import { PunchTypeService } from './punch-type.service';

describe('PunchTypeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PunchTypeService = TestBed.get(PunchTypeService);
    expect(service).toBeTruthy();
  });
});
