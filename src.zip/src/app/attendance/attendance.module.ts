import { NgModule,ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
// import { HttpClientModule} from '@angular/common/http';
import { GlobalErrorHandlerService } from '../global-error-handler.service';

import { SharedModule } from '../shared/shared.module';

import { HrisAttendanceListingComponent } from './component/hris-attendance-listing/hris-attendance-listing.component';
import { HrisAttendanceMarkingComponent } from './component/hris-attendance-marking/hris-attendance-marking.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { HrisAttendanceReportComponent } from './component/hris-attendance-report/hris-attendance-report.component';
import { PunchTypeComponent } from './component/punch-type/punch-type.component';
import { OverrideAttendanceComponent } from './component/override-attendance/override-attendance.component';
import { OverrideAttendanceListingComponent } from './component/override-attendance-listing/override-attendance-listing.component';



const attendanceRoutes: Routes = [
  {
    path : 'listing', component: HrisAttendanceListingComponent
  },
  {
    path : 'marking/:id', component  :  HrisAttendanceMarkingComponent,
  },
  // {
  //   path : 'marking', component: HrisAttendanceMarkingComponent
  // },
  {
    path : 'report', component: HrisAttendanceReportComponent
  },
  {
    path : 'punch-type', component: PunchTypeComponent
  },
  {
    path : 'override-attendance/:id', component: OverrideAttendanceComponent
  },
  {
    path : 'override-listing', component: OverrideAttendanceListingComponent
  },
  {
    path : '', redirectTo : 'listing', pathMatch: 'full'
  }


];


@NgModule({
  declarations: [HrisAttendanceListingComponent, HrisAttendanceMarkingComponent, HrisAttendanceReportComponent, PunchTypeComponent, OverrideAttendanceComponent, OverrideAttendanceListingComponent],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(attendanceRoutes),
    BsDatepickerModule.forRoot(),
  ],
  providers: [
      {
        provide  : ErrorHandler,
        useClass : GlobalErrorHandlerService,
      }
    ],
})
export class AttendanceModule { }
