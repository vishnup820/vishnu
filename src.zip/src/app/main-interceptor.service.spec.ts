import { TestBed } from '@angular/core/testing';

import { MainInterceptorService } from './main-interceptor.service';

describe('MainInterceptorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MainInterceptorService = TestBed.get(MainInterceptorService);
    expect(service).toBeTruthy();
  });
});
