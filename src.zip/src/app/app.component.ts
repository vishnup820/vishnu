import { Component , OnInit, ElementRef  } from '@angular/core';
import { LoaderActionsService } from './shared/services/loader/loader-actions.service'
import { NotificationService } from './shared/services/notifications/notification.service';
import { Router, Event, NavigationStart, NavigationEnd, NavigationError,RouteConfigLoadStart} from '@angular/router';
import { globalVariables } from './shared/constants/globals';
import { CookieService } from 'ngx-cookie-service';
import { CookieDataService } from './shared/services/cookie-data/cookie-data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    j:number = 1;
	constructor(private router            : Router,
		private loaderService     : LoaderActionsService,
        private notification      : NotificationService,
        private elm               : ElementRef,
        private cookieService : CookieService,
        private cookieDataService:CookieDataService) {
	}
	ngOnInit() {
		globalVariables.apiBaseUrl = this.elm.nativeElement.getAttribute('appBaseUrl');
		    this.router.events.subscribe( (event: Event) => {
            if(event instanceof NavigationStart) {
                this.loaderService.display(true);
                if(this.j == 1){
                    if(!this.cookieService.get('mailrouter')){
                        // if(this.cookieService.get('session')){
                            // if(event['url'] != "/login" && event['url'] != "/" && event['url'] != undefined){
                            //     this.cookieDataService.setRoute(event['url'])
                            // }
                        // }
                        // else{
                            if(event['url'] != "/login" && event['url'] != "/" && event['url'] != undefined){
                                this.cookieDataService.setRoute(event['url'])
                            }
                        // }
                    }
                }
                this.j = 2;
            }

            if (event instanceof NavigationEnd) {
                // Hide loading indicator
                this.loaderService.display(false);
                window.scrollTo(0, 0);
                this.notification.resetAlerts();
            }

            if (event instanceof NavigationError) {
                // Hide loading indicator
                // Present error to user
                this.loaderService.display(false);
                this.notification.resetAlerts();

            }
        });
	}
}
