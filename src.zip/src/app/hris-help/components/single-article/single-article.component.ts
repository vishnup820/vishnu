import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-single-article',
  templateUrl: './single-article.component.html',
  styleUrls: ['../../../../assets/content/css/help-css/style.css']
})
export class SingleArticleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
