import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index-help',
  templateUrl: './index-help.component.html',
  styleUrls: ['../../../../assets/content/css/help-css/style.css']

})
export class IndexHelpComponent implements OnInit {
  hideMe : any;
  constructor() { }

  ngOnInit() {
    document.onclick = function (e) {
      if (e.target['id'] !== 'search-result') {
        document.getElementById('search-result').style.display = 'none';
      }
    };
  }

  keyPress() {
    document.getElementById("search-result").style.display = "block";
  }

  keyUp() {
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById("search");
    filter = input.value.toUpperCase();
    ul = document.getElementById("list");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
      a = li[i].getElementsByTagName("a")[0];
      txtValue = a.textContent || a.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        li[i].style.display = "";
      } else {
        li[i].style.display = "none";
      }
    }
  }

}
