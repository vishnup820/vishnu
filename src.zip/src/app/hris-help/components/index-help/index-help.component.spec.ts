import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndexHelpComponent } from './index-help.component';

describe('IndexHelpComponent', () => {
  let component: IndexHelpComponent;
  let fixture: ComponentFixture<IndexHelpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndexHelpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndexHelpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
