import { NgModule,ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { RoleGuardService } from '../shared/services/role-guard/role-guard.service';
import { IndexHelpComponent } from './components/index-help/index-help.component';
import { SingleArticleComponent } from './components/single-article/single-article.component';
import { SharedModule } from '../shared/shared.module';
import { GlobalErrorHandlerService } from '../global-error-handler.service';

@NgModule({
  declarations: [IndexHelpComponent, SingleArticleComponent],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild([
      {
        path        : 'workjoe-help',
		    component   : IndexHelpComponent
      },
      {
        path        : 'single-article',
		    component   : SingleArticleComponent
      },
  ])
  ],
  providers: [
    {
      provide  : ErrorHandler,
      useClass : GlobalErrorHandlerService,
    }
  ],
})
export class HrisHelpModule { }
