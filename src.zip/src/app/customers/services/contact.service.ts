import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../shared/constants/globals';
import { apiList } from '../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';
@Injectable({
  providedIn: 'root'
})
export class ContactService {
  apiBaseUrl: string;
  constructor(
    private http: HttpClient,
    private cookies: CookieService
  ) { this.apiBaseUrl = globalVariables.apiBaseUrl; }
  generateQuery(qobj) {
    let query = `?page=${qobj['page']?qobj['page']: ''}&page_limit=${qobj['page_limit'] ? qobj['page_limit'] : ''}${qobj.keyword ? '&keyword=' + qobj.keyword : ''}${qobj.custId ? '&custId=' + qobj.custId : ''}${qobj.desig ? '&desig=' + qobj.desig : ''}`
    return query;
  }
  getcontactData(qobj, cb) {
    let url: string = this.apiBaseUrl + apiList.projects.getContactList;
    url = url + this.generateQuery(qobj);
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  getcustomerData(cb) {
    let url: string = this.apiBaseUrl + apiList.projects.getCustomerList;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  addContactData(parms,conId,cb){
    let url: string = this.apiBaseUrl + apiList.projects.getContactList;
    if(conId){
      let promise: any = new Promise((resolve, reject) => {
        this.http.put(url + '/' + conId,parms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    else{
      let promise: any = new Promise((resolve, reject) => {
        this.http.post(url,parms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }

  }
  deleteContactPerson(id,cb){
    let url: string = this.apiBaseUrl + apiList.projects.getContactList;
    let promise: any = new Promise((resolve, reject) => {
			this.http.delete(url + "/" + id)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
  }
  editContactPerson(cus_id,cb){
    let url: string = this.apiBaseUrl + apiList.projects.getContactList;
    let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "/" + cus_id)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
  }
  designationList(cb){
    let url: string = this.apiBaseUrl + apiList.projects.getdesignation;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  aadDesignation(des_name,cb){
    let url: string = this.apiBaseUrl + apiList.projects.adddesignation;
    let promise: any = new Promise((resolve, reject) => {
      this.http.post(url,des_name)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
}
