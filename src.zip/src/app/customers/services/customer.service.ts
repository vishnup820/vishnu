import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../shared/constants/globals';
import { apiList } from '../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';
@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  apiBaseUrl: string;
  constructor(
    private http: HttpClient,
    private cookies: CookieService
  ) { this.apiBaseUrl = globalVariables.apiBaseUrl; }

  generateQuery(qobj) {
    let query = `?page=${qobj['page']?qobj['page']: ''}&page_limit=${qobj['page_limit'] ? qobj['page_limit'] : ''}${qobj.keyword ? '&keyword=' + qobj.keyword : ''}${qobj.cnId ? '&cnId=' + qobj.cnId : ''}${qobj.cmType ? '&cmType=' + qobj.cmType : ''}`
    return query;
  }
  getcustomerData(qobj, cb) {
    let url: string = this.apiBaseUrl + apiList.projects.getCustomerList;
    url = url + this.generateQuery(qobj);
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  getData(type, id, callBack) {
		let url: string;
		if (type == 'country') {
			url = this.apiBaseUrl + apiList.onboard.getMastersCountry;
		}
		else if (type == 'state') {
			url = this.apiBaseUrl + apiList.onboard.getMastersStates + id;
		}
		else if (type == 'other') {
			url = this.apiBaseUrl + apiList.onboard.getMasterData;
		}
		let promise = new Promise((resolve, reject) => {
			this.http.get(url)
				.toPromise()
				.then(res => {
					if (res) callBack(res)
				})
		})
		return promise;
  }
  addcustomer(parms,id,cb){
    let url: string = this.apiBaseUrl + apiList.projects.getCustomerList;
    if(id){
      let promise: any = new Promise((resolve, reject) => {
        this.http.put(url + "/" +id,parms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
    else{
      let promise: any = new Promise((resolve, reject) => {
        this.http.post(url,parms)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
  }
  deletecustomer(id,cb){
    let url: string = this.apiBaseUrl + apiList.projects.getCustomerList;
    let promise: any = new Promise((resolve, reject) => {
			this.http.delete(url + "/" + id)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
  }
  editCusData(cus_id,cb){
    let url: string = this.apiBaseUrl + apiList.projects.getCustomerList;
    let promise: any = new Promise((resolve, reject) => {
			this.http.get(url + "/" + cus_id)
				.toPromise()
				.then(res => {
					cb(res);
				})
		})
  }
}
