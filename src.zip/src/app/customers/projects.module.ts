import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddNewCustomerComponent } from './components/add-new-customer/add-new-customer.component';
import { ContactPersonListComponent } from './components/contact-person-list/contact-person-list.component';
import { CustomerListComponent } from './components/customer-list/customer-list.component';
import { RouterModule } from '@angular/router';
import { AuthGuardService } from '../shared/services/auth-guard/auth-guard.service';
import { RoleGuardService } from '../shared/services/role-guard/role-guard.service';
import { SharedModule } from '../shared/shared.module';
import { ReactiveFormsModule , FormsModule} from '@angular/forms';
import { ClickOutsideModule } from 'ng4-click-outside';
@NgModule({
  declarations: [AddNewCustomerComponent, ContactPersonListComponent, CustomerListComponent],
  imports: [
    CommonModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    ClickOutsideModule,
    RouterModule.forChild([
      {
        path       : 'customer-list',
        canActivate : [RoleGuardService],
        component  :  CustomerListComponent,
      },
      {
        path       : 'add-new-customer',
        canActivate : [RoleGuardService],
        component  :  AddNewCustomerComponent,
      },
      {
        path       : 'add-new-customer/:cus_id',
        canActivate : [RoleGuardService],
        component  :  AddNewCustomerComponent,
      },
      {
        path       : 'contact-person-list',
        canActivate : [RoleGuardService],
        component  :  ContactPersonListComponent,
      }
     
    ])
  ],
  providers : [RoleGuardService]
})
export class ProjectsModule { }
