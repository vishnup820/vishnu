import { Component, OnInit, ElementRef, ViewChild, ChangeDetectorRef } from '@angular/core';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { Router, NavigationEnd } from '@angular/router';
import { CustomerService } from '../../services/customer.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
  @ViewChild('foc') inputEl: ElementRef;
  type: any = [{ "type": "Individual", "value": 1 }, { "type": "Large Enterprise", "value": 2 },{ "type": "SME", "value": 3 }]
  searchD: any;
  searchKeyword: any = "";
  selcustomerType: any;
  selectedcuscon: any;
  selectCusType: any;
  selcountryName: any;
  config: any;
  queryObject: any = {};
  searchTextBox: boolean = false;
  filterActive: boolean = false;
  countryData: boolean = false;
  showAdvanceFilter: boolean = false;
  confirmBox: boolean = false;
  totalRecords: number;
  deleteCustomer: number;
  recordsPerPage: number = 10;
  currentPage: number = 1;
  customerData: any = [];
  countryList: any = [];
  constructor(
    private router: Router,
    private customerService: CustomerService,
    private notificationService: NotificationService,
    private loader: LoaderActionsService
  ) { }

  ngOnInit() {
    this.config = "Are You Sure You Want To Delete?"
    if (localStorage.getItem("itemsperpage")) {

      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    this.currentPage = 1;
    this.queryObject.page_limit = this.recordsPerPage;
    this.queryObject.page = this.currentPage;
    this.custimerList();
    this.customerService.getData('country', 0, response => {
      if (response.data && response.data.length > 0) {
        this.countryData = false;
        this.countryList = response.data;
      }
      else {
        this.countryList = [];
        this.countryData = false;
      }
    });
  }

  custimerList() {

    this.loader.display(true);
    this.customerService.getcustomerData(this.queryObject, res => {
      if (res.status == "OK") {
        this.loader.display(false);
        this.customerData = res.data;
        this.totalRecords = res.count;
        this.currentPage = this.queryObject.page;
      }
      else {
        this.loader.display(false);
        this.customerData = [];
      }
    });
  }
  inputfocus() {
    setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
  }
  searchList(keyword) {
    if (this.searchKeyword || this.searchD.trim() != '') {
      this.searchKeyword = keyword;
      // this.queryObject.page = 1;
      this.queryObject['page'] = 1;
      this.queryObject.keyword = this.searchKeyword ? this.searchKeyword : '';
      this.custimerList();
    }
  }
  addCustomer() {
    this.router.navigate(['/modules/customer/add-new-customer']);
  }
  selectedcustomerType(event) {
    if (event && event.selected && event.selected.length) {
      this.queryObject.cmType = event.selected[0].type;
    }
    else {
      this.queryObject.cmType = null;
    }
  }
  selectedCountrynames(event) {

    if (event && event.selected && event.selected.length) {
      this.queryObject.cnId = event.selected[0].id;
    }
    else {
      this.queryObject.cnId = null;
    }
  }
  filterApply() {
    if (this.selcustomerType && this.selcustomerType.selected && this.selcustomerType.selected.length || this.selcountryName && this.selcountryName.selected && this.selcountryName.selected.length) {
      this.filterActive = true;
      this.showAdvanceFilter = false;
      this.queryObject.page = 1;
      // this.addTimeSheet = [];
      this.custimerList();
    }
  }
  filterCancel() {
    if (this.selcustomerType && this.selcustomerType.selected && this.selcustomerType.selected.length || this.selcountryName && this.selcountryName.selected && this.selcountryName.selected.length) {
      this.queryObject['page'] = 1;
      this.filterActive = false;
      this.queryObject.cmType = null;
      this.queryObject.cnId = null;
      this.selectCusType = [];
      this.selectedcuscon = [];
      this.custimerList();
    }
  }
  getCustomerList(event) {
    this.currentPage = event;
    this.queryObject['page'] = this.currentPage;
    this.custimerList();
  }
  getpage(event) {
    if (event > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      this.queryObject['page'] = this.currentPage
      this.queryObject['page_limit'] = this.recordsPerPage
      this.custimerList();

    }
  }
  confirmPopup() {
    this.confirmBox = false;
    this.loader.display(true);
    this.customerService.deletecustomer(this.deleteCustomer, res => {
      this.loader.display(false);
      if (res.status == "OK") {
        this.queryObject['page'] = 1;
        this.custimerList();
        this.notificationService.alertBoxValue("success", res.message);
      }
      else {
        this.notificationService.alertBoxValue("success", res.message);
      }
    });
  }
  editCustomer(cus_id) {
    this.router.navigate(['/modules/customer/add-new-customer/' + cus_id]);
  }
}
