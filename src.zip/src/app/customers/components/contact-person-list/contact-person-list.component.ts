import { Component, OnInit, ElementRef, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { ContactService } from '../../services/contact.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
@Component({
  selector: 'app-contact-person-list',
  templateUrl: './contact-person-list.component.html',
  styleUrls: ['./contact-person-list.component.css']
})
export class ContactPersonListComponent implements OnInit {
  @ViewChild('foc') inputEl: ElementRef;
  personDetailError: boolean = false;
  filterActive: boolean = false;
  showAdvanceFilter: boolean = false;
  addcontact: boolean = false;
  confirmBox: boolean = false;
  editcontact: boolean = false;
  searchTextBox: boolean = false;
  confirmBoxCancel: boolean = false;
  editContactId: any;
  roleStatus: any;
  totalRecords: number;
  editcontactLoader: boolean = false;
  CustomerSelect: any;
  deleteContactPerson: any;
  customerDisName: any;
  searchKeyword: any = "";
  queryObject: any = {};
  selcustomerName: any;
  personData: any = [];
  designationData: any = [];
  new_designation: any;
  selectDesType: any;
  customerData: any = [];
  selectCusType: any = [];
  ediContactData: any = [];
  personRecords: number;
  contactDetails: FormGroup;
  name: FormControl;
  customer: FormControl;
  countryCode: FormControl;
  contactNumber: FormControl;
  emailId: FormControl;
  searchD: any;
  config: any;
  seldesignationName: any;
  roleChecked: any;
  designationStatus: any;
  recordsPerPage: number = 10;
  currentPage: number = 1;
  constructor(
    private contactservice: ContactService,
    private loader: LoaderActionsService,
    private notificationService: NotificationService
  ) { }
  ngOnInit() {
    this.customerList();
    this.config = "Are You Sure You Want To Delete?"
    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    this.currentPage = 1;
    this.queryObject.page_limit = this.recordsPerPage;
    this.queryObject.page = this.currentPage;
    this.createFormControls();
    this.createForm();
    this.designationList();
    this.contactList();

  }
  createFormControls() {
    let alpha = "^[a-zA-Z ]*$";
    let beta = "^[a-zA-Z ]+[.]*[a-zA-Z]*$";
    let contactNumber = "^[0-9+() -]*$";
    let number = "^[0-9]*$";
    let useName = "^[a-zA-Z0-9._@]+$";
    let emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$";
    this.name = new FormControl('', [Validators.required, this.noWhitespaceValidator, Validators.pattern(beta)]);

    this.countryCode = new FormControl('', [Validators.pattern(contactNumber)]);
    this.contactNumber = new FormControl('', [Validators.pattern(number)]);
    this.emailId = new FormControl('', [Validators.pattern(emailPattern)]);
  }
  createForm() {
    this.contactDetails = new FormGroup({
      name: this.name,
      countryCode: this.countryCode,
      contactNumber: this.contactNumber,
      emailId: this.emailId
    });
  }
  designationList() {
    this.loader.display(true);
    this.contactservice.designationList(res => {
      if (res.status == "OK") {
        this.designationData = res.data;
        this.loader.display(false);
      } else {
        this.designationData = [];
      }

    })
  }
  addContactPerson() {
    if (this.editContactId && !this.contactDetails.valid) {
      this.editcontact = true;
    } else {
      this.editcontact = false;
    }
    this.roleChecked = [];
    let parms: any;
    if (!this.contactDetails.valid || !this.CustomerSelect.selected[0]) {
      this.personDetailError = true;
    }
    else {
      this.loader.display(true);
      this.addcontact = false;
      this.editcontact = false;
      parms = {
        // "id":"1",
        // "tenant_id":"1",
        "cnct_prsn_name": this.contactDetails.value.name,
        "customer_id": this.CustomerSelect.selected[0].id,
        "cnct_prsn_designation": (this.designationStatus.selected[0]) ? this.designationStatus.selected[0].id : null,
        "cnct_prsn_email": (this.contactDetails.value.emailId) ? this.contactDetails.value.emailId : null,
        "cnct_prsn_contact_code": (this.contactDetails.value.countryCode) ? this.contactDetails.value.countryCode : null,
        "cnct_prsn_contact": (this.contactDetails.value.contactNumber) ? this.contactDetails.value.contactNumber : null,
        "cnct_prsn_status": "1"
      }
      this.contactservice.addContactData(parms, this.editContactId, res => {
        let self = this;
        if (res.status == "OK") {
          this.contactDetails.reset();
          this.loader.display(false);
          this.addcontact = false;
          this.designationList();
          this.contactList();
          setTimeout(function () {
            self.notificationService.alertBoxValue("success", res.message);
          });
        }
        else {
          this.loader.display(false);
          if(this.CustomerSelect.selected[0]){
            for (let i = 0; i < this.customerData.length; i++) {
              if (this.customerData[i].id == this.CustomerSelect.selected[0].id) {
                this.customerDisName = [i];
                break;
              }
            }
          }
          if(this.designationStatus.selected[0]){
            for (let i = 0; i < this.designationData.length; i++) {
              if (this.designationData[i].id == this.designationStatus.selected[0].id) {
                this.roleChecked = [i];
                break;
              }
            }
          }
          this.addcontact = true;
          self.notificationService.alertBoxValue("error", res.message);
        }
      });
    }
  }
  customerList() {
    this.loader.display(true);
    this.contactservice.getcustomerData(res => {
      if (res.status == "OK") {
        this.loader.display(false);
        this.customerData = res.data;
      }
      else {
        this.loader.display(false);
        this.customerData = [];
      }
    });
  }
  contactList() {
    this.loader.display(true);
    this.contactservice.getcontactData(this.queryObject, res => {
      if (res.status == "OK") {
        this.loader.display(false);
        this.currentPage = this.queryObject.page;
        this.personData = res.data;
        this.totalRecords = res.count;
      }
      else {
        this.personData = [];
        this.loader.display(false);
      }
    });
  }
  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }
  cancelContactPerson() {
    this.contactDetails.reset();
    this.addcontact = false;
    this.confirmBoxCancel = false;
    this.personDetailError = false;
    this.roleChecked = [];
  }
  inputfocus() {
    setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
  }
  searchList(keyword) {
    if (this.searchKeyword || this.searchD.trim() != '') {
      this.searchKeyword = keyword;
      // this.queryObject.page = 1;
      this.queryObject['page'] = 1;
      this.queryObject.keyword = this.searchKeyword ? this.searchKeyword : '';
      this.contactList();

    }
  }
  selectedcustomerName(event) {
    if (event && event.selected && event.selected.length) {
      this.queryObject.custId = event.selected[0].id;
    }
    else {
      this.queryObject.custId = null;
    }
  }
  selecteddesignationName(event) {
    if (event && event.selected && event.selected.length) {
      this.queryObject.desig = event.selected[0].id;
    }
    else {
      this.queryObject.custId = null;
    }
  }
  filterApply() {
    if (this.selcustomerName && this.selcustomerName.selected && this.selcustomerName.selected.length || this.seldesignationName && this.seldesignationName.selected && this.seldesignationName.selected.length) {
      this.filterActive = true;
      this.showAdvanceFilter = false;
      this.queryObject.page = 1;
      // this.addTimeSheet = [];
      this.contactList();

    }
  }
  filterCancel() {
    if (this.selcustomerName && this.selcustomerName.selected && this.selcustomerName.selected.length || this.seldesignationName && this.seldesignationName.selected && this.seldesignationName.selected.length) {
      this.queryObject['page'] = 1;
      this.filterActive = false;
      this.queryObject.custId = null;
      this.queryObject.desig = null;
      this.selectCusType = [];
      this.selectDesType = [];
      this.contactList();
    }
  }

  confirmPopup() {
    this.confirmBox = false;
    this.loader.display(true);
    this.contactservice.deleteContactPerson(this.deleteContactPerson, res => {
      this.loader.display(false);
      if (res.status == "OK") {
        this.queryObject.page = 1;
        this.contactList();

        this.notificationService.alertBoxValue("success", res.message);
      }
      else {
        this.notificationService.alertBoxValue("success", res.message);
      }
    });
  }
  editContactPerson(con_id) {
    this.addcontact = true;
    this.personDetailError = false;
    this.editcontactLoader = true;
    this.editcontact = true;
    this.customerDisName = [];
    this.contactservice.editContactPerson(con_id, res => {
      if (res.status == "OK") {
        this.editcontactLoader = false;
        this.ediContactData = res.data;
        this.contactDetails.patchValue({
          name: this.ediContactData.cnct_prsn_name,
          countryCode: this.ediContactData.cnct_prsn_contact_code,
          contactNumber: this.ediContactData.cnct_prsn_contact,
          emailId: this.ediContactData.cnct_prsn_email
        });
        for (let i = 0; i < this.customerData.length; i++) {
          if (this.customerData[i].id == this.ediContactData.customer_id) {
            this.customerDisName = [i];
            break;
          }
        }
        for (let i = 0; i < this.designationData.length; i++) {
          if (this.designationData[i].id == this.ediContactData.cnct_prsn_designation) {
            this.roleChecked = [i];
            break;
          }
        }
      }
      else {
        this.editcontactLoader = false;
        this.ediContactData = [];
      }
    });
  }
  getCustomerList(event) {
    this.currentPage = event;
    this.queryObject['page'] = this.currentPage;
    this.contactList();
  }
  getpage(event) {
    if (event > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = event;
      this.currentPage = 1;
      this.queryObject['page'] = this.currentPage
      this.queryObject['page_limit'] = this.recordsPerPage
      this.contactList();

    }
  }
  showAddNew(event) {
    if (event.status) {
      this.new_designation = { "new_designation": event.value }
      this.contactservice.aadDesignation(this.new_designation, res => {
        if (res.status == "OK") {
          this.designationData.push({ id: res.desigId, name: event.value })
          this.roleChecked = [this.designationData.length - 1];
          this.notificationService.alertBoxValue("success", res.message);
        }
        else {
          this.roleChecked = [this.designationData.length - 1];
          this.notificationService.alertBoxValue("error", res.message);
        }
      });
    }
  }
}
