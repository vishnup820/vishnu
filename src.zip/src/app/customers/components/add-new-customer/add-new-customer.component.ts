import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { CustomerService } from '../../services/customer.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
declare var require: any;
@Component({
  selector: 'app-add-new-customer',
  templateUrl: './add-new-customer.component.html',
  styleUrls: ['../../../../assets/content/css/recruitment.css']
})
export class AddNewCustomerComponent implements OnInit {
  type: any = [{ "type": "Individual", "value": 1 }, { "type": "Large Enterprise", "value": 2 },{ "type": "SME", "value": 3 }]
  typeSelected: any;
  countrySelected: any;
  stateSelected: any;
  typeSelect: any;
  countryList: any = [];
  tempstateList: any = [];
  stateList: any = [];
  editCustomedData: any = [];
  tempStateData: any;
  countrySelect: any;
  stateSelect: any;
  tempCountryData: any;
  tempstate: any;
  pageStatus: boolean = false;
  countryData: boolean = true;
  tempCountrySelected: any;
  tempStateSelected: any;
  sameAbove: boolean = false;
  tempstateLoader: boolean = false;
  confirmBox: boolean = false;
  loadermultiOnboard: boolean = false;
  customerDetailError: boolean = false;
  customerDetails: FormGroup;
  name: FormControl;
  displayName: FormControl;
  email: FormControl;
  contactNumber: FormControl;
  description: FormControl;
  addressOne: FormControl;
  addressTwo: FormControl;
  // country: FormControl;
  // state: FormControl;
  city: FormControl;
  zipCode: FormControl;
  phoneNumber: FormControl;
  tempAddressOne: FormControl;
  tempAddressTwo: FormControl;
  // tempCountry: FormControl;
  // tempState: FormControl;
  tempCity: FormControl;
  tempZipCode: FormControl;
  tempPhoneNumber: FormControl;
  constructor(private customerService: CustomerService,
    private locations: Router,
    private notificationService: NotificationService,
    private loaderActionsService: LoaderActionsService,
    private route: Router,
    private routeActive: ActivatedRoute) { }

  ngOnInit() {
    this.createFormControls();
    this.createForm();
    this.customerService.getData('country', 0, response => {
      if (response.data && response.data.length > 0) {
        this.countryData = false;
        this.countryList = response.data;
        this.editCustomerForm();
      }
      else {
        this.countryList = [];
        this.countryData = false;
      }
    });
    this.routeActive.snapshot.params['cus_id'] ? this.pageStatus = false : this.pageStatus = true;
    if (!this.pageStatus) {
      this.loaderActionsService.display(true);
    }

  }

  createFormControls() {
    let alpha = "^[a-zA-Z ]*$";
    let beta = "^[a-zA-Z ]+[.]*[a-zA-Z]*$";
    let contactNumber = "^[0-9+() -]*$";
    let number = "^[0-9]*$";
    let useName = "^[a-zA-Z0-9._@]+$";
    let emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$";
    this.name = new FormControl('', [Validators.required, this.noWhitespaceValidator]);
    this.displayName = new FormControl('', [Validators.required, this.noWhitespaceValidator]);
    this.email = new FormControl('', [Validators.pattern(emailPattern)]);
    this.contactNumber = new FormControl('', [Validators.pattern(number)]);
    this.description = new FormControl('');
    this.addressOne = new FormControl('');
    this.addressTwo = new FormControl('');
    this.city = new FormControl('', [Validators.pattern(alpha)]);
    this.zipCode = new FormControl('', [Validators.pattern(number)]);
    this.phoneNumber = new FormControl('', [Validators.pattern(contactNumber)]);
    this.tempAddressOne = new FormControl('');
    this.tempAddressTwo = new FormControl('');
    this.tempCity = new FormControl('',[Validators.pattern(alpha)]);
    this.tempZipCode = new FormControl('',[Validators.pattern(number)]);
    this.tempPhoneNumber = new FormControl('',[Validators.pattern(contactNumber)]);
  }
  createForm() {
    this.customerDetails = new FormGroup({
      name: this.name,
      displayName: this.displayName,
      email: this.email,
      contactNumber: this.contactNumber,
      description: this.description,
      addressOne: this.addressOne,
      addressTwo: this.addressTwo,
      city: this.city,
      zipCode: this.zipCode,
      phoneNumber: this.phoneNumber,
      tempAddressOne: this.tempAddressOne,
      tempAddressTwo: this.tempAddressTwo,
      tempCity: this.tempCity,
      tempZipCode: this.tempZipCode,
      tempPhoneNumber: this.tempPhoneNumber
    })
  }
  editCustomerForm() {
    if (!this.pageStatus) {
      this.loaderActionsService.display(true);
      this.customerService.editCusData(this.routeActive.snapshot.params['cus_id'], res => {
        if (res.status == "OK") {
          this.editCustomedData = res.data;
          this.loaderActionsService.display(false);
          this.customerDetails.patchValue({
            name: res.data.cust_name,
            displayName: res.data.cust_disply_name,
            email: res.data.cust_email,
            contactNumber: res.data.cust_contact,
            description: res.data.cust_description,
            addressOne: res.data.cust_billing_address,
            addressTwo: res.data.cust_billing_address_2,
            city: res.data.cust_billing_city,
            zipCode: res.data.cust_billing_zip,
            phoneNumber: res.data.customer_billing_phone,
            tempAddressOne: res.data.cust_address,
            tempAddressTwo: res.data.cust_address_2,
            tempCity: res.data.customer_city,
            tempZipCode: res.data.customer_zip,
            tempPhoneNumber: res.data.customer_phone
          });
          // this.tempStateSelected=res.data.cust_billing_state;
          // this.tempCountrySelected=res.data.cust_billing_country;
          // this.stateSelect=res.data.customer_state;
          // this.countrySelect=res.data.customer_country;
          if (res.data.customer_country || res.data.cust_billing_country) {
            for (let i = 0; i < this.countryList.length; i++) {
              if (this.countryList[i].id == res.data.cust_billing_country) {
                this.countrySelect = [i];
              }
              if (this.countryList[i].id == res.data.customer_country) {
                this.tempCountrySelected = [i];
              }
            }
          }
          if (res.data.cust_type) {
            for (let i = 0; i < this.type.length; i++) {
              if (this.type[i].type == res.data.cust_type) {
                this.typeSelect = [i];
              }
            }
          }
          if(res.data.cust_billing_is_same_as==1){
            this.sameAbove=true;
          }
          else{
            this.sameAbove=false;
          }

        }
        else {
          this.loaderActionsService.display(false);
        }
      });
    }
  }
  addCustomer() {
    let parms: any;
    if (!this.customerDetails.valid || !this.typeSelected.selected[0]) {
      this.customerDetailError = true;
      setTimeout(()=>{
				const error = document.querySelector('.error');
			 if(error){
				this.loaderActionsService.display(false);
				 this.scrollTop(error);
			 }
			  return;
			})
    } else {
      parms = {
        "cust_type": this.typeSelected.selected[0].type,
        "cust_name": this.customerDetails.value.name,
        "cust_disply_name": this.customerDetails.value.displayName,
        "cust_email": (this.customerDetails.value.email) ? this.customerDetails.value.email : null,
        "cust_contact": (this.customerDetails.value.contactNumber) ? this.customerDetails.value.contactNumber : null,
        "cust_description": (this.customerDetails.value.description) ? this.customerDetails.value.description : null,
        "cust_billing_address": (this.customerDetails.value.addressOne) ? this.customerDetails.value.addressOne : null,
        "cust_billing_address_2": (this.customerDetails.value.addressTwo) ? this.customerDetails.value.addressTwo: null,
        "cust_billing_country": (this.countrySelected.selected[0]) ? this.countrySelected.selected[0].id: null,
        "cust_billing_state": (this.stateSelected.selected[0]) ? this.stateSelected.selected[0].id: null,
        "cust_billing_city": (this.customerDetails.value.city) ? this.customerDetails.value.city: null,
        "cust_billing_zip": (this.customerDetails.value.zipCode) ? this.customerDetails.value.zipCode: null,
        "customer_phone": (this.customerDetails.value.tempPhoneNumber) ? this.customerDetails.value.tempPhoneNumber : null,
        "cust_billing_is_same_as": (this.sameAbove) ? 1 : 0,
        "cust_address": (this.customerDetails.value.tempAddressOne) ? this.customerDetails.value.tempAddressOne : null,
        "cust_address_2": (this.customerDetails.value.tempAddressTwo) ? this.customerDetails.value.tempAddressTwo : null,
        "customer_country": (this.tempCountryData.selected[0]) ? this.tempCountryData.selected[0].id : null,
        "customer_state": (this.tempstate.selected[0]) ? this.tempstate.selected[0].id : null,
        "customer_city": (this.customerDetails.value.tempCity) ? this.customerDetails.value.tempCity : null,
        "customer_zip": (this.customerDetails.value.tempZipCode) ? this.customerDetails.value.tempZipCode : null,
        "customer_billing_phone": (this.customerDetails.value.phoneNumber) ? this.customerDetails.value.phoneNumber : null,
        "cust_added_on": "0000-00-00 00:00:00",
        "cust_added_by": "0",
        "cust_modified_on": "0000-00-00 00:00:00",
        "cust_modified_by": "0",
        "cust_status": "1"
      }
      this.loaderActionsService.display(true);
      this.customerService.addcustomer(parms, this.routeActive.snapshot.params['cus_id'], response => {
        if (response.status == 'OK') {
          this.loaderActionsService.display(false);
          let self = this;
          setTimeout(function () {
            self.notificationService.alertBoxValue("success", response.message);
          });
          this.locations.navigate(['/modules/customer/customer-list']);

        }
        else {
          this.loaderActionsService.display(false);

          this.notificationService.alertBoxValue("error", response.message);

        }
      });
    }

  }
  scrollTop(el: Element) {
		if (el) {
			el.scrollIntoView({ behavior: 'smooth', block: 'center' });
			const input: any = el.querySelector('.form-control');
			if(input){
			  input.focus();
			}
			const firstChild = el.firstChild;
			if(input === firstChild){
				input.focus();
			}
		}
	}
  noWhitespaceValidator(control: FormControl) {
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true }
  }
  setAddress() {
    this.sameAbove = !this.sameAbove;
    if (this.sameAbove == true) {
      this.customerDetails.patchValue({
        tempAddressOne: this.addressOne.value,
        tempAddressTwo: this.addressTwo.value,
        tempCity: this.city.value,
        tempZipCode: this.zipCode.value,
        tempPhoneNumber: this.phoneNumber.value
      });
      for (let i = 0; i < this.countryList.length; i++) {
        if (this.countryList[i].id == this.countrySelected.selected[0].id) {
          this.tempCountrySelected = [i];
          break;
        }
      }
      this.tempstateList = this.stateList;
      for (let i = 0; i < this.tempstateList.length; i++) {
        if (this.tempstateList[i].id == this.stateSelected.selected[0].id) {
          this.tempStateSelected = [i];
          break;
        }
      }
    }
    else {
      this.customerDetails.patchValue({
        tempAddressOne: '',
        tempAddressTwo: '',
        tempCity: '',
        tempZipCode: '',
        tempPhoneNumber: ''
      });
      for (let i = 0; i < this.countryList.length; i++) {
        if (this.countryList[i].id == this.countrySelected.selected[0].id) {
          this.tempCountrySelected = '';
          break;
        }
      }
      this.tempstateList = this.stateList;
      for (let i = 0; i < this.tempstateList.length; i++) {
        if (this.tempstateList[i].id == this.stateSelected.selected[0].id) {
          this.tempStateSelected = '';
          break;
        }
      }
    }

  }
  confirmPopup() {
    window.history.back()
  }
  selectCountry(value, event, key, type) {
    if (event.selected[0] && type == 2) {
      this.loadermultiOnboard = true;
      this.customerService.getData('state', event.selected[0].id, response => {
        if (response.data && response.data.length > 0) {
          this.loadermultiOnboard = false;
          this.stateList = response.data;
          if (this.editCustomedData.id) {
            for (let i = 0; i < this.stateList.length; i++) {
              if (this.stateList[i].id == this.editCustomedData.cust_billing_state) {
                this.stateSelect = [i]
              }
            }
          }
          if(this.editCustomedData.id && this.sameAbove){
            this.tempstateList=this.stateList;
            for (let j = 0; j < this.stateList.length; j++) {
              if (this.stateList[j].id == this.editCustomedData.customer_state) {
                this.tempStateSelected = [j]
              }
            }
          }else{
            this.tempstateList=[];
          }
        }
        else {
          this.loadermultiOnboard = false;
          this.stateList = [];
        }
      });
    }
  }
  tempselectCountry(value, event, key, type) {
    if (event.selected[0] && type == 1 && !this.sameAbove) {
      this.tempStateData = event.selected[0];
      this.tempstateLoader = true;
      this.customerService.getData('state', event.selected[0].id, response => {
        if (response.data && response.data.length > 0) {
          this.tempstateLoader = false;
          this.tempstateList = response.data;
          if (this.editCustomedData.id) {
            for (let i = 0; i < this.tempstateList.length; i++) {
              if (this.tempstateList[i].id == this.editCustomedData.customer_state) {
                this.tempStateSelected = [i]
              }
            }
          }
        }
        else {
          this.tempstateLoader = false;
          this.stateList = [];
        }
      });
    }
  }

}
