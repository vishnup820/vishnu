import { Component, OnInit } from '@angular/core';
import { ApprovalsService } from '../../services/onduty-approvals/approvals.service';
import { CookieService } from 'ngx-cookie-service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { PendingListService } from '../../../shared/services/pending-list/pending-list.service';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-approval',
  templateUrl: './approval.component.html',
  styleUrls: ['./approval.component.css']
})
export class ApprovalComponent implements OnInit {


  userData           : any;
  searchValue        : any;
  advanceFilterData  : any;
  filterStatVal      : number;
  totalRecords       : number;
  selectedId         : number;
  status             : number;
  subId              : number;
  canelVal           : any


  currentPage        : number = 1;
  recordsPerPage     : number = 10;

  queryObject        : any = {}
  approvalDetails    : any = [];
  confirmBox         : boolean = false;
  searchTextBox      : boolean = false;
  filterStatus       : boolean = false;

  rejectPopUp        : boolean = false;
  cancelBox          : boolean = false;
  deleteBox          : boolean = false;
  adminRole          : boolean = false;
  managerRole        : boolean = false;
  singleCancelBox    : boolean = false;

  adminFilterSelected : any = [];
  adminFilter         : any = [{'name':'My Team','value':1},{'name':'Others','value':2}];
  selAdminfilter      : any = [];
  blockedInitialcall  : number = 0;
  constructor( private ApprovalsService:ApprovalsService,
    private cookieService:CookieService,
    private loader:LoaderActionsService,
    private timezoneDetailsService:TimezoneDetailsService,
    private notifications:NotificationService,
    private AclVerificationService:AclVerificationService,
    private PendingListService  :PendingListService) { }

  ngOnInit() {
    this.adminRole   = this.AclVerificationService.checkAclDummy('onduty-all-employees');
    this.managerRole = this.AclVerificationService.checkAclDummy('team-list');
    if (this.cookieService.get("user-data")) {
      this.userData = JSON.parse(this.cookieService.get("user-data"));
    }
    if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    if(this.adminRole){
      this.adminFilterSelected = [0]
      this.queryObject['adminFilter'] = 'myteam';
    }
    this.queryObject.page = this.currentPage;
    this.queryObject.page_limit = this.recordsPerPage;
    this.approvalList();
  }
  open(url){
    window.open(url)
  }

  updateList(){
    this.PendingListService.getPendingList(response => {
      if (response) {
            let pendata = response;
          let aclData=  JSON.parse(localStorage.getItem("acl"));
          if(aclData.acl.length>0){
            for(let i=0; i<aclData.acl.length;i++){
              if(aclData.acl[i].name=='Approvals'){
                aclData.acl[i].acl.pending=pendata.total_pending;
                for(let j=0;j<aclData.acl[i].child.length; j++){
                    if(aclData.acl[i].child[j].name=='Onduty Approval'){
                      aclData.acl[i].child[j].acl.pending=pendata.onDuty[0].pending;
                    }
                  }
              }
            }
          }
          localStorage.setItem('acl',JSON.stringify(aclData))
          this.PendingListService.setAclData(aclData);
        }
    })
  } 
  selectedAdminfilter(ev){
    if(this.blockedInitialcall == 1)
    if(ev && ev.selected && ev.selected[0].value == 2){
      this.queryObject['adminFilter'] = 'all';
      this.queryObject.page = 1;
      this.approvalList();
    }else if(ev && ev.selected && ev.selected[0].value == 1){
      this.queryObject['adminFilter'] = 'myteam';
      this.queryObject.page = 1;
    this.approvalList();
    }else{
      this.queryObject['adminFilter'] = '';
    }
    this.blockedInitialcall = 1
  }

  approvalList() {
    let secondHand = [];
    let tempArray = [];
    this.loader.display(true);
    this.ApprovalsService.getApprovalList(this.queryObject, response => {
      if (response.status == "OK") {
        for (var i = 0; i < response.data.length; i++) {
        for (var j = 0; j < response.data[i].details.length; j++) {
          secondHand.push({ date: response.data[i].details[j].applied_date, status:response.data[i].details[j].status });
        }
        tempArray.push(secondHand);
        let name =[];
        name =  response.data[i].name.split(" ");
        response.data[i].first_name = name[0];
        response.data[i].last_name  = name[name.length-1];

      }
        this.approvalDetails = response.data;
        this.dateConversion();
        this.currentPage = this.queryObject.page;
        this.totalRecords = Number(response.count);
        this.loader.display(false);


      }
    })
  }


  dateConversion() {
    for (let i = 0; i < this.approvalDetails.length; i++) {
      let temp = this.approvalDetails[i].requested_on.split(" ");

      let tempFirst = this.timezoneDetailsService.getLocalDate(temp[0] + " " + temp[1]);
      this.approvalDetails[i].requested_on = new Date(tempFirst).getFullYear() + "-" + (Number(new Date(tempFirst).getMonth()) + 1) + "-" + new Date(tempFirst).getDate();
    }
  }
  
  commentCheck(d){
    if(d.comments==null || d.comments=="" || d.comments=='' || d.comments==undefined || !d.comments){
      return false;
    }else{
      return true;
    }
  }
   /*
  author : Nilena Alexander
  desc   : add class based on index
 */
getClassByValue(index) {
  return this.ApprovalsService.getClassByValue(index);

}
  /**
* @ desc   : TO implement pagination
* @ author  : Nilena Alexander
*/
  pageChangeEvent(page) {
    this.queryObject.page = page;
    this.currentPage = page;
    this.approvalList();
  }
  /*
   * @ desc   : TO implement pagination
   * @ author  : Nilena Alexander
   */
  getpage(eve) {
    if (eve > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = eve;
      this.queryObject['page_limit'] = eve;
      this.queryObject['page'] = 1;
      this.currentPage = 1;
      this.approvalList();
    }
  }
  /*
   * @ desc   : TO implement search
   * @ author  : Nilena Alexander
   */
  search(value, set) {
    if (value.trim() != '' || (this.searchValue != '' && this.searchValue)) {
      this.searchValue = value;
      this.currentPage = 1;
      this.queryObject.keyword =  this.searchValue;
      this.approvalList();
    }
  }
 /*
  *  @desc   :method send messages to the server with sender's id
  *  @author :nilena
  */
 setFocus() {
  window.setTimeout(function() {
    document.getElementById('searchField').focus();
  }, 1);
}
  /*
  author : nilena
  desc   : send Filter Data
  params :
   */

  filterData(event) {
   if (event || this.advanceFilterData) {
    this.advanceFilterData = event;
    // let temp = (this.queryObject.type) ? "-" + obj.department : obj.department;

    if (this.advanceFilterData) {
      if (this.advanceFilterData.range) {
        this.queryObject.reqstart = this.formatForApi(this.advanceFilterData.range[0]);
        this.queryObject.reqend = this.formatForApi(this.advanceFilterData.range[1]);
     }
      if (this.advanceFilterData.status.selected.length) {
        if (this.advanceFilterData.status.selected[0].value == "Pending") {
          if(!this.adminRole && this.managerRole){
            this.queryObject.mngstat  = "1";
            this.filterStatVal = 1;
          }
          else
          this.queryObject.stat = "1";
        } else if (this.advanceFilterData.status.selected[0].value == "Approved") {
          if(!this.adminRole && this.managerRole)
          {  
          this.queryObject.mngstat  = "2";
          this.filterStatVal = 2;
          }
          else
          this.queryObject.stat = "2";
        }
        else if (this.advanceFilterData.status.selected[0].value == "Rejected") {
          if(!this.adminRole && this.managerRole)
          {  this.queryObject.mngstat  = "3";
          this.filterStatVal = 3;
          }        
          else
          this.queryObject.stat = "3";
        }
        else if (this.advanceFilterData.status.selected[0].value == "Cancelled") {
          if(!this.adminRole && this.managerRole)
          {  
          this.queryObject.mngstat  = "4";
           this.filterStatVal = 4;
          }    
           else
          this.queryObject.stat = "4";
        }
      }
      else {
        this.queryObject.stat = null;
        this.queryObject.mngstat  = null;
        this.filterStatVal = 0;
      }
        if (this.advanceFilterData.department.selected.length) {
          this.queryObject.dept= this.advanceFilterData.department.selected[0].id;
        }else {
          this.queryObject.dept = null;
        }
        if (this.advanceFilterData.designation.selected.length) {
         this.queryObject.desig = this.advanceFilterData.designation.selected[0].id;
        }else {
          this.queryObject.desig = null;
        }
        if (this.advanceFilterData.location.selected.length) {
         this.queryObject.loc = this.advanceFilterData.location.selected[0].id;
        }else {
          this.queryObject.loc = null;
        }
        this.queryObject.page = 1;
        this.approvalList();

    }else{
      this.queryObject.page = 1;
    this.advanceFilterData = undefined;
    this.queryObject.stat = null;
    this.queryObject.desig = null;
    this.queryObject.dept = null;
    this.queryObject.loc = null;
    this.queryObject.mngstat  = null;
    this.queryObject.reqstart = null;
    this.queryObject.reqend = null;
    this.approvalList();

    }
  //   if(!temp)
  //       temp = "";
  //  }
   }
   else{
    this.queryObject.page = 1;
    this.advanceFilterData = undefined;
    this.queryObject.stat = null;
    this.queryObject.desig = null;
    this.queryObject.dept = null;
    this.queryObject.loc = null;
    this.queryObject.reqstart = null;
    this.queryObject.reqend = null;
    this.queryObject.mngstat  = null;


   }
   
  }



  /*
	*  @desc   : make date to the format 'dd-mm-yyyy'
	*  @author : nilena
	*/
  formatForApi(inputDate) {
    var date = this.timezoneDetailsService.toLocal(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
      }
      else
        return undefined;
    }
   /*
  *  @desc   :method toapprove
  *  @author :nilena
  */

  toApprove(index) {
    this.confirmBox = true;
    this.status = 3;
    this.selectedId = this.approvalDetails[index].id;
  }
 /*
  *  @desc   :method to reject
  */
  toReject(index) {
    this.selectedId = this.approvalDetails[index].id;
    this.rejectPopUp = true;
    this.status = 3;
  }
   /*
  *  @desc   :method tocancel
  *  @author :nilena
  */
 toCancel(i) {
  this.selectedId = this.approvalDetails[i].id;
  this.cancelBox = true;
 } 
  /*
  *  @desc   :method tocancelSingle
  *  @author :nilena
  */
 singleCancel(i, j,mainstat ,mangerstat) {
   if(this.adminRole){
    this.selectedId = this.approvalDetails[i].id;
    this.subId = this.approvalDetails[i].details[j].id;
    if(mainstat != 2){
      this.deleteBox = true;
      this.singleCancelBox = false;
    }
    else{
      this.singleCancelBox = true;
      this.deleteBox = false;
     }
   }else {
    if(mangerstat == 2 || mainstat ==2 ){
      this.selectedId = this.approvalDetails[i].id;
      this.subId = this.approvalDetails[i].details[j].id;
        this.singleCancelBox = true;
        this.deleteBox = false;
     }else{
      this.selectedId = this.approvalDetails[i].id;
      this.subId = this.approvalDetails[i].details[j].id;
      this.deleteBox = true;
      this.singleCancelBox = false;
     }
   } 
 
}

getDeleteConfirm(event) {
  this.deleteBox = false;
  this.loader.display(true);
  this.ApprovalsService.singleReject(this.selectedId, {
    "comments": event.value, "status": "R"
  }, this.subId, response => {
    if (response.status == "OK") {
      this.updateList()
      this.notifications.alertBoxValue("success", "Onduty Rejected Sucessfully");
      this.currentPage = 1;
      this.approvalList();
    }
    else {
      this.updateList();
      this.currentPage = 1;
      this.approvalList();
      this.loader.display(false);
      this.notifications.alertBoxValue("error", response.message);
    }
  })
}
getSingleCancelConfirm(event) {
  this.singleCancelBox = false;
  this.loader.display(true);
  this.ApprovalsService.singleReject(this.selectedId, {
    "comments": event.value, "status": "C"
  }, this.subId, response => {
    if (response.status == "OK") {
      this.updateList()
      this.notifications.alertBoxValue("success", "Onduty Cancelled Successfully");
      this.currentPage = 1;
      this.approvalList();
    }
    else {
      this.updateList();
      this.currentPage = 1;
      this.approvalList();
      this.loader.display(false);
      this.notifications.alertBoxValue("error", response.message);
    }
  })
}

	/*
   *  @desc   :download attachment form leave list
   *  @author :dipin
   */
	attachmentDownloadCommon(id, i, j, value) {
   var tempI = i;
		var tempJ = j;
		this.loader.display(true);
		this.ApprovalsService.attachemntDownload(id, res => {
			if (res.status != "success") {
				this.loader.display(false);
			}
			else {
				let binary_string: any = window.atob(res.data);
				let types;
				if (value == false)
					if (this.approvalDetails[tempI].file_details[tempJ].file_type == "png" || this.approvalDetails[tempI].file_details[tempJ].file_type == "jpg" || this.approvalDetails[tempI].file_details[tempJ].file_type == "jpeg") {
						types = 'image/png';
					}
					else if (this.approvalDetails[tempI].file_details[tempJ].file_type == "pdf") {
						types = 'application/pdf';
					}
					else {
						types = "application/octet-stream";
					}
				else {
					types = "application/zip";
				}
				let len: any = binary_string.length;
				let bytes: any = new Uint8Array(len);
				for (var i = 0; i < len; i++) {
					bytes[i] = binary_string.charCodeAt(i);
				}
				let file: any = new Blob([bytes.buffer], { type: types });
				if (value == false)
					FileSaver.saveAs(file, this.approvalDetails[tempI].file_details[tempJ].file_name);
				else
					FileSaver.saveAs(file, "document " + this.timezoneDetailsService.getCurrentDate().toDateString());
				this.loader.display(false);
			}
		})
	}

dateDelete(event) {
  this.rejectPopUp = false;
  this.loader.display(true);
  this.ApprovalsService.ChangeSatus(this.selectedId, {
    "comments": event.value, 
    "status": "3"
  }, response => {
    if (response.status == "OK") {
      this.updateList();
      this.notifications.alertBoxValue("success", "Onduty Rejected Successfully");
      this.currentPage = 1;
      this.approvalList();
    }
    else {
     
      this.updateList();
      this.notifications.alertBoxValue("error", response.message);
      this.currentPage = 1;
      this.approvalList();
    }
  })
}

  /*
   *  @desc   :method to get responce from the confirm popup component
   *  @author :nilena
   */
  getPopupConfirm(event) {
    this.confirmBox = false;
    if (event.status == true) {
      this.loader.display(true);
      this.ApprovalsService.ChangeSatus(this.selectedId, {
       "status": "2", "comments": event.value
      }, response => {
        if (response.status == "OK") {
          this.updateList()
          this.notifications.alertBoxValue("success", "Onduty Approved Successfully");
          this.currentPage = 1;
          this.approvalList();
        }
        else {
          this.updateList()
          this.currentPage = 1;
          this.approvalList();
          this.loader.display(false);
          this.notifications.alertBoxValue("error", response.message);
        }
      })
    }
  }

 getCancelConfirm(event) {
  this.cancelBox = false;
  if (event.status == true) {
     let obj=  {
      "status":'4', 
      "comments": event.value
     }
    this.loader.display(true);
    this.ApprovalsService.ChangeSatus(this.selectedId, obj, response => {
      if (response.status == "OK") {
        this.updateList()
        this.notifications.alertBoxValue("success", "Onduty Cancelled Successfully");
        this.currentPage = 1;
        this.approvalList();
      }
      else {
        this.updateList()
        this.notifications.alertBoxValue("error", response.message);
        this.currentPage = 1;
        this.approvalList();
        this.loader.display(false);
        this.notifications.alertBoxValue("error", response.message);
      }
    })
  }
}



}
