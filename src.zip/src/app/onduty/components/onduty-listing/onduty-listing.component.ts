import { Component, OnInit, Renderer2 } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormArrayName, FormControl, Validators } from '@angular/forms';
import * as FileSaver from 'file-saver';
import { OndutyListingService } from '../../services/onduty-listing/onduty-listing.service';
import { CookieService } from 'ngx-cookie-service';

// import { LoaderActionsService } from 'src/app/shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';

declare var require: any;
var moment = require('moment');
@Component({
  selector: 'app-onduty-listing',
  templateUrl: './onduty-listing.component.html',
  styleUrls: ['../../../../assets/content/css/manager_compensatory.css']
})
export class OndutyListingComponent implements OnInit { 

  empSearch         : any;
  userData          : any;

  dateRangeValue    : any;
  statusSelected    : any;
  dateValue         : any;
  maxdate           : any;
  minDate           : any;
  reasonField       : any;
  selectedEmailData : any;
  emailData         : any;
  daySelect         : any;
  listId            : any;
  payExtraPeriod    : any;
  payPeriod         : any;
  fileData          : any;
  fileName          : any;
  minDateFinancial  : any;
  deleteId          : number;
  empId             : number;
  editId            : number;
  totalRecords      : number;

  currentPage       : number = 1;
  recordsPerPage    : number = 10;

  dateFromValue     : any = [];
  bsValue           : any = [];
  dateToValue       : any = [];
  userList          : any = [];
  selectedItems     : any = [];
  ondutyData        : any = [];
  daySelected       : any = [];
  empList           : any = [];
  empDetails        : any = [];
  dayTime           : any = [];
  status            : any = [];
  dayValue          : any = [];
  fromValue         : any = [];
  toValue           : any = [];
  selectedEmail     : any = [];
  sameFromdate      : any = [];
  sameTodate        : any = [];
  editdetailList    : any = [];
  dayRestricted     : any = [];
  dispListList      : any = [];
  requiredTodate    : any = [];
  statusChecked     : any = [];
  requiredFromdate  : any = [];
  dayCheckList      : any = [];
  filterStatVal     :number;
  queryObject       : any = {};
  ondutyForm        : FormGroup;
  empExit           : boolean = false;
  addForm           : boolean = false;
  addNewError       : boolean = false;
  fromError         : boolean = false
  toError           : boolean = false
  dayError          : boolean = false
  reasonEmpty       : boolean = false
  lazyLoad		      : boolean = false;
  employeeEmpty     : boolean = false;
  SameSelectedDates : boolean = false;
  editStatus        : boolean = false;
  filterStatus	    : boolean = false;
  filterActive      : boolean = false;
  confirmBox        : boolean = false;
  disabled          : boolean = false;
  adminRole         : boolean = false; 
  managerRole       : boolean = false;
  userType          : boolean = false;
  moveToTop         : boolean = false;
  toDateDisabled    : any=  [];
  start             : any;
  config            : any = "Are You Sure You Want To Cancel?";



  constructor( private OndutyListingService: OndutyListingService,
        private formBuilder                : FormBuilder,
        private cookieService              : CookieService,
        private timezoneDetailsService     : TimezoneDetailsService,
        private NotificationService        : NotificationService,
        private loader                     : LoaderActionsService,
        private AclVerificationService     : AclVerificationService

 ) { }


	ngOnInit() {
    this.loader.display(true);
		if (this.cookieService.get("user-data")) {
      this.userData = JSON.parse(this.cookieService.get("user-data"));
      this.minDateFinancial= this.timezoneDetailsService.toLocal(this.userData.financialMin_date);
			this.adminRole    = this.AclVerificationService.checkAclDummy('onduty-all-employees');
			this.managerRole  = this.AclVerificationService.checkAclDummy('team-list');
			this.listId       = this.userData.user_id;
      this.empId        = this.userData.user_id;

      this.start   = this.timezoneDetailsService.toLocal(this.userData.start_date);
      this.maxdate = this.timezoneDetailsService.toLocal(this.userData.end_date);
      this.dateRangeValue=[this.start,this.maxdate];
      if (this.dateRangeValue) {
        setTimeout(() => {
          this.dateRangeValue = [this.start,this.maxdate];
          this.dateRangeChange(this.dateRangeValue);
        }, 500);
      }
      if (this.dateRangeValue) {
        this.queryObject.reqstart = this.formatForApi(this.dateRangeValue[0]);
        this.queryObject.reqend = this.formatForApi(this.dateRangeValue[1]);
      }
      this.filterActive = true;
       
			if (this.empId != this.userData.user_id) {
				this.userType = false;
			}
			else {
				this.userType = true;
			}
			this.empSearch = this.userData.first_name + " " + this.userData.last_name + "(" + this.userData.employee_id + ")";
			this.status = [{ "value": "Rejected", "name": 3 }, { "value": "Pending", "name": 1 }, { "value": "Approved", "name": 2 }, { "value": "Cancelled", "name": 2 }];

			this.dayTime = [{ "id": 1, "name": "Full Day" },
			{ "id": 2, "name": "Half day(First Half)" },
			{ "id": 3, "name": "Half day(Second Half)" }]
			if (localStorage.getItem("itemsperpage")) {
				this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
			}
			else {
				this.recordsPerPage = 10;
			}
			if (!this.emailData) {
				this.OndutyListingService.emailListing(response => {
					if (response.status == "OK") {
						if (response.data) {
							this.emailData = response.data;
							for (let i = 0; i < this.emailData.length; i++) {
								if (this.emailData[i].email.trim() == "" || this.emailData[i].email == this.userData.rm_email || this.emailData[i].email == this.userData.email) {
									this.emailData.splice(i, 1);
								}
							}
						}
            this.peopleList();
					}
				})
			}
			this.queryObject.page = this.currentPage;
			this.queryObject.page_limit = this.recordsPerPage;
		}
  }
  
/*
   author : Nilena Alexander
   desc   : To view add Form
   */
  addview() {
    this.fileData= null
    this.daySelected[0] = [0];
    this.empId = this.userData.user_id;
    this.empSearch = this.userData.first_name + " " + this.userData.last_name + "(" + this.userData.employee_id + ")";
    if (this.empId != this.userData.user_id) {
      this.userType = false;
    }
    else {
      this.userType = true;
    }
    this.holidayCheck();
    this.intialForm();
    this.createform();
  }

  /*
   author : Nilena Alexander
   desc   : Intial form fields
   */

  intialForm() {
    this.ondutyForm = this.formBuilder.group({
      repeatForm: this.formBuilder.array([this.createform()])
    })

  }
  createform(dateFromValue?, dateToValue?, daytype?) {

    return new FormGroup({
      dateFromValue: new FormControl(dateFromValue ? dateFromValue : '', [Validators.required]),
      dateToValue: new FormControl(dateToValue ? dateToValue : '', [Validators.required]),
      daytype: new FormControl(daytype ? daytype : '', [Validators.required]),
    })

  }


  get AddForms() {
    return this.ondutyForm.get('repeatForm') as FormArray
  }

  /*
   author : Nilena Alexander
   desc   : To add a row
   */
  addRow() {
    let i = this.AddForms.value.length - 1;
    if (this.AddForms.value[i].dateFromValue == '' || this.AddForms.value[i].dateToValue == '') {
      this.addNewError = true;
      if (this.AddForms.value[i].dateFromValue == '') {
        this.sameFromdate[i] = true;
        this.fromError = true;
      }
      if (this.AddForms.value[i].dateToValue == '') {
        this.sameTodate[i] = true;
        this.toError = true;
      }
    }
    else {
      this.addNewError = false;
      this.sameFromdate[i] = false;
      this.sameTodate[i] = false;
    }

    if (!this.addNewError && !this.toValue[i] && !this.fromValue[i] && !this.requiredFromdate[i] && !this.requiredTodate[i]) {

      this.AddForms.push(this.createform());
      this.daySelected[i + 1] = [0];
      this.dateFromValue[i + 1] = null;
      this.dateToValue[i + 1] = null;

    } else
      this.addNewError = true;
  }

  /*
   author : Nilena Alexander
   desc   : To delete a row
   */
  deleteRow(i) {

    this.AddForms.controls.splice(i, 1)
    this.AddForms.value.splice(i, 1)
    this.dateFromValue.splice(i, 1);
    this.dateToValue.splice(i, 1);
    this.fromValue[i] = false;
    this.toValue[i] = false;
    this.sameFromdate[i] = false;
    this.sameTodate[i] = false;
    this.requiredTodate[i] = false;
    this.requiredFromdate[i] = false;

  }
  /*
    author : Nilena Alexander
    desc   : To pick a daytype for onduty
    */
  dayTimeEvent(event, i) {
    (event.selected[0]) ? this.AddForms.controls[i]['controls']['daytype'] = (event.selected[0].id) : '';
    (event.selected[0]) ? this.AddForms.value[i]['daytype'] = (event.selected[0].id) : '';
    (event.selected[0]) ? (this.daySelect = event.selected[0].id) : (this.daySelect = '');

  }

	/*
   *  @desc   :download attachment form leave list
   *  @author :dipin
   */
	attachmentDownloadCommon(id, i, j, value) {
    var tempI = i;
     var tempJ = j;
     this.loader.display(true);
     this.OndutyListingService.attachemntDownload(id, res => {
       if (res.status != "success") {
         this.loader.display(false);
       }
       else {
         let binary_string: any = window.atob(res.data);
         let types;
         if (value == false)
           if (this.ondutyData[tempI].file_details[tempJ].file_type == "png" || this.ondutyData[tempI].file_details[tempJ].file_type == "jpg" || this.ondutyData[tempI].file_details[tempJ].file_type == "jpeg") {
             types = 'image/png';
           }
           else if (this.ondutyData[tempI].file_details[tempJ].file_type == "pdf") {
             types = 'application/pdf';
           }
           else {
             types = "application/octet-stream";
           }
         else {
           types = "application/zip";
         }
         let len: any = binary_string.length;
         let bytes: any = new Uint8Array(len);
         for (var i = 0; i < len; i++) {
           bytes[i] = binary_string.charCodeAt(i);
         }
         let file: any = new Blob([bytes.buffer], { type: types });
         if (value == false)
           FileSaver.saveAs(file, this.ondutyData[tempI].file_details[tempJ].file_name);
         else
           FileSaver.saveAs(file, "document " + this.timezoneDetailsService.getCurrentDate().toDateString());
         this.loader.display(false);
       }
     })
   }
  /*
    author : Nilena Alexander
    desc   : TbsDateChange event
    */

  dateChange(dateFrom, dateTo, i, type) {
    if (dateFrom)
      this.dateFromValue[i] = dateFrom;


    if (dateTo){
       this.dateToValue[i] = dateTo;
     }
    else{
      this.dateToValue[i] = this.dateFromValue[i];
    }


    if(this.timezoneDetailsService.toLocal( this.dateFromValue[i])>=this.timezoneDetailsService.toLocal( this.dateToValue[i])){
         this.dateToValue[i] = this.dateFromValue[i];
    }
      // var startDate =this.formatDate(this.dateFromValue[i]);
      // var endDate = this.formatDate(this.dateToValue[i]);
      // var regExp = "/(\d{1,2})\/(\d{1,2})\/(\d{2,4})/";
      // if(parseInt(startDate.replace(regExp, "$3$2$1")) > parseInt(endDate.replace(regExp, "$3$2$1"))){
      //   this.dateToValue[i] = this.dateFromValue[i];
      // }
    // this.dateRangeChecking(i);
    (this.dateFromValue[i]) ? (this.sameFromdate[i] = false) : (this.sameFromdate[i] = true);
    (this.dateToValue[i]) ? (this.sameTodate[i] = false) : (this.sameTodate[i] = true);

    this.checkValidations(this.dateFromValue[i], this.dateToValue[i], i);

    if(this.sameFromdate[i]||this.requiredFromdate[i] || this.fromValue[i]){
      this.toDateDisabled [i]=true;
    }else{
      this.toDateDisabled [i]=false;
      (this.dateFromValue[i]) ? this.AddForms.controls[i]['controls']['dateFromValue'] = this.dateFromValue[i] : null;
      (this.dateFromValue[i]) ? this.AddForms.value[i]['dateFromValue'] = this.dateFromValue[i] : null;

      (this.dateToValue[i]) ? this.AddForms.value[i]['dateToValue'] = this.dateToValue[i] : null;
      (this.dateToValue[i]) ? this.AddForms.controls[i]['controls']['dateToValue'] = this.dateToValue[i] : null;

    }

  }

  // formatDate(inputDate) {
  //   var date =  this.timezoneDetailsService.toLocal(inputDate);
  //   if (!isNaN(date.getTime())) {
  //     if ((Number(date.getMonth()) + 1) < 10) {
  //       if (Number(date.getDate() < 10)) {
  //         return "0" + date.getDate() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
  //       }
  //       else {
  //         return date.getDate() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
  //       }
  //     }
  //     else {
  //       if (Number(date.getDate() < 10)) {
  //         return "0" + date.getDate() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
  //       }
  //       else {
  //         return date.getDate() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getFullYear();
  //       }
  //     }
  //   }
  // }

  checkValidations(dateFrom?, dateTo?, index?) {

    let cStatus = false;
    let eStatus = false;
    if (dateFrom) {
      if (this.dayRestricted.leaveDates.holiday) {
        for (let j = 0; j < this.dayRestricted.leaveDates.holiday.length; j++) {
          if (this.formatForApi(this.dateFromValue[index]) == this.dayRestricted.leaveDates.holiday[j]) {
            this.fromValue[index] = true;
            this.dateToValue[index] = null;
            cStatus = true;
            break;
          }
          else {
            cStatus = false;
            this.fromValue[index] = false;
          }
        }
      }
      if (!cStatus) {
        for (let j = 0; j < this.dayRestricted.leaveDates.weekend.length; j++) {
          if (this.formatForApi(this.dateFromValue[index]) == this.dayRestricted.leaveDates.weekend[j]) {
            this.fromValue[index] = true;
            this.dateToValue[index] = null;
            eStatus = true;
            break;
          }
          else {
            eStatus = false;
            this.fromValue[index] = false;
          }
        }
      }
    }
    if (dateTo) {
      let cStatus = false;
      if (this.dayRestricted.leaveDates.holiday) {
        for (let j = 0; j < this.dayRestricted.leaveDates.holiday.length; j++) {
          if (this.formatForApi(this.dateToValue[index]) == this.dayRestricted.leaveDates.holiday[j]) {
            this.toValue[index] = true;
            cStatus = true;
            break;
          }
          else {
            cStatus = false;
            this.toValue[index] = false;
          }
        }
      }
      if (!cStatus) {
        for (let j = 0; j < this.dayRestricted.leaveDates.weekend.length; j++) {
          if (this.formatForApi(this.dateToValue[index]) == this.dayRestricted.leaveDates.weekend[j]) {
            this.toValue[index] = true;
            eStatus = true;
            break;
          }
          else {
            eStatus = false;
            this.toValue[index] = false;
          }
        }
      }
    }

    if (!cStatus && !eStatus) {
      let fStatus: boolean = false;
       for (let j = 0; j < this.AddForms.value.length; j++) {
        if (j != index && this.dateFromValue[index] >=  this.AddForms.value[j]['dateFromValue'] && this.dateFromValue[index] <=  this.AddForms.value[j]['dateToValue'] && this.dateFromValue[index]) {
          this.requiredFromdate[index] = true;
          this.dateToValue[index] = null;
          fStatus = true;
          break;
        } else
         this.requiredFromdate[index] = false;
         fStatus = false;
    }
    for (let j = 0; j < this.AddForms.value.length; j++) {
      if (j != index && this.dateToValue[index] >=  this.AddForms.value[j]['dateFromValue'] && this.dateToValue[index] <=  this.AddForms.value[j]['dateToValue'] && this.dateToValue[index]) {
        this.requiredTodate[index] = true;
        fStatus = true;
        break;
      } else
       this.requiredTodate[index] = false;
       fStatus = false;
   }
  }
    // for(let j=0;j<this.AddForms.value.length;j++){
    //   if(j!=index){
    // let val1 = this.dateFromValue[index].valueOf();
    //     let val3 = val2.valueOf();
    //     let val5 = val4.valueOf();

    //     if(val1==val3){
    //       this.SameSelectedDates=true;
    //       this.sameFromdate[i]='';
    //     }
    //     else if(val1===val5){
    //       this.SameSelectedDates=true;
    //       this.sameTodate[i]='';
    //     }
    //     else
    //      this.SameSelectedDates=false;
    //   }
    // }
    // if(this.SameSelectedDates==false){
    //   this.dateFromValue[i]==null;
    // }

    //  }
  }
  financialYearMin(listid) {
    this.lazyLoad = true;
    this.OndutyListingService.validationsForDate(listid, res => {
      if (res.status == "OK") {
        this.dayRestricted = res.data;
        this.disabled = false;
        this.minDateFinancial = this.timezoneDetailsService.getLocalDate(this.dayRestricted.financialYear.start_date);
        this.maxdate = this.timezoneDetailsService.getLocalDate(this.dayRestricted.financialYear.end_date);
          setTimeout(() => {
            this.dateRangeValue = [this.minDateFinancial,this.maxdate]         
            this.dateRangeChange(this.dateRangeValue);   
          }, 500);
          this.queryObject.reqstart = this.dayRestricted.financialYear.start_date;
          this.queryObject.reqend =this.dayRestricted.financialYear.end_date;   
        this.ondutyDetails();
        this.lazyLoad = false;

      } else
        if (res.message == "No data found" || res.status == "Failed") {
          this.dayRestricted = [];
          this.lazyLoad = false;
          this.disabled = true;

        }

    })
  }


  /*
   author : Nilena Alexander
   desc   : datechecking
   */
  holidayCheck() {
    this.lazyLoad = true;
    this.OndutyListingService.validationsForDate(this.empId, res => {
      if (res.status == "OK") {
        this.dayRestricted = res.data;
        this.disabled = false;
        this.minDate = this.timezoneDetailsService.getLocalDate(this.dayRestricted.financialYear.start_date);
        this.maxdate = this.timezoneDetailsService.getLocalDate(this.dayRestricted.financialYear.end_date);
        this.payPeriod = (res && res.data)?res.data.payPeriodDay:undefined;
        this.payExtraPeriod = (res && res.data && res.data.overRideDay)?Number(res.data.overRideDay) : undefined;
        this.checkWithPayperiod();
        this.lazyLoad = false;

      } else
        if (res.message == "No data found" || res.status == "Failed") {
          this.dayRestricted = [];
          this.lazyLoad = false;
          this.disabled = true;

        }

    })
  }

  /*
   author : Nilena Alexander
   desc   : reaon box
   */
  reason() {

    if (this.reasonField == null || this.reasonField == "")
      this.reasonEmpty = true;
    else
      if (!this.reasonField.replace(/\s/g, '').length)
        this.reasonEmpty = true;
      else
        this.reasonEmpty = false;
  }
  /*
    author : Nilena Alexander
    desc   : submit
    */
  submitForm() {
    let cStatus = false;
    let eStatus = false;
    let fStatus = false;
    let gStatus = false;
    let hStatus = false;
    let kStatus = false;

    for (let i = 0; i < this.AddForms.value.length; i++) {
      if (this.AddForms.value[i].dateFromValue == '' || this.AddForms.value[i].dateToValue == '') {
        this.addNewError = true;
        if (this.AddForms.value[i].dateFromValue == '') {
          this.sameFromdate[i] = true;
          this.fromError = true;
        }
        if (this.AddForms.value[i].dateToValue == '') {
          this.sameTodate[i] = true;
          this.toError = true;
        }
      }
      else {
        this.sameFromdate[i] = false;
        this.sameTodate[i] = false;
        this.addNewError = false;
        this.toError=false
        this.fromError = false;

      }

    }
    if (this.reasonField == null) {
      this.reasonEmpty = true;
    }
    if (this.empId == null ) {
      this.employeeEmpty = true;
    }
    if(this.sameTodate.length){
      for( let i =0;i<this.sameTodate.length;i++){
         if(this.sameTodate[i] == true) {
          this.sameTodate[i] =true;
          fStatus= true;
          break;
         }
         else{
          fStatus= false;
          this.sameTodate[i] =false;
         }
      }
    }
    if(this.sameFromdate.length){
      for( let i =0;i<this.sameFromdate.length;i++){
         if(this.sameFromdate[i] == true) {
          this.sameFromdate[i] = true;
          hStatus= true;
          break;
         }
         else{
          hStatus= false;
          this.sameFromdate[i] = false;
         }
      }
    }
    if(this.toValue.length){
      for( let i =0;i<this.toValue.length;i++){
         if(this.toValue[i] == true) {
          this.toValue[i] =true;
          cStatus= true;
          break;
         }
         else{
          cStatus= false;
          this.toValue[i] =false;
         }
      }
    }
    if(this.fromValue.length){
      for( let i =0;i<this.fromValue.length;i++){
         if(this.fromValue[i] == true) {
          this.fromValue[i] = true;
          if(this.sameFromdate[i] == true ){
            this.sameFromdate[i] = false
          }
          gStatus= true;
          break;
         }
         else{
          gStatus= false;
          this.fromValue[i] = false;
         }
      }
    }

    if(this.requiredTodate.length){
      for( let i =0;i<this.requiredTodate.length;i++){
         if(this.requiredTodate[i] == true) {
          this.requiredTodate[i] = true;

          eStatus= true;
          break;
         }
         else{
          eStatus= false;
          this.sameTodate[i] = false;
         }
      }
    }
    if(this.requiredFromdate.length){
      for( let i =0;i<this.requiredFromdate.length;i++){
         if(this.requiredFromdate[i] == true) {
          this.requiredFromdate[i] = true;
          if(this.sameFromdate[i]== true ){
            this.sameFromdate[i]= false
          }
          kStatus= true;
          break;
         }
         else{
          kStatus= false;
          this.requiredFromdate[i] = false;
         }
      }
    }

    if (!this.addNewError && !this.reasonEmpty && !this.employeeEmpty && !cStatus && !hStatus && !fStatus && !eStatus && !kStatus && !gStatus) {
      this.lazyLoad=true;
      let tempDetails = [];
      let tempEmail = [];
      for (var i = 0; i < this.AddForms.value.length; i++) {
        tempDetails.push({
          "from": this.formatForApi(this.AddForms.value[i].dateFromValue),
          "to": this.formatForApi(this.AddForms.value[i].dateToValue),
          "application_type": this.AddForms.value[i].daytype
        });
      }
      if (this.selectedEmailData) {
        for (let i = 0; i < this.selectedEmailData.length; i++) {
          tempEmail.push(this.selectedEmailData[i].label);
        }
      }
      let onduty_obj = {
        "details": {
          "user_id": this.empId,
          "notified_peoples": (tempEmail.length) ? tempEmail.toString() : '',
          "reason_for_leave": this.reasonField,
          "requested_by": this.userData.user_id,
        },
        "dateDetails": tempDetails,
        "file_details": this.fileData
      }
      this.OndutyListingService.addOndutyRequest(onduty_obj, this.editStatus, this.editId, response => {
        if (response.status == "OK") {
          this.NotificationService.alertBoxValue("success", response.message);
          this.lazyLoad=false;
          this.addForm = false;
          this.reasonField = null;
          this.fileData= null;
          this.fileName = null;
          this.employeeEmpty = false;
          this.reasonEmpty = false;
          this.toError = false;
          this.fromError = false;
          this.fromValue = [];
          this.toValue = [];
          this.sameFromdate = [];
          this.sameTodate = [];
          this.requiredFromdate = [];
          this.requiredTodate = [];

          this.dateFromValue = [];
          this.dateToValue = [];
          this.daySelected = []
          this.editStatus = false;
          this.AddForms.controls = [];
          this.ondutyDetails();
        }
        else {
          this.NotificationService.alertBoxValue("error", response.message);
          this.lazyLoad=false;
          this.addForm = true;

        }
      })
    }
  }

	/*
	*  @desc   : make date to the format 'dd-mm-yyyy'
	*  @author : nilena
	*/
  formatForApi(inputDate) {
    var date = this.timezoneDetailsService.toLocal(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
      }
      else
        return undefined;
  }
	/*
	*  @desc   : method for add form cancel
	*  @author : nilena
	*/

  cancel() {
    const arr = <FormArray>this.ondutyForm.controls.repeatForm;
    arr.controls = [];
    this.reasonField = null;
    this.employeeEmpty = false;
    this.reasonEmpty = false;
    this.empExit =false;
    this.toError = false;
    this.fromError = false;
    this.fromValue = [];
    this.toValue = [];
    this.sameFromdate = [];
    this.sameTodate = [];
    this.requiredFromdate = [];
    this.requiredTodate = [];
    this.fileData= null
    this.fileName=null
    this.dateFromValue = [];
    this.dateToValue = [];
    this.daySelected = []
    this.editStatus = false;
    this.AddForms.controls = [];
  }


  /*
  author :nilena alexander
  desc   : get emp details  from api
  */
  getEmpDetails(val) {
    this.lazyLoad = true;
    if (this.empSearch && this.empSearch.length >= 3) {
      this.OndutyListingService.getEmployeeDetails(this.empSearch, this.userData.user_id,res => {
        this.empList = [];
        if (res.message == "No data found" || (res.data && res.data.length == 0)) {
          this.empList = [];
          this.empExit = true;
          this.lazyLoad = false;
        }
        else {
          this.lazyLoad = false;
          this.empExit = false;
          this.empList = res.data;
        }
      })
    } else {
      this.lazyLoad = false;
      this.empList = [];
    }
    if(this.empSearch==null){
      this.employeeEmpty=true;
    }
    else
    this.employeeEmpty=false;

  }


  /*
   * @desc :method for calling  employee
   * @auth : nilena Alexander
   */
  getEmployee(list, index) {
    this.empDetails = list;
    this.empSearch = list.first_name + " " + list.last_name + " (" + list.code + ")";
    this.empId = this.empDetails.id;
    if (this.empId != this.userData.user_id) {
      this.userType = false;
  }
  else {
      this.userType = true;
  }
    this.holidayCheck();

    if(this.empSearch==null){
      this.employeeEmpty=true;
      this.empId = null
    }
    else
    this.employeeEmpty=false;
  }

   /*
   * @desc :method for employee field functions
   * @auth : nilena Alexander
   */
  empCheck(){
    if(this.empSearch==null){
    this.empId = null
    this.employeeEmpty =true;
    this.dateFromValue   = [];
    this.dateToValue     = [];
    this.fromValue       = [];
    this.toValue         = [];
    this.sameFromdate    = [];
    this.sameTodate      = [];
    this.requiredTodate  = [];
    this.requiredFromdate= [];
    for( let j=0;j<this.AddForms.value.length;j++){
      this.AddForms.value.pop(j);
    }
    this.AddForms.controls = [];
    this.intialForm();
    this.createform();
    }
    else
    this.employeeEmpty=false;
  }

  /*
  * @desc :method for matching index of two values
  * @auth : Nilena
  */
  matchingIndex(srcArray, compareValue, key) {
    for (var x in srcArray) {
      if (srcArray[x][key] == compareValue) {
        return x;
      }
    }
    return null;
  }


  /*
   * @desc :method for getEditDetails of particular id
   * @auth : Nilena
   */
  editDetails(id) {
    this.lazyLoad = true;
    this.intialForm();
    this.createform();

    const arr = <FormArray>this.ondutyForm.controls.repeatForm;
    arr.controls = [];
    const control = <FormArray>this.ondutyForm.get('repeatForm');
    this.editId = id;
    this.editdetailList = [];
    this.lazyLoad = true;
    this.OndutyListingService.editOndutyDetails(id, response => {
      if (response.status == "OK") {
        this.editdetailList = response.data;
        this.reasonField = this.editdetailList.reason;
        this.empSearch = this.editdetailList.name + " " + "(" + this.editdetailList.code + ")";
        this.empId = this.editdetailList.user_id;
        if (this.empId != this.userData.user_id) {
            this.userType = false;
        }
        else {
            this.userType = true;
        }

        this.holidayCheck();
        this.lazyLoad = false;
        for (let i = 0; i < this.editdetailList.date_details.length; i++) {
          this.editdetailList.date_details[i].start_range = this.timezoneDetailsService.toLocal(this.editdetailList.date_details[i].start_range);
          this.editdetailList.date_details[i].end_range = this.timezoneDetailsService.toLocal(this.editdetailList.date_details[i].end_range);

          // this.dateFromValue[]
          this.AddForms.push(this.createform(this.editdetailList.date_details[i].start_range,
            this.editdetailList.date_details[i].end_range,
            this.editdetailList.date_details[i].application_type));
        }


        for (let i = 0; i < control.length; i++) {
          this.dateFromValue[i] = this.editdetailList.date_details[i].start_range;
          this.dateToValue[i] = this.editdetailList.date_details[i].end_range;
          this.daySelected[i] = this.matchingIndex(this.dayTime, this.editdetailList.date_details[i].application_type, "id");

          control.at(i).patchValue({
            dateFromValue: (this.editdetailList.date_details[i].start_range) ? this.editdetailList.date_details[i].start_range : null,
            dateToValue: (this.editdetailList.date_details[i].end_range) ? this.editdetailList.date_details[i].end_range : null,
            daytype: this.editdetailList.date_details[i].application_type ? this.editdetailList.date_details[i].application_type : null
          });

        }
        for (let i = 0; i < this.AddForms.controls.length; i++) {
        }

        if (!this.emailData) {
          this.OndutyListingService.emailListing(response => {
            if (response.status == "OK") {
              if (response.data) {
                this.emailData = response.data;
                for (let i = 0; i < this.emailData.length; i++) {
                  if (this.emailData[i].email.trim() == "" || this.emailData[i].email == this.userData.rm_email || this.emailData[i].email == this.userData.email) {
                    this.emailData.splice(i, 1);
                  }
                }
                this.lazyLoad = false;
              }
            }
          })
        }
        if (this.editdetailList.file_details && this.editdetailList.file_details.length) {
          this.fileData = [];
          for (let i = 0; i < this.editdetailList.file_details.length; i++) {
            this.fileData.push({
              file_id: this.editdetailList.file_details[i].file_id,
              fileName: this.editdetailList.file_details[i].file_name,
              type: this.editdetailList.file_details[i].file_type,
              file_size: this.editdetailList.file_details[i].file_size,
              file_url:this.editdetailList.file_details[i].file_url,
            });
          }
        }
        if (this.editdetailList.notified_peoples)
          this.selectedEmail = this.editdetailList.notified_peoples.split(',');
        this.lazyLoad = false;
      
      } else if (response.message == "No data found") {
        this.NotificationService.alertBoxValue("error", response.message);
        this.lazyLoad = false;
      }

    })
  }
 /**
 * @ desc   : TO getDetails of onduty
 * @ author  : Nilena Alexander
 */
  ondutyDetails() {
    this.loader.display(true)
    this.queryObject.page = this.currentPage;
    this.queryObject.page_limit = this.recordsPerPage;
    this.OndutyListingService.ondutyDetailsList(this.listId,this.queryObject, response => {
      if (response.status == "OK") {
        this.loader.display(false);
        for(let i =0;i<response.data.length;i++){
          let name =response.data[i].name;
           name =name.split(" ");
           response.data[i].first_name=name[0];
           response.data[i].last_name=name[name.length-1];
        }

        this.ondutyData = response.data;
        this.dateConversion();
        this.currentPage = this.queryObject.page;
        this.totalRecords = Number(response.count);
        for (let i = 0; i < this.ondutyData.length; i++) {

          let secondHand = [];
          for (var j = 0; j < this.ondutyData[i].details.length; j++) {
            secondHand.push({ date: this.ondutyData[i].details[j].applied_date, status: this.ondutyData[i].details[j].status });
          }
          this.loader.display(false);
        }
      } else {
        this.ondutyData = [];
        this.loader.display(false)

      }
    })
  }
/**
 * @ desc   : For date Conversion
 * @ author  : Nilena Alexander
 */
  dateConversion(){
    for (let i =0;i<this.ondutyData.length;i++){
      let temp = this.ondutyData[i].requested_on.split(" ");

      let tempFirst = this.timezoneDetailsService.getLocalDate(temp[0] + " " +  temp[1]);
      this.ondutyData[i].requested_on = new Date(tempFirst).getFullYear() + "-" + (Number(new Date(tempFirst).getMonth()) + 1) + "-" + new Date(tempFirst).getDate();
    }


  }
  /**
  * @ desc   : TO implement pagination
  * @ author  : Nilena Alexander
  */
  pageChangeEvent(page) {
    this.queryObject.page = page;
    this.currentPage = page;
    this.ondutyDetails();
  }
  /*
   * @ desc   : TO implement pagination
   * @ author  : Nilena Alexander
   */
  getpage(eve) {
    if (eve > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = eve;
      this.queryObject['page_limit'] = eve;
      this.queryObject['page'] = 1;
      this.currentPage = 1;
      this.ondutyDetails();
    }
  }

  /*
    *  @desc   :select employee name from dropdown listed only for admin
    *  @author :nilena
    */
  userSelected(event) {
        if (event.selected)
          if (event.selected[0]) {
            this.loader.display(true);
            this.currentPage = 1;
            this.listId = event.selected[0].id;
            if (this.listId != "All")
              this.OndutyListingService.getLeaveTypes(event.selected[0].id, res => {
                if (res.message == "No data found") {
                  this.loader.display(false);
                  this.dispListList = [];
                  this.ondutyData = [];
                }
                else {
                  this.dispListList = res.data;
                   this.ondutyDetails();
                  // this.financialYearMin( this.listId);

                }
              })
            else {
              this.ondutyDetails();
              this.dispListList = [];
            }
          }
          else {
            this.listId = this.userData.user_id;
            this.dispListList = [];
          }

  }
   /*
    *  @desc   :select employee name from dropdown listed only for admin
    *  @author :nilena
    */

  peopleList() {
    if(this.adminRole||this.managerRole){
    this.OndutyListingService.getPeople(this.userData.user_id,response => {
      if (response.status == "OK") {
        if (response.data) {
          this.userList = response.data;
          for (var i = 0; i < this.userList.length; i++) {
            this.userList[i].name = this.userList[i].first_name + " " + this.userList[i].last_name + " (" + this.userList[i].code + ")";
          }
          if (this.adminRole || this.managerRole) {
            this.userList.splice(0, 0, {
              name: "All",
              id: 'All',
              role: "Administrator",
              role_id: "2",
              status: "1"
            });
          }

          for (var i = 0; i < this.userList.length; i++) {
            if (this.userData.user_id == this.userList[i].id) {
              this.selectedItems = [i];
              break;
            }
          }
        }
         this.loader.display(false);
      }
    })
  }
  else {
    this.listId=this.userData.user_id;
    this.queryObject.page = 1;
    this.ondutyDetails();
  }
}
  dateRangeChange(event) {
		this.dateRangeValue = event;
  }
    /*
    author : Nilena Alexander
    desc   : to get status in filter
    */
   filterStatusEvent(event) {
    if (event.selectedIndex.length != 0) {
      this.statusChecked = event.selectedIndex;
    }
    else {
      this.statusChecked = [];
    }
    this.statusSelected = event;
  }
  /*
  author : Nilena Alexander
  desc   : filter apply function

  */
 filterApply() { //this.filterSelect is a copy of selected value
  let range = this.dateRangeValue == undefined ? null : this.dateRangeValue ;
  let status = this.statusSelected && this.statusSelected.selected && this.statusSelected.selected[0] && this.statusSelected.selected[0].value ? this.statusSelected.selected[0].value : 0;
  let loader = this.OndutyListingService.checkFilterStatus(range, status);
  if (loader) {
    this.filterActive = true;
    if (this.statusSelected.selected.length) {
      if (this.statusSelected.selected[0].value == "Pending") {
        // if(!this.adminRole && this.managerRole){
        //   this.filterStatVal=1;
        //   // this.queryObject.mngstat  = "1";
        // }
        // else
        this.queryObject.stat = "1";
      } else if (this.statusSelected.selected[0].value == "Approved") {

        // if(!this.adminRole && this.managerRole)
        // {
        //   // this.queryObject.mngstat  = "2";
        //   this.filterStatVal= 2;
        // }
        // else
        this.queryObject.stat = "2";
       }
      else if (this.statusSelected.selected[0].value == "Rejected") {
        // if(!this.adminRole && this.managerRole)
        // {
        //   // this.queryObject.mngstat  = "3";
        //   this.filterStatVal= 3;
        // }
        // else
        this.queryObject.stat = "3";
      }
      else if (this.statusSelected.selected[0].value == "Cancelled") {
        // if(!this.adminRole && this.managerRole)
        // {
        //   // this.queryObject.mngstat  = "4";
        //   this.filterStatVal= 4;
        // }
        // else
        this.queryObject.stat = "4";
      }
    }
    else {
      this.queryObject.stat = null;
      // this.queryObject.mngstat  = null;
      // this.filterStatVal= 0;

    }
    if (this.dateRangeValue) {
       this.queryObject.reqstart = this.formatForApi(this.dateRangeValue[0]);
       this.queryObject.reqend = this.formatForApi(this.dateRangeValue[1]);
    } else {
      this.queryObject.reqstart = null;
      this.queryObject.reqend =null;
    }
    if (this.statusSelected.selected.length == 0 &&this.dateRangeValue ==null) {
      this.filterActive = false;
      this.queryObject.stat = null;
      this.queryObject.reqend=null;
      this.queryObject.reqstart=null;
      this.queryObject.mngstat  = null;
      this.currentPage = 1;
      this.queryObject.page =   this.currentPage ;

    }
    this.currentPage = 1;
    this.queryObject.page =   this.currentPage ;
    this.ondutyDetails();

  }
  else {
    this.filterActive = true;
    this.queryObject.stat = null;
    this.queryObject.mngstat  = null;
    this.queryObject.reqend=null;
    this.queryObject.reqstart=null
    this.currentPage = 1;
    this.queryObject.page =   this.currentPage ;
    this.filterStatVal= 0;


  }
}
/*
author : Nilena Alexander
desc   : filter cancel function

*/

filterCancel() {
  if (this.OndutyListingService.checkFilterCanCancel()) {
    this.queryObject.stat = null
    // this.queryObject.reqend=null;
    // this.queryObject.reqstart=null;
    this.start= this.timezoneDetailsService.toLocal(this.userData.start_date);
    this.maxdate= this.timezoneDetailsService.toLocal(this.userData.end_date);
    this.dateRangeValue=[this.start,this.maxdate];
    this.queryObject.reqstart = this.formatForApi(this.dateRangeValue[0]);
    this.queryObject.reqend = this.formatForApi(this.dateRangeValue[1]);

    this.queryObject.mngstat  = null;
    this.queryObject.page = 1;
    this.filterStatVal= 0;
    this.ondutyDetails();
  }
  // this.filterActive = false;
  this.OndutyListingService.clearFilterStatus();
    
      this.start= this.timezoneDetailsService.toLocal(this.userData.start_date);
      this.maxdate= this.timezoneDetailsService.toLocal(this.userData.end_date);
      this.dateRangeValue=[this.start,this.maxdate];
      if (this.dateRangeValue) {
        setTimeout(() => {
          this.dateRangeValue = [this.start,this.maxdate];
          this.dateRangeChange(this.dateRangeValue);
        }, 500);
      }
      if (this.dateRangeValue) {
        this.queryObject.reqstart = this.formatForApi(this.dateRangeValue[0]);
        this.queryObject.reqend = this.formatForApi(this.dateRangeValue[1]);
      }
      this.filterActive = true;
  // this.dateRangeValue = null;
  this.statusChecked = null;


}
 /*
  author : Nilena Alexander
  desc   : add class based on index
 */
getClassByValue(index) {
  return this.OndutyListingService.getClassByValue(index);

}
/*
author : Nilena Alexander
desc   :  cancel request

*/
deleteRequest(id){

  this.deleteId=id;
  this.confirmBox = true;
}

/**method for confirmation popup
     * @ author  : Nilena Alexander
     */
    getPopupConfirm(event) {

      this.loader.display(true);
      this.confirmBox = false;
      if (event == true) {
        this.OndutyListingService.delete(this.deleteId,response=>{
          if (response.status == "OK") {
            this.NotificationService.alertBoxValue("success", response.message);
            this.ondutyDetails();
            this.queryObject.page=1;
            this.loader.display(false);
          }
          else {
            this.NotificationService.alertBoxValue("error", response.message);
            this.loader.display(false);
          }
         })
      }
    }
    // To check a date is included in a date range
    dateRangeChecking(i){

      for (let j = 0; j < this.dayRestricted.leaveDates.holiday.length; j++) {

        if(i!=j){
          let test1=    this.timezoneDetailsService.toLocal(this.dateFromValue[i])
          let test2 = this.timezoneDetailsService.toLocal(this.dateToValue[i])
          let test3 = this.timezoneDetailsService.toLocal(this.dayRestricted.leaveDates.holiday[j])

          if ( test3> test1 &&  test3< test2 ){
            alert('Correct Date')
          }
          else{
           alert('Out Side range !!')
         }
       }
     }
    }
    open(url){
      window.open(url)
    }

    getlastday(y,m){
      return  new Date(y, m, 0).getDate();
    }
     /*
    author : vinod
    desc   : get emp details  from api
   */
  checkWithPayperiod(){
    let val = false;
    let last = false
           let date = this.timezoneDetailsService.getCurrentDate();
           let tempDate = moment(this.timezoneDetailsService.toLocal(date.getFullYear() + "-"+ Number(date.getMonth() + 1) + "-" + Number(this.payPeriod)), 'MM-DD-YYYY HH:mm').add(this.payExtraPeriod + 1, 'days');
           let nextCycleStart = tempDate.toDate()
           let nextMonthStart = this.timezoneDetailsService.toLocal(date.getFullYear() + "-" +Number(date.getMonth() + 1) + "-" + (Number(this.payPeriod)+1))
           let tempPay = this.timezoneDetailsService.toLocal(date.getFullYear() + "-" +Number(date.getMonth()) + "-" + (Number(this.payPeriod)+1))

           if(this.payPeriod == "29"){
            last = true;
            this.payPeriod = this.getlastday(date.getFullYear(),(date.getMonth()))
           }
           let tempDate2 = moment(this.timezoneDetailsService.toLocal(date.getFullYear() + "-"+ Number(date.getMonth()) + "-" + Number(this.payPeriod)), 'MM-DD-YYYY HH:mm').add(this.payExtraPeriod, 'days');     
          	if (!this.userType) {
							if (this.adminRole || this.managerRole) {
								if (date.getDate() >= Number(this.payPeriod)) {
									if (Date.parse(tempDate.toDate()) >= Date.parse(moment(this.timezoneDetailsService.getCurrentDate(), 'MM-DD-YYYY HH:mm').toDate())) {
										this.minDate = this.timezoneDetailsService.toLocal(date.getFullYear() + "-" + Number(date.getMonth()) + "-" + (Number(this.payPeriod)+1));
									}
									else {
                    if(last ){
											this.minDate = this.timezoneDetailsService.toLocal(date.getFullYear() + "-" +Number(date.getMonth() ) + "-" +(Number(this.payPeriod)+1));
										}
									
										else{
											this.minDate = this.timezoneDetailsService.toLocal(date.getFullYear() + "-" +Number(date.getMonth()+1 ) + "-" +(Number(this.payPeriod)+1));
                    }	
              		}
								}
								else {
									if((nextCycleStart != undefined) || (nextCycleStart! = null) || (nextCycleStart != "Invalid Date")){
										let currentDay = new Date(date.getFullYear(),date.getMonth(),date.getDate())
										let lastdaywithExtapayprd = new Date(tempDate2.toDate().getFullYear(),tempDate2.toDate().getMonth(),tempDate2.toDate().getDate())
										if(Number(nextCycleStart.getMonth()) > Number(nextMonthStart.getMonth()) && (currentDay<=lastdaywithExtapayprd)){
											val = true;
										}
										else if(Number(nextCycleStart.getMonth())==0 && Number(nextMonthStart.getMonth())==11 && (currentDay<=lastdaywithExtapayprd)){
											val = true;
										}
									}
									if(val){
										if(last){
											this.minDate = this.timezoneDetailsService.toLocal(date.getFullYear()+"-"+ Number(date.getMonth()) + "-" + 1);
										}
										else{
											this.minDate = this.timezoneDetailsService.toLocal(date.getFullYear()+"-"+ Number(date.getMonth()-1) + "-" + (Number(this.payPeriod)+1));
										}
									}else{
                    let currentDay = new Date(date.getFullYear(),date.getMonth(),date.getDate())
										let lastdaywithExtapayprd = new Date(tempDate2.toDate().getFullYear(),tempDate2.toDate().getMonth(),tempDate2.toDate().getDate())
										if(currentDay<=lastdaywithExtapayprd){
											this.minDate = this.timezoneDetailsService.toLocal(date.getFullYear()+"-"+ Number(date.getMonth()-1) + "-" + (Number(this.payPeriod)+1));

											// this.startDate = this.timeZone.toLocal(date.getFullYear()+"-"+ Number(date.getMonth()) + "-" + (Number(this.payPeriod)+1));
											// this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
										}else
										{
											 this.minDate = this.timezoneDetailsService.toLocal(date.getFullYear()+"-"+ Number(date.getMonth()) + "-" + (Number(this.payPeriod)+1));
											// this.endDate = this.timeZone.toLocal(this.restrictData.financialYear.end_date);
                    }			
          					}
								}
							}
							else {
								if (date.getDate() > Number(this.payPeriod)) {
									this.minDate = this.timezoneDetailsService.toLocal(date.getFullYear() + "-" + Number(date.getMonth() + 1) + "-" + (Number(this.payPeriod)+1));
								}
								else {
									this.minDate = this.timezoneDetailsService.toLocal(date.getFullYear() +"-"+Number(date.getMonth()) + "-" + (Number(this.payPeriod)+1));
								}
							}
						}
           else {

              if(!last) {

                if(date.getDate()>=tempPay.getDate()){
                  this.minDate  = this.timezoneDetailsService.toLocal(date.getFullYear() + "-" +Number(date.getMonth()+1 ) + "-" + (Number(this.payPeriod)+1));
                }
                else{
                  this.minDate  = this.timezoneDetailsService.toLocal(date.getFullYear() + "-" +Number(date.getMonth() ) + "-" + (Number(this.payPeriod)+1));
                 }
              }
              else{
                this.minDate = this.timezoneDetailsService.toLocal(date.getFullYear() + "-" +Number(date.getMonth() ) + "-" + (Number(this.payPeriod)+1))
            }
          }
         this.lazyLoad = false;
       }

    commentCheck(d){
      if(d.comments==null || d.comments=="" || d.comments=='' || d.comments==undefined || !d.comments){
        return false;
      }else{
        return true;
      }
    }

/*
	 *  @desc   :method to update list by api call
		 *  @author :dipin
	*/
	changeListener($event): void {
		this.readThis($event.target);
	}

	/*
	*  @desc   :method to check file input
	*  @author :dipin
	*/
	readThis(inputValue: any): void {
		let self = this;
		let fileSize: number = 0;
		let prevFileData;
		if (inputValue) {
			if (this.fileData)
				for (let i = 0; i < this.fileData.length; i++) {
					fileSize = fileSize + Number(this.fileData[i].file_size);
				}

			for (let i = 0; i < inputValue.files.length; i++) {
				fileSize = fileSize + Number(inputValue.files[i].size);
      }
      if ((inputValue.files.length <= 5) &&
       (!this.fileData || (this.fileData && (this.fileData.length + inputValue.files.length) <= 5))
        && (Number(fileSize) <= 4194304)) {
				if (!this.fileData) {
					this.fileData = [];
					prevFileData = 0;
				}
				else {
					prevFileData = this.fileData.length;
				}
				let maxCount = Number(inputValue.files.length + this.fileData.length);
				let startCount = Number(this.fileData.length);

				for (let i = startCount; i < maxCount; i++) {
					var file: File;
					file = inputValue.files[i - prevFileData];
					if (file != undefined) {
						self.fileData.push({});
						self.fileData[i] = { fileName: "", type: "", file_data: "", file_size: "" };
						self.fileData[i].type = inputValue.files[i - prevFileData].name.split('.').pop();
						self.fileData[i].fileName = file.name;
						self.fileData[i].file_size = file.size;
						self.uploadProcess(file, i);
					}
					else {
						self.fileData[i] = undefined;
						self.fileName[i] = "";
					}
				}
			}
			else {
				if (Number(fileSize) > 4194304) {
					this.NotificationService.alertBoxValue("error", "You Can Only Upload A Maximum Of Size 4 MB");
				}
				else
					this.NotificationService.alertBoxValue("error", "You Can Only Upload A Maximum Of 5 Files");
			}
		}
		else {
			self.fileData = undefined;
			self.fileName = undefined;
		}
	}


    /*
	*  @desc   :method to initiate upload process
	*  @author :dipin
	*/
	uploadProcess(file, i) {
		let self = this;
		let reader = new FileReader();
		reader.readAsDataURL(file);
		reader.onload = () => {
			self.fileData[i].file_data = reader.result;
		};
	}

    /*
	*  @desc   :delete files from the upload list
	*  @author :dipin
	*/
	deleteFile(value) {
		this.fileData.splice(value, 1);
		if (this.fileData.length == 0) {
			this.fileData = undefined;
		}
  }
  
  	/*
	*  @desc   :method to update list by api call
	*  @author :dipin
   */
	downloadFile(selected) {
    if(selected != undefined && selected !=null && selected!='' ){
      window.open(selected);
    }else{
      return false;
    }
  }
	// 	if (this.editStatus) {
	// 		this.loader.display(true);
	// 		this.OndutyListingService.attachemntDownload(this.fileData[selected].file_id, this.editId, res => {
	// 			if (res.status != "success") {
	// 				this.loader.display(false);
	// 			}
	// 			else {
	// 				let binary_string: any = window.atob(res.data);
	// 				let types;
	// 				if (this.fileData[selected].type == "png" || this.fileData[selected].type == "jpg" || this.fileData[selected].type == "jpeg") {
	// 					types = 'image/png';
	// 				}
	// 				else if (this.fileData[selected].type == "pdf") {
	// 					types = 'application/pdf';
	// 				}
	// 				else {
	// 					types = "application/octet-stream";
	// 				}
	// 				let len: any = binary_string.length;
	// 				let bytes: any = new Uint8Array(len);
	// 				for (var i = 0; i < len; i++) {
	// 					bytes[i] = binary_string.charCodeAt(i);
	// 				}
	// 				let file: any = new Blob([bytes.buffer], { type: types });
	// 				FileSaver.saveAs(file, this.fileData[selected].fileName);
	// 				this.loader.display(false);
	// 			}
	// 		})
	// 	}
  // }
  
  topPositionData(event,z){
   let yPosition = event.clientY;
   let innerheight  = window.innerHeight;
   if(((innerheight)/2) < yPosition && (z>3)){
     this.moveToTop = true;
   }
   else{
    this.moveToTop = false;
   }
  }
}
