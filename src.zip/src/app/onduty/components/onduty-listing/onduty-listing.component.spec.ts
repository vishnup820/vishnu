import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OndutyListingComponent } from './onduty-listing.component';

describe('OndutyListingComponent', () => {
  let component: OndutyListingComponent;
  let fixture: ComponentFixture<OndutyListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OndutyListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OndutyListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
