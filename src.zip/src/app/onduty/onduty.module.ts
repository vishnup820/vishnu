import { NgModule,ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { ClickOutsideModule } from 'ng4-click-outside';
import { BsDatepickerModule,BsDatepickerConfig} from 'ngx-bootstrap/datepicker';
import { GlobalErrorHandlerService } from '../global-error-handler.service';

import { AuthGuardService } from '../shared/services/auth-guard/auth-guard.service';
import { RoleGuardService } from '../shared/services/role-guard/role-guard.service';

import { OndutyListingComponent } from './components/onduty-listing/onduty-listing.component';
import { ApprovalComponent } from './components/approval/approval.component';

@NgModule({
  declarations: [OndutyListingComponent, ApprovalComponent],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    ClickOutsideModule,
    BsDatepickerModule.forRoot(),
    RouterModule.forChild([
    {
      path        : 'onduty-listing',
      canActivate : [RoleGuardService],
      component   :  OndutyListingComponent,
    },{
      path        :'onduty-approval',
      component   :  ApprovalComponent,
      canActivate : [RoleGuardService],
    }
  ])
  ],
  providers:[
    AuthGuardService,
    RoleGuardService,
    {
      provide  : ErrorHandler,
      useClass : GlobalErrorHandlerService,
     }
  ]
})
export class OndutyModule { }
