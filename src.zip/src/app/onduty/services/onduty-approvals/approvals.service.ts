import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class ApprovalsService {

  apiBaseUrl: string;

  constructor(private http: HttpClient) {

    this.apiBaseUrl = globalVariables.apiBaseUrl;

  }
/*
  *  @desc   :method export file data downloading
  *  @author :dipin
  */
 attachemntDownload(id,cb){
  let url : string;
    url = this.apiBaseUrl +"/api/v1/onDuty/downloadDutyDocs?dutyId="+id
    // http://services.local/api/v1/onDuty/downloadDutyDocs/47?dutyId=48  
    let promise: any = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
}
  /*
    author : Nilena
    desc   : get employee details based on empid
  */
  getApprovalList(qobj,cb) {
    let url: string = this.apiBaseUrl + apiList.onduty.approvals ;
    url=url+this.generateQuery(qobj) ;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  /*
  *  @desc   :to gengerate query
  *  @author :Nilena Alexander
  */

 generateQuery(qobj) {
  let query = `?page=${qobj.page ? qobj.page : ''}&page_limit=${qobj['page_limit'] ? qobj['page_limit'] : ''}${qobj.sort ? '&sort=' + qobj.sort : ''}${qobj.reqend ? '&reqend=' + qobj.reqend : ''}${qobj.reqstart ? '&reqstart=' + qobj.reqstart : ''}${qobj.stat ? '&stat=' + qobj.stat : ''}${qobj.keyword ? '&keyword=' + qobj.keyword : ''}${qobj.desig ? '&desig=' + qobj.desig : ''}${qobj.dept ? '&dept=' + qobj.dept : ''}${qobj.loc ? '&loc=' + qobj.loc : ''}${qobj.mngstat ? '&mngstat=' + qobj.mngstat : ''}${qobj.adminFilter ? '&fetchType=' + qobj.adminFilter : ''}`
  return query;
 }

 ChangeSatus(id,obj,cb){
   let url :string =this.apiBaseUrl + apiList.onduty.ChangeSatus + id ;

  let promise = new Promise((resolve, reject) => {
    this.http.put(url, obj)
      .toPromise()
      .then(res => {
        if (res) cb(res)
      })
  })
  return promise;

 }


  singleReject(id,obj,detailId,callBack) {
  let url: string = this.apiBaseUrl + apiList.onduty.singleReject + id+"/"+detailId;
  let promise = new Promise((resolve, reject) => {
    this.http.put(url,obj)
      .toPromise()
      .then(res => {
        if (res) callBack(res)
      })
  })
  return promise;

}
   /*
       author : Nilena Alexander
       desc   : add class based on index
    */
   getClassByValue(index) {
    switch (index % 10) {
        case 0: return "default-avatar islamic-green";
        case 1: return "default-avatar limerick";
        case 2: return "default-avatar chilean-fire";
        case 3: return "default-avatar persian-pink";
        case 4: return "default-avatar deep-magenta";
        case 5: return "default-avatar gigas";
        case 6: return "default-avatar endeavour";
        case 7: return "default-avatar dodger-blue";
        case 8: return "default-avatar jordy-blue";
        case 9: return "default-avatar Light-sea-green";
        case 10: return "emp-profileimage";
    }
}
}
