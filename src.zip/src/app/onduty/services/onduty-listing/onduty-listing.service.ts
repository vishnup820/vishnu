import { Injectable,OnInit } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
import { AclVerificationService } from '../../../shared/services/acl-verification/acl-verification.service';


@Injectable({
  providedIn: 'root'
})
export class OndutyListingService implements OnInit{

  apiBaseUrl: string;

	status   : any = 0;
  range    : any = null ;
  adminRole: boolean = false;

  constructor(private http: HttpClient,
    private AclVerificationService:AclVerificationService) {
    this.apiBaseUrl = globalVariables.apiBaseUrl;
    this.adminRole   = this.AclVerificationService.checkAclDummy('onduty-all-employees');


  }
  ngOnInit(){
    this.adminRole   = this.AclVerificationService.checkAclDummy('onduty-all-employees');
  }

   /*
      author : dipin
      desc   : get employee details based on empid
    */
   getEmployeeDetails(search,id,cb) {
    let empId=id;
    let url: string;
    this.adminRole   = this.AclVerificationService.checkAclDummy('onduty-all-employees');
    if(this.adminRole)
    url = this.apiBaseUrl+apiList.onduty.getAdminData+"&keyword="+search;
    else
    url = this.apiBaseUrl + "/api/v1/people/"+empId+"/myteam?stat=1&sort=f_name&keyword="+search;
    let promise: any = new Promise((resolve, reject) => {
        this.http.get(url)
            .toPromise()
            .then(res => {
                cb(res);
            })
    })
}

 /*
  *  @desc   :method put api call for add onduty
  *  @author :nilena
  */
 addOndutyRequest(obj, type,editId,cb) {

  if (type == true) {
    let url: string = this.apiBaseUrl+ apiList.onduty.ondutyAdd+"/"+editId;
    let promise = new Promise((resolve, reject) => {
      this.http.put(url, obj)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }
  else {
    let url: string = this.apiBaseUrl + apiList.onduty.ondutyAdd;
    let promise = new Promise((resolve, reject) => {
      this.http.post(url, obj)
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
  }
}

/*
  *  @desc   : get all users email id
  *  @author : nilena
  */
 emailListing(cb) {
  let url: string;
  url = this.apiBaseUrl +"/api/v1/people?fields=email&sort=email";
  let promise: any = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
}
/*
  *  @desc   :get validations for dateSelection
  *  @author :nilena
  */
 validationsForDate(uId,cb){
  let url: string = this.apiBaseUrl +apiList.onduty.daytypes+"/"+0+"/restrictions/"+uId;
  let promise = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        if (res) cb(res)
      })
  })
  return promise;
}
/*
  *  @desc   :method export file data downloading
  *  @author :dipin
  */
 attachemntDownload(id,cb){
  let url : string;
    url = this.apiBaseUrl +"/api/v1/onDuty/downloadDutyDocs?dutyId="+id
    // http://services.local/api/v1/onDuty/downloadDutyDocs/47?dutyId=48  
    let promise: any = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
}
    /*
  *  @desc   :method edit onduty
  *  @author :nilena
  */
 editOndutyDetails(id,callBack) {
  let url: string = this.apiBaseUrl + apiList.onduty.ondutyAdd +"/"+id;
  let promise = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        if (res) callBack(res)
      })
  })
  return promise;
}
 /*
      author : nilena
      desc   : get onduty details
    */
   ondutyDetailsList(id,qobj,cb) {
    let url: string
   if(id != "All")
    url= this.apiBaseUrl + apiList.onduty.getDetails +"?userId="+id+"&";
   else
    url  = this.apiBaseUrl + apiList.onduty.getDetails+"?";
    url = url + this.generateQuery(qobj);
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  /*
  *  @desc   :method deleting get api call for delete one item
  *  @author :nilena
  */
 getLeaveTypes(id,callBack) {
  let url: string = this.apiBaseUrl +"/api/v1/people/"+id+"/leavetypes";
  let promise = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        if (res) callBack(res)
      })
  })
  return promise;
}
/*
  *  @desc   :method get people list for admin drop down
  *  @author :nilena
  */
 getPeople(user_id,callBack){
 let url: string;
  if(this.AclVerificationService.checkAclDummy('onduty-all-employees'))
   url = this.apiBaseUrl+apiList.onduty.getAdminData;
  else
   url= `${this.apiBaseUrl}${apiList.people.details}/${user_id}/myteam`;

 let promise: any = new Promise((resolve, reject) => {
  this.http.get(url + "?stat=1")
    .toPromise()
    .then(res => {
      callBack(res);
    })
  })
}
/*
  *  @desc   :to gengerate query
  *  @author :Nilena Alexander
  */

 generateQuery(qobj) {
  let query = `page=${qobj.page ? qobj.page : ''}&page_limit=${qobj['page_limit'] ? qobj['page_limit'] : ''}${qobj.sort ? '&sort=' + qobj.sort : ''}${qobj.reqend ? '&reqend=' + qobj.reqend : ''}${qobj.reqstart ? '&reqstart=' + qobj.reqstart : ''}${qobj.stat ? '&stat=' + qobj.stat : ''}${qobj.mngstat ? '&mngstat=' + qobj.mngstat : ''}`
  return query;
 }

 /*
    *  @desc   :to cancel registration
    *  @author :Nilena Alexander
    */
   delete(id, cb) {
    let url: string = `${this.apiBaseUrl + apiList.onduty.deleteOnduty}${id}`;
    let promise: any = new Promise((resolve, reject) => {
      this.http.request("delete", url)
        .toPromise()
        .then(res => {
          res["status"] ? cb(res) : '';
        })
    })
  }

 	/*
  * @ desc   :  method to check value receving from filter is same or not
  * @ author  : nilena alexander
  */

 checkFilterStatus( stat, date ) {

  let ret = true ;
  // if( this.status == stat && this.owner == own && this.range == date ) {
  // 	ret = false;
  // }
  if( stat == 0  && date == null &&
    (this.status == stat && this.range == date)
    ) {
    ret = false;
  }
  this.status = stat ;
  this.range = date ;
  return ret ;
}

/*
* @ desc   :  method to check value receving from filter is same or not with previous val
* @ author  : nilena alexander
*/
checkFilterCanCancel() {

  let ret = true ;
  if( this.status == 0  && this.range == null ) {
    return false ;
  }
  return true ;
}
/*
* @ desc   :  method to clear filter
* @ author  : nilena alexander
*/

clearFilterStatus() {
  this.status = 0;
  this.range = null ;
}

   /*
       author : Nilena Alexander
       desc   : add class based on index
    */
   getClassByValue(index) {
    switch (index % 10) {
        case 0: return "default-avatar islamic-green";
        case 1: return "default-avatar limerick";
        case 2: return "default-avatar chilean-fire";
        case 3: return "default-avatar persian-pink";
        case 4: return "default-avatar deep-magenta";
        case 5: return "default-avatar gigas";
        case 6: return "default-avatar endeavour";
        case 7: return "default-avatar dodger-blue";
        case 8: return "default-avatar jordy-blue";
        case 9: return "default-avatar Light-sea-green";
        case 10: return "emp-profileimage";
    }
}

}
