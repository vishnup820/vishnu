import { TestBed } from '@angular/core/testing';

import { OndutyListingService } from './onduty-listing.service';

describe('OndutyListingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OndutyListingService = TestBed.get(OndutyListingService);
    expect(service).toBeTruthy();
  });
});
