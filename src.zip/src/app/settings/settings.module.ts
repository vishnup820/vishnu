import { NgModule,ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
// import { HttpClientModule} from '@angular/common/http';

import { SharedModule } from '../shared/shared.module';
import { ClickOutsideModule } from 'ng4-click-outside';
import { GlobalErrorHandlerService } from '../global-error-handler.service';
import { HrisDepartmentComponent } from '../organization/component/hris-department/hris-department.component';
import { HrisGroupComponent } from '../organization/component/hris-group/hris-group.component';
import { HrisLocationComponent } from '../organization/component/hris-location/hris-location.component';
import { HrisDesignationComponent } from '../organization/component/hris-designation/hris-designation.component';
import { HrisCompanyComponent } from '../organization/component/hris-company/hris-company.component';
import { AclComponent } from '../organization/component/acl/acl.component';
import{ HrisRoleComponent }from '../organization/component/hris-role/hris-role.component';
import { RoleGuardService } from '../shared/services/role-guard/role-guard.service';
const organizationRoutes: Routes = [
  {
    path : 'department', component: HrisDepartmentComponent , canActivate : [RoleGuardService]
  },
  {
    path : 'designation', component: HrisDesignationComponent , canActivate : [RoleGuardService]
  },
  {
     path : 'group', component: HrisGroupComponent, pathMatch: 'full' , canActivate : [RoleGuardService]
  },
  {
    path : 'location', component: HrisLocationComponent , canActivate : [RoleGuardService]
  },
  {
    path : 'company', component: HrisCompanyComponent , canActivate : [RoleGuardService]
  },
   {
    path : 'role', component: HrisRoleComponent 
  },
  {
    path : 'acl',component :AclComponent , canActivate : [RoleGuardService]
  },
  {
    path : '', redirectTo : 'department', pathMatch: 'full' , canActivate : [RoleGuardService]
  }

  
];


@NgModule({
  declarations: [
  	HrisDepartmentComponent,
    HrisGroupComponent,
    HrisLocationComponent,
    HrisDesignationComponent,
    HrisCompanyComponent,
    HrisRoleComponent,
    AclComponent
  ],
  imports: [
  	CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ClickOutsideModule,
    RouterModule.forChild(organizationRoutes),
  ],
  providers: [
    {
      provide  : ErrorHandler,
      useClass : GlobalErrorHandlerService,
    }
  ],
})
export class SettingsModule { }
