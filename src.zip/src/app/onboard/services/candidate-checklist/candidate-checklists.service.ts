import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
@Injectable({
  providedIn: 'root'
})
export class CandidateChecklistsService {

 apiBaseUrl: string;
  constructor(private http: HttpClient) {

    this.apiBaseUrl = globalVariables.apiBaseUrl;

  }
  getcandidateCheckList(cand_id,qobj,cb) {
  let url: string = this.apiBaseUrl+apiList.onboard.checklistLists+"/"+cand_id;
  url = url + this.generateQuery(qobj)
  // url = url+this.generateQuery(obj)
  // let url = 'http://onboard-services.local/api/v1/onboardChecklist?page=1&page_limit=10'
  let promise: any = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
}
generateQuery(queryObject) {
    let query=`${queryObject.sort?'?sort='+ queryObject.sort:''}`;
    return query;
  }
  getPeople(cb){
    let url: string = this.apiBaseUrl+apiList.people.details;
  // /let url: string = this.apiBaseUrl+apiList.people.details+'?fields=f_name,l_name,id,name,dp,code';
  // let url = 'http://onboard-services.local/api/v1/onboardChecklist?page=1&page_limit=10'
  let promise: any = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
  }
  closeAllcheckliststatus(id,cb){
    let url: string = this.apiBaseUrl+apiList.onboard.onboardCandidate+"/"+id;
  // url = url+this.generateQuery(obj)
  // let url = 'http://onboard-services.local/api/v1/onboardChecklist?page=1&page_limit=10'
  let promise: any = new Promise((resolve, reject) => {
    this.http.patch(url,{"stat": 2})
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
  }
}
