import { TestBed } from '@angular/core/testing';

import { CandidateChecklistsService } from './candidate-checklists.service';

describe('CandidateChecklistsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CandidateChecklistsService = TestBed.get(CandidateChecklistsService);
    expect(service).toBeTruthy();
  });
});
