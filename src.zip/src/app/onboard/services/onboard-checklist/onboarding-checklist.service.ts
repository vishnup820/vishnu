import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';

@Injectable({
  providedIn: 'root'
})
export class OnboardingChecklistService {
apiBaseUrl: string;
  constructor(private http: HttpClient) {

    this.apiBaseUrl = globalVariables.apiBaseUrl;

  }
   /*
    author : vinod
    desc   : 
  */
 getChecklist(obj,cb) {
  let url: string = this.apiBaseUrl+apiList.onboard.checklistList;
  url = url+this.generateQuery(obj)
  // let url = 'http://onboard-services.local/api/v1/onboardChecklist?page=1&page_limit=10'
  let promise: any = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
}
generateQuery(queryObject) {
    let query=`?page=${queryObject.page?queryObject.page:''}&page_limit=${queryObject['page_limit']?queryObject['page_limit']:''}${queryObject.sort?'&sort='+ queryObject.sort:''}${queryObject.keyword?'&keyword=' + queryObject.keyword: ''}`;
    return query;
  }

  getPeople(cb){
  // let url: string = this.apiBaseUrl+apiList.people.details+'?fields=f_name,l_name,id,name,dp,code';
  let url =  this.apiBaseUrl+apiList.people.details;
  let promise: any = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
  }
deleteCgecklist(id,cb){
  let url: string = this.apiBaseUrl + apiList.onboard.checklistList +"/"+ id;
  let promise: any = new Promise((resolve, reject) => {
    this.http.delete(url)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
}

geteditData(id,cb) {
  let url: string = this.apiBaseUrl+apiList.onboard.checklistList+"/"+id;
  // let url = 'http://onboard-services.local/api/v1/onboardChecklist?page=1&page_limit=10'
  let promise: any = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
}

submitDetails(btn,id,data,cb){
		let method
	if(btn == 'edit'){
		method = "put"
  		let url: string = this.apiBaseUrl + apiList.onboard.checklistList+"/"+id;
  		let promise: any = new Promise((resolve, reject) => {
    this.http.put(url,data)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
	}else{
		method = "post"
		let url: string = this.apiBaseUrl + apiList.onboard.checklistList;
		let promise: any = new Promise((resolve, reject) => {
    this.http.post(url,data)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
	}
  
}
}
