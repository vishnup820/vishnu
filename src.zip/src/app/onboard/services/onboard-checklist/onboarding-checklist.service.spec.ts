import { TestBed } from '@angular/core/testing';

import { OnboardingChecklistService } from './onboarding-checklist.service';

describe('OnboardingChecklistService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OnboardingChecklistService = TestBed.get(OnboardingChecklistService);
    expect(service).toBeTruthy();
  });
});
