import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
@Injectable({
  providedIn: 'root'
})
export class OnboardVerifyService {

  apiBaseUrl: string;

  constructor(private http: HttpClient) {
    this.apiBaseUrl = globalVariables.apiBaseUrl;
   }

   downloadDoc(candId,section, val, cb){
    let url: string 
     if( section =='pesAddress' || section == 'perAddress'){
     url = this.apiBaseUrl  +'/api/v1/onboard/docuement?onId='+ candId +'&section='+ section 
     }
     else if(section =='edu'){
     url= this.apiBaseUrl  +'/api/v1/onboard/docuement?onId='+ candId +'&section='+ section +'&qid='+val
     }
     else if(section =='workExp'){
      url= this.apiBaseUrl  +'/api/v1/onboard/docuement?onId='+ candId +'&section='+ section +'&desig='+val
      }
      else {
        url= this.apiBaseUrl  +'/api/v1/onboard/docuement?onId='+ candId +'&section='+ section +'&docType='+val
        }
     //onboard-services.local/api/v1/onboard/docuement?onId=86&section=workExp
   let promise = new Promise((resolve, reject) => {
     this.http.get(url)
       .toPromise()
       .then(res => {
         if (res) cb(res)
       })
   })
   return promise;
  }
   /*
    author : Nilena Alexander
    desc   : get employee details based on onboard id
  */
  getBasicDetails(id, cb) {
    let url: string = this.apiBaseUrl + apiList.onboard.getselfOnboard +"/"+id;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  /*
    author : Nilena Alexander
    desc   : to submit verification Details
  */
  submitDetails(id,obj,cb){
    let url: string = this.apiBaseUrl + apiList.onboard.onboardCandidate +"/"+id;
    let promise: any = new Promise((resolve, reject) => {
      this.http.patch(url,obj)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  /*
     author : Nilena Alexander
     desc   : add class based on index
  */
 getClassByValue(index) {
  switch (index % 10) {
    case 0: return "default-avatar islamic-green";
    case 1: return "default-avatar limerick";
    case 2: return "default-avatar chilean-fire";
    case 3: return "default-avatar persian-pink";
    case 4: return "default-avatar deep-magenta";
    case 5: return "default-avatar gigas";
    case 6: return "default-avatar endeavour";
    case 7: return "default-avatar dodger-blue";
    case 8: return "default-avatar jordy-blue";
    case 9: return "default-avatar Light-sea-green";
    case 10: return "emp-profileimage";
  }
}
}
