import { TestBed } from '@angular/core/testing';

import { OnboardVerifyService } from './onboard-verify.service';

describe('OnboardVerifyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OnboardVerifyService = TestBed.get(OnboardVerifyService);
    expect(service).toBeTruthy();
  });
});
