import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
@Injectable({
  providedIn: 'root'
})
export class OnboardListingService {

  apiBaseUrl: string;

	status   : any = 0;
  range    : any = null ;
  range2   : any = null ;
  range3   : any = null ;

  adminRole: boolean = false;
  constructor(private http: HttpClient) {

    this.apiBaseUrl = globalVariables.apiBaseUrl;
  }
  /*
    author : Nilena
    desc   : get employee details based on empid
  */
  getList(qobj, cb) {
    let url: string = this.apiBaseUrl + apiList.onboard.onboardCandidate;
    url = url + this.generateQuery(qobj);
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }

  informReminderCall(id,cb){
    let url: string = this.apiBaseUrl + apiList.onboard.onboardReminder+id;
    let promise: any = new Promise((resolve, reject) => {
      this.http.get(url)
        .toPromise()
        .then(res => {
          cb(res);
        })
    })
  }
  
 cancelStatus(id,cb){
    let url: string = this.apiBaseUrl + apiList.onboard.onboardCandidate+"/"+id;
    let promise = new Promise((resolve, reject) => {
      this.http.patch(url,{stat : 3})
        .toPromise()
        .then(res => {
          if (res) cb(res)
        })
    })
    return promise;
    // let promise: any = new Promise((resolve, reject) => {
    //   this.http.patch(obj,url)
    //     .toPromise()
    //     .then(res => {
    //       cb(res);
    //     })
    // })
  }
  /*
    *  @desc   :to gengerate query
    *  @author :Nilena Alexander
    */

  generateQuery(qobj) {
    let query = `?page=${qobj.page ? qobj.page : ''}&page_limit=${qobj['page_limit'] ? qobj['page_limit'] : ''}${qobj.sort ? '&sort=' + qobj.sort : ''}${qobj.subon ? '&subon=' + qobj.subon : ''}${qobj.veron ? '&veron=' + qobj.veron   : ''}${qobj.creaton ? '&creaton=' + qobj.creaton : ''}${qobj.stat ? '&stat=' + qobj.stat : ''}${qobj.keyword ? '&keyword=' + qobj.keyword : ''}`
    return query;
  }

  /*
     author : Nilena Alexander
     desc   : add class based on index
  */
  getClassByValue(index) {
    switch (index % 10) {
      case 0: return "default-avatar islamic-green";
      case 1: return "default-avatar limerick";
      case 2: return "default-avatar chilean-fire";
      case 3: return "default-avatar persian-pink";
      case 4: return "default-avatar deep-magenta";
      case 5: return "default-avatar gigas";
      case 6: return "default-avatar endeavour";
      case 7: return "default-avatar dodger-blue";
      case 8: return "default-avatar jordy-blue";
      case 9: return "default-avatar Light-sea-green";
      case 10: return "emp-profileimage";
    }
  }

  	/*
  * @ desc   :  method to check value receving from filter is same or not
  * @ author  : nilena alexander
  */

 checkFilterStatus( date1,date2,date3,stat ) {

  let ret = true ;
  // if( this.status == stat && this.owner == own && this.range == date ) {
  // 	ret = false;
  // }
  if( stat == 0  && date1 == null &&
    (this.status == stat && this.range == date1  && this.range2 == date2 && this.range3 == date3)
    ) {
    ret = false;
  }
  this.status = stat ;
  this.range = date1 ;
  this.range2 =date2 
  this.range3 = date3
  return ret ;

}

/*
* @ desc   :  method to check value receving from filter is same or not with previous val
* @ author  : nilena alexander
*/
checkFilterCanCancel() {
  let ret = true ;
  if( this.status == 0  && this.range == null && this.range2 == null&& this.range3 == null) {
    return false ;
  }
  return true ;


}
/*
* @ desc   :  method to clear filter
* @ author  : nilena alexander
*/

clearFilterStatus() {
  this.status = 0;
  this.range = null ;
  this.range2 == null
  this.range3 == null
}
}
