import { TestBed } from '@angular/core/testing';

import { OnboardListingService } from './onboard-listing.service';

describe('OnboardListingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OnboardListingService = TestBed.get(OnboardListingService);
    expect(service).toBeTruthy();
  });
});
