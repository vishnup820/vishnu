import { TestBed } from '@angular/core/testing';

import { CandidateChecklistService } from './candidate-checklist.service';

describe('CandidateChecklistService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CandidateChecklistService = TestBed.get(CandidateChecklistService);
    expect(service).toBeTruthy();
  });
});
