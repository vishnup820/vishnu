import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
@Injectable({
  providedIn: 'root'
})
export class CandidateChecklistService {

  apiBaseUrl: string;
  constructor(private http: HttpClient) {

    this.apiBaseUrl = globalVariables.apiBaseUrl;

  }
  getcandidateeditCheckList(cand_id,cb) {
  let url: string = this.apiBaseUrl+apiList.onboard.checklistLists+"/"+cand_id;
  let promise: any = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
}
getPeople(cb){
  let url: string = this.apiBaseUrl+apiList.people.details+'?fields=f_name,l_name,id,name,dp,code';
 
  // let url = 'http://onboard-services.local/api/v1/onboardChecklist?page=1&page_limit=10'
  let promise: any = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
  }
  submitDetails(id,obj,cb){
    let sendObj = {"data": obj} 
     let url: string = this.apiBaseUrl+apiList.onboard.candidateChecklist + "/" +id;
    // let url = 'http://onboard-services.local/api/v1/onboardChecklist?page=1&page_limit=10'
    let promise: any = new Promise((resolve, reject) => {
    this.http.put(url,sendObj)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
  }
}
