import { TestBed } from '@angular/core/testing';

import { AddCandidateService } from './add-candidate.service';

describe('AddCandidateService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AddCandidateService = TestBed.get(AddCandidateService);
    expect(service).toBeTruthy();
  });
});
