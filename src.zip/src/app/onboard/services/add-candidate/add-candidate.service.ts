import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { globalVariables } from '../../../shared/constants/globals';
import { apiList } from '../../../shared/constants/apilist';
import { CookieService } from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root'
})
export class AddCandidateService {

  data  :any
  apiBaseUrl: string;

  constructor(private http: HttpClient,   
     private cookieService               : CookieService
    ) {

    this.apiBaseUrl = globalVariables.apiBaseUrl;

  }
  getpeopleSettings(){
    if (this.cookieService.get("people_settings")){
      this.data= JSON.parse(this.cookieService.get("people_settings"));
    }
    return this.data
  }

  /*
    author : Nilena
    desc   : get employee details based on empid
  */
 getList(cb) {
  let url: string = this.apiBaseUrl + apiList.onboard.addCandidate+"?from=dropDown"
  let promise: any = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
}
getDetails(id,cb){
  let url: string = this.apiBaseUrl + apiList.onboard.addCandidate+"?cand_id="+id;
  let promise: any = new Promise((resolve, reject) => {
    this.http.get(url)
      .toPromise()
      .then(res => {
        cb(res);
      })
  })
}

/*
  *  @desc   :method get people list for admin drop down
  *  @author :nilena
*/
addForm(obj,cb){
  let url: string;
    url = this.apiBaseUrl+apiList.onboard.onboardCandidate;
    let promise: any = new Promise((resolve, reject) => {
        this.http.post(url,obj)
          .toPromise()
          .then(res => {
            cb(res);
          })
      })
    }
}
