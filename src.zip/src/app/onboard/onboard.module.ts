import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { ClickOutsideModule } from 'ng4-click-outside';
import { BsDatepickerModule,BsDatepickerConfig} from 'ngx-bootstrap/datepicker';

import { AuthGuardService } from '../shared/services/auth-guard/auth-guard.service';
import { RoleGuardService } from '../shared/services/role-guard/role-guard.service';

import { OnboardListingComponent } from './components/onboard-listing/onboard-listing.component';
import { OnboardAddComponent } from './components/onboard-add/onboard-add.component';
import { OnboardingChecklistComponent } from './components/onboarding-checklist/onboarding-checklist.component';
import { CandidateChecklistComponent } from './components/candidate-checklist/candidate-checklist.component';
import { CandidateEditchecklistComponent } from './components/candidate-editchecklist/candidate-editchecklist.component';
import { PopUpComponent } from './components/pop-up/pop-up.component';
import { OnboardVerifyComponent } from './components/onboard-verify/onboard-verify.component';
@NgModule({
  declarations: [OnboardListingComponent, OnboardAddComponent,OnboardingChecklistComponent,PopUpComponent, CandidateChecklistComponent, CandidateEditchecklistComponent, OnboardVerifyComponent],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    ClickOutsideModule,
    BsDatepickerModule.forRoot(),
    RouterModule.forChild([
    {
      path        : 'onboard-listing',
      // canActivate : [RoleGuardService],
      component   :  OnboardListingComponent
    },
    {
      path        : 'onboard-add',
      // canActivate : [RoleGuardService],
      component   :  OnboardAddComponent
    },
    {
      path        : 'onboarding-checklist',
      // canActivate : [RoleGuardService],
      component   :  OnboardingChecklistComponent
    },
    {
      path        : 'candidate-checklist/:id',
      // canActivate : [RoleGuardService],
      component   :  CandidateChecklistComponent
    },
    {
      path        : 'edit-checklist/:id',
      // canActivate : [RoleGuardService],
      component   :  CandidateEditchecklistComponent
    },
    {
      path        : 'candidate-verification/:id',
      // canActivate : [RoleGuardService],
      component   :  OnboardVerifyComponent
    }
    ])
  ],
  providers:[
    AuthGuardService,
    RoleGuardService
  ]
})
export class OnboardModule { }
