import { Component, OnInit,ViewChild,ElementRef,ChangeDetectorRef } from '@angular/core';
import { RouterModule,Routes,Router} from '@angular/router';
import { ActivatedRoute} from '@angular/router';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { OnboardingChecklistService } from '../../services/onboard-checklist/onboarding-checklist.service';

declare var require: any;
var moment = require('moment');
@Component({
  selector: 'app-onboarding-checklist',
  templateUrl: './onboarding-checklist.component.html',
  styleUrls: ['../../../../assets/content/css/onbording.css']
})
export class OnboardingChecklistComponent implements OnInit {
  checklist_response 		: any;
  currentPage     			: number = 1;
  recordsPerPage      		: number = 10;
  perpage      				: number = 10;
  totalRecords        		: number;
  addClass                  : boolean = false;
  showForm                  : boolean = false; 
  addStatus					: any = [{"status":"Active","value":1},{"status":"Inactive","value":2}]
  selectedItems             : any = [];
  additemName               : any;
  addSubmit                 : boolean = false;
  addstatusEvent		    : any;
  responsible				: any = [];
  finalObj                  : any;
  responsibleData			: any = [];
  selectedResponsibleData	: any = [];
  selectedResponsible       : any = [];
  queryObject				: any = {};
  responsibleSubmitted      : boolean = false;

lazyLoader: boolean = false;

  //for edit   
  formPosition 				: boolean = false;
  dataFull					: any;
  filterSort        		: any = {};
  searchTextBox				: boolean = false;
  searchKeyword     		: any="";
  searchD           		: any;
  editData					: any;
  button					: any;
  editedId					: any;
  confirmBox				: boolean = false;
  disableSubmit   		: boolean = false;
  config					: any = "";
  delId						: any;
  editForm        : boolean = false;
  @ViewChild('foc') inputEl:ElementRef;
  newAarray       : any =[];

  constructor(
		private route                 		: ActivatedRoute,
		private notificationService   		: NotificationService,
		private _router               		: Router,
		private loader                		: LoaderActionsService,
		private cookieService         		: CookieService,
		private timeZone              		: TimezoneDetailsService,
		private onboardingChecklistService 	: OnboardingChecklistService
		) {}

  ngOnInit() {
  	if (localStorage.getItem("itemsperpage")) {
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    }
    else {
      this.recordsPerPage = 10;
    }
    this.queryObject = {
      "page": this.currentPage,
      "page_limit": this.recordsPerPage,
    }
  	this.checkGetlist();
  	this.getAllpeople();
    this.selectedItems = [0]
	}

  checkGetlist(){
  	this.loader.display(true);
  	this.onboardingChecklistService.getChecklist(this.queryObject,res=>{
  		if (res && res.data.length) {
        this.checklist_response = res.data;
        this.totalRecords = res.count;
        this.currentPage = this.queryObject.page;
        this.loader.display(false);
      } else {
        this.checklist_response = [];
        this.loader.display(false);
      }
  	})
  }
  /*
  *  @desc   :method to add random classes bsed on index
  *  @author :vinod
  */
 getClassByValue(index) {
  switch (index % 10) {
    case 0: return "default-avatar islamic-green";
    case 1: return "default-avatar limerick";
    case 2: return "default-avatar chilean-fire";
    case 3: return "default-avatar persian-pink";
    case 4: return "default-avatar deep-magenta";
    case 5: return "default-avatar gigas";
    case 6: return "default-avatar endeavour";
    case 7: return "default-avatar dodger-blue";
    case 8: return "default-avatar jordy-blue";
    case 9: return "default-avatar Light-sea-green";
    case 10: return "emp-profileimage";
  }
}

getAllpeople(){
	this.onboardingChecklistService.getPeople(res=>{
		if(res){
      this.responsibleData = res.data
			for(var i=0;i<this.responsibleData.length;i++){
        
				this.responsibleData[i].full_name = this.responsibleData[i].first_name + " " + this.responsibleData[i].last_name +' ('+ this.responsibleData[i].code +')';
			}
    }
	})
}

closeAll(){
  for(let i = 0 ; i < this.checklist_response.length;i++){
    this.checklist_response[i].display = false;
    for(let j = 0 ; j < this.checklist_response[i].responsible.length;j++){
      this.checklist_response[i].responsible[j].display = false;
    }
  }
}

/**
* @ desc   : TO close the add and edit form
* @ author  : vinod.k
*/

  toggleForm(event) {
    this.showForm = !this.showForm;
    if (this.dataFull) {
      this.dataFull.editStatus = false;
    }
    if (this.showForm) {
    this.editedId				 = null;
    this.additemName 		  	 = null;
  	this.responsibleSubmitted 	 = false;
  	this.selectedItems 		  	 = [0]
  	this.selectedResponsibleData = [];
  	this.selectedResponsible     = [];
    this.addSubmit = false;
    this.addClass = true;
    }
    else {
      this.addClass = false;
    }
  }

  submitForm(identify_button){
  	let finalResp = [];
  	this.button = identify_button;
  	let itemEmpty = this.checkISaddItemnameEmpty(this.additemName)
  	if(!this.selectedResponsibleData.length){
  		this.responsibleSubmitted = true
  	}else{
  		this.responsibleSubmitted = false;
  	}
  	if(this.button == "edit"){
      for(var i =0;i<this.selectedResponsibleData.length;i++){
        let v = (this.selectedResponsibleData[i].label.split('('))
        let h2= v[1]
        let h3 =[]
    
        h3= (h2).split(')')
        if(h3[0].split(' ')){
          let h4 = h3[0].split(' ');
          h3[0] = h4[0]
        }
          for(var j=0;j<this.responsibleData.length;j++){
             if(h3[0] ==this.responsibleData[j].code ){
                if(this.responsibleData[j].code!= '' && this.responsibleData[j].code!=null){
                    finalResp.push({"user_id":this.responsibleData[j].id});
              
            }
      }
        // this.finalObj[k].user_id += e[i].originalData.id;
      }
    }
  }
  	if(this.button == "add"){
  		for(var i = 0;i<this.selectedResponsibleData.length;i++){
  			finalResp.push({"user_id":this.selectedResponsibleData[i].originalData.id});
  		}
  	}
  	if(!itemEmpty && !this.responsibleSubmitted){
      this.disableSubmit = true
  		this.finalObj = {
  			"item_name"   		: this.additemName,
  			"status"	  		: this.addstatusEvent,
  			"responsible_users" : finalResp
  		}
  		this.onboardingChecklistService.submitDetails(this.button,this.editedId,this.finalObj,res=>{
  			if(res.status=="OK"){
  				if(this.button == "add"){
  					this.showForm = false;
  				}
  				if(this.button == "edit"){
  					for (var i = 0; i < this.checklist_response.length; i++) {
  						this.checklist_response[i].editStatus = false;
              this.editForm = false;
      			}	
            this.selectedResponsible= [];
      			this.selectedResponsibleData = [];
          }
          this.disableSubmit = false
  				this.notificationService.alertBoxValue("success", res.message);
  				this.checkGetlist();
  			}else{
          this.disableSubmit = false
  				this.notificationService.alertBoxValue("danger", res.message);		
  			}
  		})
  	}
  }

  selectedAddStatus(event){
  	if(event.selected.length){
  		this.addstatusEvent = event.selected[0].value;
  	}
  }

  addItemnameChange(addeditem){
  	this.checkISaddItemnameEmpty(this.additemName)
  }

  checkISaddItemnameEmpty(item){
  	if(item == '' || item == null){
  		this.addSubmit = true;
  		return true
  	}else{
  		this.addSubmit = false;
  		return false 
  	}
  }

  getpage(eve) {
    if (eve > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = eve;
      this.queryObject['page_limit'] = eve;
      this.queryObject['page'] = 1;
      this.currentPage = 1;
      this.checkGetlist();
    }
  }

  pageChangeEvent(page) {
    this.queryObject.page = page;
    this.checkGetlist();
  }

  editRowdata(id,data,event,index){
    data.editStatus= !data.editStatus;
    if(data.editStatus){
    this.selectedResponsible = [];
    // this.selectedResponsibleData = [];
    this.lazyLoader= true
    this.editForm = true;
  	this.editedId = id;
    let yPosition = event.clientY;
    let innerheight = document.getElementById("candidatesChecklist").clientHeight;
    if (((innerheight) / 2) < yPosition && (index > index)) {
      this.formPosition = true;
    }
    else {
      this.formPosition = false;
    }
    let target = event.target || event.srcElement || event.currentTarget;
    let idAttr = event.target.id;
    this.dataFull = data;
    if (idAttr == "a") {
    	// for (var i = 0; i < this.checklist_response.length; i++) {
      //   if (this.checklist_response[i].id == data.id) {
      //     data.editStatus = true;
      //   }
      //   else {
      //     this.checklist_response[i].editStatus = false;
      //   }
      // }	
      this.onboardingChecklistService.geteditData(id,res=>{
      	if(res.status == "OK"){
          this.editData = [];
          this.editData = res.data; 
      		this.additemName = this.editData.item_name;
      		if(this.editData.status == '1'){
      			this.selectedItems =  [0];
      		}else{
      			this.selectedItems =  [1];
          }
          this.addstatusEvent = this.editData.status;
      		for(var i = 0;i<this.editData.responsible.length;i++){
            if(this.editData.responsible.length){
            if(i== this.editData.responsible.length-1){
              this.selectedResponsible += this.editData.responsible[i].full_name + ' ('+ this.editData.responsible[i].code +' )';
            }else{
              this.selectedResponsible += this.editData.responsible[i].full_name + ' ('+ this.editData.responsible[i].code +' )' +',';
            }
          }
      		 if(this.selectedResponsible[i] != ''){
             this.selectedResponsible = this.selectedResponsible.split(',');
      		 }
          }
          // this.selectedResponsible[0] = [2];
          // setTimeout( ()=>{
            this.lazyLoader= false;
          // },3000)
          

      	}else{
          // setTimeout( ()=>{
            this.lazyLoader= false;
          // },3000)
        }
        
      })
    }
  }

  }
  getResponsibleData(event){
    this.selectedResponsibleData = event;
  }
 
  removeAllvalidation(){
  	this.additemName 		  	 = null;
  	this.responsibleSubmitted 	 = false;
  	this.selectedItems 		  	 = [0]
  	this.addSubmit 			  	 = false;
    this.editForm             = false;
  	this.selectedResponsibleData = [];
  	this.selectedResponsible= [];
  }

  sortRows(label){
    let currentSortStatus = this.filterSort[label] ? this.filterSort[label].rev : true;
    this.filterSort = {};
    this.filterSort[label] = { rev: !currentSortStatus }
    this.filterSort["label"] = label;
    this.queryObject.sort = `${this.filterSort[label].rev ? '-' : ''}${label}`
    this.checkGetlist();
  }
  inputfocus() {
    setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
  }

  searchList(keyword){
    if (this.searchKeyword || this.searchD.trim() != '') {
      this.searchKeyword = keyword;
      this.queryObject.keyword = this.searchKeyword ? this.searchKeyword : '';
      this.queryObject.page = 1;
      this.checkGetlist();
    }
  }

  getPopupConfirm(ev){
  	if(ev==true){
  		this.onboardingChecklistService.deleteCgecklist(this.delId,res=>{
  			if(res.status=='OK'){
  				this.queryObject['page'] = 1; 
  				this.currentPage = 1;
  				this.confirmBox = false;
          this.checkGetlist()
  				this.notificationService.alertBoxValue("success", res.message);
        }else{
          this.queryObject['page'] = 1; 
  				this.currentPage = 1;
  				this.confirmBox = false;
          this.checkGetlist()
  				this.notificationService.alertBoxValue("error", res.message);
        }
  		})
  	}else{
  		this.confirmBox = false;
  	}
  }

  deleteCurrentChecklist(data){
  	this.delId = data;
  	this.confirmBox = true;
  	this.config = "Are You Sure You Want To Delete?";
  }
}


