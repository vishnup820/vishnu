import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnboardVerifyComponent } from './onboard-verify.component';

describe('OnboardVerifyComponent', () => {
  let component: OnboardVerifyComponent;
  let fixture: ComponentFixture<OnboardVerifyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnboardVerifyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnboardVerifyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
