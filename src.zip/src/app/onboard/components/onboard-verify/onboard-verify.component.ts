import { Component, OnInit } from '@angular/core';
import { OnboardVerifyService } from '../../services/onboard-verify/onboard-verify.service';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import * as FileSaver from 'file-saver';
import { TimezoneDetailsService } from 'src/app/shared/services/timezone-details/timezone-details.service';
declare var require: any;
var moment = require('moment-timezone');
@Component({
  selector: 'app-onboard-verify',
  templateUrl: './onboard-verify.component.html',
  styleUrls: ['../../../../assets/content/css/onbording.css']
})
export class OnboardVerifyComponent implements OnInit {

  detailId            : number
  persnlStat          : number
  qualfStat           : number
  workStat            : number
  docStat             : number
  StatVal             : number 
  candidateDetails    : any 
  familyRemark        : any
  qualRemark          : any
  workRemark          : any 
  docRemark           : any 
  docNumberView       : any
  familyDetails       : any = []

  personalApp               : string
  personalReject            : string
  qualApp                   : string
  qualReject                : string
  workApp                   : string
  workReject                : string
  docApp                    : string
  docReject                 : string
  familyRemarks             : boolean = false
  qualRemarks               : boolean = false
  workRemarks               : boolean = false
  docRemarks                : boolean = false
  confirmBox                : boolean = false            
  persnlApproveDisabled     : boolean = false
  persnlRejectDisabled      : boolean = false
  qualApproveDisabled       : boolean = false
  qualRejectDisabled        : boolean = false
  workApproveDisabled       : boolean = false
  workRejectDisabled        : boolean = false 
  docApproveDisabled        : boolean = false
  docRejectDisabled         : boolean = false
  remarkdoc                 : boolean = false
  remarkPrsnal              : boolean = false
  remarkwork                : boolean = false
  remarkqualf               : boolean = false
  submittedErr              : boolean = false
  presentAddShow            : boolean = false
  hideBtn                   : boolean = false
  showPopup                 : boolean = true
  uu  : any;
  config                           : any = "Are You Sure You Want To Proceed With These Changes?";

  constructor( private onboardVerfication :OnboardVerifyService,
    private activatedRoute                :ActivatedRoute,
    private loader                        : LoaderActionsService,
    private NotificationService           : NotificationService,
    private router                        : Router,
    private timezone                      : TimezoneDetailsService) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params =>
       this.detailId = params.id);
    this.getBasicInfo();

  }
  getFileType(filename){
    return filename.substr(filename.lastIndexOf('.') + 1);
}
  /**@author: Nilena Alexander
   * @desc  : to get basic details of the candidate
   */
  getBasicInfo(){
    this.loader.display(true)
    this.onboardVerfication.getBasicDetails(this.detailId,response=>{
      if(response.status =="OK"){
        this.candidateDetails = response.data;
         if((this.candidateDetails && this.candidateDetails.personalDetails &&  this.candidateDetails.personalDetails.verifyStatus == 3)|| (this.candidateDetails && this.candidateDetails.personalDetails && this.candidateDetails.personalDetails.verifyStatus == 2) ||(this.candidateDetails && this.candidateDetails.personalDetails &&  this.candidateDetails.personalDetails.stat==2)|| (this.candidateDetails && this.candidateDetails.personalDetails &&  this.candidateDetails.personalDetails.stat==3) ){
              this.hideBtn = true;
         }else
             this.hideBtn  = false;

        if(response.data.personalDetails.isSamePresent == '1')
        this.presentAddShow = false
        else
        this.presentAddShow = true

        for(let i=0;i<this.candidateDetails.documents.length;i++){
          if(this.candidateDetails.documents[i].docValidity=='0000-00-00')
             this.candidateDetails.documents[i].docValidity=''  
        }
        if( this.candidateDetails &&  this.candidateDetails.educationalQualification){
          

          for(let i=0;i< this.candidateDetails.educationalQualification.length;i++){
            for(let j=0;j < this.candidateDetails.educationalQualification[i].file_details.length;j++){
            this.candidateDetails.educationalQualification[i].file_details[j].file_type = this.getFileType( this.candidateDetails.educationalQualification[i].file_details[j].certificate_name)
            }
          }
          
        }
        if( this.candidateDetails &&  this.candidateDetails.documents){
          

          for(let i=0;i< this.candidateDetails.documents.length;i++){
            for(let j=0;j< this.candidateDetails.documents[i].file_details.length;j++){
            this.candidateDetails.documents[i].file_details[j].file_type = this.getFileType( this.candidateDetails.documents[i].file_details[j].doc_name)
            }
          }
        }
        if( this.candidateDetails &&  this.candidateDetails.workExperince){
          

          for(let i=0;i< this.candidateDetails.workExperince.length;i++){
            for(let j=0;j< this.candidateDetails.workExperince[i].file_details.length;j++){
            this.candidateDetails.workExperince[i].file_details[j].file_type = this.getFileType( this.candidateDetails.workExperince[i].file_details[j].certificate_name)
            }
          }
        }
        if( this.candidateDetails &&  this.candidateDetails.personalDetails){
          
          for(let i=0;i< this.candidateDetails.personalDetails.permantAddrProof.length;i++){
            this.candidateDetails.personalDetails.permantAddrProof[i].file_type = this.getFileType( this.candidateDetails.personalDetails.permantAddrProof[i].file_name)
          }
          for(let i=0;i< this.candidateDetails.personalDetails.presentAddrProof.length;i++){
            this.candidateDetails.personalDetails.presentAddrProof[i].file_type = this.getFileType( this.candidateDetails.personalDetails.presentAddrProof[i].file_name)
          }
          
        }
       
        this.loader.display(false)
        this.familyDetails = [];
        if(this.candidateDetails.personalDetails.fatherName)
        this.familyDetails.push({"relation":'Father',"name":this.candidateDetails.personalDetails.fatherName,"mobile":this.candidateDetails.personalDetails.fatherMob,"dob":this.candidateDetails.personalDetails.fatherDob,"email":this.candidateDetails.personalDetails.fatherEmail})
        if(this.candidateDetails.personalDetails.motherNam)
        this.familyDetails.push({"relation":'Mother',"name":this.candidateDetails.personalDetails.motherNam,"mobile":this.candidateDetails.personalDetails.motherMob,"dob":this.candidateDetails.personalDetails.motherDob,"email":this.candidateDetails.personalDetails.motherEmail})
        if(this.candidateDetails.personalDetails.spouseName)
        this.familyDetails.push({"relation":'Spouse',"name":this.candidateDetails.personalDetails.spouseName,"mobile":this.candidateDetails.personalDetails.spouseMob,"dob":this.candidateDetails.personalDetails.spouseDob,"email":this.candidateDetails.personalDetails.spouseEmail})
        if(this.candidateDetails&&this.candidateDetails.personalDetails&& this.candidateDetails.personalDetails.child_details.length>0){
          for(let i =0;i<  this.candidateDetails.personalDetails.child_details.length;i++){
            this.familyDetails.push({"relation":'Child',"name":this.candidateDetails.personalDetails.child_details[i].childName,"gender":this.candidateDetails.personalDetails.child_details[i].childGender,"dob":this.candidateDetails.personalDetails.child_details[i].childDob})
          }
        }
        this.persnlStat   =   this.candidateDetails.personalDetails.persnlSectStat
        this.qualfStat    =   this.candidateDetails.personalDetails.qualfSectStat 
        this.workStat     =   this.candidateDetails.personalDetails.workSectStat 
        this.docStat      =   this.candidateDetails.personalDetails.docSectStat 
        if(this.candidateDetails.personalDetails.persnlSectRemarks!=''|| this.candidateDetails.personalDetails.persnlSectRemarks!=null || this.candidateDetails.personalDetails.persnlSectRemarks!=undefined )
        this.familyRemark =   this.candidateDetails.personalDetails.persnlSectRemarks 
        
        if(this.candidateDetails.personalDetails.qualfSectRemarks!=''|| this.candidateDetails.personalDetails.qualfSectRemarks!=null || this.candidateDetails.personalDetails.qualfSectRemarks!=undefined )
        this.qualRemark  =   this.candidateDetails.personalDetails.qualfSectRemarks 

        if(this.candidateDetails.personalDetails.workSectRemarks!=''|| this.candidateDetails.personalDetails.workSectRemarks!=null || this.candidateDetails.personalDetails.workSectRemarks!=undefined )
        this.workRemark   =   this.candidateDetails.personalDetails.workSectRemarks 

        if(this.candidateDetails.personalDetails.docSectRemarks!=''|| this.candidateDetails.personalDetails.docSectRemarks!=null || this.candidateDetails.personalDetails.docSectRemarks!=undefined )
        this.docRemark    =   this.candidateDetails.personalDetails.docSectRemarks 

        if(this.candidateDetails&&this.candidateDetails.personalDetails&& this.candidateDetails.personalDetails.persnlSectStat ==='1'){
          this.persnlApproveDisabled = false
          this.persnlRejectDisabled = false
          this.personalApp = 'APPROVE'
          this.personalReject = 'REJECT'

        }else if(this.candidateDetails&&this.candidateDetails.personalDetails&& this.candidateDetails.personalDetails.persnlSectStat ==='2'){         
          this.persnlApproveDisabled = true
          this.personalApp = 'APPROVED'
          this.persnlRejectDisabled = false
          this.personalReject = 'REJECT'
        }
        else if(this.candidateDetails&&this.candidateDetails.personalDetails&& this.candidateDetails.personalDetails.persnlSectStat ==='3'){         
          this.persnlApproveDisabled = false
          this.personalApp = 'APPROVE'
          this.persnlRejectDisabled = true
          this.personalReject = 'REJECTED'

        }

        if(this.candidateDetails&&this.candidateDetails.personalDetails&& this.candidateDetails.personalDetails.qualfSectStat ==='1'){
          this.qualApproveDisabled = false
          this.qualRejectDisabled = false
          this.qualApp = 'APPROVE'
          this.qualReject = 'REJECT'
        }else if(this.candidateDetails&&this.candidateDetails.personalDetails&& this.candidateDetails.personalDetails.qualfSectStat ==='2'){         
          this.qualApproveDisabled = true
          this.qualApp = 'APPROVED'
          this.qualRejectDisabled = false
          this.qualReject = 'REJECT'
        }
        else if(this.candidateDetails&&this.candidateDetails.personalDetails&& this.candidateDetails.personalDetails.qualfSectStat ==='3'){         
          this.qualApproveDisabled = false
          this.qualApp = 'APPROVE'
          this.qualRejectDisabled = true
          this.qualReject = 'REJECTED'
        }
        if(this.candidateDetails&&this.candidateDetails.personalDetails&& this.candidateDetails.personalDetails.workSectStat ==='1'){
          this.workApproveDisabled = false
          this.workRejectDisabled = false
          this.workApp = 'APPROVE'
          this.workReject = 'REJECT'
        }else if(this.candidateDetails&&this.candidateDetails.personalDetails&& this.candidateDetails.personalDetails.workSectStat ==='2'){         
          this.workApproveDisabled = true
          this.workApp = 'APPROVED'
          this.workRejectDisabled = false
          this.workReject = 'REJECT'
        }
        else if(this.candidateDetails&&this.candidateDetails.personalDetails&& this.candidateDetails.personalDetails.workSectStat ==='3'){         
          this.workApproveDisabled = false
          this.workApp = 'APPROVE'
          this.workRejectDisabled = true
          this.workReject = 'REJECTED'
        }    
        
        if(this.candidateDetails&&this.candidateDetails.personalDetails&& this.candidateDetails.personalDetails.docSectStat ==='1'){
          this.docApproveDisabled = false
          this.docRejectDisabled = false
          this.docApp = 'APPROVE'
          this.docReject = 'REJECT'
        }else if(this.candidateDetails&&this.candidateDetails.personalDetails&& this.candidateDetails.personalDetails.docSectStat ==='2'){         
          this.docApproveDisabled = true
          this.docApp = 'APPROVED'
          this.docRejectDisabled = false
          this.docReject = 'REJECT'
        }
        else if(this.candidateDetails&&this.candidateDetails.personalDetails&& this.candidateDetails.personalDetails.docSectStat ==='3'){         
          this.docApproveDisabled = false
          this.docApp = 'APPROVE'
          this.docRejectDisabled = true
          this.docReject = 'REJECTED'
        }
      }
    })
  }
  /**@author: Nilena Alexander
  * @desc  : to handle approve peronsal info
  */
 personalApproveBtn(){
  this.persnlApproveDisabled = true
  this.personalApp = 'APPROVED'
  this.persnlRejectDisabled = false
  this.personalReject = 'REJECT'   
  this.persnlStat  = 2
  this.familyRemarks = false

  // this.NotificationService.alertBoxValue("success",'Approved Successfully');
  }

  /**@author: Nilena Alexander
  * @desc  : to handle reject peronsal info
  */
  personalRejectBtn(){
    this.persnlApproveDisabled = false
    this.personalApp = 'APPROVE'
    this.persnlRejectDisabled = true
    this.personalReject = 'REJECTED'
    this.persnlStat  = 3
    if(this.familyRemark =='' || this.familyRemark ==null || this.familyRemark ==undefined){
      this.familyRemarks=true
     this.remarkPrsnal = true;
     }
     else{
      this.familyRemarks=false   
       this.remarkPrsnal = false;
    }
         // this.NotificationService.alertBoxValue("success",'Rejected Sucessfully');
  }
  /**@author: Nilena Alexander
  * @desc  : to handle approve educational info
  */
  qualApprovrBtn(){
    this.qualApproveDisabled = true
    this.qualApp = 'APPROVED'
    this.qualRejectDisabled = false
    this.qualReject = 'REJECT'
    this.qualfStat  = 2
    this.qualRemarks =false
    // this.NotificationService.alertBoxValue("success",'Approved Successfully');

  }
  /**@author: Nilena Alexander
  * @desc  : to handle approve educational info
  */
 qualRejectBtn(){
  this.qualApproveDisabled = false
  this.qualApp = 'APPROVE'
  this.qualRejectDisabled = true
  this.qualReject = 'REJECTED' 
  this.qualfStat  = 3

    if(this.qualRemark =='' || this.qualRemark ==null || this.qualRemark ==undefined){
      this.qualRemarks =true
      this.remarkqualf = true;
     }
    else {   
      this.remarkqualf = false;
      this.qualRemarks =false
    }  // this.NotificationService.alertBoxValue("success",'Rejected Sucessfully');
  }
  /**@author: Nilena Alexander
  * @desc  : to handle approve work info
  */
 workApprovrBtn(){
  this.workApproveDisabled = true
  this.workApp = 'APPROVED'
  this.workRejectDisabled = false
  this.workReject = 'REJECT'
  this.workStat  = 2
  this.workRemarks = false
  // this.NotificationService.alertBoxValue("success",'Approved Successfully');
  }
  
  	/*
   *  @desc   :download attachment form leave list
   *  @author :dipin
   */
	attachmentDownloadCommon(id, section,val,j, value) {
		var tempJ = j;
		this.loader.display(true);
		this.onboardVerfication.downloadDoc(id, section,val, res => {
			if (res.status != "OK") {
				this.loader.display(false);
			}
			else {
				let binary_string: any = window.atob(res.data);
				let types;
				if (value == false)
					if (this.candidateDetails.personalDetails.permantAddrProof.file_details[tempJ].file_type == "png" || this.candidateDetails.personalDetails.permantAddrProof.file_details[tempJ].file_type == "jpg" ||this.candidateDetails.personalDetails.permantAddrProof.file_details[tempJ].file_type == "jpeg") {
						types = 'image/png';
					}
					else if (this.candidateDetails.personalDetails.permantAddrProof.file_detail.file_details[tempJ].file_type == "pdf") {
						types = 'application/pdf';
					}
					else {
						types = "application/octet-stream";
					}
				else {
					types = "application/zip";
				}
				let len: any = binary_string.length;
				let bytes: any = new Uint8Array(len);
				for (var i = 0; i < len; i++) {
					bytes[i] = binary_string.charCodeAt(i);
				}
				let file: any = new Blob([bytes.buffer], { type: types });
				if (value == false)
					FileSaver.saveAs(file, this.candidateDetails.personalDetails.permantAddrProof.file_details[tempJ].file_name);
				else
					FileSaver.saveAs(file, "document " + this.timezone.getCurrentDate().toDateString());
				this.loader.display(false);
			}
		})
	}

  /**@author: Nilena Alexander
  * @desc  : to handle approve work info
  */
  workRejectBtn(){
  this.workApproveDisabled = false
  this.workApp = 'APPROVE'
  this.workRejectDisabled = true
  this.workReject = 'REJECTED' 
  this.workStat  = 3
  if(this.workRemark =='' || this.workRemark ==null || this.workRemark ==undefined){
    this.remarkwork = true;
    this.workRemarks=true;
  }
  else{
    this.workRemarks=false;
    this.remarkwork = false;
  }  // this.NotificationService.alertBoxValue("success",'Rejected Sucessfully');
  }
   /**@author: Nilena Alexander
  * @desc  : to handle approve work info
  */
  docApprovrBtn(){
  this.docApproveDisabled = true
  this.docApp = 'APPROVED'
  this.docRejectDisabled = false
  this.docReject = 'REJECT'
  this.docStat  = 2
  this.docRemarks = false
  // this.NotificationService.alertBoxValue("success",'Approved Successfully');
  }
  /**@author: Nilena Alexander
  * @desc  : to handle approve work info
  */
  docRejectBtn(){
  this.docApproveDisabled = false
  this.docApp = 'APPROVE'
  this.docRejectDisabled = true
  this.docReject = 'REJECTED' 
  this.docStat  = 3
  if(this.docRemark =='' || this.docRemark ==null || this.docRemark ==undefined){
    this.remarkdoc = true;
     this.docRemarks= true
   }
     else{
       this.docRemarks= false
       this.remarkdoc = false; 
   }  // this.NotificationService.alertBoxValue("success",'Rejected Sucessfully');
  }
  /**@author: Nilena Alexander
   ** @desc  : to view address attached
  */

  open(value){
    window.open(value);
  }

  /**@author: Nilena Alexander
  * @desc  : to  active confrm popup
  */
  getPopupConfirm(event) {
    this.confirmBox = false; 
      if (event == true) {
        if(this.candidateDetails.workExperince.length == 0 ){
          this.workStat =2
        }
        let obj = 
          {
            "persnlStat"    : this.persnlStat,
            "persnlRemarks" : this.familyRemark,
            "qualfStat"     : this.qualfStat,
            "qualfRemarks"  : this.qualRemark ,
            "workStat"      : this.workStat,
            "workRemarks"   : this.workRemark ,
            "docStat"       : this.docStat,
            "docRemarks"    : this.docRemark ,
            "submitType"    : this.StatVal
            }
             
        this.loader.display(true);
        this.onboardVerfication.submitDetails(this.detailId,obj,response =>{
          if(response.status =="Success"){
            this.router.navigate(['/modules/onboard/onboard-listing'])
            setTimeout(() => {
              this.NotificationService.alertBoxValue("success", response.message);
            }, 500)
            this.loader.display(false)
          }
          else{
            this.loader.display(false)
            this.NotificationService.alertBoxValue("error", response.message);

          }
        })
      
    }
  
 
  }
   /*
 author : Nilena Alexander
 desc   : add class based on index
*/
getClassByValue(index) {
  return this.onboardVerfication.getClassByValue(index);

}


checkValidation(){
  if(this.persnlStat ==3){
    if(this.familyRemark =='' || this.familyRemark ==null || this.familyRemark ==undefined){
     this.familyRemarks=true
    this.remarkPrsnal = true;
    }
    else{
      this.familyRemarks=false   
       this.remarkPrsnal = false;
    }
  }else{
    this.familyRemarks=false
    this.remarkPrsnal = false;
  }

  if(this.qualfStat ==3){
    if(this.qualRemark =='' || this.qualRemark ==null || this.qualRemark ==undefined){
      this.qualRemarks =true
      this.remarkqualf = true;
     }
    else {   
      this.remarkqualf = false;
      this.qualRemarks =false
    }
  }else{
    this.remarkqualf = false;
    this.qualRemarks =false
    }

  if(this.workStat ==3){
    if(this.workRemark =='' || this.workRemark ==null || this.workRemark ==undefined){
      this.remarkwork = true;
      this.workRemarks=true;
    }
    else{
      this.workRemarks=false;
      this.remarkwork = false;
    }
  }else{
    this.workRemarks=false;
    this.remarkwork = false;
    }

  if(this.docStat ==3){
    if(this.docRemark =='' || this.docRemark ==null || this.docRemark ==undefined){
   this.remarkdoc = true;
    this.docRemarks= true
  }
    else{
      this.docRemarks= false
      this.remarkdoc = false; 
  }
}else{
    this.docRemarks= false
    this.remarkdoc = false;
  }
  if(this.remarkPrsnal || this.remarkqualf || this.remarkwork || this.remarkdoc ){
    this.submittedErr= true
    this.NotificationService.alertBoxValue("error", 'Please Provide Remarks for Rejected Sections');
  }
    else
    this.submittedErr= false

    return this.submittedErr;
  
}

saveFn(){ 
  let stat = false;
  stat = this.checkValidation();
  if(!stat){
    let obj = 
    {
      "persnlStat"    : this.persnlStat,
      "persnlRemarks" : this.familyRemark,
      "qualfStat"     : this.qualfStat,
      "qualfRemarks"  : this.qualRemark ,
      "workStat"      : this.workStat,
      "workRemarks"   : this.workRemark ,
      "docStat"       : this.docStat,
      "docRemarks"    : this.docRemark ,
      "submitType"    : this.StatVal
      } 
    this.loader.display(true);
  this.onboardVerfication.submitDetails(this.detailId,obj,response =>{
    if(response.status =="Success"){
      this.router.navigate(['/modules/onboard/onboard-listing'])
      setTimeout(() => {
        this.NotificationService.alertBoxValue("success", response.message);
      }, 500)
      this.loader.display(false)
    }else{
      this.NotificationService.alertBoxValue("error", response.message);
    this.loader.display(false)
    }
  })
  }
  
}

subCheck(){
  if(this.candidateDetails.educationalQualification.length != 0 && this.candidateDetails.workExperince.length  != 0 && this.candidateDetails.documents.length  != 0  && this.candidateDetails.personalDetails.length  != 0 ){
    if(this.persnlStat != 1 && this.qualfStat != 1 &&this.workStat != 1 &&this.docStat != 1  ){
    
      let stat = false;
      stat = this.checkValidation();
      if(!stat){
      this.confirmBox = true;
      }
    }
    else{
      this.NotificationService.alertBoxValue("error","To submit the form, you have to take an action against each and every section");
    }
  }else if(this.candidateDetails.workExperince.length == 0 ){
    if(this.persnlStat != 1 && this.qualfStat != 1 &&this.docStat != 1  ){
      let stat = false;
      stat = this.checkValidation();
      if(!stat){
      this.confirmBox = true;
      }  
    }
    else{
      this.NotificationService.alertBoxValue("error","To submit the form, you have to take an action against each and every section");
    }
  }
  else{
    this.NotificationService.alertBoxValue("error","To submit the form, you have to take an action against each and every section");
  }
  // let val = this.candidateDetails.educationalQualification.length + this.candidateDetails.workExperince.length 
  // console.log( val)
 
 }
 openImage(img){
  let replaceImgUrl=img.replace("-150X150", "");
  window.open(replaceImgUrl)
 }
 checkPassword(event,index){
   if (event.status == false) {
   this.docNumberView = event.doceNumber
   this.candidateDetails.documents[index]['docNoPush']=this.docNumberView
  this.candidateDetails.documents[index].showPopup = event.status;
  
  }
 }
 shoeHidePassword(docData,index){
   if(docData){
    this.candidateDetails.documents[index]['docNoPush']=''
    this.candidateDetails.documents[index].showPopup = false
   }
   else{
     
   }

 }
}
