import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import { RouterModule,Routes,Router} from '@angular/router';
import { ActivatedRoute} from '@angular/router';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { CandidateChecklistService } from '../../services/candidate-checklistservice/candidate-checklist.service';
@Component({
  selector: 'app-candidate-editchecklist',
  templateUrl: './candidate-editchecklist.component.html',
  styleUrls: ['../../../../assets/content/css/onbording.css']
})
export class CandidateEditchecklistComponent implements OnInit {
  //variable declarations(boolean array object)
  sub				          : any;
  cand_ids			      : number;
  candidateEditData	  : any     = [];
  done				        : any     = [{"status":"Yes","stat":false,"value":1},{"status":"No","stat":false,"value":2},{"status":"NA","stat":false,"value":3}] 
  finalObj 			      : any     = [];
  nodata			        : boolean = false;
  selectedRespData    : any     = [];
  selectedRes         : any     = [];
  responsibleData     : any     = [];
  finalSubmit         : boolean = false;
  arrayRes            : any     = [];
  candidate_name      : any;
  notesArray          : any     = [];

  // constructor initilaization
  constructor(private route           : ActivatedRoute,
		private notificationService   		: NotificationService,
		private _router               		: Router,
		private loader                		: LoaderActionsService,
		private cookieService         		: CookieService,
		private timeZone              		: TimezoneDetailsService,
		private candidateChecklistService : CandidateChecklistService,
    private cdr                       : ChangeDetectorRef) { }

  // component start
  ngOnInit() {
    this.loader.display(true);
  	this.sub = this.route.params.subscribe(params => {
  		this.cand_ids = params.id;
      this.candidateChecklistService.getPeople(res=>{
        if(res){
          this.responsibleData = res.data
          for(var i=0;i<this.responsibleData.length;i++){
            this.responsibleData[i].full_name = this.responsibleData[i].first_name + " " + this.responsibleData[i].last_name + ' (' + this.responsibleData[i].code +')';
          }
        }
        this.getEditData();
  
      })
    })

  }

  // author : vinod
  // desc   : initial edit data load
  getEditData(){
  	this.loader.display(true);
  	this.candidateChecklistService.getcandidateeditCheckList(this.cand_ids,res=>{
  		if(res.status == "OK"){
        this.candidateEditData = res.data;
        this.candidate_name = res.candidate_name; 
        if(this.candidateEditData.length){
        for(var j=0;j<this.candidateEditData.length;j++){
          if(this.candidateEditData[j] && this.candidateEditData[j].responsible.length){
        for(var i=0;i<this.candidateEditData[j].responsible.length;i++){
          if(this.candidateEditData && this.candidateEditData[j] &&  this.candidateEditData[j].responsible &&  this.candidateEditData[j].responsible[i]){
          this.candidateEditData[j].responsible[i].full_name = this.candidateEditData[j].responsible[i].first_name + " " + this.candidateEditData[j].responsible[i].last_name + ' (' + this.candidateEditData[j].responsible[i].code +')';
         }
        }
      }}}


        for(var i =0;i<this.candidateEditData.length;i++){
          this.notesArray[i] = this.candidateEditData[i].note

        }
     this.processData(this.candidateEditData);
  			this.nodata = false;
  		}else{
  			this.candidateEditData = [];
  			this.nodata = true;	
  			this.loader.display(false);
  		}
  	})
  }
  
  // author : vinod
  // desc   : patch fields
  processData(data){
  	var self  = this;
  
        for(var i = 0;i<data.length;i++){
          data[i].full_name = '';
          for(var j = 0;j<data[i].responsible.length;j++){
            if(data[i].full_name != ''){
              data[i].full_name += ",";
            }  
            if(data[i].responsible[j].full_name){
              data[i].full_name +=  data[i].responsible[j].full_name + ' (' + data[i].responsible[j].code +')';
            }
          }
        }
        for(var i = 0;i<data.length;i++){
          this.selectedRes[i] = data[i].full_name.split(',');
          this.selectedRes[i].id =  data[i].user_id
        }
        if (data) {
          data.forEach((item, index) => {
            item['selected'] = {};
            if(item.done == '1'){
              item['selected'] = [0];
            }else if(item.done == '2'){
              item['selected'] = [1];
            }
            else if(item.done == '3') {
              item['selected'] = [2];
            }else{
              item['selected'] = [0];
            }
            self.finalObj.push({
              "done"			: item.done,
              "notes" 		: item.note,
              "check_list_id"			: item.id,
            })
          })
        }
         this.loader.display(false);
  }

  // author : vinod
  // desc   : responsible event trigger (obj,index)
  ChnagedResponsible(e,k){
    if(e && e.length){
      this.arrayRes[k] = false;
      this.finalSubmit = false;
      this.finalObj[k].user_id = '';
      let v=[]
      for(var i =0;i<e.length;i++){
        let v = (e[i].label.split('('))
        let h2= v[1]
       let h3 =[]
      h3= (h2).split(')')
      if(h3[0].split(' ')){
        let h4 = h3[0].split(' ');
        h3[0] = h4[0]
      }
        for(var j=0;j<this.responsibleData.length;j++){
           if(h3[0] ==this.responsibleData[j].code ){
            if(this.responsibleData[j].code!= '' && this.responsibleData[j].code!=null){
          //   this.finalObj[k].user_id +=  ",";
          // }
          //  (this.finalObj[k].user_id).push(this.responsibleData[j].id)
            if(e.length-1 == i){
            this.finalObj[k].user_id +=  this.responsibleData[j].id ;
          }else{
            this.finalObj[k].user_id +=  this.responsibleData[j].id +',';

          }
          
        }
        }else{
        }
      }
      // for(var i = 0;i<this.candidateEditData.length;i++){
      //   this.selectedRes[i] = this.candidateEditData[i].full_name.split(',');
      //   this.selectedRes[i].id =  this.candidateEditData[i].user_id
      // }
        
        // this.finalObj[k].user_id += e[i].originalData.id;
      }
      // console.log( this.finalObj )
    }else{
      this.finalObj[k].user_id = '';
      // this.arrayRes[k] = true;
      this.finalSubmit = true;
    }
    this.cdr.detectChanges();
  }

  // author : vinod
  // desc   : responsible event trigger (event,data,index)
  changeStatus(e,data,index){
  	if(e && e.selected && e.selected.length){
  		this.finalObj[index].done = e.selected[0].value; 
  	}
  }

  // author : vinod
  // desc   : note field event trigger (data,index)
  changeNote(data,index){
  	if(data){
  		this.finalObj[index].notes = data; 
    }else{
      this.finalObj[index].notes = ''; 
    }
  }

  // author : vinod
  // desc   : navigate to candidate checklist page
  cancel(){
    this._router.navigate(['modules/onboard/candidate-checklist/'+this.cand_ids])
  }
  checkIsvalid(obj){
    if(obj.length){
    for(var i = 0;i<obj.length;i++){
      if(obj[i]==true){
        this.finalSubmit = true;
        break;
      }
      else{
        this.finalSubmit = false;
        }
      }
    }
    return this.finalSubmit;
  }
  // author : vinod
  // desc   : submit final data;
  submitFinalDetails(){
    let j = false
    for(var i=0;i<this.finalObj.length;i++){
      if(this.finalObj[i].user_id == ""){
        this.arrayRes[i] = true;
      }else{
        this.arrayRes[i] = false;
      }
      // console.log(this.finalObj)
    }
    j = this.checkIsvalid(this.arrayRes)

    if(!j){
    this.candidateChecklistService.submitDetails(this.cand_ids,this.finalObj,res=>{
      if(res && res.status == "OK"){
        // setTimeout( ()=>{
          this.notificationService.alertBoxValue("success", res.message);
        // })
        this._router.navigate(['modules/onboard/candidate-checklist/'+this.cand_ids])
      }else{
        this.notificationService.alertBoxValue("danger", res.message);
      }
    })}
  }
}
