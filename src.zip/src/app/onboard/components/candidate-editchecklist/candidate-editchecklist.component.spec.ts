import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateEditchecklistComponent } from './candidate-editchecklist.component';

describe('CandidateEditchecklistComponent', () => {
  let component: CandidateEditchecklistComponent;
  let fixture: ComponentFixture<CandidateEditchecklistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandidateEditchecklistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidateEditchecklistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
