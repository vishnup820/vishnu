import { Component, OnInit } from '@angular/core';
import { AddCandidateService } from '../../services/add-candidate/add-candidate.service';
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { Router } from '@angular/router';
import { debug } from 'util';
declare var require: any;
var moment = require('moment-timezone'); @Component({
  selector: 'app-onboard-add',
  templateUrl: './onboard-add.component.html',
  styleUrls: ['../../../../assets/content/css/onbording.css']
})
export class OnboardAddComponent implements OnInit {

  firstName       :  string;
  middleName      : string;
  lastName        : string;
  candidateId     : string;
  displayName     : string;
  gender          : any;
  dateOfBirth     : any;
  dob             : string;
  emailId         : string;
  joiningDate     : any;
  mobileNum       : string;
  mindate         : any;
  maxdate         : any;
  altMobNum       : any;
  gendeStatus     : any;
  candidateDetail : any = [];
  candidateData   : any = []
  userData        : any;
  age             : number;
  popStat         : number;
  getCurrentdate  : any;
  noError         : boolean = false;
  emailTest       : boolean = false;
  firstNameErr    : boolean = false;
  lastNameErr     : boolean = false;
  mobileNumErr    : boolean = false;
  emailIdErr      : boolean = false;
  submitted       : boolean = false;
  lazyLoad        : boolean = false;
  dojErrr         : boolean = false;
  dropdownLoader  : boolean = false;
  cancelConfirm   : boolean = false;
  disableSubmit   : boolean = false;
  middleNameErr   : boolean = false;
  genderErr       : boolean = false;
  popupVal        : any
  maxDate         : any
  maxdOfJoing     : any
  minDate         : any
  selectedStat    : any = []
  selectedGenderStat  : any = []
  config1             : any;
  lastnameval       : boolean = false;
  middlenameval     : boolean = false;
  dojError          : boolean = false;
  dobError          : boolean = false;
  doJInvalid        : boolean = false;
  constructor( private onboardService   : AddCandidateService,
    private cookieService               : CookieService,
    private timezoneDetailsService      : TimezoneDetailsService,
    private NotificationService         : NotificationService,
    private loader                      : LoaderActionsService,
    private router                      : Router) { 
    this.gendeStatus = [{ id: "Male", value: "Male" }, { id: "Female", value: "Female" }, { id: "Other", value: "Others" }]

  }
  checkValid(event){
    // let clipboardData = event.clipboardData;
    // if(clipboardData){
    //   let pastedText = clipboardData.getData('text');
    //   if(!pastedText.match(/^-?[1-9]*[0-9,\.]+$/) || isNaN(pastedText) || Number(pastedText) <= 0){
        event.preventDefault();
      // }
    // }
  }
  ngOnInit() {
    if (this.cookieService.get("user-data")) {
      this.userData = JSON.parse(this.cookieService.get("user-data"));
      this.minDate  = this.timezoneDetailsService.getCurrentDate()
      this.mindate = this.timezoneDetailsService.toLocal("01/01/1970");
      this.maxdate = this.timezoneDetailsService.getCurrentDate();
      this.maxdOfJoing = this.timezoneDetailsService.toLocal(this.userData.end_date);


    }
    this.onboardService.getList(response => {
      this.dropdownLoader =true;
      if (response.data.length) {
        this.dropdownLoader =false;
        this.candidateDetail = response.data
      }else{
        this.candidateDetail = []
      }
    })
  }
    /**@author:nilena alexandr
   * @desc  : to get detailds of candidate id
   */
  getCandidateId(event) {
    if (event.selected.length > 0) {
      this.candidateId = event.selected[0].id
      this.lazyLoad = true;
      this.onboardService.getDetails(event.selected[0].id, response => {
        if (response.data) {
          this.candidateData = response.data[0]
          this.firstName = this.candidateData.first_name
          this.lastName = this.candidateData.last_name
          this.emailId = this.candidateData.email_id
          if(this.emailId !=null || this.emailId !=undefined || this.emailId !='' ){
            this.emailIdCheck(this.emailId)
          }
          this.mobileNum = this.candidateData.mobile
          this.lazyLoad = false;
        }
        else {
          this.lazyLoad = false;
        }
      })
    }
    else{
      // console.log("true")
      this.firstName = null
      this.lastName = null
      this.emailId = null
      this.mobileNum =null
      this.candidateId=null

    }

  }
   /**@author:nilena alexandr
   * @desc  : to chec firstname
   */
  firstname(firstName) {
    if(firstName && firstName.trim()!= ''){
      if (firstName == undefined && firstName == null && firstName == '' && this.firstNameErr && this.submitted) {
        this.firstNameErr = true;
      }
      else
        if (!this.firstName.replace(/\s/g, '').length)
          this.firstNameErr = true;
        else {
          let beta = /^[a-zA-Z ]+[.]*[a-zA-Z]*$/;
          let v =  (beta.test(firstName))
         if(v==true)
           this.firstNameErr = false;
           else{
            this.firstNameErr = true
          }
    }
  } 
   else{
      this.firstNameErr = true
    }
  }
    /**@author:nilena alexandr
   * @desc  : to chec lastname
   */

  middlename(middleName) {

    if(middleName && middleName.trim()!= ''){
    if (middleName == undefined && middleName == null && middleName == '') {
      this.middleNameErr = true;
    }
    else{
      this.middlenameval = true
      if (!middleName.replace(/\s/g, '').length)
        this.middleNameErr = true;
      else {
        let beta = /^[a-zA-Z ]+[.]*[a-zA-Z]*$/;
        let v =  (beta.test(middleName))
       if(v==true)
         this.middleNameErr = false;
         else{
          this.middleNameErr = true
        }
      }
      
    }  
  }else{
    this.middleNameErr = false
    this.lastnameval = false
  }
}
  /**@author:nilena alexandr
   * @desc  : to chec lastname
   */

  lastname(lastname) {

    if(lastname && lastname.trim()!= ''){
    if (lastname == undefined && lastname == null && lastname == '' ) {
      this.lastNameErr = true;
    }
    else{
      this.lastnameval = true
      if (!lastname.replace(/\s/g, '').length)
        this.lastNameErr = true;
      else {
        let beta = /^[a-zA-Z ]+[.]*[a-zA-Z]*$/;
        let v =  (beta.test(lastname))
       if(v==true)
         this.lastNameErr = false;
         else{
          this.lastNameErr = true
        }
      }
      
    }  
  }else{
    this.lastnameval = false
    this.lastNameErr =false
  }
}
   /**@author:nilena alexandr
   * @desc  : to check mob num erppr
   */
  mobileNumber(mobile) {
    if (mobile == undefined && mobile == null && mobile == '' && this.mobileNumErr && this.submitted) {
      this.mobileNumErr = true
    } else
      this.mobileNumErr = false
  }
  
   /**@author:nilena alexandr
   * @desc  : to check reg expo
   */

  emailIdCheck(id) {
    if (id == undefined && id == null && id == '' && this.emailIdErr && this.submitted) {
      this.emailIdErr = true;
    }else
     { 
      let rEGEXP = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
      let v =  (rEGEXP.test(id))
      if(v == true){
        this.emailIdErr = false;   
        this.emailTest  = true;     
      }else{
        this.emailIdErr = true;
        this.emailTest  = false; 
      }
     }
   }
   /**@author:nilena alexandr
   * @desc  : toseellect gender
   */

  getStatus(event) {
    if (event.selected.length > 0) {
      this.gender = event.selected[0].id
      this.genderErr= false
    }else{
      this.genderErr= true
    }
  }
  scrollTo(el: Element) {
    if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        const input: any = el.querySelector('.form-control');
        const pattern: any = el.querySelector('.pattern');
        // if(pattern){
        //   pattern.focus();
        // }
        if(input){
          input.focus();
        }
        const firstChild = el.firstChild;
        if(input === firstChild){
            input.focus();
        }
    }
}

  
  /**@author:nilena alexandr
   * @desc  : to form submit
   */
  submitForm() {       
     this.loader.display(true)
    this.submitted = true
    this.popupVal   = this.onboardService.getpeopleSettings();
    let stat= true
    if( this.lastnameval ){
      if(this.lastNameErr){
        stat = false
      }else{
        stat= true
      }
    }
    else{
      stat= true
    }
    let mstat= true
    if(this.middlenameval){
      if(this.middleNameErr){
        mstat = false
      }else{
        mstat= true
      }
    }
    else{
      mstat= true
    }
    if(this.gender==null || this.gender==undefined || this.gender =='')
    this.genderErr = true
    else
    this.genderErr= false
    if (this.joiningDate == undefined || this.joiningDate == null || this.joiningDate == '') {
      this.dojErrr = true
    } else
      this.dojErrr = false
    setTimeout(()=>{
      const error = document.querySelector('.error');
   if(error){
    this.loader.display(false)
       this.scrollTo(error);
   }
    return;
  })
    if (!this.firstNameErr &&  stat &&  mstat && this.emailTest &&  !this.genderErr&&  this.mobileNum && !this.dojErrr) {
      this.disableSubmit = true
      if( this.popupVal && this.popupVal.people_settings.onboardPopupHide ==='1'){
        this.noError   = false
        let obj = {
          "cand_id": this.candidateId,
          "fname": this.firstName,
          "mname": this.middleName,
          "lname": this.lastName,
          "dname": this.displayName,
          "gndr": this.gender,
          "dob": this.dateOfBirth,
          "email": this.emailId,
          "doj": this.joiningDate,
          "mob": this.mobileNum,
          "altr_mob": this.altMobNum,
          "popup_status": 1
        }
        this.onboardService.addForm(obj, response => {
          if (response.status == "Success") {
            this.router.navigate(['/modules/onboard/onboard-listing'])
            setTimeout(() => {
              this.NotificationService.alertBoxValue("success", response.message);
            }, 400)
            this.disableSubmit = false
            this.loader.display(false)
          }
          else {
            this.disableSubmit = false
            this.NotificationService.alertBoxValue("error", response.message);
            this.loader.display(false)
          }
        })
      }
      else{
        this.disableSubmit = false
        this.noError   = true
      }
    }
    else { 
      this.noError =false
      this.disableSubmit = false
      if (this.firstNameErr == true || this.firstName == null || this.firstName == '') {
        this.firstNameErr = true
      } else
        this.firstNameErr = false
      // if (this.lastNameErr == true || this.lastName == null || this.lastName == '') {
      //   this.lastNameErr = true
      // } else
      //   this.lastNameErr = false
      if (!this.emailTest) {
        this.emailIdErr = true
      } else
        this.emailIdErr = false
      if (this.mobileNum == undefined || this.mobileNum == null || this.mobileNum == '') {
        this.mobileNumErr = true
      } else
        this.mobileNumErr = false
      if (this.joiningDate == undefined || this.joiningDate == null || this.joiningDate == '') {
        this.dojErrr = true
      } else
        this.dojErrr = false
    }
  }
  cancelPopuph(){
    this.loader.display(false)
  }
  /**@author:nilena alexandr
   * @desc  : for confirmation popup
   */
  getPopupConfirm(event){
    this.noError = false;
    // if(event.checkbox ==true){
    //   this.popStat = 1
    // }
    // else{
    //   this.popStat = 0

    // }

    let obj = {}  
    if(event.status){
       let obj = {
        "cand_id": this.candidateId,
        "fname": this.firstName,
        "mname": this.middleName,
        "lname": this.lastName,
        "dname": this.displayName,
        "gndr": this.gender,
        "dob": this.dateOfBirth,
        "email": this.emailId,
        "doj": this.joiningDate,
        "mob": this.mobileNum,
        "altr_mob": this.altMobNum,
        // "popup_status":this.popStat
      }
      this.onboardService.addForm(obj, response => {
        if (response.status == "Success") {
          this.router.navigate(['/modules/onboard/onboard-listing'])
          setTimeout(() => {
            this.NotificationService.alertBoxValue("success", response.message);
          }, 400)
          this.loader.display(false)
          this.disableSubmit = false
        }
        else {
          this.NotificationService.alertBoxValue("error", response.message);
          this.loader.display(false)
          this.disableSubmit = false
        }
      })
    }else{
      this.disableSubmit = false

    }
  }



  /**@author:nilena alexandr
   * @desc  : to cancel submit
   */
  cancelForm() {
    // this.router.navigate(['/modules/onboard/onboard-listing'])
    this.config1="Changes made will not be saved . Do you want to proceed? "
    this.cancelConfirm=true;
  }
   /**@author:nilena alexandr
   * @desc  : to cancel submithange doj
   * */
  dateChange(event) {
    if (event.date != undefined || event.date != null || event.date != '') {
      this.dojErrr = false
    let pattern  = /^([0]?[1-9]|[1|2][0-9]|[3][0|1])[./-]([0]?[1-9]|[1][0-2])[./-]([0-9]{4}|[0-9]{2})$/
    let today = new Date () 
    today.setHours(0,0,0,0);
    let otherDay = event.date
    let v= otherDay.split('-')
    let stat = false
    if(v.length==3){
      if(v[3]!=''){
        otherDay = new Date(v[2],(v[1]-1),v[0])
        let year = v[2]
				if(year.length==4){
          stat = true
        }
        else
        stat = false
      }
    }
    if(pattern.test(event.date)){
      this.doJInvalid = false
      if(stat)
      if(otherDay >= today){
        this.joiningDate = this.formatForApi(otherDay)
        this.dojError = false;
        this.doJInvalid = false
        this.dojErrr = false;
      }
      else{
        this.dojError = true;
        this.dojErrr = false;
        this.doJInvalid = false
        this.joiningDate = null

      }
    }
      else{
        this.doJInvalid = true
        this.joiningDate = null
        this.dojError = false
        this.dojErrr = false
      }
    }else{
      this.joiningDate = null
      this.dojError = false;
       this.dojErrr = true;
       this.doJInvalid = true
  }
    // if (joiningDate == undefined || joiningDate == null || joiningDate == '') {
    //   this.dojErrr = true;
    // } else
    //   this.dojErrr = false;
  }
  
  /*
	*  @desc   : make date to the format 'dd-mm-yyyy'
	*  @author : nilena
	*/
  formatForApi(inputDate) {
    var date = this.timezoneDetailsService.toLocal(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
      }
      else
        return undefined;
    }

   /**@author:nilena alexandr
   * @desc  : to find age
   */

  dateBirth(event) {
      let pattern  = /^([0]?[1-9]|[1|2][0-9]|[3][0|1])[./-]([0]?[1-9]|[1][0-2])[./-]([0-9]{4}|[0-9]{2})$/
      let today = new Date () 
      today.setHours(0,0,0,0);
      let otherDay = event.date
      let v= otherDay.split('-')
      let stat = false
      if(v.length==3){
        if(v[3]!=''){
          otherDay = new Date(v[2],(v[1]-1),v[0])
          let year = v[2]
          if(year.length==4){
            stat = true
          }
          else
          stat = false
        
        }
      }
      if(pattern.test(event.date)){
        if(stat)
        if(otherDay <= today){
          this.dateOfBirth = this.formatForApi(otherDay)
          if (event.date != undefined || event.date != null || event.date != '') {
            this.age = moment().diff(otherDay, 'years');
          this.dobError = false;
        }
        else{
          this.dateOfBirth = null
          this.dobError = true
          this.age= null;
        }
      }else{
        this.dateOfBirth = null
        this.dobError = true;
        this.age= null;
      }    
    }
  }

  cancelPopup(event){
    if (event == true) {
      this.router.navigate(['modules/onboard/onboard-listing'])
    }
    else{
      this.cancelConfirm = false;
    }
  }

}
