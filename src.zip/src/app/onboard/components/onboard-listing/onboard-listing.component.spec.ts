import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnboardListingComponent } from './onboard-listing.component';

describe('OnboardListingComponent', () => {
  let component: OnboardListingComponent;
  let fixture: ComponentFixture<OnboardListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnboardListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnboardListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
