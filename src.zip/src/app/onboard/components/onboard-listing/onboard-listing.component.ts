import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service';
import { Router } from '@angular/router';
import { OnboardListingService } from '../../services/onboard-listing/onboard-listing.service';

@Component({
  selector: 'app-onboard-listing',
  templateUrl: './onboard-listing.component.html',
  styleUrls: ['../../../../assets/content/css/onbording.css']
})
export class OnboardListingComponent implements OnInit {
  searchD                          : any 
  userData                         : any 
  verifiedDate                     : any 
  submittedDate                    : any 
  dateValue                        : any 
  statId                           : any
  statusChecked                    : any = []
  dataList                         : any = []
  queryObject                      : any = {}
  filterStatus                     : any = {}
  filterSort                       : any = {}
  searchKeyword                    : any = ""
  totalRecords                     : number;
  filterStatVal                    : number;
  cancelId                         : number;
  currentPage                      : number = 1;
  recordsPerPage                   : number = 1;
  searchTextInputBox               : boolean;
  showAdvancedFilter               : boolean;
  filter                           : boolean = false;
  searchTextBox                    : boolean = false;
  filterActive                     : boolean = false;
  confirmBox                       : boolean = false
  noError                          : boolean = false
  cancelBox                        : boolean = false
  remainderActive                  : boolean = false
  toggleChange                     : boolean = false

  popupVal                         : any
  remainderId : any
  config                           : any = "Are You Sure You Want To Cancel?";
  config1                          : any ;
  @ViewChild('foc') inputEl        : ElementRef;
  @ViewChild('myDiv') myDiv        : ElementRef;
  constructor(private onboardService   : OnboardListingService,
    private cookieService               : CookieService,
    private timezoneDetailsService      : TimezoneDetailsService,
    private NotificationService         : NotificationService,
    private loader                      : LoaderActionsService,
    private router                      : Router) { }

  ngOnInit() {
    this.filterStatus =[ {"id":1,"value":"open"},{"id":2,"value":"closed"},{"id":3,"value":"cancelled"},{"id":4,"value":"Inprogress"}]
    if (localStorage.getItem("itemsperpage"))
      this.recordsPerPage = Number(localStorage.getItem("itemsperpage"));
    else
      this.recordsPerPage = 10;
    if (this.cookieService.get("user-data"))
      this.userData = JSON.parse(this.cookieService.get("user-data"));
    this.queryObject.page = this.currentPage;
    this.queryObject.page_limit = this.recordsPerPage;
    this.getOnboardList();
  }

  getOnboardList() {
    this.loader.display(true)
    this.onboardService.getList(this.queryObject, response => {
      this.loader.display(false)
      if(response.status=="OK"){
        this.totalRecords =response.count
        if (response.data) {
          this.dataList = response.data         
          for(let i = 0;i<this.dataList.length;i++){
            if(this.dataList[i].verifyStatus == 3|| this.dataList[i].verifyStatus == 2 || this.dataList[i].stat==2||  this.dataList[i].stat==3 ){
              this.dataList[i].toggleChange = true
            }
            else
            this.dataList[i].toggleChange = false

            if( this.dataList[i].creaton != null){
              this.dataList[i].creaton = this.timezoneDetailsService.getLocalDate(this.dataList[i].creaton)
              this.dataList[i].creaton = this.formatForApi(this.dataList[i].creaton)
            }
            if( this.dataList[i].veron != null){
              this.dataList[i].veron = this.timezoneDetailsService.getLocalDate(this.dataList[i].veron)
              this.dataList[i].veron = this.formatForApi(this.dataList[i].veron)
            }
            if( this.dataList[i].subon != null){
              this.dataList[i].subon = this.timezoneDetailsService.getLocalDate(this.dataList[i].subon)
              this.dataList[i].subon = this.formatForApi(this.dataList[i].subon)
            }
          }  
        }else{
          this.dataList = []   
        }
      }
   
    })
  }
    /*
   author : Arun Johnson
   desc   : sort
   params : based on value asc or desc will be performed.
  */
 sortFunction(label) {
  let currentSortStatus = this.filterSort[label]?this.filterSort[label].rev: true;
  this.filterSort = {};
  this.filterSort[label] = {rev:!currentSortStatus}
  this.filterSort["label"] = label;
  this.queryObject.sort = `${this.filterSort[label].rev? '-': ''}${label}`;
  this.getOnboardList();
}

  /*
 author : Nilena Alexander
 desc   : add class based on index
*/
  getClassByValue(index) {
    return this.onboardService.getClassByValue(index);

  }

  /**
  * @ desc   : TO implement pagination
  * @ author  : Nilena Alexander
  */
  pageChangeEvent(page) {
    this.queryObject.page = page;
    this.currentPage = page;
    this.getOnboardList();
  }
  /*
   * @ desc   : TO implement pagination
   * @ author  : Nilena Alexander
   */
  getpage(eve) {
    if (eve > 10 || this.recordsPerPage != 10) {
      this.recordsPerPage = eve;
      this.queryObject['page_limit'] = eve;
      this.queryObject['page'] = 1;
      this.currentPage = 1;
      this.getOnboardList();
    }
  }
  /*
    * @ desc   : To implement search
    * @ author  : Nilena Alexander
    */
  inputfocus() {
    setTimeout(() => { this.inputEl.nativeElement.focus(); }, 100)
  }
  /*
   * @desc :method for search
   * @auth : Ashiq
   */
  searchList(keyword) {
    if (this.searchKeyword || this.searchD.trim() != '') {
      this.searchKeyword = keyword;
      this.queryObject.keyword = this.searchKeyword ? this.searchKeyword : '';
      this.queryObject.page = 1;
      this.currentPage = 1;
      this.getOnboardList();
    }
  }

  dateChangeVerify(event){
    this.verifiedDate = event

  }
dateChangesubmited(event){
  this.submittedDate = event
}
dateChange(event){
  this.dateValue  = event
}

filterEvent(event){
  if (event.selectedIndex.length != 0) {
    this.statusChecked = event.selectedIndex;
  }
  else {
    this.statusChecked = [];
  }
  this.statId = event;
}

  /*
  author : Nilena Alexander
  desc   : filter apply function

  */
 filterApply() { //this.filterSelect is a copy of selected value
  let range1 = this.submittedDate == undefined ? null : this.submittedDate ;
  let range2 = this.verifiedDate == undefined ? null : this.verifiedDate ;
  let range3 = this.dateValue == undefined ? null : this.dateValue ;


  let status = this.statId && this.statId.selected && this.statId.selected[0] && this.statId.selected[0].value ? this.statId.selected[0].value : 0;
  let loader = this.onboardService.checkFilterStatus(range1,range2, range3, status);
  if (loader) {
    this.filterActive = true;
    if (this.statId.selected.length) {
      if (this.statId.selected[0].value == "open") {
        this.queryObject.stat = "1";
      } else if (this.statId.selected[0].value == "closed") {
        this.queryObject.stat = "2";
       }
      else if (this.statId.selected[0].value == "cancelled") {
        this.queryObject.stat = "3";
      }
      else if (this.statId.selected[0].value == "Inprogress") {
        this.queryObject.stat = "4";
      }
    }
    else {
      this.queryObject.stat = null;
    }
    if (this.submittedDate) {
       this.queryObject.subon = this.formatForApi(this.submittedDate);
    }else {
      this.queryObject.subon  = null;
    }
    if(this.verifiedDate){
      this.queryObject.veron   = this.formatForApi(this.verifiedDate);
    }else
    this.queryObject.veron   = null;
    if(this.dateValue){
      this.queryObject.creaton   = this.formatForApi(this.dateValue);
    }else
    this.queryObject.creaton   = null;

    if (this.statId.selected.length == 0 && this.dateValue ==null &&this.submittedDate ==null&&this.verifiedDate ==null ) {
      this.filterActive = false;
      this.queryObject.stat = null;
      this.queryObject.subon  =null;
      this.queryObject.veron  =null;
      this.queryObject.creaton    = null;
      this.currentPage = 1;
      this.queryObject.page =   this.currentPage ;

    }
    this.currentPage = 1;
    this.queryObject.page =   this.currentPage ;
    this.getOnboardList();

  }
  else {
    this.filterActive           = false;
    this.queryObject.stat       = null;
    this.queryObject.creaton    = null;
    this.queryObject.veron      = null;
    this.queryObject.subon      = null
    this.currentPage = 1;
    this.queryObject.page =   this.currentPage ;
    this.filterStatVal= 0;


  }
}
/*
author : Nilena Alexander
desc   : filter cancel function

*/

filterCancel() {
  if (this.onboardService.checkFilterCanCancel()) {
    this.queryObject.stat    = null
    this.queryObject.veron   = null;
    this.queryObject.creaton = null;
    this.queryObject.subon   = null;
    this.queryObject.page = 1;
    this.currentPage = 1
    this.filterStatVal= 0;
    this.getOnboardList();
  }
  this.filterActive = false;
  this.onboardService.clearFilterStatus();
  this.dateValue     = null;
  this.submittedDate = null;
  this.verifiedDate  = null;
  this.statusChecked = null;
}

	/*
	*  @desc   : make date to the format 'dd-mm-yyyy'
	*  @author : nilena
	*/
  formatForApi(inputDate) {
    var date = this.timezoneDetailsService.toLocal(inputDate);
    if (date)
      if (!isNaN(date.getTime())) {
        if ((Number(date.getMonth()) + 1) < 10) {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-0" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
        else {
          if (Number(date.getDate() < 10)) {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + "0" + date.getDate();
          }
          else {
            return date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();
          }
        }
      }
      else
        return undefined;
  }
  /*
	*  @desc   : make date to the format 'dd-mm-yyyy'
	*  @author : nilena
	*/
  reminderCall(id :string,email:string){
    this.loader.display(true)
    this.remainderId =id
    this.remainderActive = true 
    this.config1 = "Are You Sure You Want To Send Reminder Mail To "+ email;
  }

  getReamindeRPopUp(event){
    if (event == true) {
      this.onboardService.informReminderCall( this.remainderId,response =>{
        if(response.status =="Success"){
          setTimeout(() => {
            this.NotificationService.alertBoxValue("success", response.message);
            this.remainderActive = false
          }, 500)
          this.loader.display(false)
        }  
      else {
        this.NotificationService.alertBoxValue("error", response.message);
        this.loader.display(false)
      }
      })
    }else{
      this.loader.display(false)
    }

  }
  /*
	*  @desc   : route to verify
	*  @author : nilena
  */
  
  verifyCall(id:string){
    // if(this.dataList.verifyStatus == 3|| this.dataList.verifyStatus == 2 || this.dataList.stat==2||  this.dataList.stat==3 ){

    // }
    // data.verifyStatus==3 || data.verifyStatus==2 ||data.stat==2||data.stat==3}
    this.router.navigate(['/modules/onboard/candidate-verification/'+id])
  }

  getPopupConfirm(event) {
    this.confirmBox = false;
    if (event == true) {
      let obj = {
        "stat":3
       }
      this.loader.display(true);
      this.onboardService.cancelStatus(this.cancelId,response =>{
        if(response.status =="Success"){
          setTimeout(() => {
            this.NotificationService.alertBoxValue("success", response.message);
          }, 500)
          this.currentPage =1
          this.getOnboardList()
          this.loader.display(false)
        }else{
          this.NotificationService.alertBoxValue("error", response.message);
        this.loader.display(false)
        }
      })
    }
  }
  /*
	*  @desc   : to cancel
	*  @author : nilena
	*/
  cancelStatus(id:number){  
    this.cancelId = id
    this.confirmBox = true;
  }
   /*
	*  @desc   : to cancel
	*  @author : nilena
	*/
  convertToEmployee(id:number, stat :number){
    if(stat==0){
       this.router.navigate(['/modules/employee/toemployee/'+id])
    }else{
       this.NotificationService.alertBoxValue("info", "This candidate is already an employee now. Please check Employee Profile.");
    }
  }
  
}
