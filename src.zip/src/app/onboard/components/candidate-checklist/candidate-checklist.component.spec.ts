import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateChecklistComponent } from './candidate-checklist.component';

describe('CandidateChecklistComponent', () => {
  let component: CandidateChecklistComponent;
  let fixture: ComponentFixture<CandidateChecklistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandidateChecklistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidateChecklistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
