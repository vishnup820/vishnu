import { Component, OnInit } from '@angular/core';
import { RouterModule,Routes,Router} from '@angular/router';
import { ActivatedRoute} from '@angular/router';
import { NotificationService } from '../../../shared/services/notifications/notification.service';
import { LoaderActionsService } from '../../../shared/services/loader/loader-actions.service'
import { CookieService } from 'ngx-cookie-service';
import { TimezoneDetailsService } from '../../../shared/services/timezone-details/timezone-details.service';
import { CandidateChecklistsService } from '../../services/candidate-checklist/candidate-checklists.service';
@Component({
  selector: 'app-candidate-checklist',
  templateUrl: './candidate-checklist.component.html',
  styleUrls: ['../../../../assets/content/css/onbording.css']
})
export class CandidateChecklistComponent implements OnInit {
 
    candidateData	: any = [];
    nodata : boolean  = false;
    cand_id : number;
    sub :any;
    filterSort	: any = {};
    queryObject	: any = {};
    candidate_name  : any;
    candidateres    : any;
 
  constructor(private route                 		: ActivatedRoute,
		private notificationService   		: NotificationService,
		private _router               		: Router,
		private loader                		: LoaderActionsService,
		private cookieService         		: CookieService,
		private timeZone              		: TimezoneDetailsService,
		private candidateChecklistsService 	: CandidateChecklistsService) { }

  ngOnInit() {
  	this.sub = this.route.params.subscribe(params => {
      this.cand_id = params.id
      this.getCandidatecheckList();

  	})
  }

  getCandidatecheckList(){
    this.loader.display(true);
  	this.candidateChecklistsService.getcandidateCheckList(this.cand_id,this.queryObject,res=>{
      if(res.status == "OK"){
        this.candidateres = res;
        this.candidate_name = res.candidate_name; 
  			this.candidateData  = res.data;
  			this.nodata = false;
        setTimeout( ()=>{
  			  this.loader.display(false);
        },1800)
  		}else{
  			this.candidateData = [];
  			this.nodata = true;	
  			this.loader.display(false);
  		}
  	})
}
sortItem(label){
	let currentSortStatus = this.filterSort[label] ? this.filterSort[label].rev : true;
    this.filterSort = {};
    this.filterSort[label] = { rev: !currentSortStatus }
    this.filterSort["label"] = label;
    this.queryObject.sort = `${this.filterSort[label].rev ? '-' : ''}${label}`
    this.getCandidatecheckList();
}
close(){  
  this.loader.display(true);
  this.candidateChecklistsService.closeAllcheckliststatus(this.cand_id,res=>{
    if(res.status = "OK"){
      setTimeout( ()=>{
        this.notificationService.alertBoxValue("success", res.message);
      },300)
        
	    this._router.navigate(['/modules/onboard/onboard-listing'])	
    }else{
      this.loader.display(false);
       this.notificationService.alertBoxValue("warning", res.message);
    }
  })
}
candidateChecklistEdit(){
		this._router.navigate(['/modules/onboard/edit-checklist/'+this.cand_id])	
}
  /*
  *  @desc   :method to add random classes bsed on index
  *  @author :vinod
  */
 getClassByValue(index) {
  switch (index % 10) {
    case 0: return "default-avatar islamic-green";
    case 1: return "default-avatar limerick";
    case 2: return "default-avatar chilean-fire";
    case 3: return "default-avatar persian-pink";
    case 4: return "default-avatar deep-magenta";
    case 5: return "default-avatar gigas";
    case 6: return "default-avatar endeavour";
    case 7: return "default-avatar dodger-blue";
    case 8: return "default-avatar jordy-blue";
    case 9: return "default-avatar Light-sea-green";
    case 10: return "emp-profileimage";
    }
  }

  backtoList(){
    this._router.navigate(['/modules/onboard/onboard-listing'])  
  }
}

