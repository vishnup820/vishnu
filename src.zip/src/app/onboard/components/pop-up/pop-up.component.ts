import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-pop-up',
  templateUrl: './pop-up.component.html',
  styleUrls: ['../../../../assets/content/css/toast-and-confirmation.css']
})
export class PopUpComponent implements OnInit {
  reason       : any = "";
  noError      : boolean;
  formerror    : boolean = false;
  checkBoxValue   : boolean = false;

  @Output() status: EventEmitter<any> = new EventEmitter();
  @Output() noStatus: EventEmitter<any> = new EventEmitter();
  @Output() checkBoxVal: EventEmitter<any> = new EventEmitter();
  @Input() emailName       : any;

  constructor(private cookieService:CookieService) { }

  ngOnInit() {
    this.noError  =  true;
  }
  
  	/*
  	*  @desc   :close button to close the popup window
  	*  @author :dipin
 	 */
 	closePopup(){
		this.noError = false;
		let reason         = this.reason;
		this.noStatus.emit(false);
  	}
  /*
    author : Nilena Alexander
    desc   : for single select
    */

   checkBoxClick(num) {
    this.checkBoxValue = !this.checkBoxValue
  }

  /*
  	*  @desc   :user confirmation of popupbox confirmation and emit value
  	*  @author :dipin
  	*/
  confirmation(value: string, checkBox: boolean) {
    if (value == 'no') {
      let reason = this.reason;
      this.noError = false;
      this.noStatus.emit(false);
      this.checkBoxValue = false
    }
    else {
      let reason = this.reason;
      this.noError = false;
      if(checkBox== true){
        this.cookieService.set('people_settings',  JSON.stringify({
          "people_settings"  : {
            onboardPopupHide: "1"
          }
        }));
      }
      if (this.reason && this.reason.trim() != "") {
        this.status.emit({ "status": true, "value": reason ,"checkbox": checkBox});
      } else {
        this.status.emit({ "status": true, "value": "","checkbox": checkBox });
      }
    }
  };

}
