import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './auth/component/login/login.component';
import { ModulesComponent } from './modules/modules.component';
import { AuthGuardService } from './shared/services/auth-guard/auth-guard.service';

import { NotFoundComponent } from './shared/component/not-found/not-found.component';


const routes: Routes = [
	{
		path: 'login',
		component: LoginComponent,
	},
	{
		path: 'modules',
		component: ModulesComponent,
		children: [

			{
				path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'leave', loadChildren: './leave-management/leave-management.module#LeaveManagementModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'employee', loadChildren: './peoples/peoples.module#PeoplesModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'organization', loadChildren: './settings/settings.module#SettingsModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'attendance', loadChildren: './attendance/attendance.module#AttendanceModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'report', loadChildren: './report/report.module#ReportModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'case', loadChildren: './case-operations/case-operations.module#CaseOperationsModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'training', loadChildren: './training/training.module#TrainingModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'useraccounts', loadChildren: './user-accounts/user-accounts.module#UserAccountsModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'shift', loadChildren: './shift-management/shift-management.module#ShiftManagementModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'biometric', loadChildren: './biometric/biometric.module#BiometricModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'onduty', loadChildren: './onduty/onduty.module#OndutyModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'travel', loadChildren: './travel/travel.module#TravelModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'recruitment', loadChildren: './recruitment-management/recruitment-management.module#RecruitmentManagementModule',
				//    canActivate : [AuthGuardService]
			},
			{
				path: 'timesheet', loadChildren: './timesheet/timesheet.module#TimesheetModule',
				//    canActivate : [AuthGuardService]
			},
			{
				path: 'customer', loadChildren: './customers/projects.module#ProjectsModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'projects', loadChildren: './project/project.module#ProjectModule',
				canActivate: [AuthGuardService]
			},
			{
				path: 'onboard', loadChildren: './onboard/onboard.module#OnboardModule',
				//    canActivate : [AuthGuardService]
			},
			{
				path: 'help', loadChildren: './hris-help/hris-help.module#HrisHelpModule',
				canActivate: [AuthGuardService]
			},
			{
				path: '', redirectTo: 'dashboard', pathMatch: 'full',
				canActivate: [AuthGuardService]
			}
		]
	},
	{
		path: 'not-found', component: NotFoundComponent
	},
	{
		path: '', redirectTo: 'modules', pathMatch: 'full'
	},
	{ path: '**', component: NotFoundComponent }
];

@NgModule({
	imports: [RouterModule.forRoot(routes, { useHash: true, scrollPositionRestoration: 'enabled' })],
	exports: [RouterModule]
})
export class AppRoutingModule { }
